(function () {
  const F = document.createElement("link").relList;
  if (F && F.supports && F.supports("modulepreload")) return;
  for (const g of document.querySelectorAll('link[rel="modulepreload"]')) k(g);
  new MutationObserver((g) => {
    for (const M of g)
      if (M.type === "childList")
        for (const P of M.addedNodes)
          P.tagName === "LINK" && P.rel === "modulepreload" && k(P);
  }).observe(document, { childList: !0, subtree: !0 });
  function u(g) {
    const M = {};
    return (
      g.integrity && (M.integrity = g.integrity),
      g.referrerPolicy && (M.referrerPolicy = g.referrerPolicy),
      g.crossOrigin === "use-credentials"
        ? (M.credentials = "include")
        : g.crossOrigin === "anonymous"
          ? (M.credentials = "omit")
          : (M.credentials = "same-origin"),
      M
    );
  }
  function k(g) {
    if (g.ep) return;
    g.ep = !0;
    const M = u(g);
    fetch(g.href, M);
  }
})();
var wr = { exports: {} },
  m2 = {},
  kr = { exports: {} },
  O = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Bn;
function Wa() {
  if (Bn) return O;
  Bn = 1;
  var L = Symbol.for("react.element"),
    F = Symbol.for("react.portal"),
    u = Symbol.for("react.fragment"),
    k = Symbol.for("react.strict_mode"),
    g = Symbol.for("react.profiler"),
    M = Symbol.for("react.provider"),
    P = Symbol.for("react.context"),
    D = Symbol.for("react.forward_ref"),
    N = Symbol.for("react.suspense"),
    A = Symbol.for("react.memo"),
    z = Symbol.for("react.lazy"),
    H = Symbol.iterator;
  function Q(f) {
    return f === null || typeof f != "object"
      ? null
      : ((f = (H && f[H]) || f["@@iterator"]),
        typeof f == "function" ? f : null);
  }
  var ue = {
      isMounted: function () {
        return !1;
      },
      enqueueForceUpdate: function () {},
      enqueueReplaceState: function () {},
      enqueueSetState: function () {},
    },
    Ue = Object.assign,
    se = {};
  function te(f, V, W) {
    ((this.props = f),
      (this.context = V),
      (this.refs = se),
      (this.updater = W || ue));
  }
  ((te.prototype.isReactComponent = {}),
    (te.prototype.setState = function (f, V) {
      if (typeof f != "object" && typeof f != "function" && f != null)
        throw Error(
          "setState(...): takes an object of state variables to update or a function which returns an object of state variables.",
        );
      this.updater.enqueueSetState(this, f, V, "setState");
    }),
    (te.prototype.forceUpdate = function (f) {
      this.updater.enqueueForceUpdate(this, f, "forceUpdate");
    }));
  function m1() {}
  m1.prototype = te.prototype;
  function c1(f, V, W) {
    ((this.props = f),
      (this.context = V),
      (this.refs = se),
      (this.updater = W || ue));
  }
  var e1 = (c1.prototype = new m1());
  ((e1.constructor = c1), Ue(e1, te.prototype), (e1.isPureReactComponent = !0));
  var Fe = Array.isArray,
    t1 = Object.prototype.hasOwnProperty,
    Ne = { current: null },
    Be = { key: !0, ref: !0, __self: !0, __source: !0 };
  function Qe(f, V, W) {
    var U,
      Y = {},
      K = null,
      le = null;
    if (V != null)
      for (U in (V.ref !== void 0 && (le = V.ref),
      V.key !== void 0 && (K = "" + V.key),
      V))
        t1.call(V, U) && !Be.hasOwnProperty(U) && (Y[U] = V[U]);
    var q = arguments.length - 2;
    if (q === 1) Y.children = W;
    else if (1 < q) {
      for (var ae = Array(q), ze = 0; ze < q; ze++) ae[ze] = arguments[ze + 2];
      Y.children = ae;
    }
    if (f && f.defaultProps)
      for (U in ((q = f.defaultProps), q)) Y[U] === void 0 && (Y[U] = q[U]);
    return {
      $$typeof: L,
      type: f,
      key: K,
      ref: le,
      props: Y,
      _owner: Ne.current,
    };
  }
  function Z1(f, V) {
    return {
      $$typeof: L,
      type: f.type,
      key: V,
      ref: f.ref,
      props: f.props,
      _owner: f._owner,
    };
  }
  function g1(f) {
    return typeof f == "object" && f !== null && f.$$typeof === L;
  }
  function Y1(f) {
    var V = { "=": "=0", ":": "=2" };
    return (
      "$" +
      f.replace(/[=:]/g, function (W) {
        return V[W];
      })
    );
  }
  var p1 = /\/+/g;
  function Te(f, V) {
    return typeof f == "object" && f !== null && f.key != null
      ? Y1("" + f.key)
      : V.toString(36);
  }
  function l1(f, V, W, U, Y) {
    var K = typeof f;
    (K === "undefined" || K === "boolean") && (f = null);
    var le = !1;
    if (f === null) le = !0;
    else
      switch (K) {
        case "string":
        case "number":
          le = !0;
          break;
        case "object":
          switch (f.$$typeof) {
            case L:
            case F:
              le = !0;
          }
      }
    if (le)
      return (
        (le = f),
        (Y = Y(le)),
        (f = U === "" ? "." + Te(le, 0) : U),
        Fe(Y)
          ? ((W = ""),
            f != null && (W = f.replace(p1, "$&/") + "/"),
            l1(Y, V, W, "", function (ze) {
              return ze;
            }))
          : Y != null &&
            (g1(Y) &&
              (Y = Z1(
                Y,
                W +
                  (!Y.key || (le && le.key === Y.key)
                    ? ""
                    : ("" + Y.key).replace(p1, "$&/") + "/") +
                  f,
              )),
            V.push(Y)),
        1
      );
    if (((le = 0), (U = U === "" ? "." : U + ":"), Fe(f)))
      for (var q = 0; q < f.length; q++) {
        K = f[q];
        var ae = U + Te(K, q);
        le += l1(K, V, W, ae, Y);
      }
    else if (((ae = Q(f)), typeof ae == "function"))
      for (f = ae.call(f), q = 0; !(K = f.next()).done; )
        ((K = K.value), (ae = U + Te(K, q++)), (le += l1(K, V, W, ae, Y)));
    else if (K === "object")
      throw (
        (V = String(f)),
        Error(
          "Objects are not valid as a React child (found: " +
            (V === "[object Object]"
              ? "object with keys {" + Object.keys(f).join(", ") + "}"
              : V) +
            "). If you meant to render a collection of children, use an array instead.",
        )
      );
    return le;
  }
  function f1(f, V, W) {
    if (f == null) return f;
    var U = [],
      Y = 0;
    return (
      l1(f, U, "", "", function (K) {
        return V.call(W, K, Y++);
      }),
      U
    );
  }
  function Ee(f) {
    if (f._status === -1) {
      var V = f._result;
      ((V = V()),
        V.then(
          function (W) {
            (f._status === 0 || f._status === -1) &&
              ((f._status = 1), (f._result = W));
          },
          function (W) {
            (f._status === 0 || f._status === -1) &&
              ((f._status = 2), (f._result = W));
          },
        ),
        f._status === -1 && ((f._status = 0), (f._result = V)));
    }
    if (f._status === 1) return f._result.default;
    throw f._result;
  }
  var pe = { current: null },
    C = { transition: null },
    I = {
      ReactCurrentDispatcher: pe,
      ReactCurrentBatchConfig: C,
      ReactCurrentOwner: Ne,
    };
  function y() {
    throw Error("act(...) is not supported in production builds of React.");
  }
  return (
    (O.Children = {
      map: f1,
      forEach: function (f, V, W) {
        f1(
          f,
          function () {
            V.apply(this, arguments);
          },
          W,
        );
      },
      count: function (f) {
        var V = 0;
        return (
          f1(f, function () {
            V++;
          }),
          V
        );
      },
      toArray: function (f) {
        return (
          f1(f, function (V) {
            return V;
          }) || []
        );
      },
      only: function (f) {
        if (!g1(f))
          throw Error(
            "React.Children.only expected to receive a single React element child.",
          );
        return f;
      },
    }),
    (O.Component = te),
    (O.Fragment = u),
    (O.Profiler = g),
    (O.PureComponent = c1),
    (O.StrictMode = k),
    (O.Suspense = N),
    (O.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = I),
    (O.act = y),
    (O.cloneElement = function (f, V, W) {
      if (f == null)
        throw Error(
          "React.cloneElement(...): The argument must be a React element, but you passed " +
            f +
            ".",
        );
      var U = Ue({}, f.props),
        Y = f.key,
        K = f.ref,
        le = f._owner;
      if (V != null) {
        if (
          (V.ref !== void 0 && ((K = V.ref), (le = Ne.current)),
          V.key !== void 0 && (Y = "" + V.key),
          f.type && f.type.defaultProps)
        )
          var q = f.type.defaultProps;
        for (ae in V)
          t1.call(V, ae) &&
            !Be.hasOwnProperty(ae) &&
            (U[ae] = V[ae] === void 0 && q !== void 0 ? q[ae] : V[ae]);
      }
      var ae = arguments.length - 2;
      if (ae === 1) U.children = W;
      else if (1 < ae) {
        q = Array(ae);
        for (var ze = 0; ze < ae; ze++) q[ze] = arguments[ze + 2];
        U.children = q;
      }
      return {
        $$typeof: L,
        type: f.type,
        key: Y,
        ref: K,
        props: U,
        _owner: le,
      };
    }),
    (O.createContext = function (f) {
      return (
        (f = {
          $$typeof: P,
          _currentValue: f,
          _currentValue2: f,
          _threadCount: 0,
          Provider: null,
          Consumer: null,
          _defaultValue: null,
          _globalName: null,
        }),
        (f.Provider = { $$typeof: M, _context: f }),
        (f.Consumer = f)
      );
    }),
    (O.createElement = Qe),
    (O.createFactory = function (f) {
      var V = Qe.bind(null, f);
      return ((V.type = f), V);
    }),
    (O.createRef = function () {
      return { current: null };
    }),
    (O.forwardRef = function (f) {
      return { $$typeof: D, render: f };
    }),
    (O.isValidElement = g1),
    (O.lazy = function (f) {
      return { $$typeof: z, _payload: { _status: -1, _result: f }, _init: Ee };
    }),
    (O.memo = function (f, V) {
      return { $$typeof: A, type: f, compare: V === void 0 ? null : V };
    }),
    (O.startTransition = function (f) {
      var V = C.transition;
      C.transition = {};
      try {
        f();
      } finally {
        C.transition = V;
      }
    }),
    (O.unstable_act = y),
    (O.useCallback = function (f, V) {
      return pe.current.useCallback(f, V);
    }),
    (O.useContext = function (f) {
      return pe.current.useContext(f);
    }),
    (O.useDebugValue = function () {}),
    (O.useDeferredValue = function (f) {
      return pe.current.useDeferredValue(f);
    }),
    (O.useEffect = function (f, V) {
      return pe.current.useEffect(f, V);
    }),
    (O.useId = function () {
      return pe.current.useId();
    }),
    (O.useImperativeHandle = function (f, V, W) {
      return pe.current.useImperativeHandle(f, V, W);
    }),
    (O.useInsertionEffect = function (f, V) {
      return pe.current.useInsertionEffect(f, V);
    }),
    (O.useLayoutEffect = function (f, V) {
      return pe.current.useLayoutEffect(f, V);
    }),
    (O.useMemo = function (f, V) {
      return pe.current.useMemo(f, V);
    }),
    (O.useReducer = function (f, V, W) {
      return pe.current.useReducer(f, V, W);
    }),
    (O.useRef = function (f) {
      return pe.current.useRef(f);
    }),
    (O.useState = function (f) {
      return pe.current.useState(f);
    }),
    (O.useSyncExternalStore = function (f, V, W) {
      return pe.current.useSyncExternalStore(f, V, W);
    }),
    (O.useTransition = function () {
      return pe.current.useTransition();
    }),
    (O.version = "18.3.1"),
    O
  );
}
var En;
function Er() {
  return (En || ((En = 1), (kr.exports = Wa())), kr.exports);
}
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Gn;
function Oa() {
  if (Gn) return m2;
  Gn = 1;
  var L = Er(),
    F = Symbol.for("react.element"),
    u = Symbol.for("react.fragment"),
    k = Object.prototype.hasOwnProperty,
    g = L.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
    M = { key: !0, ref: !0, __self: !0, __source: !0 };
  function P(D, N, A) {
    var z,
      H = {},
      Q = null,
      ue = null;
    (A !== void 0 && (Q = "" + A),
      N.key !== void 0 && (Q = "" + N.key),
      N.ref !== void 0 && (ue = N.ref));
    for (z in N) k.call(N, z) && !M.hasOwnProperty(z) && (H[z] = N[z]);
    if (D && D.defaultProps)
      for (z in ((N = D.defaultProps), N)) H[z] === void 0 && (H[z] = N[z]);
    return {
      $$typeof: F,
      type: D,
      key: Q,
      ref: ue,
      props: H,
      _owner: g.current,
    };
  }
  return ((m2.Fragment = u), (m2.jsx = P), (m2.jsxs = P), m2);
}
var An;
function Ua() {
  return (An || ((An = 1), (wr.exports = Oa())), wr.exports);
}
var e = Ua(),
  y0 = {},
  Nr = { exports: {} },
  Ie = {},
  Zr = { exports: {} },
  yr = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Dn;
function Qa() {
  return (
    Dn ||
      ((Dn = 1),
      (function (L) {
        function F(C, I) {
          var y = C.length;
          C.push(I);
          e: for (; 0 < y; ) {
            var f = (y - 1) >>> 1,
              V = C[f];
            if (0 < g(V, I)) ((C[f] = I), (C[y] = V), (y = f));
            else break e;
          }
        }
        function u(C) {
          return C.length === 0 ? null : C[0];
        }
        function k(C) {
          if (C.length === 0) return null;
          var I = C[0],
            y = C.pop();
          if (y !== I) {
            C[0] = y;
            e: for (var f = 0, V = C.length, W = V >>> 1; f < W; ) {
              var U = 2 * (f + 1) - 1,
                Y = C[U],
                K = U + 1,
                le = C[K];
              if (0 > g(Y, y))
                K < V && 0 > g(le, Y)
                  ? ((C[f] = le), (C[K] = y), (f = K))
                  : ((C[f] = Y), (C[U] = y), (f = U));
              else if (K < V && 0 > g(le, y))
                ((C[f] = le), (C[K] = y), (f = K));
              else break e;
            }
          }
          return I;
        }
        function g(C, I) {
          var y = C.sortIndex - I.sortIndex;
          return y !== 0 ? y : C.id - I.id;
        }
        if (
          typeof performance == "object" &&
          typeof performance.now == "function"
        ) {
          var M = performance;
          L.unstable_now = function () {
            return M.now();
          };
        } else {
          var P = Date,
            D = P.now();
          L.unstable_now = function () {
            return P.now() - D;
          };
        }
        var N = [],
          A = [],
          z = 1,
          H = null,
          Q = 3,
          ue = !1,
          Ue = !1,
          se = !1,
          te = typeof setTimeout == "function" ? setTimeout : null,
          m1 = typeof clearTimeout == "function" ? clearTimeout : null,
          c1 = typeof setImmediate < "u" ? setImmediate : null;
        typeof navigator < "u" &&
          navigator.scheduling !== void 0 &&
          navigator.scheduling.isInputPending !== void 0 &&
          navigator.scheduling.isInputPending.bind(navigator.scheduling);
        function e1(C) {
          for (var I = u(A); I !== null; ) {
            if (I.callback === null) k(A);
            else if (I.startTime <= C)
              (k(A), (I.sortIndex = I.expirationTime), F(N, I));
            else break;
            I = u(A);
          }
        }
        function Fe(C) {
          if (((se = !1), e1(C), !Ue))
            if (u(N) !== null) ((Ue = !0), Ee(t1));
            else {
              var I = u(A);
              I !== null && pe(Fe, I.startTime - C);
            }
        }
        function t1(C, I) {
          ((Ue = !1), se && ((se = !1), m1(Qe), (Qe = -1)), (ue = !0));
          var y = Q;
          try {
            for (
              e1(I), H = u(N);
              H !== null && (!(H.expirationTime > I) || (C && !Y1()));
            ) {
              var f = H.callback;
              if (typeof f == "function") {
                ((H.callback = null), (Q = H.priorityLevel));
                var V = f(H.expirationTime <= I);
                ((I = L.unstable_now()),
                  typeof V == "function"
                    ? (H.callback = V)
                    : H === u(N) && k(N),
                  e1(I));
              } else k(N);
              H = u(N);
            }
            if (H !== null) var W = !0;
            else {
              var U = u(A);
              (U !== null && pe(Fe, U.startTime - I), (W = !1));
            }
            return W;
          } finally {
            ((H = null), (Q = y), (ue = !1));
          }
        }
        var Ne = !1,
          Be = null,
          Qe = -1,
          Z1 = 5,
          g1 = -1;
        function Y1() {
          return !(L.unstable_now() - g1 < Z1);
        }
        function p1() {
          if (Be !== null) {
            var C = L.unstable_now();
            g1 = C;
            var I = !0;
            try {
              I = Be(!0, C);
            } finally {
              I ? Te() : ((Ne = !1), (Be = null));
            }
          } else Ne = !1;
        }
        var Te;
        if (typeof c1 == "function")
          Te = function () {
            c1(p1);
          };
        else if (typeof MessageChannel < "u") {
          var l1 = new MessageChannel(),
            f1 = l1.port2;
          ((l1.port1.onmessage = p1),
            (Te = function () {
              f1.postMessage(null);
            }));
        } else
          Te = function () {
            te(p1, 0);
          };
        function Ee(C) {
          ((Be = C), Ne || ((Ne = !0), Te()));
        }
        function pe(C, I) {
          Qe = te(function () {
            C(L.unstable_now());
          }, I);
        }
        ((L.unstable_IdlePriority = 5),
          (L.unstable_ImmediatePriority = 1),
          (L.unstable_LowPriority = 4),
          (L.unstable_NormalPriority = 3),
          (L.unstable_Profiling = null),
          (L.unstable_UserBlockingPriority = 2),
          (L.unstable_cancelCallback = function (C) {
            C.callback = null;
          }),
          (L.unstable_continueExecution = function () {
            Ue || ue || ((Ue = !0), Ee(t1));
          }),
          (L.unstable_forceFrameRate = function (C) {
            0 > C || 125 < C
              ? console.error(
                  "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported",
                )
              : (Z1 = 0 < C ? Math.floor(1e3 / C) : 5);
          }),
          (L.unstable_getCurrentPriorityLevel = function () {
            return Q;
          }),
          (L.unstable_getFirstCallbackNode = function () {
            return u(N);
          }),
          (L.unstable_next = function (C) {
            switch (Q) {
              case 1:
              case 2:
              case 3:
                var I = 3;
                break;
              default:
                I = Q;
            }
            var y = Q;
            Q = I;
            try {
              return C();
            } finally {
              Q = y;
            }
          }),
          (L.unstable_pauseExecution = function () {}),
          (L.unstable_requestPaint = function () {}),
          (L.unstable_runWithPriority = function (C, I) {
            switch (C) {
              case 1:
              case 2:
              case 3:
              case 4:
              case 5:
                break;
              default:
                C = 3;
            }
            var y = Q;
            Q = C;
            try {
              return I();
            } finally {
              Q = y;
            }
          }),
          (L.unstable_scheduleCallback = function (C, I, y) {
            var f = L.unstable_now();
            switch (
              (typeof y == "object" && y !== null
                ? ((y = y.delay),
                  (y = typeof y == "number" && 0 < y ? f + y : f))
                : (y = f),
              C)
            ) {
              case 1:
                var V = -1;
                break;
              case 2:
                V = 250;
                break;
              case 5:
                V = 1073741823;
                break;
              case 4:
                V = 1e4;
                break;
              default:
                V = 5e3;
            }
            return (
              (V = y + V),
              (C = {
                id: z++,
                callback: I,
                priorityLevel: C,
                startTime: y,
                expirationTime: V,
                sortIndex: -1,
              }),
              y > f
                ? ((C.sortIndex = y),
                  F(A, C),
                  u(N) === null &&
                    C === u(A) &&
                    (se ? (m1(Qe), (Qe = -1)) : (se = !0), pe(Fe, y - f)))
                : ((C.sortIndex = V), F(N, C), Ue || ue || ((Ue = !0), Ee(t1))),
              C
            );
          }),
          (L.unstable_shouldYield = Y1),
          (L.unstable_wrapCallback = function (C) {
            var I = Q;
            return function () {
              var y = Q;
              Q = I;
              try {
                return C.apply(this, arguments);
              } finally {
                Q = y;
              }
            };
          }));
      })(yr)),
    yr
  );
}
var Rn;
function $a() {
  return (Rn || ((Rn = 1), (Zr.exports = Qa())), Zr.exports);
}
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var Sn;
function Xa() {
  if (Sn) return Ie;
  Sn = 1;
  var L = Er(),
    F = $a();
  function u(t) {
    for (
      var l = "https://reactjs.org/docs/error-decoder.html?invariant=" + t,
        r = 1;
      r < arguments.length;
      r++
    )
      l += "&args[]=" + encodeURIComponent(arguments[r]);
    return (
      "Minified React error #" +
      t +
      "; visit " +
      l +
      " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    );
  }
  var k = new Set(),
    g = {};
  function M(t, l) {
    (P(t, l), P(t + "Capture", l));
  }
  function P(t, l) {
    for (g[t] = l, t = 0; t < l.length; t++) k.add(l[t]);
  }
  var D = !(
      typeof window > "u" ||
      typeof window.document > "u" ||
      typeof window.document.createElement > "u"
    ),
    N = Object.prototype.hasOwnProperty,
    A =
      /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
    z = {},
    H = {};
  function Q(t) {
    return N.call(H, t)
      ? !0
      : N.call(z, t)
        ? !1
        : A.test(t)
          ? (H[t] = !0)
          : ((z[t] = !0), !1);
  }
  function ue(t, l, r, n) {
    if (r !== null && r.type === 0) return !1;
    switch (typeof l) {
      case "function":
      case "symbol":
        return !0;
      case "boolean":
        return n
          ? !1
          : r !== null
            ? !r.acceptsBooleans
            : ((t = t.toLowerCase().slice(0, 5)),
              t !== "data-" && t !== "aria-");
      default:
        return !1;
    }
  }
  function Ue(t, l, r, n) {
    if (l === null || typeof l > "u" || ue(t, l, r, n)) return !0;
    if (n) return !1;
    if (r !== null)
      switch (r.type) {
        case 3:
          return !l;
        case 4:
          return l === !1;
        case 5:
          return isNaN(l);
        case 6:
          return isNaN(l) || 1 > l;
      }
    return !1;
  }
  function se(t, l, r, n, s, a, o) {
    ((this.acceptsBooleans = l === 2 || l === 3 || l === 4),
      (this.attributeName = n),
      (this.attributeNamespace = s),
      (this.mustUseProperty = r),
      (this.propertyName = t),
      (this.type = l),
      (this.sanitizeURL = a),
      (this.removeEmptyString = o));
  }
  var te = {};
  ("children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style"
    .split(" ")
    .forEach(function (t) {
      te[t] = new se(t, 0, !1, t, null, !1, !1);
    }),
    [
      ["acceptCharset", "accept-charset"],
      ["className", "class"],
      ["htmlFor", "for"],
      ["httpEquiv", "http-equiv"],
    ].forEach(function (t) {
      var l = t[0];
      te[l] = new se(l, 1, !1, t[1], null, !1, !1);
    }),
    ["contentEditable", "draggable", "spellCheck", "value"].forEach(
      function (t) {
        te[t] = new se(t, 2, !1, t.toLowerCase(), null, !1, !1);
      },
    ),
    [
      "autoReverse",
      "externalResourcesRequired",
      "focusable",
      "preserveAlpha",
    ].forEach(function (t) {
      te[t] = new se(t, 2, !1, t, null, !1, !1);
    }),
    "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope"
      .split(" ")
      .forEach(function (t) {
        te[t] = new se(t, 3, !1, t.toLowerCase(), null, !1, !1);
      }),
    ["checked", "multiple", "muted", "selected"].forEach(function (t) {
      te[t] = new se(t, 3, !0, t, null, !1, !1);
    }),
    ["capture", "download"].forEach(function (t) {
      te[t] = new se(t, 4, !1, t, null, !1, !1);
    }),
    ["cols", "rows", "size", "span"].forEach(function (t) {
      te[t] = new se(t, 6, !1, t, null, !1, !1);
    }),
    ["rowSpan", "start"].forEach(function (t) {
      te[t] = new se(t, 5, !1, t.toLowerCase(), null, !1, !1);
    }));
  var m1 = /[\-:]([a-z])/g;
  function c1(t) {
    return t[1].toUpperCase();
  }
  ("accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height"
    .split(" ")
    .forEach(function (t) {
      var l = t.replace(m1, c1);
      te[l] = new se(l, 1, !1, t, null, !1, !1);
    }),
    "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type"
      .split(" ")
      .forEach(function (t) {
        var l = t.replace(m1, c1);
        te[l] = new se(l, 1, !1, t, "http://www.w3.org/1999/xlink", !1, !1);
      }),
    ["xml:base", "xml:lang", "xml:space"].forEach(function (t) {
      var l = t.replace(m1, c1);
      te[l] = new se(
        l,
        1,
        !1,
        t,
        "http://www.w3.org/XML/1998/namespace",
        !1,
        !1,
      );
    }),
    ["tabIndex", "crossOrigin"].forEach(function (t) {
      te[t] = new se(t, 1, !1, t.toLowerCase(), null, !1, !1);
    }),
    (te.xlinkHref = new se(
      "xlinkHref",
      1,
      !1,
      "xlink:href",
      "http://www.w3.org/1999/xlink",
      !0,
      !1,
    )),
    ["src", "href", "action", "formAction"].forEach(function (t) {
      te[t] = new se(t, 1, !1, t.toLowerCase(), null, !0, !0);
    }));
  function e1(t, l, r, n) {
    var s = te.hasOwnProperty(l) ? te[l] : null;
    (s !== null
      ? s.type !== 0
      : n ||
        !(2 < l.length) ||
        (l[0] !== "o" && l[0] !== "O") ||
        (l[1] !== "n" && l[1] !== "N")) &&
      (Ue(l, r, s, n) && (r = null),
      n || s === null
        ? Q(l) &&
          (r === null ? t.removeAttribute(l) : t.setAttribute(l, "" + r))
        : s.mustUseProperty
          ? (t[s.propertyName] = r === null ? (s.type === 3 ? !1 : "") : r)
          : ((l = s.attributeName),
            (n = s.attributeNamespace),
            r === null
              ? t.removeAttribute(l)
              : ((s = s.type),
                (r = s === 3 || (s === 4 && r === !0) ? "" : "" + r),
                n ? t.setAttributeNS(n, l, r) : t.setAttribute(l, r))));
  }
  var Fe = L.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
    t1 = Symbol.for("react.element"),
    Ne = Symbol.for("react.portal"),
    Be = Symbol.for("react.fragment"),
    Qe = Symbol.for("react.strict_mode"),
    Z1 = Symbol.for("react.profiler"),
    g1 = Symbol.for("react.provider"),
    Y1 = Symbol.for("react.context"),
    p1 = Symbol.for("react.forward_ref"),
    Te = Symbol.for("react.suspense"),
    l1 = Symbol.for("react.suspense_list"),
    f1 = Symbol.for("react.memo"),
    Ee = Symbol.for("react.lazy"),
    pe = Symbol.for("react.offscreen"),
    C = Symbol.iterator;
  function I(t) {
    return t === null || typeof t != "object"
      ? null
      : ((t = (C && t[C]) || t["@@iterator"]),
        typeof t == "function" ? t : null);
  }
  var y = Object.assign,
    f;
  function V(t) {
    if (f === void 0)
      try {
        throw Error();
      } catch (r) {
        var l = r.stack.trim().match(/\n( *(at )?)/);
        f = (l && l[1]) || "";
      }
    return (
      `
` +
      f +
      t
    );
  }
  var W = !1;
  function U(t, l) {
    if (!t || W) return "";
    W = !0;
    var r = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      if (l)
        if (
          ((l = function () {
            throw Error();
          }),
          Object.defineProperty(l.prototype, "props", {
            set: function () {
              throw Error();
            },
          }),
          typeof Reflect == "object" && Reflect.construct)
        ) {
          try {
            Reflect.construct(l, []);
          } catch (v) {
            var n = v;
          }
          Reflect.construct(t, [], l);
        } else {
          try {
            l.call();
          } catch (v) {
            n = v;
          }
          t.call(l.prototype);
        }
      else {
        try {
          throw Error();
        } catch (v) {
          n = v;
        }
        t();
      }
    } catch (v) {
      if (v && n && typeof v.stack == "string") {
        for (
          var s = v.stack.split(`
`),
            a = n.stack.split(`
`),
            o = s.length - 1,
            d = a.length - 1;
          1 <= o && 0 <= d && s[o] !== a[d];
        )
          d--;
        for (; 1 <= o && 0 <= d; o--, d--)
          if (s[o] !== a[d]) {
            if (o !== 1 || d !== 1)
              do
                if ((o--, d--, 0 > d || s[o] !== a[d])) {
                  var c =
                    `
` + s[o].replace(" at new ", " at ");
                  return (
                    t.displayName &&
                      c.includes("<anonymous>") &&
                      (c = c.replace("<anonymous>", t.displayName)),
                    c
                  );
                }
              while (1 <= o && 0 <= d);
            break;
          }
      }
    } finally {
      ((W = !1), (Error.prepareStackTrace = r));
    }
    return (t = t ? t.displayName || t.name : "") ? V(t) : "";
  }
  function Y(t) {
    switch (t.tag) {
      case 5:
        return V(t.type);
      case 16:
        return V("Lazy");
      case 13:
        return V("Suspense");
      case 19:
        return V("SuspenseList");
      case 0:
      case 2:
      case 15:
        return ((t = U(t.type, !1)), t);
      case 11:
        return ((t = U(t.type.render, !1)), t);
      case 1:
        return ((t = U(t.type, !0)), t);
      default:
        return "";
    }
  }
  function K(t) {
    if (t == null) return null;
    if (typeof t == "function") return t.displayName || t.name || null;
    if (typeof t == "string") return t;
    switch (t) {
      case Be:
        return "Fragment";
      case Ne:
        return "Portal";
      case Z1:
        return "Profiler";
      case Qe:
        return "StrictMode";
      case Te:
        return "Suspense";
      case l1:
        return "SuspenseList";
    }
    if (typeof t == "object")
      switch (t.$$typeof) {
        case Y1:
          return (t.displayName || "Context") + ".Consumer";
        case g1:
          return (t._context.displayName || "Context") + ".Provider";
        case p1:
          var l = t.render;
          return (
            (t = t.displayName),
            t ||
              ((t = l.displayName || l.name || ""),
              (t = t !== "" ? "ForwardRef(" + t + ")" : "ForwardRef")),
            t
          );
        case f1:
          return (
            (l = t.displayName || null),
            l !== null ? l : K(t.type) || "Memo"
          );
        case Ee:
          ((l = t._payload), (t = t._init));
          try {
            return K(t(l));
          } catch {}
      }
    return null;
  }
  function le(t) {
    var l = t.type;
    switch (t.tag) {
      case 24:
        return "Cache";
      case 9:
        return (l.displayName || "Context") + ".Consumer";
      case 10:
        return (l._context.displayName || "Context") + ".Provider";
      case 18:
        return "DehydratedFragment";
      case 11:
        return (
          (t = l.render),
          (t = t.displayName || t.name || ""),
          l.displayName || (t !== "" ? "ForwardRef(" + t + ")" : "ForwardRef")
        );
      case 7:
        return "Fragment";
      case 5:
        return l;
      case 4:
        return "Portal";
      case 3:
        return "Root";
      case 6:
        return "Text";
      case 16:
        return K(l);
      case 8:
        return l === Qe ? "StrictMode" : "Mode";
      case 22:
        return "Offscreen";
      case 12:
        return "Profiler";
      case 21:
        return "Scope";
      case 13:
        return "Suspense";
      case 19:
        return "SuspenseList";
      case 25:
        return "TracingMarker";
      case 1:
      case 0:
      case 17:
      case 2:
      case 14:
      case 15:
        if (typeof l == "function") return l.displayName || l.name || null;
        if (typeof l == "string") return l;
    }
    return null;
  }
  function q(t) {
    switch (typeof t) {
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return t;
      case "object":
        return t;
      default:
        return "";
    }
  }
  function ae(t) {
    var l = t.type;
    return (
      (t = t.nodeName) &&
      t.toLowerCase() === "input" &&
      (l === "checkbox" || l === "radio")
    );
  }
  function ze(t) {
    var l = ae(t) ? "checked" : "value",
      r = Object.getOwnPropertyDescriptor(t.constructor.prototype, l),
      n = "" + t[l];
    if (
      !t.hasOwnProperty(l) &&
      typeof r < "u" &&
      typeof r.get == "function" &&
      typeof r.set == "function"
    ) {
      var s = r.get,
        a = r.set;
      return (
        Object.defineProperty(t, l, {
          configurable: !0,
          get: function () {
            return s.call(this);
          },
          set: function (o) {
            ((n = "" + o), a.call(this, o));
          },
        }),
        Object.defineProperty(t, l, { enumerable: r.enumerable }),
        {
          getValue: function () {
            return n;
          },
          setValue: function (o) {
            n = "" + o;
          },
          stopTracking: function () {
            ((t._valueTracker = null), delete t[l]);
          },
        }
      );
    }
  }
  function g2(t) {
    t._valueTracker || (t._valueTracker = ze(t));
  }
  function Rr(t) {
    if (!t) return !1;
    var l = t._valueTracker;
    if (!l) return !0;
    var r = l.getValue(),
      n = "";
    return (
      t && (n = ae(t) ? (t.checked ? "true" : "false") : t.value),
      (t = n),
      t !== r ? (l.setValue(t), !0) : !1
    );
  }
  function _2(t) {
    if (
      ((t = t || (typeof document < "u" ? document : void 0)), typeof t > "u")
    )
      return null;
    try {
      return t.activeElement || t.body;
    } catch {
      return t.body;
    }
  }
  function G0(t, l) {
    var r = l.checked;
    return y({}, l, {
      defaultChecked: void 0,
      defaultValue: void 0,
      value: void 0,
      checked: r ?? t._wrapperState.initialChecked,
    });
  }
  function Sr(t, l) {
    var r = l.defaultValue == null ? "" : l.defaultValue,
      n = l.checked != null ? l.checked : l.defaultChecked;
    ((r = q(l.value != null ? l.value : r)),
      (t._wrapperState = {
        initialChecked: n,
        initialValue: r,
        controlled:
          l.type === "checkbox" || l.type === "radio"
            ? l.checked != null
            : l.value != null,
      }));
  }
  function Ir(t, l) {
    ((l = l.checked), l != null && e1(t, "checked", l, !1));
  }
  function A0(t, l) {
    Ir(t, l);
    var r = q(l.value),
      n = l.type;
    if (r != null)
      n === "number"
        ? ((r === 0 && t.value === "") || t.value != r) && (t.value = "" + r)
        : t.value !== "" + r && (t.value = "" + r);
    else if (n === "submit" || n === "reset") {
      t.removeAttribute("value");
      return;
    }
    (l.hasOwnProperty("value")
      ? D0(t, l.type, r)
      : l.hasOwnProperty("defaultValue") && D0(t, l.type, q(l.defaultValue)),
      l.checked == null &&
        l.defaultChecked != null &&
        (t.defaultChecked = !!l.defaultChecked));
  }
  function Tr(t, l, r) {
    if (l.hasOwnProperty("value") || l.hasOwnProperty("defaultValue")) {
      var n = l.type;
      if (
        !(
          (n !== "submit" && n !== "reset") ||
          (l.value !== void 0 && l.value !== null)
        )
      )
        return;
      ((l = "" + t._wrapperState.initialValue),
        r || l === t.value || (t.value = l),
        (t.defaultValue = l));
    }
    ((r = t.name),
      r !== "" && (t.name = ""),
      (t.defaultChecked = !!t._wrapperState.initialChecked),
      r !== "" && (t.name = r));
  }
  function D0(t, l, r) {
    (l !== "number" || _2(t.ownerDocument) !== t) &&
      (r == null
        ? (t.defaultValue = "" + t._wrapperState.initialValue)
        : t.defaultValue !== "" + r && (t.defaultValue = "" + r));
  }
  var At = Array.isArray;
  function ct(t, l, r, n) {
    if (((t = t.options), l)) {
      l = {};
      for (var s = 0; s < r.length; s++) l["$" + r[s]] = !0;
      for (r = 0; r < t.length; r++)
        ((s = l.hasOwnProperty("$" + t[r].value)),
          t[r].selected !== s && (t[r].selected = s),
          s && n && (t[r].defaultSelected = !0));
    } else {
      for (r = "" + q(r), l = null, s = 0; s < t.length; s++) {
        if (t[s].value === r) {
          ((t[s].selected = !0), n && (t[s].defaultSelected = !0));
          return;
        }
        l !== null || t[s].disabled || (l = t[s]);
      }
      l !== null && (l.selected = !0);
    }
  }
  function R0(t, l) {
    if (l.dangerouslySetInnerHTML != null) throw Error(u(91));
    return y({}, l, {
      value: void 0,
      defaultValue: void 0,
      children: "" + t._wrapperState.initialValue,
    });
  }
  function zr(t, l) {
    var r = l.value;
    if (r == null) {
      if (((r = l.children), (l = l.defaultValue), r != null)) {
        if (l != null) throw Error(u(92));
        if (At(r)) {
          if (1 < r.length) throw Error(u(93));
          r = r[0];
        }
        l = r;
      }
      (l == null && (l = ""), (r = l));
    }
    t._wrapperState = { initialValue: q(r) };
  }
  function Pr(t, l) {
    var r = q(l.value),
      n = q(l.defaultValue);
    (r != null &&
      ((r = "" + r),
      r !== t.value && (t.value = r),
      l.defaultValue == null && t.defaultValue !== r && (t.defaultValue = r)),
      n != null && (t.defaultValue = "" + n));
  }
  function Hr(t) {
    var l = t.textContent;
    l === t._wrapperState.initialValue &&
      l !== "" &&
      l !== null &&
      (t.value = l);
  }
  function Wr(t) {
    switch (t) {
      case "svg":
        return "http://www.w3.org/2000/svg";
      case "math":
        return "http://www.w3.org/1998/Math/MathML";
      default:
        return "http://www.w3.org/1999/xhtml";
    }
  }
  function S0(t, l) {
    return t == null || t === "http://www.w3.org/1999/xhtml"
      ? Wr(l)
      : t === "http://www.w3.org/2000/svg" && l === "foreignObject"
        ? "http://www.w3.org/1999/xhtml"
        : t;
  }
  var b2,
    Or = (function (t) {
      return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction
        ? function (l, r, n, s) {
            MSApp.execUnsafeLocalFunction(function () {
              return t(l, r, n, s);
            });
          }
        : t;
    })(function (t, l) {
      if (t.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in t)
        t.innerHTML = l;
      else {
        for (
          b2 = b2 || document.createElement("div"),
            b2.innerHTML = "<svg>" + l.valueOf().toString() + "</svg>",
            l = b2.firstChild;
          t.firstChild;
        )
          t.removeChild(t.firstChild);
        for (; l.firstChild; ) t.appendChild(l.firstChild);
      }
    });
  function Dt(t, l) {
    if (l) {
      var r = t.firstChild;
      if (r && r === t.lastChild && r.nodeType === 3) {
        r.nodeValue = l;
        return;
      }
    }
    t.textContent = l;
  }
  var Rt = {
      animationIterationCount: !0,
      aspectRatio: !0,
      borderImageOutset: !0,
      borderImageSlice: !0,
      borderImageWidth: !0,
      boxFlex: !0,
      boxFlexGroup: !0,
      boxOrdinalGroup: !0,
      columnCount: !0,
      columns: !0,
      flex: !0,
      flexGrow: !0,
      flexPositive: !0,
      flexShrink: !0,
      flexNegative: !0,
      flexOrder: !0,
      gridArea: !0,
      gridRow: !0,
      gridRowEnd: !0,
      gridRowSpan: !0,
      gridRowStart: !0,
      gridColumn: !0,
      gridColumnEnd: !0,
      gridColumnSpan: !0,
      gridColumnStart: !0,
      fontWeight: !0,
      lineClamp: !0,
      lineHeight: !0,
      opacity: !0,
      order: !0,
      orphans: !0,
      tabSize: !0,
      widows: !0,
      zIndex: !0,
      zoom: !0,
      fillOpacity: !0,
      floodOpacity: !0,
      stopOpacity: !0,
      strokeDasharray: !0,
      strokeDashoffset: !0,
      strokeMiterlimit: !0,
      strokeOpacity: !0,
      strokeWidth: !0,
    },
    $n = ["Webkit", "ms", "Moz", "O"];
  Object.keys(Rt).forEach(function (t) {
    $n.forEach(function (l) {
      ((l = l + t.charAt(0).toUpperCase() + t.substring(1)), (Rt[l] = Rt[t]));
    });
  });
  function Ur(t, l, r) {
    return l == null || typeof l == "boolean" || l === ""
      ? ""
      : r || typeof l != "number" || l === 0 || (Rt.hasOwnProperty(t) && Rt[t])
        ? ("" + l).trim()
        : l + "px";
  }
  function Qr(t, l) {
    t = t.style;
    for (var r in l)
      if (l.hasOwnProperty(r)) {
        var n = r.indexOf("--") === 0,
          s = Ur(r, l[r], n);
        (r === "float" && (r = "cssFloat"),
          n ? t.setProperty(r, s) : (t[r] = s));
      }
  }
  var Xn = y(
    { menuitem: !0 },
    {
      area: !0,
      base: !0,
      br: !0,
      col: !0,
      embed: !0,
      hr: !0,
      img: !0,
      input: !0,
      keygen: !0,
      link: !0,
      meta: !0,
      param: !0,
      source: !0,
      track: !0,
      wbr: !0,
    },
  );
  function I0(t, l) {
    if (l) {
      if (Xn[t] && (l.children != null || l.dangerouslySetInnerHTML != null))
        throw Error(u(137, t));
      if (l.dangerouslySetInnerHTML != null) {
        if (l.children != null) throw Error(u(60));
        if (
          typeof l.dangerouslySetInnerHTML != "object" ||
          !("__html" in l.dangerouslySetInnerHTML)
        )
          throw Error(u(61));
      }
      if (l.style != null && typeof l.style != "object") throw Error(u(62));
    }
  }
  function T0(t, l) {
    if (t.indexOf("-") === -1) return typeof l.is == "string";
    switch (t) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return !1;
      default:
        return !0;
    }
  }
  var z0 = null;
  function P0(t) {
    return (
      (t = t.target || t.srcElement || window),
      t.correspondingUseElement && (t = t.correspondingUseElement),
      t.nodeType === 3 ? t.parentNode : t
    );
  }
  var H0 = null,
    pt = null,
    ft = null;
  function $r(t) {
    if ((t = n2(t))) {
      if (typeof H0 != "function") throw Error(u(280));
      var l = t.stateNode;
      l && ((l = U2(l)), H0(t.stateNode, t.type, l));
    }
  }
  function Xr(t) {
    pt ? (ft ? ft.push(t) : (ft = [t])) : (pt = t);
  }
  function Yr() {
    if (pt) {
      var t = pt,
        l = ft;
      if (((ft = pt = null), $r(t), l)) for (t = 0; t < l.length; t++) $r(l[t]);
    }
  }
  function Kr(t, l) {
    return t(l);
  }
  function Jr() {}
  var W0 = !1;
  function qr(t, l, r) {
    if (W0) return t(l, r);
    W0 = !0;
    try {
      return Kr(t, l, r);
    } finally {
      ((W0 = !1), (pt !== null || ft !== null) && (Jr(), Yr()));
    }
  }
  function St(t, l) {
    var r = t.stateNode;
    if (r === null) return null;
    var n = U2(r);
    if (n === null) return null;
    r = n[l];
    e: switch (l) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        ((n = !n.disabled) ||
          ((t = t.type),
          (n = !(
            t === "button" ||
            t === "input" ||
            t === "select" ||
            t === "textarea"
          ))),
          (t = !n));
        break e;
      default:
        t = !1;
    }
    if (t) return null;
    if (r && typeof r != "function") throw Error(u(231, l, typeof r));
    return r;
  }
  var O0 = !1;
  if (D)
    try {
      var It = {};
      (Object.defineProperty(It, "passive", {
        get: function () {
          O0 = !0;
        },
      }),
        window.addEventListener("test", It, It),
        window.removeEventListener("test", It, It));
    } catch {
      O0 = !1;
    }
  function Yn(t, l, r, n, s, a, o, d, c) {
    var v = Array.prototype.slice.call(arguments, 3);
    try {
      l.apply(r, v);
    } catch (m) {
      this.onError(m);
    }
  }
  var Tt = !1,
    F2 = null,
    M2 = !1,
    U0 = null,
    Kn = {
      onError: function (t) {
        ((Tt = !0), (F2 = t));
      },
    };
  function Jn(t, l, r, n, s, a, o, d, c) {
    ((Tt = !1), (F2 = null), Yn.apply(Kn, arguments));
  }
  function qn(t, l, r, n, s, a, o, d, c) {
    if ((Jn.apply(this, arguments), Tt)) {
      if (Tt) {
        var v = F2;
        ((Tt = !1), (F2 = null));
      } else throw Error(u(198));
      M2 || ((M2 = !0), (U0 = v));
    }
  }
  function K1(t) {
    var l = t,
      r = t;
    if (t.alternate) for (; l.return; ) l = l.return;
    else {
      t = l;
      do ((l = t), (l.flags & 4098) !== 0 && (r = l.return), (t = l.return));
      while (t);
    }
    return l.tag === 3 ? r : null;
  }
  function e3(t) {
    if (t.tag === 13) {
      var l = t.memoizedState;
      if (
        (l === null && ((t = t.alternate), t !== null && (l = t.memoizedState)),
        l !== null)
      )
        return l.dehydrated;
    }
    return null;
  }
  function t3(t) {
    if (K1(t) !== t) throw Error(u(188));
  }
  function es(t) {
    var l = t.alternate;
    if (!l) {
      if (((l = K1(t)), l === null)) throw Error(u(188));
      return l !== t ? null : t;
    }
    for (var r = t, n = l; ; ) {
      var s = r.return;
      if (s === null) break;
      var a = s.alternate;
      if (a === null) {
        if (((n = s.return), n !== null)) {
          r = n;
          continue;
        }
        break;
      }
      if (s.child === a.child) {
        for (a = s.child; a; ) {
          if (a === r) return (t3(s), t);
          if (a === n) return (t3(s), l);
          a = a.sibling;
        }
        throw Error(u(188));
      }
      if (r.return !== n.return) ((r = s), (n = a));
      else {
        for (var o = !1, d = s.child; d; ) {
          if (d === r) {
            ((o = !0), (r = s), (n = a));
            break;
          }
          if (d === n) {
            ((o = !0), (n = s), (r = a));
            break;
          }
          d = d.sibling;
        }
        if (!o) {
          for (d = a.child; d; ) {
            if (d === r) {
              ((o = !0), (r = a), (n = s));
              break;
            }
            if (d === n) {
              ((o = !0), (n = a), (r = s));
              break;
            }
            d = d.sibling;
          }
          if (!o) throw Error(u(189));
        }
      }
      if (r.alternate !== n) throw Error(u(190));
    }
    if (r.tag !== 3) throw Error(u(188));
    return r.stateNode.current === r ? t : l;
  }
  function l3(t) {
    return ((t = es(t)), t !== null ? r3(t) : null);
  }
  function r3(t) {
    if (t.tag === 5 || t.tag === 6) return t;
    for (t = t.child; t !== null; ) {
      var l = r3(t);
      if (l !== null) return l;
      t = t.sibling;
    }
    return null;
  }
  var i3 = F.unstable_scheduleCallback,
    n3 = F.unstable_cancelCallback,
    ts = F.unstable_shouldYield,
    ls = F.unstable_requestPaint,
    xe = F.unstable_now,
    rs = F.unstable_getCurrentPriorityLevel,
    Q0 = F.unstable_ImmediatePriority,
    s3 = F.unstable_UserBlockingPriority,
    C2 = F.unstable_NormalPriority,
    is = F.unstable_LowPriority,
    a3 = F.unstable_IdlePriority,
    w2 = null,
    u1 = null;
  function ns(t) {
    if (u1 && typeof u1.onCommitFiberRoot == "function")
      try {
        u1.onCommitFiberRoot(w2, t, void 0, (t.current.flags & 128) === 128);
      } catch {}
  }
  var r1 = Math.clz32 ? Math.clz32 : os,
    ss = Math.log,
    as = Math.LN2;
  function os(t) {
    return ((t >>>= 0), t === 0 ? 32 : (31 - ((ss(t) / as) | 0)) | 0);
  }
  var k2 = 64,
    N2 = 4194304;
  function zt(t) {
    switch (t & -t) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t & 4194240;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return t & 130023424;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 1073741824;
      default:
        return t;
    }
  }
  function Z2(t, l) {
    var r = t.pendingLanes;
    if (r === 0) return 0;
    var n = 0,
      s = t.suspendedLanes,
      a = t.pingedLanes,
      o = r & 268435455;
    if (o !== 0) {
      var d = o & ~s;
      d !== 0 ? (n = zt(d)) : ((a &= o), a !== 0 && (n = zt(a)));
    } else ((o = r & ~s), o !== 0 ? (n = zt(o)) : a !== 0 && (n = zt(a)));
    if (n === 0) return 0;
    if (
      l !== 0 &&
      l !== n &&
      (l & s) === 0 &&
      ((s = n & -n), (a = l & -l), s >= a || (s === 16 && (a & 4194240) !== 0))
    )
      return l;
    if (((n & 4) !== 0 && (n |= r & 16), (l = t.entangledLanes), l !== 0))
      for (t = t.entanglements, l &= n; 0 < l; )
        ((r = 31 - r1(l)), (s = 1 << r), (n |= t[r]), (l &= ~s));
    return n;
  }
  function ds(t, l) {
    switch (t) {
      case 1:
      case 2:
      case 4:
        return l + 250;
      case 8:
      case 16:
      case 32:
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return l + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
      case 67108864:
        return -1;
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function cs(t, l) {
    for (
      var r = t.suspendedLanes,
        n = t.pingedLanes,
        s = t.expirationTimes,
        a = t.pendingLanes;
      0 < a;
    ) {
      var o = 31 - r1(a),
        d = 1 << o,
        c = s[o];
      (c === -1
        ? ((d & r) === 0 || (d & n) !== 0) && (s[o] = ds(d, l))
        : c <= l && (t.expiredLanes |= d),
        (a &= ~d));
    }
  }
  function $0(t) {
    return (
      (t = t.pendingLanes & -1073741825),
      t !== 0 ? t : t & 1073741824 ? 1073741824 : 0
    );
  }
  function o3() {
    var t = k2;
    return ((k2 <<= 1), (k2 & 4194240) === 0 && (k2 = 64), t);
  }
  function X0(t) {
    for (var l = [], r = 0; 31 > r; r++) l.push(t);
    return l;
  }
  function Pt(t, l, r) {
    ((t.pendingLanes |= l),
      l !== 536870912 && ((t.suspendedLanes = 0), (t.pingedLanes = 0)),
      (t = t.eventTimes),
      (l = 31 - r1(l)),
      (t[l] = r));
  }
  function ps(t, l) {
    var r = t.pendingLanes & ~l;
    ((t.pendingLanes = l),
      (t.suspendedLanes = 0),
      (t.pingedLanes = 0),
      (t.expiredLanes &= l),
      (t.mutableReadLanes &= l),
      (t.entangledLanes &= l),
      (l = t.entanglements));
    var n = t.eventTimes;
    for (t = t.expirationTimes; 0 < r; ) {
      var s = 31 - r1(r),
        a = 1 << s;
      ((l[s] = 0), (n[s] = -1), (t[s] = -1), (r &= ~a));
    }
  }
  function Y0(t, l) {
    var r = (t.entangledLanes |= l);
    for (t = t.entanglements; r; ) {
      var n = 31 - r1(r),
        s = 1 << n;
      ((s & l) | (t[n] & l) && (t[n] |= l), (r &= ~s));
    }
  }
  var ee = 0;
  function d3(t) {
    return (
      (t &= -t),
      1 < t ? (4 < t ? ((t & 268435455) !== 0 ? 16 : 536870912) : 4) : 1
    );
  }
  var c3,
    K0,
    p3,
    f3,
    u3,
    J0 = !1,
    y2 = [],
    y1 = null,
    B1 = null,
    E1 = null,
    Ht = new Map(),
    Wt = new Map(),
    G1 = [],
    fs =
      "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(
        " ",
      );
  function x3(t, l) {
    switch (t) {
      case "focusin":
      case "focusout":
        y1 = null;
        break;
      case "dragenter":
      case "dragleave":
        B1 = null;
        break;
      case "mouseover":
      case "mouseout":
        E1 = null;
        break;
      case "pointerover":
      case "pointerout":
        Ht.delete(l.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        Wt.delete(l.pointerId);
    }
  }
  function Ot(t, l, r, n, s, a) {
    return t === null || t.nativeEvent !== a
      ? ((t = {
          blockedOn: l,
          domEventName: r,
          eventSystemFlags: n,
          nativeEvent: a,
          targetContainers: [s],
        }),
        l !== null && ((l = n2(l)), l !== null && K0(l)),
        t)
      : ((t.eventSystemFlags |= n),
        (l = t.targetContainers),
        s !== null && l.indexOf(s) === -1 && l.push(s),
        t);
  }
  function us(t, l, r, n, s) {
    switch (l) {
      case "focusin":
        return ((y1 = Ot(y1, t, l, r, n, s)), !0);
      case "dragenter":
        return ((B1 = Ot(B1, t, l, r, n, s)), !0);
      case "mouseover":
        return ((E1 = Ot(E1, t, l, r, n, s)), !0);
      case "pointerover":
        var a = s.pointerId;
        return (Ht.set(a, Ot(Ht.get(a) || null, t, l, r, n, s)), !0);
      case "gotpointercapture":
        return (
          (a = s.pointerId),
          Wt.set(a, Ot(Wt.get(a) || null, t, l, r, n, s)),
          !0
        );
    }
    return !1;
  }
  function h3(t) {
    var l = J1(t.target);
    if (l !== null) {
      var r = K1(l);
      if (r !== null) {
        if (((l = r.tag), l === 13)) {
          if (((l = e3(r)), l !== null)) {
            ((t.blockedOn = l),
              u3(t.priority, function () {
                p3(r);
              }));
            return;
          }
        } else if (l === 3 && r.stateNode.current.memoizedState.isDehydrated) {
          t.blockedOn = r.tag === 3 ? r.stateNode.containerInfo : null;
          return;
        }
      }
    }
    t.blockedOn = null;
  }
  function B2(t) {
    if (t.blockedOn !== null) return !1;
    for (var l = t.targetContainers; 0 < l.length; ) {
      var r = el(t.domEventName, t.eventSystemFlags, l[0], t.nativeEvent);
      if (r === null) {
        r = t.nativeEvent;
        var n = new r.constructor(r.type, r);
        ((z0 = n), r.target.dispatchEvent(n), (z0 = null));
      } else return ((l = n2(r)), l !== null && K0(l), (t.blockedOn = r), !1);
      l.shift();
    }
    return !0;
  }
  function v3(t, l, r) {
    B2(t) && r.delete(l);
  }
  function xs() {
    ((J0 = !1),
      y1 !== null && B2(y1) && (y1 = null),
      B1 !== null && B2(B1) && (B1 = null),
      E1 !== null && B2(E1) && (E1 = null),
      Ht.forEach(v3),
      Wt.forEach(v3));
  }
  function Ut(t, l) {
    t.blockedOn === l &&
      ((t.blockedOn = null),
      J0 ||
        ((J0 = !0),
        F.unstable_scheduleCallback(F.unstable_NormalPriority, xs)));
  }
  function Qt(t) {
    function l(s) {
      return Ut(s, t);
    }
    if (0 < y2.length) {
      Ut(y2[0], t);
      for (var r = 1; r < y2.length; r++) {
        var n = y2[r];
        n.blockedOn === t && (n.blockedOn = null);
      }
    }
    for (
      y1 !== null && Ut(y1, t),
        B1 !== null && Ut(B1, t),
        E1 !== null && Ut(E1, t),
        Ht.forEach(l),
        Wt.forEach(l),
        r = 0;
      r < G1.length;
      r++
    )
      ((n = G1[r]), n.blockedOn === t && (n.blockedOn = null));
    for (; 0 < G1.length && ((r = G1[0]), r.blockedOn === null); )
      (h3(r), r.blockedOn === null && G1.shift());
  }
  var ut = Fe.ReactCurrentBatchConfig,
    E2 = !0;
  function hs(t, l, r, n) {
    var s = ee,
      a = ut.transition;
    ut.transition = null;
    try {
      ((ee = 1), q0(t, l, r, n));
    } finally {
      ((ee = s), (ut.transition = a));
    }
  }
  function vs(t, l, r, n) {
    var s = ee,
      a = ut.transition;
    ut.transition = null;
    try {
      ((ee = 4), q0(t, l, r, n));
    } finally {
      ((ee = s), (ut.transition = a));
    }
  }
  function q0(t, l, r, n) {
    if (E2) {
      var s = el(t, l, r, n);
      if (s === null) (Ll(t, l, n, G2, r), x3(t, n));
      else if (us(s, t, l, r, n)) n.stopPropagation();
      else if ((x3(t, n), l & 4 && -1 < fs.indexOf(t))) {
        for (; s !== null; ) {
          var a = n2(s);
          if (
            (a !== null && c3(a),
            (a = el(t, l, r, n)),
            a === null && Ll(t, l, n, G2, r),
            a === s)
          )
            break;
          s = a;
        }
        s !== null && n.stopPropagation();
      } else Ll(t, l, n, null, r);
    }
  }
  var G2 = null;
  function el(t, l, r, n) {
    if (((G2 = null), (t = P0(n)), (t = J1(t)), t !== null))
      if (((l = K1(t)), l === null)) t = null;
      else if (((r = l.tag), r === 13)) {
        if (((t = e3(l)), t !== null)) return t;
        t = null;
      } else if (r === 3) {
        if (l.stateNode.current.memoizedState.isDehydrated)
          return l.tag === 3 ? l.stateNode.containerInfo : null;
        t = null;
      } else l !== t && (t = null);
    return ((G2 = t), null);
  }
  function L3(t) {
    switch (t) {
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 1;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "toggle":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 4;
      case "message":
        switch (rs()) {
          case Q0:
            return 1;
          case s3:
            return 4;
          case C2:
          case is:
            return 16;
          case a3:
            return 536870912;
          default:
            return 16;
        }
      default:
        return 16;
    }
  }
  var A1 = null,
    tl = null,
    A2 = null;
  function j3() {
    if (A2) return A2;
    var t,
      l = tl,
      r = l.length,
      n,
      s = "value" in A1 ? A1.value : A1.textContent,
      a = s.length;
    for (t = 0; t < r && l[t] === s[t]; t++);
    var o = r - t;
    for (n = 1; n <= o && l[r - n] === s[a - n]; n++);
    return (A2 = s.slice(t, 1 < n ? 1 - n : void 0));
  }
  function D2(t) {
    var l = t.keyCode;
    return (
      "charCode" in t
        ? ((t = t.charCode), t === 0 && l === 13 && (t = 13))
        : (t = l),
      t === 10 && (t = 13),
      32 <= t || t === 13 ? t : 0
    );
  }
  function R2() {
    return !0;
  }
  function V3() {
    return !1;
  }
  function Pe(t) {
    function l(r, n, s, a, o) {
      ((this._reactName = r),
        (this._targetInst = s),
        (this.type = n),
        (this.nativeEvent = a),
        (this.target = o),
        (this.currentTarget = null));
      for (var d in t)
        t.hasOwnProperty(d) && ((r = t[d]), (this[d] = r ? r(a) : a[d]));
      return (
        (this.isDefaultPrevented = (
          a.defaultPrevented != null ? a.defaultPrevented : a.returnValue === !1
        )
          ? R2
          : V3),
        (this.isPropagationStopped = V3),
        this
      );
    }
    return (
      y(l.prototype, {
        preventDefault: function () {
          this.defaultPrevented = !0;
          var r = this.nativeEvent;
          r &&
            (r.preventDefault
              ? r.preventDefault()
              : typeof r.returnValue != "unknown" && (r.returnValue = !1),
            (this.isDefaultPrevented = R2));
        },
        stopPropagation: function () {
          var r = this.nativeEvent;
          r &&
            (r.stopPropagation
              ? r.stopPropagation()
              : typeof r.cancelBubble != "unknown" && (r.cancelBubble = !0),
            (this.isPropagationStopped = R2));
        },
        persist: function () {},
        isPersistent: R2,
      }),
      l
    );
  }
  var xt = {
      eventPhase: 0,
      bubbles: 0,
      cancelable: 0,
      timeStamp: function (t) {
        return t.timeStamp || Date.now();
      },
      defaultPrevented: 0,
      isTrusted: 0,
    },
    ll = Pe(xt),
    $t = y({}, xt, { view: 0, detail: 0 }),
    Ls = Pe($t),
    rl,
    il,
    Xt,
    S2 = y({}, $t, {
      screenX: 0,
      screenY: 0,
      clientX: 0,
      clientY: 0,
      pageX: 0,
      pageY: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      getModifierState: sl,
      button: 0,
      buttons: 0,
      relatedTarget: function (t) {
        return t.relatedTarget === void 0
          ? t.fromElement === t.srcElement
            ? t.toElement
            : t.fromElement
          : t.relatedTarget;
      },
      movementX: function (t) {
        return "movementX" in t
          ? t.movementX
          : (t !== Xt &&
              (Xt && t.type === "mousemove"
                ? ((rl = t.screenX - Xt.screenX), (il = t.screenY - Xt.screenY))
                : (il = rl = 0),
              (Xt = t)),
            rl);
      },
      movementY: function (t) {
        return "movementY" in t ? t.movementY : il;
      },
    }),
    m3 = Pe(S2),
    js = y({}, S2, { dataTransfer: 0 }),
    Vs = Pe(js),
    ms = y({}, $t, { relatedTarget: 0 }),
    nl = Pe(ms),
    gs = y({}, xt, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }),
    _s = Pe(gs),
    bs = y({}, xt, {
      clipboardData: function (t) {
        return "clipboardData" in t ? t.clipboardData : window.clipboardData;
      },
    }),
    Fs = Pe(bs),
    Ms = y({}, xt, { data: 0 }),
    g3 = Pe(Ms),
    Cs = {
      Esc: "Escape",
      Spacebar: " ",
      Left: "ArrowLeft",
      Up: "ArrowUp",
      Right: "ArrowRight",
      Down: "ArrowDown",
      Del: "Delete",
      Win: "OS",
      Menu: "ContextMenu",
      Apps: "ContextMenu",
      Scroll: "ScrollLock",
      MozPrintableKey: "Unidentified",
    },
    ws = {
      8: "Backspace",
      9: "Tab",
      12: "Clear",
      13: "Enter",
      16: "Shift",
      17: "Control",
      18: "Alt",
      19: "Pause",
      20: "CapsLock",
      27: "Escape",
      32: " ",
      33: "PageUp",
      34: "PageDown",
      35: "End",
      36: "Home",
      37: "ArrowLeft",
      38: "ArrowUp",
      39: "ArrowRight",
      40: "ArrowDown",
      45: "Insert",
      46: "Delete",
      112: "F1",
      113: "F2",
      114: "F3",
      115: "F4",
      116: "F5",
      117: "F6",
      118: "F7",
      119: "F8",
      120: "F9",
      121: "F10",
      122: "F11",
      123: "F12",
      144: "NumLock",
      145: "ScrollLock",
      224: "Meta",
    },
    ks = {
      Alt: "altKey",
      Control: "ctrlKey",
      Meta: "metaKey",
      Shift: "shiftKey",
    };
  function Ns(t) {
    var l = this.nativeEvent;
    return l.getModifierState
      ? l.getModifierState(t)
      : (t = ks[t])
        ? !!l[t]
        : !1;
  }
  function sl() {
    return Ns;
  }
  var Zs = y({}, $t, {
      key: function (t) {
        if (t.key) {
          var l = Cs[t.key] || t.key;
          if (l !== "Unidentified") return l;
        }
        return t.type === "keypress"
          ? ((t = D2(t)), t === 13 ? "Enter" : String.fromCharCode(t))
          : t.type === "keydown" || t.type === "keyup"
            ? ws[t.keyCode] || "Unidentified"
            : "";
      },
      code: 0,
      location: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      repeat: 0,
      locale: 0,
      getModifierState: sl,
      charCode: function (t) {
        return t.type === "keypress" ? D2(t) : 0;
      },
      keyCode: function (t) {
        return t.type === "keydown" || t.type === "keyup" ? t.keyCode : 0;
      },
      which: function (t) {
        return t.type === "keypress"
          ? D2(t)
          : t.type === "keydown" || t.type === "keyup"
            ? t.keyCode
            : 0;
      },
    }),
    ys = Pe(Zs),
    Bs = y({}, S2, {
      pointerId: 0,
      width: 0,
      height: 0,
      pressure: 0,
      tangentialPressure: 0,
      tiltX: 0,
      tiltY: 0,
      twist: 0,
      pointerType: 0,
      isPrimary: 0,
    }),
    _3 = Pe(Bs),
    Es = y({}, $t, {
      touches: 0,
      targetTouches: 0,
      changedTouches: 0,
      altKey: 0,
      metaKey: 0,
      ctrlKey: 0,
      shiftKey: 0,
      getModifierState: sl,
    }),
    Gs = Pe(Es),
    As = y({}, xt, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }),
    Ds = Pe(As),
    Rs = y({}, S2, {
      deltaX: function (t) {
        return "deltaX" in t
          ? t.deltaX
          : "wheelDeltaX" in t
            ? -t.wheelDeltaX
            : 0;
      },
      deltaY: function (t) {
        return "deltaY" in t
          ? t.deltaY
          : "wheelDeltaY" in t
            ? -t.wheelDeltaY
            : "wheelDelta" in t
              ? -t.wheelDelta
              : 0;
      },
      deltaZ: 0,
      deltaMode: 0,
    }),
    Ss = Pe(Rs),
    Is = [9, 13, 27, 32],
    al = D && "CompositionEvent" in window,
    Yt = null;
  D && "documentMode" in document && (Yt = document.documentMode);
  var Ts = D && "TextEvent" in window && !Yt,
    b3 = D && (!al || (Yt && 8 < Yt && 11 >= Yt)),
    F3 = " ",
    M3 = !1;
  function C3(t, l) {
    switch (t) {
      case "keyup":
        return Is.indexOf(l.keyCode) !== -1;
      case "keydown":
        return l.keyCode !== 229;
      case "keypress":
      case "mousedown":
      case "focusout":
        return !0;
      default:
        return !1;
    }
  }
  function w3(t) {
    return (
      (t = t.detail),
      typeof t == "object" && "data" in t ? t.data : null
    );
  }
  var ht = !1;
  function zs(t, l) {
    switch (t) {
      case "compositionend":
        return w3(l);
      case "keypress":
        return l.which !== 32 ? null : ((M3 = !0), F3);
      case "textInput":
        return ((t = l.data), t === F3 && M3 ? null : t);
      default:
        return null;
    }
  }
  function Ps(t, l) {
    if (ht)
      return t === "compositionend" || (!al && C3(t, l))
        ? ((t = j3()), (A2 = tl = A1 = null), (ht = !1), t)
        : null;
    switch (t) {
      case "paste":
        return null;
      case "keypress":
        if (!(l.ctrlKey || l.altKey || l.metaKey) || (l.ctrlKey && l.altKey)) {
          if (l.char && 1 < l.char.length) return l.char;
          if (l.which) return String.fromCharCode(l.which);
        }
        return null;
      case "compositionend":
        return b3 && l.locale !== "ko" ? null : l.data;
      default:
        return null;
    }
  }
  var Hs = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0,
  };
  function k3(t) {
    var l = t && t.nodeName && t.nodeName.toLowerCase();
    return l === "input" ? !!Hs[t.type] : l === "textarea";
  }
  function N3(t, l, r, n) {
    (Xr(n),
      (l = H2(l, "onChange")),
      0 < l.length &&
        ((r = new ll("onChange", "change", null, r, n)),
        t.push({ event: r, listeners: l })));
  }
  var Kt = null,
    Jt = null;
  function Ws(t) {
    Q3(t, 0);
  }
  function I2(t) {
    var l = mt(t);
    if (Rr(l)) return t;
  }
  function Os(t, l) {
    if (t === "change") return l;
  }
  var Z3 = !1;
  if (D) {
    var ol;
    if (D) {
      var dl = "oninput" in document;
      if (!dl) {
        var y3 = document.createElement("div");
        (y3.setAttribute("oninput", "return;"),
          (dl = typeof y3.oninput == "function"));
      }
      ol = dl;
    } else ol = !1;
    Z3 = ol && (!document.documentMode || 9 < document.documentMode);
  }
  function B3() {
    Kt && (Kt.detachEvent("onpropertychange", E3), (Jt = Kt = null));
  }
  function E3(t) {
    if (t.propertyName === "value" && I2(Jt)) {
      var l = [];
      (N3(l, Jt, t, P0(t)), qr(Ws, l));
    }
  }
  function Us(t, l, r) {
    t === "focusin"
      ? (B3(), (Kt = l), (Jt = r), Kt.attachEvent("onpropertychange", E3))
      : t === "focusout" && B3();
  }
  function Qs(t) {
    if (t === "selectionchange" || t === "keyup" || t === "keydown")
      return I2(Jt);
  }
  function $s(t, l) {
    if (t === "click") return I2(l);
  }
  function Xs(t, l) {
    if (t === "input" || t === "change") return I2(l);
  }
  function Ys(t, l) {
    return (t === l && (t !== 0 || 1 / t === 1 / l)) || (t !== t && l !== l);
  }
  var i1 = typeof Object.is == "function" ? Object.is : Ys;
  function qt(t, l) {
    if (i1(t, l)) return !0;
    if (
      typeof t != "object" ||
      t === null ||
      typeof l != "object" ||
      l === null
    )
      return !1;
    var r = Object.keys(t),
      n = Object.keys(l);
    if (r.length !== n.length) return !1;
    for (n = 0; n < r.length; n++) {
      var s = r[n];
      if (!N.call(l, s) || !i1(t[s], l[s])) return !1;
    }
    return !0;
  }
  function G3(t) {
    for (; t && t.firstChild; ) t = t.firstChild;
    return t;
  }
  function A3(t, l) {
    var r = G3(t);
    t = 0;
    for (var n; r; ) {
      if (r.nodeType === 3) {
        if (((n = t + r.textContent.length), t <= l && n >= l))
          return { node: r, offset: l - t };
        t = n;
      }
      e: {
        for (; r; ) {
          if (r.nextSibling) {
            r = r.nextSibling;
            break e;
          }
          r = r.parentNode;
        }
        r = void 0;
      }
      r = G3(r);
    }
  }
  function D3(t, l) {
    return t && l
      ? t === l
        ? !0
        : t && t.nodeType === 3
          ? !1
          : l && l.nodeType === 3
            ? D3(t, l.parentNode)
            : "contains" in t
              ? t.contains(l)
              : t.compareDocumentPosition
                ? !!(t.compareDocumentPosition(l) & 16)
                : !1
      : !1;
  }
  function R3() {
    for (var t = window, l = _2(); l instanceof t.HTMLIFrameElement; ) {
      try {
        var r = typeof l.contentWindow.location.href == "string";
      } catch {
        r = !1;
      }
      if (r) t = l.contentWindow;
      else break;
      l = _2(t.document);
    }
    return l;
  }
  function cl(t) {
    var l = t && t.nodeName && t.nodeName.toLowerCase();
    return (
      l &&
      ((l === "input" &&
        (t.type === "text" ||
          t.type === "search" ||
          t.type === "tel" ||
          t.type === "url" ||
          t.type === "password")) ||
        l === "textarea" ||
        t.contentEditable === "true")
    );
  }
  function Ks(t) {
    var l = R3(),
      r = t.focusedElem,
      n = t.selectionRange;
    if (
      l !== r &&
      r &&
      r.ownerDocument &&
      D3(r.ownerDocument.documentElement, r)
    ) {
      if (n !== null && cl(r)) {
        if (
          ((l = n.start),
          (t = n.end),
          t === void 0 && (t = l),
          "selectionStart" in r)
        )
          ((r.selectionStart = l),
            (r.selectionEnd = Math.min(t, r.value.length)));
        else if (
          ((t = ((l = r.ownerDocument || document) && l.defaultView) || window),
          t.getSelection)
        ) {
          t = t.getSelection();
          var s = r.textContent.length,
            a = Math.min(n.start, s);
          ((n = n.end === void 0 ? a : Math.min(n.end, s)),
            !t.extend && a > n && ((s = n), (n = a), (a = s)),
            (s = A3(r, a)));
          var o = A3(r, n);
          s &&
            o &&
            (t.rangeCount !== 1 ||
              t.anchorNode !== s.node ||
              t.anchorOffset !== s.offset ||
              t.focusNode !== o.node ||
              t.focusOffset !== o.offset) &&
            ((l = l.createRange()),
            l.setStart(s.node, s.offset),
            t.removeAllRanges(),
            a > n
              ? (t.addRange(l), t.extend(o.node, o.offset))
              : (l.setEnd(o.node, o.offset), t.addRange(l)));
        }
      }
      for (l = [], t = r; (t = t.parentNode); )
        t.nodeType === 1 &&
          l.push({ element: t, left: t.scrollLeft, top: t.scrollTop });
      for (typeof r.focus == "function" && r.focus(), r = 0; r < l.length; r++)
        ((t = l[r]),
          (t.element.scrollLeft = t.left),
          (t.element.scrollTop = t.top));
    }
  }
  var Js = D && "documentMode" in document && 11 >= document.documentMode,
    vt = null,
    pl = null,
    e2 = null,
    fl = !1;
  function S3(t, l, r) {
    var n =
      r.window === r ? r.document : r.nodeType === 9 ? r : r.ownerDocument;
    fl ||
      vt == null ||
      vt !== _2(n) ||
      ((n = vt),
      "selectionStart" in n && cl(n)
        ? (n = { start: n.selectionStart, end: n.selectionEnd })
        : ((n = (
            (n.ownerDocument && n.ownerDocument.defaultView) ||
            window
          ).getSelection()),
          (n = {
            anchorNode: n.anchorNode,
            anchorOffset: n.anchorOffset,
            focusNode: n.focusNode,
            focusOffset: n.focusOffset,
          })),
      (e2 && qt(e2, n)) ||
        ((e2 = n),
        (n = H2(pl, "onSelect")),
        0 < n.length &&
          ((l = new ll("onSelect", "select", null, l, r)),
          t.push({ event: l, listeners: n }),
          (l.target = vt))));
  }
  function T2(t, l) {
    var r = {};
    return (
      (r[t.toLowerCase()] = l.toLowerCase()),
      (r["Webkit" + t] = "webkit" + l),
      (r["Moz" + t] = "moz" + l),
      r
    );
  }
  var Lt = {
      animationend: T2("Animation", "AnimationEnd"),
      animationiteration: T2("Animation", "AnimationIteration"),
      animationstart: T2("Animation", "AnimationStart"),
      transitionend: T2("Transition", "TransitionEnd"),
    },
    ul = {},
    I3 = {};
  D &&
    ((I3 = document.createElement("div").style),
    "AnimationEvent" in window ||
      (delete Lt.animationend.animation,
      delete Lt.animationiteration.animation,
      delete Lt.animationstart.animation),
    "TransitionEvent" in window || delete Lt.transitionend.transition);
  function z2(t) {
    if (ul[t]) return ul[t];
    if (!Lt[t]) return t;
    var l = Lt[t],
      r;
    for (r in l) if (l.hasOwnProperty(r) && r in I3) return (ul[t] = l[r]);
    return t;
  }
  var T3 = z2("animationend"),
    z3 = z2("animationiteration"),
    P3 = z2("animationstart"),
    H3 = z2("transitionend"),
    W3 = new Map(),
    O3 =
      "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(
        " ",
      );
  function D1(t, l) {
    (W3.set(t, l), M(l, [t]));
  }
  for (var xl = 0; xl < O3.length; xl++) {
    var hl = O3[xl],
      qs = hl.toLowerCase(),
      ea = hl[0].toUpperCase() + hl.slice(1);
    D1(qs, "on" + ea);
  }
  (D1(T3, "onAnimationEnd"),
    D1(z3, "onAnimationIteration"),
    D1(P3, "onAnimationStart"),
    D1("dblclick", "onDoubleClick"),
    D1("focusin", "onFocus"),
    D1("focusout", "onBlur"),
    D1(H3, "onTransitionEnd"),
    P("onMouseEnter", ["mouseout", "mouseover"]),
    P("onMouseLeave", ["mouseout", "mouseover"]),
    P("onPointerEnter", ["pointerout", "pointerover"]),
    P("onPointerLeave", ["pointerout", "pointerover"]),
    M(
      "onChange",
      "change click focusin focusout input keydown keyup selectionchange".split(
        " ",
      ),
    ),
    M(
      "onSelect",
      "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(
        " ",
      ),
    ),
    M("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]),
    M(
      "onCompositionEnd",
      "compositionend focusout keydown keypress keyup mousedown".split(" "),
    ),
    M(
      "onCompositionStart",
      "compositionstart focusout keydown keypress keyup mousedown".split(" "),
    ),
    M(
      "onCompositionUpdate",
      "compositionupdate focusout keydown keypress keyup mousedown".split(" "),
    ));
  var t2 =
      "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(
        " ",
      ),
    ta = new Set(
      "cancel close invalid load scroll toggle".split(" ").concat(t2),
    );
  function U3(t, l, r) {
    var n = t.type || "unknown-event";
    ((t.currentTarget = r), qn(n, l, void 0, t), (t.currentTarget = null));
  }
  function Q3(t, l) {
    l = (l & 4) !== 0;
    for (var r = 0; r < t.length; r++) {
      var n = t[r],
        s = n.event;
      n = n.listeners;
      e: {
        var a = void 0;
        if (l)
          for (var o = n.length - 1; 0 <= o; o--) {
            var d = n[o],
              c = d.instance,
              v = d.currentTarget;
            if (((d = d.listener), c !== a && s.isPropagationStopped()))
              break e;
            (U3(s, d, v), (a = c));
          }
        else
          for (o = 0; o < n.length; o++) {
            if (
              ((d = n[o]),
              (c = d.instance),
              (v = d.currentTarget),
              (d = d.listener),
              c !== a && s.isPropagationStopped())
            )
              break e;
            (U3(s, d, v), (a = c));
          }
      }
    }
    if (M2) throw ((t = U0), (M2 = !1), (U0 = null), t);
  }
  function ie(t, l) {
    var r = l[bl];
    r === void 0 && (r = l[bl] = new Set());
    var n = t + "__bubble";
    r.has(n) || ($3(l, t, 2, !1), r.add(n));
  }
  function vl(t, l, r) {
    var n = 0;
    (l && (n |= 4), $3(r, t, n, l));
  }
  var P2 = "_reactListening" + Math.random().toString(36).slice(2);
  function l2(t) {
    if (!t[P2]) {
      ((t[P2] = !0),
        k.forEach(function (r) {
          r !== "selectionchange" && (ta.has(r) || vl(r, !1, t), vl(r, !0, t));
        }));
      var l = t.nodeType === 9 ? t : t.ownerDocument;
      l === null || l[P2] || ((l[P2] = !0), vl("selectionchange", !1, l));
    }
  }
  function $3(t, l, r, n) {
    switch (L3(l)) {
      case 1:
        var s = hs;
        break;
      case 4:
        s = vs;
        break;
      default:
        s = q0;
    }
    ((r = s.bind(null, l, r, t)),
      (s = void 0),
      !O0 ||
        (l !== "touchstart" && l !== "touchmove" && l !== "wheel") ||
        (s = !0),
      n
        ? s !== void 0
          ? t.addEventListener(l, r, { capture: !0, passive: s })
          : t.addEventListener(l, r, !0)
        : s !== void 0
          ? t.addEventListener(l, r, { passive: s })
          : t.addEventListener(l, r, !1));
  }
  function Ll(t, l, r, n, s) {
    var a = n;
    if ((l & 1) === 0 && (l & 2) === 0 && n !== null)
      e: for (;;) {
        if (n === null) return;
        var o = n.tag;
        if (o === 3 || o === 4) {
          var d = n.stateNode.containerInfo;
          if (d === s || (d.nodeType === 8 && d.parentNode === s)) break;
          if (o === 4)
            for (o = n.return; o !== null; ) {
              var c = o.tag;
              if (
                (c === 3 || c === 4) &&
                ((c = o.stateNode.containerInfo),
                c === s || (c.nodeType === 8 && c.parentNode === s))
              )
                return;
              o = o.return;
            }
          for (; d !== null; ) {
            if (((o = J1(d)), o === null)) return;
            if (((c = o.tag), c === 5 || c === 6)) {
              n = a = o;
              continue e;
            }
            d = d.parentNode;
          }
        }
        n = n.return;
      }
    qr(function () {
      var v = a,
        m = P0(r),
        _ = [];
      e: {
        var j = W3.get(t);
        if (j !== void 0) {
          var w = ll,
            B = t;
          switch (t) {
            case "keypress":
              if (D2(r) === 0) break e;
            case "keydown":
            case "keyup":
              w = ys;
              break;
            case "focusin":
              ((B = "focus"), (w = nl));
              break;
            case "focusout":
              ((B = "blur"), (w = nl));
              break;
            case "beforeblur":
            case "afterblur":
              w = nl;
              break;
            case "click":
              if (r.button === 2) break e;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              w = m3;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              w = Vs;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              w = Gs;
              break;
            case T3:
            case z3:
            case P3:
              w = _s;
              break;
            case H3:
              w = Ds;
              break;
            case "scroll":
              w = Ls;
              break;
            case "wheel":
              w = Ss;
              break;
            case "copy":
            case "cut":
            case "paste":
              w = Fs;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              w = _3;
          }
          var E = (l & 4) !== 0,
            he = !E && t === "scroll",
            x = E ? (j !== null ? j + "Capture" : null) : j;
          E = [];
          for (var p = v, h; p !== null; ) {
            h = p;
            var b = h.stateNode;
            if (
              (h.tag === 5 &&
                b !== null &&
                ((h = b),
                x !== null &&
                  ((b = St(p, x)), b != null && E.push(r2(p, b, h)))),
              he)
            )
              break;
            p = p.return;
          }
          0 < E.length &&
            ((j = new w(j, B, null, r, m)), _.push({ event: j, listeners: E }));
        }
      }
      if ((l & 7) === 0) {
        e: {
          if (
            ((j = t === "mouseover" || t === "pointerover"),
            (w = t === "mouseout" || t === "pointerout"),
            j &&
              r !== z0 &&
              (B = r.relatedTarget || r.fromElement) &&
              (J1(B) || B[_1]))
          )
            break e;
          if (
            (w || j) &&
            ((j =
              m.window === m
                ? m
                : (j = m.ownerDocument)
                  ? j.defaultView || j.parentWindow
                  : window),
            w
              ? ((B = r.relatedTarget || r.toElement),
                (w = v),
                (B = B ? J1(B) : null),
                B !== null &&
                  ((he = K1(B)), B !== he || (B.tag !== 5 && B.tag !== 6)) &&
                  (B = null))
              : ((w = null), (B = v)),
            w !== B)
          ) {
            if (
              ((E = m3),
              (b = "onMouseLeave"),
              (x = "onMouseEnter"),
              (p = "mouse"),
              (t === "pointerout" || t === "pointerover") &&
                ((E = _3),
                (b = "onPointerLeave"),
                (x = "onPointerEnter"),
                (p = "pointer")),
              (he = w == null ? j : mt(w)),
              (h = B == null ? j : mt(B)),
              (j = new E(b, p + "leave", w, r, m)),
              (j.target = he),
              (j.relatedTarget = h),
              (b = null),
              J1(m) === v &&
                ((E = new E(x, p + "enter", B, r, m)),
                (E.target = h),
                (E.relatedTarget = he),
                (b = E)),
              (he = b),
              w && B)
            )
              t: {
                for (E = w, x = B, p = 0, h = E; h; h = jt(h)) p++;
                for (h = 0, b = x; b; b = jt(b)) h++;
                for (; 0 < p - h; ) ((E = jt(E)), p--);
                for (; 0 < h - p; ) ((x = jt(x)), h--);
                for (; p--; ) {
                  if (E === x || (x !== null && E === x.alternate)) break t;
                  ((E = jt(E)), (x = jt(x)));
                }
                E = null;
              }
            else E = null;
            (w !== null && X3(_, j, w, E, !1),
              B !== null && he !== null && X3(_, he, B, E, !0));
          }
        }
        e: {
          if (
            ((j = v ? mt(v) : window),
            (w = j.nodeName && j.nodeName.toLowerCase()),
            w === "select" || (w === "input" && j.type === "file"))
          )
            var G = Os;
          else if (k3(j))
            if (Z3) G = Xs;
            else {
              G = Qs;
              var R = Us;
            }
          else
            (w = j.nodeName) &&
              w.toLowerCase() === "input" &&
              (j.type === "checkbox" || j.type === "radio") &&
              (G = $s);
          if (G && (G = G(t, v))) {
            N3(_, G, r, m);
            break e;
          }
          (R && R(t, j, v),
            t === "focusout" &&
              (R = j._wrapperState) &&
              R.controlled &&
              j.type === "number" &&
              D0(j, "number", j.value));
        }
        switch (((R = v ? mt(v) : window), t)) {
          case "focusin":
            (k3(R) || R.contentEditable === "true") &&
              ((vt = R), (pl = v), (e2 = null));
            break;
          case "focusout":
            e2 = pl = vt = null;
            break;
          case "mousedown":
            fl = !0;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            ((fl = !1), S3(_, r, m));
            break;
          case "selectionchange":
            if (Js) break;
          case "keydown":
          case "keyup":
            S3(_, r, m);
        }
        var S;
        if (al)
          e: {
            switch (t) {
              case "compositionstart":
                var T = "onCompositionStart";
                break e;
              case "compositionend":
                T = "onCompositionEnd";
                break e;
              case "compositionupdate":
                T = "onCompositionUpdate";
                break e;
            }
            T = void 0;
          }
        else
          ht
            ? C3(t, r) && (T = "onCompositionEnd")
            : t === "keydown" &&
              r.keyCode === 229 &&
              (T = "onCompositionStart");
        (T &&
          (b3 &&
            r.locale !== "ko" &&
            (ht || T !== "onCompositionStart"
              ? T === "onCompositionEnd" && ht && (S = j3())
              : ((A1 = m),
                (tl = "value" in A1 ? A1.value : A1.textContent),
                (ht = !0))),
          (R = H2(v, T)),
          0 < R.length &&
            ((T = new g3(T, t, null, r, m)),
            _.push({ event: T, listeners: R }),
            S ? (T.data = S) : ((S = w3(r)), S !== null && (T.data = S)))),
          (S = Ts ? zs(t, r) : Ps(t, r)) &&
            ((v = H2(v, "onBeforeInput")),
            0 < v.length &&
              ((m = new g3("onBeforeInput", "beforeinput", null, r, m)),
              _.push({ event: m, listeners: v }),
              (m.data = S))));
      }
      Q3(_, l);
    });
  }
  function r2(t, l, r) {
    return { instance: t, listener: l, currentTarget: r };
  }
  function H2(t, l) {
    for (var r = l + "Capture", n = []; t !== null; ) {
      var s = t,
        a = s.stateNode;
      (s.tag === 5 &&
        a !== null &&
        ((s = a),
        (a = St(t, r)),
        a != null && n.unshift(r2(t, a, s)),
        (a = St(t, l)),
        a != null && n.push(r2(t, a, s))),
        (t = t.return));
    }
    return n;
  }
  function jt(t) {
    if (t === null) return null;
    do t = t.return;
    while (t && t.tag !== 5);
    return t || null;
  }
  function X3(t, l, r, n, s) {
    for (var a = l._reactName, o = []; r !== null && r !== n; ) {
      var d = r,
        c = d.alternate,
        v = d.stateNode;
      if (c !== null && c === n) break;
      (d.tag === 5 &&
        v !== null &&
        ((d = v),
        s
          ? ((c = St(r, a)), c != null && o.unshift(r2(r, c, d)))
          : s || ((c = St(r, a)), c != null && o.push(r2(r, c, d)))),
        (r = r.return));
    }
    o.length !== 0 && t.push({ event: l, listeners: o });
  }
  var la = /\r\n?/g,
    ra = /\u0000|\uFFFD/g;
  function Y3(t) {
    return (typeof t == "string" ? t : "" + t)
      .replace(
        la,
        `
`,
      )
      .replace(ra, "");
  }
  function W2(t, l, r) {
    if (((l = Y3(l)), Y3(t) !== l && r)) throw Error(u(425));
  }
  function O2() {}
  var jl = null,
    Vl = null;
  function ml(t, l) {
    return (
      t === "textarea" ||
      t === "noscript" ||
      typeof l.children == "string" ||
      typeof l.children == "number" ||
      (typeof l.dangerouslySetInnerHTML == "object" &&
        l.dangerouslySetInnerHTML !== null &&
        l.dangerouslySetInnerHTML.__html != null)
    );
  }
  var gl = typeof setTimeout == "function" ? setTimeout : void 0,
    ia = typeof clearTimeout == "function" ? clearTimeout : void 0,
    K3 = typeof Promise == "function" ? Promise : void 0,
    na =
      typeof queueMicrotask == "function"
        ? queueMicrotask
        : typeof K3 < "u"
          ? function (t) {
              return K3.resolve(null).then(t).catch(sa);
            }
          : gl;
  function sa(t) {
    setTimeout(function () {
      throw t;
    });
  }
  function _l(t, l) {
    var r = l,
      n = 0;
    do {
      var s = r.nextSibling;
      if ((t.removeChild(r), s && s.nodeType === 8))
        if (((r = s.data), r === "/$")) {
          if (n === 0) {
            (t.removeChild(s), Qt(l));
            return;
          }
          n--;
        } else (r !== "$" && r !== "$?" && r !== "$!") || n++;
      r = s;
    } while (r);
    Qt(l);
  }
  function R1(t) {
    for (; t != null; t = t.nextSibling) {
      var l = t.nodeType;
      if (l === 1 || l === 3) break;
      if (l === 8) {
        if (((l = t.data), l === "$" || l === "$!" || l === "$?")) break;
        if (l === "/$") return null;
      }
    }
    return t;
  }
  function J3(t) {
    t = t.previousSibling;
    for (var l = 0; t; ) {
      if (t.nodeType === 8) {
        var r = t.data;
        if (r === "$" || r === "$!" || r === "$?") {
          if (l === 0) return t;
          l--;
        } else r === "/$" && l++;
      }
      t = t.previousSibling;
    }
    return null;
  }
  var Vt = Math.random().toString(36).slice(2),
    x1 = "__reactFiber$" + Vt,
    i2 = "__reactProps$" + Vt,
    _1 = "__reactContainer$" + Vt,
    bl = "__reactEvents$" + Vt,
    aa = "__reactListeners$" + Vt,
    oa = "__reactHandles$" + Vt;
  function J1(t) {
    var l = t[x1];
    if (l) return l;
    for (var r = t.parentNode; r; ) {
      if ((l = r[_1] || r[x1])) {
        if (
          ((r = l.alternate),
          l.child !== null || (r !== null && r.child !== null))
        )
          for (t = J3(t); t !== null; ) {
            if ((r = t[x1])) return r;
            t = J3(t);
          }
        return l;
      }
      ((t = r), (r = t.parentNode));
    }
    return null;
  }
  function n2(t) {
    return (
      (t = t[x1] || t[_1]),
      !t || (t.tag !== 5 && t.tag !== 6 && t.tag !== 13 && t.tag !== 3)
        ? null
        : t
    );
  }
  function mt(t) {
    if (t.tag === 5 || t.tag === 6) return t.stateNode;
    throw Error(u(33));
  }
  function U2(t) {
    return t[i2] || null;
  }
  var Fl = [],
    gt = -1;
  function S1(t) {
    return { current: t };
  }
  function ne(t) {
    0 > gt || ((t.current = Fl[gt]), (Fl[gt] = null), gt--);
  }
  function re(t, l) {
    (gt++, (Fl[gt] = t.current), (t.current = l));
  }
  var I1 = {},
    Me = S1(I1),
    Ge = S1(!1),
    q1 = I1;
  function _t(t, l) {
    var r = t.type.contextTypes;
    if (!r) return I1;
    var n = t.stateNode;
    if (n && n.__reactInternalMemoizedUnmaskedChildContext === l)
      return n.__reactInternalMemoizedMaskedChildContext;
    var s = {},
      a;
    for (a in r) s[a] = l[a];
    return (
      n &&
        ((t = t.stateNode),
        (t.__reactInternalMemoizedUnmaskedChildContext = l),
        (t.__reactInternalMemoizedMaskedChildContext = s)),
      s
    );
  }
  function Ae(t) {
    return ((t = t.childContextTypes), t != null);
  }
  function Q2() {
    (ne(Ge), ne(Me));
  }
  function q3(t, l, r) {
    if (Me.current !== I1) throw Error(u(168));
    (re(Me, l), re(Ge, r));
  }
  function ei(t, l, r) {
    var n = t.stateNode;
    if (((l = l.childContextTypes), typeof n.getChildContext != "function"))
      return r;
    n = n.getChildContext();
    for (var s in n) if (!(s in l)) throw Error(u(108, le(t) || "Unknown", s));
    return y({}, r, n);
  }
  function $2(t) {
    return (
      (t =
        ((t = t.stateNode) && t.__reactInternalMemoizedMergedChildContext) ||
        I1),
      (q1 = Me.current),
      re(Me, t),
      re(Ge, Ge.current),
      !0
    );
  }
  function ti(t, l, r) {
    var n = t.stateNode;
    if (!n) throw Error(u(169));
    (r
      ? ((t = ei(t, l, q1)),
        (n.__reactInternalMemoizedMergedChildContext = t),
        ne(Ge),
        ne(Me),
        re(Me, t))
      : ne(Ge),
      re(Ge, r));
  }
  var b1 = null,
    X2 = !1,
    Ml = !1;
  function li(t) {
    b1 === null ? (b1 = [t]) : b1.push(t);
  }
  function da(t) {
    ((X2 = !0), li(t));
  }
  function T1() {
    if (!Ml && b1 !== null) {
      Ml = !0;
      var t = 0,
        l = ee;
      try {
        var r = b1;
        for (ee = 1; t < r.length; t++) {
          var n = r[t];
          do n = n(!0);
          while (n !== null);
        }
        ((b1 = null), (X2 = !1));
      } catch (s) {
        throw (b1 !== null && (b1 = b1.slice(t + 1)), i3(Q0, T1), s);
      } finally {
        ((ee = l), (Ml = !1));
      }
    }
    return null;
  }
  var bt = [],
    Ft = 0,
    Y2 = null,
    K2 = 0,
    $e = [],
    Xe = 0,
    et = null,
    F1 = 1,
    M1 = "";
  function tt(t, l) {
    ((bt[Ft++] = K2), (bt[Ft++] = Y2), (Y2 = t), (K2 = l));
  }
  function ri(t, l, r) {
    (($e[Xe++] = F1), ($e[Xe++] = M1), ($e[Xe++] = et), (et = t));
    var n = F1;
    t = M1;
    var s = 32 - r1(n) - 1;
    ((n &= ~(1 << s)), (r += 1));
    var a = 32 - r1(l) + s;
    if (30 < a) {
      var o = s - (s % 5);
      ((a = (n & ((1 << o) - 1)).toString(32)),
        (n >>= o),
        (s -= o),
        (F1 = (1 << (32 - r1(l) + s)) | (r << s) | n),
        (M1 = a + t));
    } else ((F1 = (1 << a) | (r << s) | n), (M1 = t));
  }
  function Cl(t) {
    t.return !== null && (tt(t, 1), ri(t, 1, 0));
  }
  function wl(t) {
    for (; t === Y2; )
      ((Y2 = bt[--Ft]), (bt[Ft] = null), (K2 = bt[--Ft]), (bt[Ft] = null));
    for (; t === et; )
      ((et = $e[--Xe]),
        ($e[Xe] = null),
        (M1 = $e[--Xe]),
        ($e[Xe] = null),
        (F1 = $e[--Xe]),
        ($e[Xe] = null));
  }
  var He = null,
    We = null,
    oe = !1,
    n1 = null;
  function ii(t, l) {
    var r = qe(5, null, null, 0);
    ((r.elementType = "DELETED"),
      (r.stateNode = l),
      (r.return = t),
      (l = t.deletions),
      l === null ? ((t.deletions = [r]), (t.flags |= 16)) : l.push(r));
  }
  function ni(t, l) {
    switch (t.tag) {
      case 5:
        var r = t.type;
        return (
          (l =
            l.nodeType !== 1 || r.toLowerCase() !== l.nodeName.toLowerCase()
              ? null
              : l),
          l !== null
            ? ((t.stateNode = l), (He = t), (We = R1(l.firstChild)), !0)
            : !1
        );
      case 6:
        return (
          (l = t.pendingProps === "" || l.nodeType !== 3 ? null : l),
          l !== null ? ((t.stateNode = l), (He = t), (We = null), !0) : !1
        );
      case 13:
        return (
          (l = l.nodeType !== 8 ? null : l),
          l !== null
            ? ((r = et !== null ? { id: F1, overflow: M1 } : null),
              (t.memoizedState = {
                dehydrated: l,
                treeContext: r,
                retryLane: 1073741824,
              }),
              (r = qe(18, null, null, 0)),
              (r.stateNode = l),
              (r.return = t),
              (t.child = r),
              (He = t),
              (We = null),
              !0)
            : !1
        );
      default:
        return !1;
    }
  }
  function kl(t) {
    return (t.mode & 1) !== 0 && (t.flags & 128) === 0;
  }
  function Nl(t) {
    if (oe) {
      var l = We;
      if (l) {
        var r = l;
        if (!ni(t, l)) {
          if (kl(t)) throw Error(u(418));
          l = R1(r.nextSibling);
          var n = He;
          l && ni(t, l)
            ? ii(n, r)
            : ((t.flags = (t.flags & -4097) | 2), (oe = !1), (He = t));
        }
      } else {
        if (kl(t)) throw Error(u(418));
        ((t.flags = (t.flags & -4097) | 2), (oe = !1), (He = t));
      }
    }
  }
  function si(t) {
    for (
      t = t.return;
      t !== null && t.tag !== 5 && t.tag !== 3 && t.tag !== 13;
    )
      t = t.return;
    He = t;
  }
  function J2(t) {
    if (t !== He) return !1;
    if (!oe) return (si(t), (oe = !0), !1);
    var l;
    if (
      ((l = t.tag !== 3) &&
        !(l = t.tag !== 5) &&
        ((l = t.type),
        (l = l !== "head" && l !== "body" && !ml(t.type, t.memoizedProps))),
      l && (l = We))
    ) {
      if (kl(t)) throw (ai(), Error(u(418)));
      for (; l; ) (ii(t, l), (l = R1(l.nextSibling)));
    }
    if ((si(t), t.tag === 13)) {
      if (((t = t.memoizedState), (t = t !== null ? t.dehydrated : null), !t))
        throw Error(u(317));
      e: {
        for (t = t.nextSibling, l = 0; t; ) {
          if (t.nodeType === 8) {
            var r = t.data;
            if (r === "/$") {
              if (l === 0) {
                We = R1(t.nextSibling);
                break e;
              }
              l--;
            } else (r !== "$" && r !== "$!" && r !== "$?") || l++;
          }
          t = t.nextSibling;
        }
        We = null;
      }
    } else We = He ? R1(t.stateNode.nextSibling) : null;
    return !0;
  }
  function ai() {
    for (var t = We; t; ) t = R1(t.nextSibling);
  }
  function Mt() {
    ((We = He = null), (oe = !1));
  }
  function Zl(t) {
    n1 === null ? (n1 = [t]) : n1.push(t);
  }
  var ca = Fe.ReactCurrentBatchConfig;
  function s2(t, l, r) {
    if (
      ((t = r.ref),
      t !== null && typeof t != "function" && typeof t != "object")
    ) {
      if (r._owner) {
        if (((r = r._owner), r)) {
          if (r.tag !== 1) throw Error(u(309));
          var n = r.stateNode;
        }
        if (!n) throw Error(u(147, t));
        var s = n,
          a = "" + t;
        return l !== null &&
          l.ref !== null &&
          typeof l.ref == "function" &&
          l.ref._stringRef === a
          ? l.ref
          : ((l = function (o) {
              var d = s.refs;
              o === null ? delete d[a] : (d[a] = o);
            }),
            (l._stringRef = a),
            l);
      }
      if (typeof t != "string") throw Error(u(284));
      if (!r._owner) throw Error(u(290, t));
    }
    return t;
  }
  function q2(t, l) {
    throw (
      (t = Object.prototype.toString.call(l)),
      Error(
        u(
          31,
          t === "[object Object]"
            ? "object with keys {" + Object.keys(l).join(", ") + "}"
            : t,
        ),
      )
    );
  }
  function oi(t) {
    var l = t._init;
    return l(t._payload);
  }
  function di(t) {
    function l(x, p) {
      if (t) {
        var h = x.deletions;
        h === null ? ((x.deletions = [p]), (x.flags |= 16)) : h.push(p);
      }
    }
    function r(x, p) {
      if (!t) return null;
      for (; p !== null; ) (l(x, p), (p = p.sibling));
      return null;
    }
    function n(x, p) {
      for (x = new Map(); p !== null; )
        (p.key !== null ? x.set(p.key, p) : x.set(p.index, p), (p = p.sibling));
      return x;
    }
    function s(x, p) {
      return ((x = $1(x, p)), (x.index = 0), (x.sibling = null), x);
    }
    function a(x, p, h) {
      return (
        (x.index = h),
        t
          ? ((h = x.alternate),
            h !== null
              ? ((h = h.index), h < p ? ((x.flags |= 2), p) : h)
              : ((x.flags |= 2), p))
          : ((x.flags |= 1048576), p)
      );
    }
    function o(x) {
      return (t && x.alternate === null && (x.flags |= 2), x);
    }
    function d(x, p, h, b) {
      return p === null || p.tag !== 6
        ? ((p = gr(h, x.mode, b)), (p.return = x), p)
        : ((p = s(p, h)), (p.return = x), p);
    }
    function c(x, p, h, b) {
      var G = h.type;
      return G === Be
        ? m(x, p, h.props.children, b, h.key)
        : p !== null &&
            (p.elementType === G ||
              (typeof G == "object" &&
                G !== null &&
                G.$$typeof === Ee &&
                oi(G) === p.type))
          ? ((b = s(p, h.props)), (b.ref = s2(x, p, h)), (b.return = x), b)
          : ((b = b0(h.type, h.key, h.props, null, x.mode, b)),
            (b.ref = s2(x, p, h)),
            (b.return = x),
            b);
    }
    function v(x, p, h, b) {
      return p === null ||
        p.tag !== 4 ||
        p.stateNode.containerInfo !== h.containerInfo ||
        p.stateNode.implementation !== h.implementation
        ? ((p = _r(h, x.mode, b)), (p.return = x), p)
        : ((p = s(p, h.children || [])), (p.return = x), p);
    }
    function m(x, p, h, b, G) {
      return p === null || p.tag !== 7
        ? ((p = dt(h, x.mode, b, G)), (p.return = x), p)
        : ((p = s(p, h)), (p.return = x), p);
    }
    function _(x, p, h) {
      if ((typeof p == "string" && p !== "") || typeof p == "number")
        return ((p = gr("" + p, x.mode, h)), (p.return = x), p);
      if (typeof p == "object" && p !== null) {
        switch (p.$$typeof) {
          case t1:
            return (
              (h = b0(p.type, p.key, p.props, null, x.mode, h)),
              (h.ref = s2(x, null, p)),
              (h.return = x),
              h
            );
          case Ne:
            return ((p = _r(p, x.mode, h)), (p.return = x), p);
          case Ee:
            var b = p._init;
            return _(x, b(p._payload), h);
        }
        if (At(p) || I(p))
          return ((p = dt(p, x.mode, h, null)), (p.return = x), p);
        q2(x, p);
      }
      return null;
    }
    function j(x, p, h, b) {
      var G = p !== null ? p.key : null;
      if ((typeof h == "string" && h !== "") || typeof h == "number")
        return G !== null ? null : d(x, p, "" + h, b);
      if (typeof h == "object" && h !== null) {
        switch (h.$$typeof) {
          case t1:
            return h.key === G ? c(x, p, h, b) : null;
          case Ne:
            return h.key === G ? v(x, p, h, b) : null;
          case Ee:
            return ((G = h._init), j(x, p, G(h._payload), b));
        }
        if (At(h) || I(h)) return G !== null ? null : m(x, p, h, b, null);
        q2(x, h);
      }
      return null;
    }
    function w(x, p, h, b, G) {
      if ((typeof b == "string" && b !== "") || typeof b == "number")
        return ((x = x.get(h) || null), d(p, x, "" + b, G));
      if (typeof b == "object" && b !== null) {
        switch (b.$$typeof) {
          case t1:
            return (
              (x = x.get(b.key === null ? h : b.key) || null),
              c(p, x, b, G)
            );
          case Ne:
            return (
              (x = x.get(b.key === null ? h : b.key) || null),
              v(p, x, b, G)
            );
          case Ee:
            var R = b._init;
            return w(x, p, h, R(b._payload), G);
        }
        if (At(b) || I(b)) return ((x = x.get(h) || null), m(p, x, b, G, null));
        q2(p, b);
      }
      return null;
    }
    function B(x, p, h, b) {
      for (
        var G = null, R = null, S = p, T = (p = 0), ge = null;
        S !== null && T < h.length;
        T++
      ) {
        S.index > T ? ((ge = S), (S = null)) : (ge = S.sibling);
        var J = j(x, S, h[T], b);
        if (J === null) {
          S === null && (S = ge);
          break;
        }
        (t && S && J.alternate === null && l(x, S),
          (p = a(J, p, T)),
          R === null ? (G = J) : (R.sibling = J),
          (R = J),
          (S = ge));
      }
      if (T === h.length) return (r(x, S), oe && tt(x, T), G);
      if (S === null) {
        for (; T < h.length; T++)
          ((S = _(x, h[T], b)),
            S !== null &&
              ((p = a(S, p, T)),
              R === null ? (G = S) : (R.sibling = S),
              (R = S)));
        return (oe && tt(x, T), G);
      }
      for (S = n(x, S); T < h.length; T++)
        ((ge = w(S, x, T, h[T], b)),
          ge !== null &&
            (t &&
              ge.alternate !== null &&
              S.delete(ge.key === null ? T : ge.key),
            (p = a(ge, p, T)),
            R === null ? (G = ge) : (R.sibling = ge),
            (R = ge)));
      return (
        t &&
          S.forEach(function (X1) {
            return l(x, X1);
          }),
        oe && tt(x, T),
        G
      );
    }
    function E(x, p, h, b) {
      var G = I(h);
      if (typeof G != "function") throw Error(u(150));
      if (((h = G.call(h)), h == null)) throw Error(u(151));
      for (
        var R = (G = null), S = p, T = (p = 0), ge = null, J = h.next();
        S !== null && !J.done;
        T++, J = h.next()
      ) {
        S.index > T ? ((ge = S), (S = null)) : (ge = S.sibling);
        var X1 = j(x, S, J.value, b);
        if (X1 === null) {
          S === null && (S = ge);
          break;
        }
        (t && S && X1.alternate === null && l(x, S),
          (p = a(X1, p, T)),
          R === null ? (G = X1) : (R.sibling = X1),
          (R = X1),
          (S = ge));
      }
      if (J.done) return (r(x, S), oe && tt(x, T), G);
      if (S === null) {
        for (; !J.done; T++, J = h.next())
          ((J = _(x, J.value, b)),
            J !== null &&
              ((p = a(J, p, T)),
              R === null ? (G = J) : (R.sibling = J),
              (R = J)));
        return (oe && tt(x, T), G);
      }
      for (S = n(x, S); !J.done; T++, J = h.next())
        ((J = w(S, x, T, J.value, b)),
          J !== null &&
            (t && J.alternate !== null && S.delete(J.key === null ? T : J.key),
            (p = a(J, p, T)),
            R === null ? (G = J) : (R.sibling = J),
            (R = J)));
      return (
        t &&
          S.forEach(function (Ha) {
            return l(x, Ha);
          }),
        oe && tt(x, T),
        G
      );
    }
    function he(x, p, h, b) {
      if (
        (typeof h == "object" &&
          h !== null &&
          h.type === Be &&
          h.key === null &&
          (h = h.props.children),
        typeof h == "object" && h !== null)
      ) {
        switch (h.$$typeof) {
          case t1:
            e: {
              for (var G = h.key, R = p; R !== null; ) {
                if (R.key === G) {
                  if (((G = h.type), G === Be)) {
                    if (R.tag === 7) {
                      (r(x, R.sibling),
                        (p = s(R, h.props.children)),
                        (p.return = x),
                        (x = p));
                      break e;
                    }
                  } else if (
                    R.elementType === G ||
                    (typeof G == "object" &&
                      G !== null &&
                      G.$$typeof === Ee &&
                      oi(G) === R.type)
                  ) {
                    (r(x, R.sibling),
                      (p = s(R, h.props)),
                      (p.ref = s2(x, R, h)),
                      (p.return = x),
                      (x = p));
                    break e;
                  }
                  r(x, R);
                  break;
                } else l(x, R);
                R = R.sibling;
              }
              h.type === Be
                ? ((p = dt(h.props.children, x.mode, b, h.key)),
                  (p.return = x),
                  (x = p))
                : ((b = b0(h.type, h.key, h.props, null, x.mode, b)),
                  (b.ref = s2(x, p, h)),
                  (b.return = x),
                  (x = b));
            }
            return o(x);
          case Ne:
            e: {
              for (R = h.key; p !== null; ) {
                if (p.key === R)
                  if (
                    p.tag === 4 &&
                    p.stateNode.containerInfo === h.containerInfo &&
                    p.stateNode.implementation === h.implementation
                  ) {
                    (r(x, p.sibling),
                      (p = s(p, h.children || [])),
                      (p.return = x),
                      (x = p));
                    break e;
                  } else {
                    r(x, p);
                    break;
                  }
                else l(x, p);
                p = p.sibling;
              }
              ((p = _r(h, x.mode, b)), (p.return = x), (x = p));
            }
            return o(x);
          case Ee:
            return ((R = h._init), he(x, p, R(h._payload), b));
        }
        if (At(h)) return B(x, p, h, b);
        if (I(h)) return E(x, p, h, b);
        q2(x, h);
      }
      return (typeof h == "string" && h !== "") || typeof h == "number"
        ? ((h = "" + h),
          p !== null && p.tag === 6
            ? (r(x, p.sibling), (p = s(p, h)), (p.return = x), (x = p))
            : (r(x, p), (p = gr(h, x.mode, b)), (p.return = x), (x = p)),
          o(x))
        : r(x, p);
    }
    return he;
  }
  var Ct = di(!0),
    ci = di(!1),
    e0 = S1(null),
    t0 = null,
    wt = null,
    yl = null;
  function Bl() {
    yl = wt = t0 = null;
  }
  function El(t) {
    var l = e0.current;
    (ne(e0), (t._currentValue = l));
  }
  function Gl(t, l, r) {
    for (; t !== null; ) {
      var n = t.alternate;
      if (
        ((t.childLanes & l) !== l
          ? ((t.childLanes |= l), n !== null && (n.childLanes |= l))
          : n !== null && (n.childLanes & l) !== l && (n.childLanes |= l),
        t === r)
      )
        break;
      t = t.return;
    }
  }
  function kt(t, l) {
    ((t0 = t),
      (yl = wt = null),
      (t = t.dependencies),
      t !== null &&
        t.firstContext !== null &&
        ((t.lanes & l) !== 0 && (De = !0), (t.firstContext = null)));
  }
  function Ye(t) {
    var l = t._currentValue;
    if (yl !== t)
      if (((t = { context: t, memoizedValue: l, next: null }), wt === null)) {
        if (t0 === null) throw Error(u(308));
        ((wt = t), (t0.dependencies = { lanes: 0, firstContext: t }));
      } else wt = wt.next = t;
    return l;
  }
  var lt = null;
  function Al(t) {
    lt === null ? (lt = [t]) : lt.push(t);
  }
  function pi(t, l, r, n) {
    var s = l.interleaved;
    return (
      s === null ? ((r.next = r), Al(l)) : ((r.next = s.next), (s.next = r)),
      (l.interleaved = r),
      C1(t, n)
    );
  }
  function C1(t, l) {
    t.lanes |= l;
    var r = t.alternate;
    for (r !== null && (r.lanes |= l), r = t, t = t.return; t !== null; )
      ((t.childLanes |= l),
        (r = t.alternate),
        r !== null && (r.childLanes |= l),
        (r = t),
        (t = t.return));
    return r.tag === 3 ? r.stateNode : null;
  }
  var z1 = !1;
  function Dl(t) {
    t.updateQueue = {
      baseState: t.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: { pending: null, interleaved: null, lanes: 0 },
      effects: null,
    };
  }
  function fi(t, l) {
    ((t = t.updateQueue),
      l.updateQueue === t &&
        (l.updateQueue = {
          baseState: t.baseState,
          firstBaseUpdate: t.firstBaseUpdate,
          lastBaseUpdate: t.lastBaseUpdate,
          shared: t.shared,
          effects: t.effects,
        }));
  }
  function w1(t, l) {
    return {
      eventTime: t,
      lane: l,
      tag: 0,
      payload: null,
      callback: null,
      next: null,
    };
  }
  function P1(t, l, r) {
    var n = t.updateQueue;
    if (n === null) return null;
    if (((n = n.shared), (X & 2) !== 0)) {
      var s = n.pending;
      return (
        s === null ? (l.next = l) : ((l.next = s.next), (s.next = l)),
        (n.pending = l),
        C1(t, r)
      );
    }
    return (
      (s = n.interleaved),
      s === null ? ((l.next = l), Al(n)) : ((l.next = s.next), (s.next = l)),
      (n.interleaved = l),
      C1(t, r)
    );
  }
  function l0(t, l, r) {
    if (
      ((l = l.updateQueue), l !== null && ((l = l.shared), (r & 4194240) !== 0))
    ) {
      var n = l.lanes;
      ((n &= t.pendingLanes), (r |= n), (l.lanes = r), Y0(t, r));
    }
  }
  function ui(t, l) {
    var r = t.updateQueue,
      n = t.alternate;
    if (n !== null && ((n = n.updateQueue), r === n)) {
      var s = null,
        a = null;
      if (((r = r.firstBaseUpdate), r !== null)) {
        do {
          var o = {
            eventTime: r.eventTime,
            lane: r.lane,
            tag: r.tag,
            payload: r.payload,
            callback: r.callback,
            next: null,
          };
          (a === null ? (s = a = o) : (a = a.next = o), (r = r.next));
        } while (r !== null);
        a === null ? (s = a = l) : (a = a.next = l);
      } else s = a = l;
      ((r = {
        baseState: n.baseState,
        firstBaseUpdate: s,
        lastBaseUpdate: a,
        shared: n.shared,
        effects: n.effects,
      }),
        (t.updateQueue = r));
      return;
    }
    ((t = r.lastBaseUpdate),
      t === null ? (r.firstBaseUpdate = l) : (t.next = l),
      (r.lastBaseUpdate = l));
  }
  function r0(t, l, r, n) {
    var s = t.updateQueue;
    z1 = !1;
    var a = s.firstBaseUpdate,
      o = s.lastBaseUpdate,
      d = s.shared.pending;
    if (d !== null) {
      s.shared.pending = null;
      var c = d,
        v = c.next;
      ((c.next = null), o === null ? (a = v) : (o.next = v), (o = c));
      var m = t.alternate;
      m !== null &&
        ((m = m.updateQueue),
        (d = m.lastBaseUpdate),
        d !== o &&
          (d === null ? (m.firstBaseUpdate = v) : (d.next = v),
          (m.lastBaseUpdate = c)));
    }
    if (a !== null) {
      var _ = s.baseState;
      ((o = 0), (m = v = c = null), (d = a));
      do {
        var j = d.lane,
          w = d.eventTime;
        if ((n & j) === j) {
          m !== null &&
            (m = m.next =
              {
                eventTime: w,
                lane: 0,
                tag: d.tag,
                payload: d.payload,
                callback: d.callback,
                next: null,
              });
          e: {
            var B = t,
              E = d;
            switch (((j = l), (w = r), E.tag)) {
              case 1:
                if (((B = E.payload), typeof B == "function")) {
                  _ = B.call(w, _, j);
                  break e;
                }
                _ = B;
                break e;
              case 3:
                B.flags = (B.flags & -65537) | 128;
              case 0:
                if (
                  ((B = E.payload),
                  (j = typeof B == "function" ? B.call(w, _, j) : B),
                  j == null)
                )
                  break e;
                _ = y({}, _, j);
                break e;
              case 2:
                z1 = !0;
            }
          }
          d.callback !== null &&
            d.lane !== 0 &&
            ((t.flags |= 64),
            (j = s.effects),
            j === null ? (s.effects = [d]) : j.push(d));
        } else
          ((w = {
            eventTime: w,
            lane: j,
            tag: d.tag,
            payload: d.payload,
            callback: d.callback,
            next: null,
          }),
            m === null ? ((v = m = w), (c = _)) : (m = m.next = w),
            (o |= j));
        if (((d = d.next), d === null)) {
          if (((d = s.shared.pending), d === null)) break;
          ((j = d),
            (d = j.next),
            (j.next = null),
            (s.lastBaseUpdate = j),
            (s.shared.pending = null));
        }
      } while (!0);
      if (
        (m === null && (c = _),
        (s.baseState = c),
        (s.firstBaseUpdate = v),
        (s.lastBaseUpdate = m),
        (l = s.shared.interleaved),
        l !== null)
      ) {
        s = l;
        do ((o |= s.lane), (s = s.next));
        while (s !== l);
      } else a === null && (s.shared.lanes = 0);
      ((nt |= o), (t.lanes = o), (t.memoizedState = _));
    }
  }
  function xi(t, l, r) {
    if (((t = l.effects), (l.effects = null), t !== null))
      for (l = 0; l < t.length; l++) {
        var n = t[l],
          s = n.callback;
        if (s !== null) {
          if (((n.callback = null), (n = r), typeof s != "function"))
            throw Error(u(191, s));
          s.call(n);
        }
      }
  }
  var a2 = {},
    h1 = S1(a2),
    o2 = S1(a2),
    d2 = S1(a2);
  function rt(t) {
    if (t === a2) throw Error(u(174));
    return t;
  }
  function Rl(t, l) {
    switch ((re(d2, l), re(o2, t), re(h1, a2), (t = l.nodeType), t)) {
      case 9:
      case 11:
        l = (l = l.documentElement) ? l.namespaceURI : S0(null, "");
        break;
      default:
        ((t = t === 8 ? l.parentNode : l),
          (l = t.namespaceURI || null),
          (t = t.tagName),
          (l = S0(l, t)));
    }
    (ne(h1), re(h1, l));
  }
  function Nt() {
    (ne(h1), ne(o2), ne(d2));
  }
  function hi(t) {
    rt(d2.current);
    var l = rt(h1.current),
      r = S0(l, t.type);
    l !== r && (re(o2, t), re(h1, r));
  }
  function Sl(t) {
    o2.current === t && (ne(h1), ne(o2));
  }
  var de = S1(0);
  function i0(t) {
    for (var l = t; l !== null; ) {
      if (l.tag === 13) {
        var r = l.memoizedState;
        if (
          r !== null &&
          ((r = r.dehydrated), r === null || r.data === "$?" || r.data === "$!")
        )
          return l;
      } else if (l.tag === 19 && l.memoizedProps.revealOrder !== void 0) {
        if ((l.flags & 128) !== 0) return l;
      } else if (l.child !== null) {
        ((l.child.return = l), (l = l.child));
        continue;
      }
      if (l === t) break;
      for (; l.sibling === null; ) {
        if (l.return === null || l.return === t) return null;
        l = l.return;
      }
      ((l.sibling.return = l.return), (l = l.sibling));
    }
    return null;
  }
  var Il = [];
  function Tl() {
    for (var t = 0; t < Il.length; t++)
      Il[t]._workInProgressVersionPrimary = null;
    Il.length = 0;
  }
  var n0 = Fe.ReactCurrentDispatcher,
    zl = Fe.ReactCurrentBatchConfig,
    it = 0,
    ce = null,
    Le = null,
    Ve = null,
    s0 = !1,
    c2 = !1,
    p2 = 0,
    pa = 0;
  function Ce() {
    throw Error(u(321));
  }
  function Pl(t, l) {
    if (l === null) return !1;
    for (var r = 0; r < l.length && r < t.length; r++)
      if (!i1(t[r], l[r])) return !1;
    return !0;
  }
  function Hl(t, l, r, n, s, a) {
    if (
      ((it = a),
      (ce = l),
      (l.memoizedState = null),
      (l.updateQueue = null),
      (l.lanes = 0),
      (n0.current = t === null || t.memoizedState === null ? ha : va),
      (t = r(n, s)),
      c2)
    ) {
      a = 0;
      do {
        if (((c2 = !1), (p2 = 0), 25 <= a)) throw Error(u(301));
        ((a += 1),
          (Ve = Le = null),
          (l.updateQueue = null),
          (n0.current = La),
          (t = r(n, s)));
      } while (c2);
    }
    if (
      ((n0.current = d0),
      (l = Le !== null && Le.next !== null),
      (it = 0),
      (Ve = Le = ce = null),
      (s0 = !1),
      l)
    )
      throw Error(u(300));
    return t;
  }
  function Wl() {
    var t = p2 !== 0;
    return ((p2 = 0), t);
  }
  function v1() {
    var t = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null,
    };
    return (Ve === null ? (ce.memoizedState = Ve = t) : (Ve = Ve.next = t), Ve);
  }
  function Ke() {
    if (Le === null) {
      var t = ce.alternate;
      t = t !== null ? t.memoizedState : null;
    } else t = Le.next;
    var l = Ve === null ? ce.memoizedState : Ve.next;
    if (l !== null) ((Ve = l), (Le = t));
    else {
      if (t === null) throw Error(u(310));
      ((Le = t),
        (t = {
          memoizedState: Le.memoizedState,
          baseState: Le.baseState,
          baseQueue: Le.baseQueue,
          queue: Le.queue,
          next: null,
        }),
        Ve === null ? (ce.memoizedState = Ve = t) : (Ve = Ve.next = t));
    }
    return Ve;
  }
  function f2(t, l) {
    return typeof l == "function" ? l(t) : l;
  }
  function Ol(t) {
    var l = Ke(),
      r = l.queue;
    if (r === null) throw Error(u(311));
    r.lastRenderedReducer = t;
    var n = Le,
      s = n.baseQueue,
      a = r.pending;
    if (a !== null) {
      if (s !== null) {
        var o = s.next;
        ((s.next = a.next), (a.next = o));
      }
      ((n.baseQueue = s = a), (r.pending = null));
    }
    if (s !== null) {
      ((a = s.next), (n = n.baseState));
      var d = (o = null),
        c = null,
        v = a;
      do {
        var m = v.lane;
        if ((it & m) === m)
          (c !== null &&
            (c = c.next =
              {
                lane: 0,
                action: v.action,
                hasEagerState: v.hasEagerState,
                eagerState: v.eagerState,
                next: null,
              }),
            (n = v.hasEagerState ? v.eagerState : t(n, v.action)));
        else {
          var _ = {
            lane: m,
            action: v.action,
            hasEagerState: v.hasEagerState,
            eagerState: v.eagerState,
            next: null,
          };
          (c === null ? ((d = c = _), (o = n)) : (c = c.next = _),
            (ce.lanes |= m),
            (nt |= m));
        }
        v = v.next;
      } while (v !== null && v !== a);
      (c === null ? (o = n) : (c.next = d),
        i1(n, l.memoizedState) || (De = !0),
        (l.memoizedState = n),
        (l.baseState = o),
        (l.baseQueue = c),
        (r.lastRenderedState = n));
    }
    if (((t = r.interleaved), t !== null)) {
      s = t;
      do ((a = s.lane), (ce.lanes |= a), (nt |= a), (s = s.next));
      while (s !== t);
    } else s === null && (r.lanes = 0);
    return [l.memoizedState, r.dispatch];
  }
  function Ul(t) {
    var l = Ke(),
      r = l.queue;
    if (r === null) throw Error(u(311));
    r.lastRenderedReducer = t;
    var n = r.dispatch,
      s = r.pending,
      a = l.memoizedState;
    if (s !== null) {
      r.pending = null;
      var o = (s = s.next);
      do ((a = t(a, o.action)), (o = o.next));
      while (o !== s);
      (i1(a, l.memoizedState) || (De = !0),
        (l.memoizedState = a),
        l.baseQueue === null && (l.baseState = a),
        (r.lastRenderedState = a));
    }
    return [a, n];
  }
  function vi() {}
  function Li(t, l) {
    var r = ce,
      n = Ke(),
      s = l(),
      a = !i1(n.memoizedState, s);
    if (
      (a && ((n.memoizedState = s), (De = !0)),
      (n = n.queue),
      Ql(mi.bind(null, r, n, t), [t]),
      n.getSnapshot !== l || a || (Ve !== null && Ve.memoizedState.tag & 1))
    ) {
      if (
        ((r.flags |= 2048),
        u2(9, Vi.bind(null, r, n, s, l), void 0, null),
        me === null)
      )
        throw Error(u(349));
      (it & 30) !== 0 || ji(r, l, s);
    }
    return s;
  }
  function ji(t, l, r) {
    ((t.flags |= 16384),
      (t = { getSnapshot: l, value: r }),
      (l = ce.updateQueue),
      l === null
        ? ((l = { lastEffect: null, stores: null }),
          (ce.updateQueue = l),
          (l.stores = [t]))
        : ((r = l.stores), r === null ? (l.stores = [t]) : r.push(t)));
  }
  function Vi(t, l, r, n) {
    ((l.value = r), (l.getSnapshot = n), gi(l) && _i(t));
  }
  function mi(t, l, r) {
    return r(function () {
      gi(l) && _i(t);
    });
  }
  function gi(t) {
    var l = t.getSnapshot;
    t = t.value;
    try {
      var r = l();
      return !i1(t, r);
    } catch {
      return !0;
    }
  }
  function _i(t) {
    var l = C1(t, 1);
    l !== null && d1(l, t, 1, -1);
  }
  function bi(t) {
    var l = v1();
    return (
      typeof t == "function" && (t = t()),
      (l.memoizedState = l.baseState = t),
      (t = {
        pending: null,
        interleaved: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: f2,
        lastRenderedState: t,
      }),
      (l.queue = t),
      (t = t.dispatch = xa.bind(null, ce, t)),
      [l.memoizedState, t]
    );
  }
  function u2(t, l, r, n) {
    return (
      (t = { tag: t, create: l, destroy: r, deps: n, next: null }),
      (l = ce.updateQueue),
      l === null
        ? ((l = { lastEffect: null, stores: null }),
          (ce.updateQueue = l),
          (l.lastEffect = t.next = t))
        : ((r = l.lastEffect),
          r === null
            ? (l.lastEffect = t.next = t)
            : ((n = r.next), (r.next = t), (t.next = n), (l.lastEffect = t))),
      t
    );
  }
  function Fi() {
    return Ke().memoizedState;
  }
  function a0(t, l, r, n) {
    var s = v1();
    ((ce.flags |= t),
      (s.memoizedState = u2(1 | l, r, void 0, n === void 0 ? null : n)));
  }
  function o0(t, l, r, n) {
    var s = Ke();
    n = n === void 0 ? null : n;
    var a = void 0;
    if (Le !== null) {
      var o = Le.memoizedState;
      if (((a = o.destroy), n !== null && Pl(n, o.deps))) {
        s.memoizedState = u2(l, r, a, n);
        return;
      }
    }
    ((ce.flags |= t), (s.memoizedState = u2(1 | l, r, a, n)));
  }
  function Mi(t, l) {
    return a0(8390656, 8, t, l);
  }
  function Ql(t, l) {
    return o0(2048, 8, t, l);
  }
  function Ci(t, l) {
    return o0(4, 2, t, l);
  }
  function wi(t, l) {
    return o0(4, 4, t, l);
  }
  function ki(t, l) {
    if (typeof l == "function")
      return (
        (t = t()),
        l(t),
        function () {
          l(null);
        }
      );
    if (l != null)
      return (
        (t = t()),
        (l.current = t),
        function () {
          l.current = null;
        }
      );
  }
  function Ni(t, l, r) {
    return (
      (r = r != null ? r.concat([t]) : null),
      o0(4, 4, ki.bind(null, l, t), r)
    );
  }
  function $l() {}
  function Zi(t, l) {
    var r = Ke();
    l = l === void 0 ? null : l;
    var n = r.memoizedState;
    return n !== null && l !== null && Pl(l, n[1])
      ? n[0]
      : ((r.memoizedState = [t, l]), t);
  }
  function yi(t, l) {
    var r = Ke();
    l = l === void 0 ? null : l;
    var n = r.memoizedState;
    return n !== null && l !== null && Pl(l, n[1])
      ? n[0]
      : ((t = t()), (r.memoizedState = [t, l]), t);
  }
  function Bi(t, l, r) {
    return (it & 21) === 0
      ? (t.baseState && ((t.baseState = !1), (De = !0)), (t.memoizedState = r))
      : (i1(r, l) ||
          ((r = o3()), (ce.lanes |= r), (nt |= r), (t.baseState = !0)),
        l);
  }
  function fa(t, l) {
    var r = ee;
    ((ee = r !== 0 && 4 > r ? r : 4), t(!0));
    var n = zl.transition;
    zl.transition = {};
    try {
      (t(!1), l());
    } finally {
      ((ee = r), (zl.transition = n));
    }
  }
  function Ei() {
    return Ke().memoizedState;
  }
  function ua(t, l, r) {
    var n = U1(t);
    if (
      ((r = {
        lane: n,
        action: r,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      }),
      Gi(t))
    )
      Ai(l, r);
    else if (((r = pi(t, l, r, n)), r !== null)) {
      var s = ye();
      (d1(r, t, n, s), Di(r, l, n));
    }
  }
  function xa(t, l, r) {
    var n = U1(t),
      s = {
        lane: n,
        action: r,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      };
    if (Gi(t)) Ai(l, s);
    else {
      var a = t.alternate;
      if (
        t.lanes === 0 &&
        (a === null || a.lanes === 0) &&
        ((a = l.lastRenderedReducer), a !== null)
      )
        try {
          var o = l.lastRenderedState,
            d = a(o, r);
          if (((s.hasEagerState = !0), (s.eagerState = d), i1(d, o))) {
            var c = l.interleaved;
            (c === null
              ? ((s.next = s), Al(l))
              : ((s.next = c.next), (c.next = s)),
              (l.interleaved = s));
            return;
          }
        } catch {
        } finally {
        }
      ((r = pi(t, l, s, n)),
        r !== null && ((s = ye()), d1(r, t, n, s), Di(r, l, n)));
    }
  }
  function Gi(t) {
    var l = t.alternate;
    return t === ce || (l !== null && l === ce);
  }
  function Ai(t, l) {
    c2 = s0 = !0;
    var r = t.pending;
    (r === null ? (l.next = l) : ((l.next = r.next), (r.next = l)),
      (t.pending = l));
  }
  function Di(t, l, r) {
    if ((r & 4194240) !== 0) {
      var n = l.lanes;
      ((n &= t.pendingLanes), (r |= n), (l.lanes = r), Y0(t, r));
    }
  }
  var d0 = {
      readContext: Ye,
      useCallback: Ce,
      useContext: Ce,
      useEffect: Ce,
      useImperativeHandle: Ce,
      useInsertionEffect: Ce,
      useLayoutEffect: Ce,
      useMemo: Ce,
      useReducer: Ce,
      useRef: Ce,
      useState: Ce,
      useDebugValue: Ce,
      useDeferredValue: Ce,
      useTransition: Ce,
      useMutableSource: Ce,
      useSyncExternalStore: Ce,
      useId: Ce,
      unstable_isNewReconciler: !1,
    },
    ha = {
      readContext: Ye,
      useCallback: function (t, l) {
        return ((v1().memoizedState = [t, l === void 0 ? null : l]), t);
      },
      useContext: Ye,
      useEffect: Mi,
      useImperativeHandle: function (t, l, r) {
        return (
          (r = r != null ? r.concat([t]) : null),
          a0(4194308, 4, ki.bind(null, l, t), r)
        );
      },
      useLayoutEffect: function (t, l) {
        return a0(4194308, 4, t, l);
      },
      useInsertionEffect: function (t, l) {
        return a0(4, 2, t, l);
      },
      useMemo: function (t, l) {
        var r = v1();
        return (
          (l = l === void 0 ? null : l),
          (t = t()),
          (r.memoizedState = [t, l]),
          t
        );
      },
      useReducer: function (t, l, r) {
        var n = v1();
        return (
          (l = r !== void 0 ? r(l) : l),
          (n.memoizedState = n.baseState = l),
          (t = {
            pending: null,
            interleaved: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: t,
            lastRenderedState: l,
          }),
          (n.queue = t),
          (t = t.dispatch = ua.bind(null, ce, t)),
          [n.memoizedState, t]
        );
      },
      useRef: function (t) {
        var l = v1();
        return ((t = { current: t }), (l.memoizedState = t));
      },
      useState: bi,
      useDebugValue: $l,
      useDeferredValue: function (t) {
        return (v1().memoizedState = t);
      },
      useTransition: function () {
        var t = bi(!1),
          l = t[0];
        return ((t = fa.bind(null, t[1])), (v1().memoizedState = t), [l, t]);
      },
      useMutableSource: function () {},
      useSyncExternalStore: function (t, l, r) {
        var n = ce,
          s = v1();
        if (oe) {
          if (r === void 0) throw Error(u(407));
          r = r();
        } else {
          if (((r = l()), me === null)) throw Error(u(349));
          (it & 30) !== 0 || ji(n, l, r);
        }
        s.memoizedState = r;
        var a = { value: r, getSnapshot: l };
        return (
          (s.queue = a),
          Mi(mi.bind(null, n, a, t), [t]),
          (n.flags |= 2048),
          u2(9, Vi.bind(null, n, a, r, l), void 0, null),
          r
        );
      },
      useId: function () {
        var t = v1(),
          l = me.identifierPrefix;
        if (oe) {
          var r = M1,
            n = F1;
          ((r = (n & ~(1 << (32 - r1(n) - 1))).toString(32) + r),
            (l = ":" + l + "R" + r),
            (r = p2++),
            0 < r && (l += "H" + r.toString(32)),
            (l += ":"));
        } else ((r = pa++), (l = ":" + l + "r" + r.toString(32) + ":"));
        return (t.memoizedState = l);
      },
      unstable_isNewReconciler: !1,
    },
    va = {
      readContext: Ye,
      useCallback: Zi,
      useContext: Ye,
      useEffect: Ql,
      useImperativeHandle: Ni,
      useInsertionEffect: Ci,
      useLayoutEffect: wi,
      useMemo: yi,
      useReducer: Ol,
      useRef: Fi,
      useState: function () {
        return Ol(f2);
      },
      useDebugValue: $l,
      useDeferredValue: function (t) {
        var l = Ke();
        return Bi(l, Le.memoizedState, t);
      },
      useTransition: function () {
        var t = Ol(f2)[0],
          l = Ke().memoizedState;
        return [t, l];
      },
      useMutableSource: vi,
      useSyncExternalStore: Li,
      useId: Ei,
      unstable_isNewReconciler: !1,
    },
    La = {
      readContext: Ye,
      useCallback: Zi,
      useContext: Ye,
      useEffect: Ql,
      useImperativeHandle: Ni,
      useInsertionEffect: Ci,
      useLayoutEffect: wi,
      useMemo: yi,
      useReducer: Ul,
      useRef: Fi,
      useState: function () {
        return Ul(f2);
      },
      useDebugValue: $l,
      useDeferredValue: function (t) {
        var l = Ke();
        return Le === null ? (l.memoizedState = t) : Bi(l, Le.memoizedState, t);
      },
      useTransition: function () {
        var t = Ul(f2)[0],
          l = Ke().memoizedState;
        return [t, l];
      },
      useMutableSource: vi,
      useSyncExternalStore: Li,
      useId: Ei,
      unstable_isNewReconciler: !1,
    };
  function s1(t, l) {
    if (t && t.defaultProps) {
      ((l = y({}, l)), (t = t.defaultProps));
      for (var r in t) l[r] === void 0 && (l[r] = t[r]);
      return l;
    }
    return l;
  }
  function Xl(t, l, r, n) {
    ((l = t.memoizedState),
      (r = r(n, l)),
      (r = r == null ? l : y({}, l, r)),
      (t.memoizedState = r),
      t.lanes === 0 && (t.updateQueue.baseState = r));
  }
  var c0 = {
    isMounted: function (t) {
      return (t = t._reactInternals) ? K1(t) === t : !1;
    },
    enqueueSetState: function (t, l, r) {
      t = t._reactInternals;
      var n = ye(),
        s = U1(t),
        a = w1(n, s);
      ((a.payload = l),
        r != null && (a.callback = r),
        (l = P1(t, a, s)),
        l !== null && (d1(l, t, s, n), l0(l, t, s)));
    },
    enqueueReplaceState: function (t, l, r) {
      t = t._reactInternals;
      var n = ye(),
        s = U1(t),
        a = w1(n, s);
      ((a.tag = 1),
        (a.payload = l),
        r != null && (a.callback = r),
        (l = P1(t, a, s)),
        l !== null && (d1(l, t, s, n), l0(l, t, s)));
    },
    enqueueForceUpdate: function (t, l) {
      t = t._reactInternals;
      var r = ye(),
        n = U1(t),
        s = w1(r, n);
      ((s.tag = 2),
        l != null && (s.callback = l),
        (l = P1(t, s, n)),
        l !== null && (d1(l, t, n, r), l0(l, t, n)));
    },
  };
  function Ri(t, l, r, n, s, a, o) {
    return (
      (t = t.stateNode),
      typeof t.shouldComponentUpdate == "function"
        ? t.shouldComponentUpdate(n, a, o)
        : l.prototype && l.prototype.isPureReactComponent
          ? !qt(r, n) || !qt(s, a)
          : !0
    );
  }
  function Si(t, l, r) {
    var n = !1,
      s = I1,
      a = l.contextType;
    return (
      typeof a == "object" && a !== null
        ? (a = Ye(a))
        : ((s = Ae(l) ? q1 : Me.current),
          (n = l.contextTypes),
          (a = (n = n != null) ? _t(t, s) : I1)),
      (l = new l(r, a)),
      (t.memoizedState =
        l.state !== null && l.state !== void 0 ? l.state : null),
      (l.updater = c0),
      (t.stateNode = l),
      (l._reactInternals = t),
      n &&
        ((t = t.stateNode),
        (t.__reactInternalMemoizedUnmaskedChildContext = s),
        (t.__reactInternalMemoizedMaskedChildContext = a)),
      l
    );
  }
  function Ii(t, l, r, n) {
    ((t = l.state),
      typeof l.componentWillReceiveProps == "function" &&
        l.componentWillReceiveProps(r, n),
      typeof l.UNSAFE_componentWillReceiveProps == "function" &&
        l.UNSAFE_componentWillReceiveProps(r, n),
      l.state !== t && c0.enqueueReplaceState(l, l.state, null));
  }
  function Yl(t, l, r, n) {
    var s = t.stateNode;
    ((s.props = r), (s.state = t.memoizedState), (s.refs = {}), Dl(t));
    var a = l.contextType;
    (typeof a == "object" && a !== null
      ? (s.context = Ye(a))
      : ((a = Ae(l) ? q1 : Me.current), (s.context = _t(t, a))),
      (s.state = t.memoizedState),
      (a = l.getDerivedStateFromProps),
      typeof a == "function" && (Xl(t, l, a, r), (s.state = t.memoizedState)),
      typeof l.getDerivedStateFromProps == "function" ||
        typeof s.getSnapshotBeforeUpdate == "function" ||
        (typeof s.UNSAFE_componentWillMount != "function" &&
          typeof s.componentWillMount != "function") ||
        ((l = s.state),
        typeof s.componentWillMount == "function" && s.componentWillMount(),
        typeof s.UNSAFE_componentWillMount == "function" &&
          s.UNSAFE_componentWillMount(),
        l !== s.state && c0.enqueueReplaceState(s, s.state, null),
        r0(t, r, s, n),
        (s.state = t.memoizedState)),
      typeof s.componentDidMount == "function" && (t.flags |= 4194308));
  }
  function Zt(t, l) {
    try {
      var r = "",
        n = l;
      do ((r += Y(n)), (n = n.return));
      while (n);
      var s = r;
    } catch (a) {
      s =
        `
Error generating stack: ` +
        a.message +
        `
` +
        a.stack;
    }
    return { value: t, source: l, stack: s, digest: null };
  }
  function Kl(t, l, r) {
    return { value: t, source: null, stack: r ?? null, digest: l ?? null };
  }
  function Jl(t, l) {
    try {
      console.error(l.value);
    } catch (r) {
      setTimeout(function () {
        throw r;
      });
    }
  }
  var ja = typeof WeakMap == "function" ? WeakMap : Map;
  function Ti(t, l, r) {
    ((r = w1(-1, r)), (r.tag = 3), (r.payload = { element: null }));
    var n = l.value;
    return (
      (r.callback = function () {
        (L0 || ((L0 = !0), (ur = n)), Jl(t, l));
      }),
      r
    );
  }
  function zi(t, l, r) {
    ((r = w1(-1, r)), (r.tag = 3));
    var n = t.type.getDerivedStateFromError;
    if (typeof n == "function") {
      var s = l.value;
      ((r.payload = function () {
        return n(s);
      }),
        (r.callback = function () {
          Jl(t, l);
        }));
    }
    var a = t.stateNode;
    return (
      a !== null &&
        typeof a.componentDidCatch == "function" &&
        (r.callback = function () {
          (Jl(t, l),
            typeof n != "function" &&
              (W1 === null ? (W1 = new Set([this])) : W1.add(this)));
          var o = l.stack;
          this.componentDidCatch(l.value, {
            componentStack: o !== null ? o : "",
          });
        }),
      r
    );
  }
  function Pi(t, l, r) {
    var n = t.pingCache;
    if (n === null) {
      n = t.pingCache = new ja();
      var s = new Set();
      n.set(l, s);
    } else ((s = n.get(l)), s === void 0 && ((s = new Set()), n.set(l, s)));
    s.has(r) || (s.add(r), (t = Ba.bind(null, t, l, r)), l.then(t, t));
  }
  function Hi(t) {
    do {
      var l;
      if (
        ((l = t.tag === 13) &&
          ((l = t.memoizedState),
          (l = l !== null ? l.dehydrated !== null : !0)),
        l)
      )
        return t;
      t = t.return;
    } while (t !== null);
    return null;
  }
  function Wi(t, l, r, n, s) {
    return (t.mode & 1) === 0
      ? (t === l
          ? (t.flags |= 65536)
          : ((t.flags |= 128),
            (r.flags |= 131072),
            (r.flags &= -52805),
            r.tag === 1 &&
              (r.alternate === null
                ? (r.tag = 17)
                : ((l = w1(-1, 1)), (l.tag = 2), P1(r, l, 1))),
            (r.lanes |= 1)),
        t)
      : ((t.flags |= 65536), (t.lanes = s), t);
  }
  var Va = Fe.ReactCurrentOwner,
    De = !1;
  function Ze(t, l, r, n) {
    l.child = t === null ? ci(l, null, r, n) : Ct(l, t.child, r, n);
  }
  function Oi(t, l, r, n, s) {
    r = r.render;
    var a = l.ref;
    return (
      kt(l, s),
      (n = Hl(t, l, r, n, a, s)),
      (r = Wl()),
      t !== null && !De
        ? ((l.updateQueue = t.updateQueue),
          (l.flags &= -2053),
          (t.lanes &= ~s),
          k1(t, l, s))
        : (oe && r && Cl(l), (l.flags |= 1), Ze(t, l, n, s), l.child)
    );
  }
  function Ui(t, l, r, n, s) {
    if (t === null) {
      var a = r.type;
      return typeof a == "function" &&
        !mr(a) &&
        a.defaultProps === void 0 &&
        r.compare === null &&
        r.defaultProps === void 0
        ? ((l.tag = 15), (l.type = a), Qi(t, l, a, n, s))
        : ((t = b0(r.type, null, n, l, l.mode, s)),
          (t.ref = l.ref),
          (t.return = l),
          (l.child = t));
    }
    if (((a = t.child), (t.lanes & s) === 0)) {
      var o = a.memoizedProps;
      if (
        ((r = r.compare), (r = r !== null ? r : qt), r(o, n) && t.ref === l.ref)
      )
        return k1(t, l, s);
    }
    return (
      (l.flags |= 1),
      (t = $1(a, n)),
      (t.ref = l.ref),
      (t.return = l),
      (l.child = t)
    );
  }
  function Qi(t, l, r, n, s) {
    if (t !== null) {
      var a = t.memoizedProps;
      if (qt(a, n) && t.ref === l.ref)
        if (((De = !1), (l.pendingProps = n = a), (t.lanes & s) !== 0))
          (t.flags & 131072) !== 0 && (De = !0);
        else return ((l.lanes = t.lanes), k1(t, l, s));
    }
    return ql(t, l, r, n, s);
  }
  function $i(t, l, r) {
    var n = l.pendingProps,
      s = n.children,
      a = t !== null ? t.memoizedState : null;
    if (n.mode === "hidden")
      if ((l.mode & 1) === 0)
        ((l.memoizedState = {
          baseLanes: 0,
          cachePool: null,
          transitions: null,
        }),
          re(Bt, Oe),
          (Oe |= r));
      else {
        if ((r & 1073741824) === 0)
          return (
            (t = a !== null ? a.baseLanes | r : r),
            (l.lanes = l.childLanes = 1073741824),
            (l.memoizedState = {
              baseLanes: t,
              cachePool: null,
              transitions: null,
            }),
            (l.updateQueue = null),
            re(Bt, Oe),
            (Oe |= t),
            null
          );
        ((l.memoizedState = {
          baseLanes: 0,
          cachePool: null,
          transitions: null,
        }),
          (n = a !== null ? a.baseLanes : r),
          re(Bt, Oe),
          (Oe |= n));
      }
    else
      (a !== null ? ((n = a.baseLanes | r), (l.memoizedState = null)) : (n = r),
        re(Bt, Oe),
        (Oe |= n));
    return (Ze(t, l, s, r), l.child);
  }
  function Xi(t, l) {
    var r = l.ref;
    ((t === null && r !== null) || (t !== null && t.ref !== r)) &&
      ((l.flags |= 512), (l.flags |= 2097152));
  }
  function ql(t, l, r, n, s) {
    var a = Ae(r) ? q1 : Me.current;
    return (
      (a = _t(l, a)),
      kt(l, s),
      (r = Hl(t, l, r, n, a, s)),
      (n = Wl()),
      t !== null && !De
        ? ((l.updateQueue = t.updateQueue),
          (l.flags &= -2053),
          (t.lanes &= ~s),
          k1(t, l, s))
        : (oe && n && Cl(l), (l.flags |= 1), Ze(t, l, r, s), l.child)
    );
  }
  function Yi(t, l, r, n, s) {
    if (Ae(r)) {
      var a = !0;
      $2(l);
    } else a = !1;
    if ((kt(l, s), l.stateNode === null))
      (f0(t, l), Si(l, r, n), Yl(l, r, n, s), (n = !0));
    else if (t === null) {
      var o = l.stateNode,
        d = l.memoizedProps;
      o.props = d;
      var c = o.context,
        v = r.contextType;
      typeof v == "object" && v !== null
        ? (v = Ye(v))
        : ((v = Ae(r) ? q1 : Me.current), (v = _t(l, v)));
      var m = r.getDerivedStateFromProps,
        _ =
          typeof m == "function" ||
          typeof o.getSnapshotBeforeUpdate == "function";
      (_ ||
        (typeof o.UNSAFE_componentWillReceiveProps != "function" &&
          typeof o.componentWillReceiveProps != "function") ||
        ((d !== n || c !== v) && Ii(l, o, n, v)),
        (z1 = !1));
      var j = l.memoizedState;
      ((o.state = j),
        r0(l, n, o, s),
        (c = l.memoizedState),
        d !== n || j !== c || Ge.current || z1
          ? (typeof m == "function" && (Xl(l, r, m, n), (c = l.memoizedState)),
            (d = z1 || Ri(l, r, d, n, j, c, v))
              ? (_ ||
                  (typeof o.UNSAFE_componentWillMount != "function" &&
                    typeof o.componentWillMount != "function") ||
                  (typeof o.componentWillMount == "function" &&
                    o.componentWillMount(),
                  typeof o.UNSAFE_componentWillMount == "function" &&
                    o.UNSAFE_componentWillMount()),
                typeof o.componentDidMount == "function" &&
                  (l.flags |= 4194308))
              : (typeof o.componentDidMount == "function" &&
                  (l.flags |= 4194308),
                (l.memoizedProps = n),
                (l.memoizedState = c)),
            (o.props = n),
            (o.state = c),
            (o.context = v),
            (n = d))
          : (typeof o.componentDidMount == "function" && (l.flags |= 4194308),
            (n = !1)));
    } else {
      ((o = l.stateNode),
        fi(t, l),
        (d = l.memoizedProps),
        (v = l.type === l.elementType ? d : s1(l.type, d)),
        (o.props = v),
        (_ = l.pendingProps),
        (j = o.context),
        (c = r.contextType),
        typeof c == "object" && c !== null
          ? (c = Ye(c))
          : ((c = Ae(r) ? q1 : Me.current), (c = _t(l, c))));
      var w = r.getDerivedStateFromProps;
      ((m =
        typeof w == "function" ||
        typeof o.getSnapshotBeforeUpdate == "function") ||
        (typeof o.UNSAFE_componentWillReceiveProps != "function" &&
          typeof o.componentWillReceiveProps != "function") ||
        ((d !== _ || j !== c) && Ii(l, o, n, c)),
        (z1 = !1),
        (j = l.memoizedState),
        (o.state = j),
        r0(l, n, o, s));
      var B = l.memoizedState;
      d !== _ || j !== B || Ge.current || z1
        ? (typeof w == "function" && (Xl(l, r, w, n), (B = l.memoizedState)),
          (v = z1 || Ri(l, r, v, n, j, B, c) || !1)
            ? (m ||
                (typeof o.UNSAFE_componentWillUpdate != "function" &&
                  typeof o.componentWillUpdate != "function") ||
                (typeof o.componentWillUpdate == "function" &&
                  o.componentWillUpdate(n, B, c),
                typeof o.UNSAFE_componentWillUpdate == "function" &&
                  o.UNSAFE_componentWillUpdate(n, B, c)),
              typeof o.componentDidUpdate == "function" && (l.flags |= 4),
              typeof o.getSnapshotBeforeUpdate == "function" &&
                (l.flags |= 1024))
            : (typeof o.componentDidUpdate != "function" ||
                (d === t.memoizedProps && j === t.memoizedState) ||
                (l.flags |= 4),
              typeof o.getSnapshotBeforeUpdate != "function" ||
                (d === t.memoizedProps && j === t.memoizedState) ||
                (l.flags |= 1024),
              (l.memoizedProps = n),
              (l.memoizedState = B)),
          (o.props = n),
          (o.state = B),
          (o.context = c),
          (n = v))
        : (typeof o.componentDidUpdate != "function" ||
            (d === t.memoizedProps && j === t.memoizedState) ||
            (l.flags |= 4),
          typeof o.getSnapshotBeforeUpdate != "function" ||
            (d === t.memoizedProps && j === t.memoizedState) ||
            (l.flags |= 1024),
          (n = !1));
    }
    return er(t, l, r, n, a, s);
  }
  function er(t, l, r, n, s, a) {
    Xi(t, l);
    var o = (l.flags & 128) !== 0;
    if (!n && !o) return (s && ti(l, r, !1), k1(t, l, a));
    ((n = l.stateNode), (Va.current = l));
    var d =
      o && typeof r.getDerivedStateFromError != "function" ? null : n.render();
    return (
      (l.flags |= 1),
      t !== null && o
        ? ((l.child = Ct(l, t.child, null, a)), (l.child = Ct(l, null, d, a)))
        : Ze(t, l, d, a),
      (l.memoizedState = n.state),
      s && ti(l, r, !0),
      l.child
    );
  }
  function Ki(t) {
    var l = t.stateNode;
    (l.pendingContext
      ? q3(t, l.pendingContext, l.pendingContext !== l.context)
      : l.context && q3(t, l.context, !1),
      Rl(t, l.containerInfo));
  }
  function Ji(t, l, r, n, s) {
    return (Mt(), Zl(s), (l.flags |= 256), Ze(t, l, r, n), l.child);
  }
  var tr = { dehydrated: null, treeContext: null, retryLane: 0 };
  function lr(t) {
    return { baseLanes: t, cachePool: null, transitions: null };
  }
  function qi(t, l, r) {
    var n = l.pendingProps,
      s = de.current,
      a = !1,
      o = (l.flags & 128) !== 0,
      d;
    if (
      ((d = o) ||
        (d = t !== null && t.memoizedState === null ? !1 : (s & 2) !== 0),
      d
        ? ((a = !0), (l.flags &= -129))
        : (t === null || t.memoizedState !== null) && (s |= 1),
      re(de, s & 1),
      t === null)
    )
      return (
        Nl(l),
        (t = l.memoizedState),
        t !== null && ((t = t.dehydrated), t !== null)
          ? ((l.mode & 1) === 0
              ? (l.lanes = 1)
              : t.data === "$!"
                ? (l.lanes = 8)
                : (l.lanes = 1073741824),
            null)
          : ((o = n.children),
            (t = n.fallback),
            a
              ? ((n = l.mode),
                (a = l.child),
                (o = { mode: "hidden", children: o }),
                (n & 1) === 0 && a !== null
                  ? ((a.childLanes = 0), (a.pendingProps = o))
                  : (a = F0(o, n, 0, null)),
                (t = dt(t, n, r, null)),
                (a.return = l),
                (t.return = l),
                (a.sibling = t),
                (l.child = a),
                (l.child.memoizedState = lr(r)),
                (l.memoizedState = tr),
                t)
              : rr(l, o))
      );
    if (((s = t.memoizedState), s !== null && ((d = s.dehydrated), d !== null)))
      return ma(t, l, o, n, d, s, r);
    if (a) {
      ((a = n.fallback), (o = l.mode), (s = t.child), (d = s.sibling));
      var c = { mode: "hidden", children: n.children };
      return (
        (o & 1) === 0 && l.child !== s
          ? ((n = l.child),
            (n.childLanes = 0),
            (n.pendingProps = c),
            (l.deletions = null))
          : ((n = $1(s, c)), (n.subtreeFlags = s.subtreeFlags & 14680064)),
        d !== null ? (a = $1(d, a)) : ((a = dt(a, o, r, null)), (a.flags |= 2)),
        (a.return = l),
        (n.return = l),
        (n.sibling = a),
        (l.child = n),
        (n = a),
        (a = l.child),
        (o = t.child.memoizedState),
        (o =
          o === null
            ? lr(r)
            : {
                baseLanes: o.baseLanes | r,
                cachePool: null,
                transitions: o.transitions,
              }),
        (a.memoizedState = o),
        (a.childLanes = t.childLanes & ~r),
        (l.memoizedState = tr),
        n
      );
    }
    return (
      (a = t.child),
      (t = a.sibling),
      (n = $1(a, { mode: "visible", children: n.children })),
      (l.mode & 1) === 0 && (n.lanes = r),
      (n.return = l),
      (n.sibling = null),
      t !== null &&
        ((r = l.deletions),
        r === null ? ((l.deletions = [t]), (l.flags |= 16)) : r.push(t)),
      (l.child = n),
      (l.memoizedState = null),
      n
    );
  }
  function rr(t, l) {
    return (
      (l = F0({ mode: "visible", children: l }, t.mode, 0, null)),
      (l.return = t),
      (t.child = l)
    );
  }
  function p0(t, l, r, n) {
    return (
      n !== null && Zl(n),
      Ct(l, t.child, null, r),
      (t = rr(l, l.pendingProps.children)),
      (t.flags |= 2),
      (l.memoizedState = null),
      t
    );
  }
  function ma(t, l, r, n, s, a, o) {
    if (r)
      return l.flags & 256
        ? ((l.flags &= -257), (n = Kl(Error(u(422)))), p0(t, l, o, n))
        : l.memoizedState !== null
          ? ((l.child = t.child), (l.flags |= 128), null)
          : ((a = n.fallback),
            (s = l.mode),
            (n = F0({ mode: "visible", children: n.children }, s, 0, null)),
            (a = dt(a, s, o, null)),
            (a.flags |= 2),
            (n.return = l),
            (a.return = l),
            (n.sibling = a),
            (l.child = n),
            (l.mode & 1) !== 0 && Ct(l, t.child, null, o),
            (l.child.memoizedState = lr(o)),
            (l.memoizedState = tr),
            a);
    if ((l.mode & 1) === 0) return p0(t, l, o, null);
    if (s.data === "$!") {
      if (((n = s.nextSibling && s.nextSibling.dataset), n)) var d = n.dgst;
      return (
        (n = d),
        (a = Error(u(419))),
        (n = Kl(a, n, void 0)),
        p0(t, l, o, n)
      );
    }
    if (((d = (o & t.childLanes) !== 0), De || d)) {
      if (((n = me), n !== null)) {
        switch (o & -o) {
          case 4:
            s = 2;
            break;
          case 16:
            s = 8;
            break;
          case 64:
          case 128:
          case 256:
          case 512:
          case 1024:
          case 2048:
          case 4096:
          case 8192:
          case 16384:
          case 32768:
          case 65536:
          case 131072:
          case 262144:
          case 524288:
          case 1048576:
          case 2097152:
          case 4194304:
          case 8388608:
          case 16777216:
          case 33554432:
          case 67108864:
            s = 32;
            break;
          case 536870912:
            s = 268435456;
            break;
          default:
            s = 0;
        }
        ((s = (s & (n.suspendedLanes | o)) !== 0 ? 0 : s),
          s !== 0 &&
            s !== a.retryLane &&
            ((a.retryLane = s), C1(t, s), d1(n, t, s, -1)));
      }
      return (Vr(), (n = Kl(Error(u(421)))), p0(t, l, o, n));
    }
    return s.data === "$?"
      ? ((l.flags |= 128),
        (l.child = t.child),
        (l = Ea.bind(null, t)),
        (s._reactRetry = l),
        null)
      : ((t = a.treeContext),
        (We = R1(s.nextSibling)),
        (He = l),
        (oe = !0),
        (n1 = null),
        t !== null &&
          (($e[Xe++] = F1),
          ($e[Xe++] = M1),
          ($e[Xe++] = et),
          (F1 = t.id),
          (M1 = t.overflow),
          (et = l)),
        (l = rr(l, n.children)),
        (l.flags |= 4096),
        l);
  }
  function en(t, l, r) {
    t.lanes |= l;
    var n = t.alternate;
    (n !== null && (n.lanes |= l), Gl(t.return, l, r));
  }
  function ir(t, l, r, n, s) {
    var a = t.memoizedState;
    a === null
      ? (t.memoizedState = {
          isBackwards: l,
          rendering: null,
          renderingStartTime: 0,
          last: n,
          tail: r,
          tailMode: s,
        })
      : ((a.isBackwards = l),
        (a.rendering = null),
        (a.renderingStartTime = 0),
        (a.last = n),
        (a.tail = r),
        (a.tailMode = s));
  }
  function tn(t, l, r) {
    var n = l.pendingProps,
      s = n.revealOrder,
      a = n.tail;
    if ((Ze(t, l, n.children, r), (n = de.current), (n & 2) !== 0))
      ((n = (n & 1) | 2), (l.flags |= 128));
    else {
      if (t !== null && (t.flags & 128) !== 0)
        e: for (t = l.child; t !== null; ) {
          if (t.tag === 13) t.memoizedState !== null && en(t, r, l);
          else if (t.tag === 19) en(t, r, l);
          else if (t.child !== null) {
            ((t.child.return = t), (t = t.child));
            continue;
          }
          if (t === l) break e;
          for (; t.sibling === null; ) {
            if (t.return === null || t.return === l) break e;
            t = t.return;
          }
          ((t.sibling.return = t.return), (t = t.sibling));
        }
      n &= 1;
    }
    if ((re(de, n), (l.mode & 1) === 0)) l.memoizedState = null;
    else
      switch (s) {
        case "forwards":
          for (r = l.child, s = null; r !== null; )
            ((t = r.alternate),
              t !== null && i0(t) === null && (s = r),
              (r = r.sibling));
          ((r = s),
            r === null
              ? ((s = l.child), (l.child = null))
              : ((s = r.sibling), (r.sibling = null)),
            ir(l, !1, s, r, a));
          break;
        case "backwards":
          for (r = null, s = l.child, l.child = null; s !== null; ) {
            if (((t = s.alternate), t !== null && i0(t) === null)) {
              l.child = s;
              break;
            }
            ((t = s.sibling), (s.sibling = r), (r = s), (s = t));
          }
          ir(l, !0, r, null, a);
          break;
        case "together":
          ir(l, !1, null, null, void 0);
          break;
        default:
          l.memoizedState = null;
      }
    return l.child;
  }
  function f0(t, l) {
    (l.mode & 1) === 0 &&
      t !== null &&
      ((t.alternate = null), (l.alternate = null), (l.flags |= 2));
  }
  function k1(t, l, r) {
    if (
      (t !== null && (l.dependencies = t.dependencies),
      (nt |= l.lanes),
      (r & l.childLanes) === 0)
    )
      return null;
    if (t !== null && l.child !== t.child) throw Error(u(153));
    if (l.child !== null) {
      for (
        t = l.child, r = $1(t, t.pendingProps), l.child = r, r.return = l;
        t.sibling !== null;
      )
        ((t = t.sibling),
          (r = r.sibling = $1(t, t.pendingProps)),
          (r.return = l));
      r.sibling = null;
    }
    return l.child;
  }
  function ga(t, l, r) {
    switch (l.tag) {
      case 3:
        (Ki(l), Mt());
        break;
      case 5:
        hi(l);
        break;
      case 1:
        Ae(l.type) && $2(l);
        break;
      case 4:
        Rl(l, l.stateNode.containerInfo);
        break;
      case 10:
        var n = l.type._context,
          s = l.memoizedProps.value;
        (re(e0, n._currentValue), (n._currentValue = s));
        break;
      case 13:
        if (((n = l.memoizedState), n !== null))
          return n.dehydrated !== null
            ? (re(de, de.current & 1), (l.flags |= 128), null)
            : (r & l.child.childLanes) !== 0
              ? qi(t, l, r)
              : (re(de, de.current & 1),
                (t = k1(t, l, r)),
                t !== null ? t.sibling : null);
        re(de, de.current & 1);
        break;
      case 19:
        if (((n = (r & l.childLanes) !== 0), (t.flags & 128) !== 0)) {
          if (n) return tn(t, l, r);
          l.flags |= 128;
        }
        if (
          ((s = l.memoizedState),
          s !== null &&
            ((s.rendering = null), (s.tail = null), (s.lastEffect = null)),
          re(de, de.current),
          n)
        )
          break;
        return null;
      case 22:
      case 23:
        return ((l.lanes = 0), $i(t, l, r));
    }
    return k1(t, l, r);
  }
  var ln, nr, rn, nn;
  ((ln = function (t, l) {
    for (var r = l.child; r !== null; ) {
      if (r.tag === 5 || r.tag === 6) t.appendChild(r.stateNode);
      else if (r.tag !== 4 && r.child !== null) {
        ((r.child.return = r), (r = r.child));
        continue;
      }
      if (r === l) break;
      for (; r.sibling === null; ) {
        if (r.return === null || r.return === l) return;
        r = r.return;
      }
      ((r.sibling.return = r.return), (r = r.sibling));
    }
  }),
    (nr = function () {}),
    (rn = function (t, l, r, n) {
      var s = t.memoizedProps;
      if (s !== n) {
        ((t = l.stateNode), rt(h1.current));
        var a = null;
        switch (r) {
          case "input":
            ((s = G0(t, s)), (n = G0(t, n)), (a = []));
            break;
          case "select":
            ((s = y({}, s, { value: void 0 })),
              (n = y({}, n, { value: void 0 })),
              (a = []));
            break;
          case "textarea":
            ((s = R0(t, s)), (n = R0(t, n)), (a = []));
            break;
          default:
            typeof s.onClick != "function" &&
              typeof n.onClick == "function" &&
              (t.onclick = O2);
        }
        I0(r, n);
        var o;
        r = null;
        for (v in s)
          if (!n.hasOwnProperty(v) && s.hasOwnProperty(v) && s[v] != null)
            if (v === "style") {
              var d = s[v];
              for (o in d) d.hasOwnProperty(o) && (r || (r = {}), (r[o] = ""));
            } else
              v !== "dangerouslySetInnerHTML" &&
                v !== "children" &&
                v !== "suppressContentEditableWarning" &&
                v !== "suppressHydrationWarning" &&
                v !== "autoFocus" &&
                (g.hasOwnProperty(v)
                  ? a || (a = [])
                  : (a = a || []).push(v, null));
        for (v in n) {
          var c = n[v];
          if (
            ((d = s != null ? s[v] : void 0),
            n.hasOwnProperty(v) && c !== d && (c != null || d != null))
          )
            if (v === "style")
              if (d) {
                for (o in d)
                  !d.hasOwnProperty(o) ||
                    (c && c.hasOwnProperty(o)) ||
                    (r || (r = {}), (r[o] = ""));
                for (o in c)
                  c.hasOwnProperty(o) &&
                    d[o] !== c[o] &&
                    (r || (r = {}), (r[o] = c[o]));
              } else (r || (a || (a = []), a.push(v, r)), (r = c));
            else
              v === "dangerouslySetInnerHTML"
                ? ((c = c ? c.__html : void 0),
                  (d = d ? d.__html : void 0),
                  c != null && d !== c && (a = a || []).push(v, c))
                : v === "children"
                  ? (typeof c != "string" && typeof c != "number") ||
                    (a = a || []).push(v, "" + c)
                  : v !== "suppressContentEditableWarning" &&
                    v !== "suppressHydrationWarning" &&
                    (g.hasOwnProperty(v)
                      ? (c != null && v === "onScroll" && ie("scroll", t),
                        a || d === c || (a = []))
                      : (a = a || []).push(v, c));
        }
        r && (a = a || []).push("style", r);
        var v = a;
        (l.updateQueue = v) && (l.flags |= 4);
      }
    }),
    (nn = function (t, l, r, n) {
      r !== n && (l.flags |= 4);
    }));
  function x2(t, l) {
    if (!oe)
      switch (t.tailMode) {
        case "hidden":
          l = t.tail;
          for (var r = null; l !== null; )
            (l.alternate !== null && (r = l), (l = l.sibling));
          r === null ? (t.tail = null) : (r.sibling = null);
          break;
        case "collapsed":
          r = t.tail;
          for (var n = null; r !== null; )
            (r.alternate !== null && (n = r), (r = r.sibling));
          n === null
            ? l || t.tail === null
              ? (t.tail = null)
              : (t.tail.sibling = null)
            : (n.sibling = null);
      }
  }
  function we(t) {
    var l = t.alternate !== null && t.alternate.child === t.child,
      r = 0,
      n = 0;
    if (l)
      for (var s = t.child; s !== null; )
        ((r |= s.lanes | s.childLanes),
          (n |= s.subtreeFlags & 14680064),
          (n |= s.flags & 14680064),
          (s.return = t),
          (s = s.sibling));
    else
      for (s = t.child; s !== null; )
        ((r |= s.lanes | s.childLanes),
          (n |= s.subtreeFlags),
          (n |= s.flags),
          (s.return = t),
          (s = s.sibling));
    return ((t.subtreeFlags |= n), (t.childLanes = r), l);
  }
  function _a(t, l, r) {
    var n = l.pendingProps;
    switch ((wl(l), l.tag)) {
      case 2:
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return (we(l), null);
      case 1:
        return (Ae(l.type) && Q2(), we(l), null);
      case 3:
        return (
          (n = l.stateNode),
          Nt(),
          ne(Ge),
          ne(Me),
          Tl(),
          n.pendingContext &&
            ((n.context = n.pendingContext), (n.pendingContext = null)),
          (t === null || t.child === null) &&
            (J2(l)
              ? (l.flags |= 4)
              : t === null ||
                (t.memoizedState.isDehydrated && (l.flags & 256) === 0) ||
                ((l.flags |= 1024), n1 !== null && (vr(n1), (n1 = null)))),
          nr(t, l),
          we(l),
          null
        );
      case 5:
        Sl(l);
        var s = rt(d2.current);
        if (((r = l.type), t !== null && l.stateNode != null))
          (rn(t, l, r, n, s),
            t.ref !== l.ref && ((l.flags |= 512), (l.flags |= 2097152)));
        else {
          if (!n) {
            if (l.stateNode === null) throw Error(u(166));
            return (we(l), null);
          }
          if (((t = rt(h1.current)), J2(l))) {
            ((n = l.stateNode), (r = l.type));
            var a = l.memoizedProps;
            switch (((n[x1] = l), (n[i2] = a), (t = (l.mode & 1) !== 0), r)) {
              case "dialog":
                (ie("cancel", n), ie("close", n));
                break;
              case "iframe":
              case "object":
              case "embed":
                ie("load", n);
                break;
              case "video":
              case "audio":
                for (s = 0; s < t2.length; s++) ie(t2[s], n);
                break;
              case "source":
                ie("error", n);
                break;
              case "img":
              case "image":
              case "link":
                (ie("error", n), ie("load", n));
                break;
              case "details":
                ie("toggle", n);
                break;
              case "input":
                (Sr(n, a), ie("invalid", n));
                break;
              case "select":
                ((n._wrapperState = { wasMultiple: !!a.multiple }),
                  ie("invalid", n));
                break;
              case "textarea":
                (zr(n, a), ie("invalid", n));
            }
            (I0(r, a), (s = null));
            for (var o in a)
              if (a.hasOwnProperty(o)) {
                var d = a[o];
                o === "children"
                  ? typeof d == "string"
                    ? n.textContent !== d &&
                      (a.suppressHydrationWarning !== !0 &&
                        W2(n.textContent, d, t),
                      (s = ["children", d]))
                    : typeof d == "number" &&
                      n.textContent !== "" + d &&
                      (a.suppressHydrationWarning !== !0 &&
                        W2(n.textContent, d, t),
                      (s = ["children", "" + d]))
                  : g.hasOwnProperty(o) &&
                    d != null &&
                    o === "onScroll" &&
                    ie("scroll", n);
              }
            switch (r) {
              case "input":
                (g2(n), Tr(n, a, !0));
                break;
              case "textarea":
                (g2(n), Hr(n));
                break;
              case "select":
              case "option":
                break;
              default:
                typeof a.onClick == "function" && (n.onclick = O2);
            }
            ((n = s), (l.updateQueue = n), n !== null && (l.flags |= 4));
          } else {
            ((o = s.nodeType === 9 ? s : s.ownerDocument),
              t === "http://www.w3.org/1999/xhtml" && (t = Wr(r)),
              t === "http://www.w3.org/1999/xhtml"
                ? r === "script"
                  ? ((t = o.createElement("div")),
                    (t.innerHTML = "<script><\/script>"),
                    (t = t.removeChild(t.firstChild)))
                  : typeof n.is == "string"
                    ? (t = o.createElement(r, { is: n.is }))
                    : ((t = o.createElement(r)),
                      r === "select" &&
                        ((o = t),
                        n.multiple
                          ? (o.multiple = !0)
                          : n.size && (o.size = n.size)))
                : (t = o.createElementNS(t, r)),
              (t[x1] = l),
              (t[i2] = n),
              ln(t, l, !1, !1),
              (l.stateNode = t));
            e: {
              switch (((o = T0(r, n)), r)) {
                case "dialog":
                  (ie("cancel", t), ie("close", t), (s = n));
                  break;
                case "iframe":
                case "object":
                case "embed":
                  (ie("load", t), (s = n));
                  break;
                case "video":
                case "audio":
                  for (s = 0; s < t2.length; s++) ie(t2[s], t);
                  s = n;
                  break;
                case "source":
                  (ie("error", t), (s = n));
                  break;
                case "img":
                case "image":
                case "link":
                  (ie("error", t), ie("load", t), (s = n));
                  break;
                case "details":
                  (ie("toggle", t), (s = n));
                  break;
                case "input":
                  (Sr(t, n), (s = G0(t, n)), ie("invalid", t));
                  break;
                case "option":
                  s = n;
                  break;
                case "select":
                  ((t._wrapperState = { wasMultiple: !!n.multiple }),
                    (s = y({}, n, { value: void 0 })),
                    ie("invalid", t));
                  break;
                case "textarea":
                  (zr(t, n), (s = R0(t, n)), ie("invalid", t));
                  break;
                default:
                  s = n;
              }
              (I0(r, s), (d = s));
              for (a in d)
                if (d.hasOwnProperty(a)) {
                  var c = d[a];
                  a === "style"
                    ? Qr(t, c)
                    : a === "dangerouslySetInnerHTML"
                      ? ((c = c ? c.__html : void 0), c != null && Or(t, c))
                      : a === "children"
                        ? typeof c == "string"
                          ? (r !== "textarea" || c !== "") && Dt(t, c)
                          : typeof c == "number" && Dt(t, "" + c)
                        : a !== "suppressContentEditableWarning" &&
                          a !== "suppressHydrationWarning" &&
                          a !== "autoFocus" &&
                          (g.hasOwnProperty(a)
                            ? c != null && a === "onScroll" && ie("scroll", t)
                            : c != null && e1(t, a, c, o));
                }
              switch (r) {
                case "input":
                  (g2(t), Tr(t, n, !1));
                  break;
                case "textarea":
                  (g2(t), Hr(t));
                  break;
                case "option":
                  n.value != null && t.setAttribute("value", "" + q(n.value));
                  break;
                case "select":
                  ((t.multiple = !!n.multiple),
                    (a = n.value),
                    a != null
                      ? ct(t, !!n.multiple, a, !1)
                      : n.defaultValue != null &&
                        ct(t, !!n.multiple, n.defaultValue, !0));
                  break;
                default:
                  typeof s.onClick == "function" && (t.onclick = O2);
              }
              switch (r) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  n = !!n.autoFocus;
                  break e;
                case "img":
                  n = !0;
                  break e;
                default:
                  n = !1;
              }
            }
            n && (l.flags |= 4);
          }
          l.ref !== null && ((l.flags |= 512), (l.flags |= 2097152));
        }
        return (we(l), null);
      case 6:
        if (t && l.stateNode != null) nn(t, l, t.memoizedProps, n);
        else {
          if (typeof n != "string" && l.stateNode === null) throw Error(u(166));
          if (((r = rt(d2.current)), rt(h1.current), J2(l))) {
            if (
              ((n = l.stateNode),
              (r = l.memoizedProps),
              (n[x1] = l),
              (a = n.nodeValue !== r) && ((t = He), t !== null))
            )
              switch (t.tag) {
                case 3:
                  W2(n.nodeValue, r, (t.mode & 1) !== 0);
                  break;
                case 5:
                  t.memoizedProps.suppressHydrationWarning !== !0 &&
                    W2(n.nodeValue, r, (t.mode & 1) !== 0);
              }
            a && (l.flags |= 4);
          } else
            ((n = (r.nodeType === 9 ? r : r.ownerDocument).createTextNode(n)),
              (n[x1] = l),
              (l.stateNode = n));
        }
        return (we(l), null);
      case 13:
        if (
          (ne(de),
          (n = l.memoizedState),
          t === null ||
            (t.memoizedState !== null && t.memoizedState.dehydrated !== null))
        ) {
          if (oe && We !== null && (l.mode & 1) !== 0 && (l.flags & 128) === 0)
            (ai(), Mt(), (l.flags |= 98560), (a = !1));
          else if (((a = J2(l)), n !== null && n.dehydrated !== null)) {
            if (t === null) {
              if (!a) throw Error(u(318));
              if (
                ((a = l.memoizedState),
                (a = a !== null ? a.dehydrated : null),
                !a)
              )
                throw Error(u(317));
              a[x1] = l;
            } else
              (Mt(),
                (l.flags & 128) === 0 && (l.memoizedState = null),
                (l.flags |= 4));
            (we(l), (a = !1));
          } else (n1 !== null && (vr(n1), (n1 = null)), (a = !0));
          if (!a) return l.flags & 65536 ? l : null;
        }
        return (l.flags & 128) !== 0
          ? ((l.lanes = r), l)
          : ((n = n !== null),
            n !== (t !== null && t.memoizedState !== null) &&
              n &&
              ((l.child.flags |= 8192),
              (l.mode & 1) !== 0 &&
                (t === null || (de.current & 1) !== 0
                  ? je === 0 && (je = 3)
                  : Vr())),
            l.updateQueue !== null && (l.flags |= 4),
            we(l),
            null);
      case 4:
        return (
          Nt(),
          nr(t, l),
          t === null && l2(l.stateNode.containerInfo),
          we(l),
          null
        );
      case 10:
        return (El(l.type._context), we(l), null);
      case 17:
        return (Ae(l.type) && Q2(), we(l), null);
      case 19:
        if ((ne(de), (a = l.memoizedState), a === null)) return (we(l), null);
        if (((n = (l.flags & 128) !== 0), (o = a.rendering), o === null))
          if (n) x2(a, !1);
          else {
            if (je !== 0 || (t !== null && (t.flags & 128) !== 0))
              for (t = l.child; t !== null; ) {
                if (((o = i0(t)), o !== null)) {
                  for (
                    l.flags |= 128,
                      x2(a, !1),
                      n = o.updateQueue,
                      n !== null && ((l.updateQueue = n), (l.flags |= 4)),
                      l.subtreeFlags = 0,
                      n = r,
                      r = l.child;
                    r !== null;
                  )
                    ((a = r),
                      (t = n),
                      (a.flags &= 14680066),
                      (o = a.alternate),
                      o === null
                        ? ((a.childLanes = 0),
                          (a.lanes = t),
                          (a.child = null),
                          (a.subtreeFlags = 0),
                          (a.memoizedProps = null),
                          (a.memoizedState = null),
                          (a.updateQueue = null),
                          (a.dependencies = null),
                          (a.stateNode = null))
                        : ((a.childLanes = o.childLanes),
                          (a.lanes = o.lanes),
                          (a.child = o.child),
                          (a.subtreeFlags = 0),
                          (a.deletions = null),
                          (a.memoizedProps = o.memoizedProps),
                          (a.memoizedState = o.memoizedState),
                          (a.updateQueue = o.updateQueue),
                          (a.type = o.type),
                          (t = o.dependencies),
                          (a.dependencies =
                            t === null
                              ? null
                              : {
                                  lanes: t.lanes,
                                  firstContext: t.firstContext,
                                })),
                      (r = r.sibling));
                  return (re(de, (de.current & 1) | 2), l.child);
                }
                t = t.sibling;
              }
            a.tail !== null &&
              xe() > Et &&
              ((l.flags |= 128), (n = !0), x2(a, !1), (l.lanes = 4194304));
          }
        else {
          if (!n)
            if (((t = i0(o)), t !== null)) {
              if (
                ((l.flags |= 128),
                (n = !0),
                (r = t.updateQueue),
                r !== null && ((l.updateQueue = r), (l.flags |= 4)),
                x2(a, !0),
                a.tail === null &&
                  a.tailMode === "hidden" &&
                  !o.alternate &&
                  !oe)
              )
                return (we(l), null);
            } else
              2 * xe() - a.renderingStartTime > Et &&
                r !== 1073741824 &&
                ((l.flags |= 128), (n = !0), x2(a, !1), (l.lanes = 4194304));
          a.isBackwards
            ? ((o.sibling = l.child), (l.child = o))
            : ((r = a.last),
              r !== null ? (r.sibling = o) : (l.child = o),
              (a.last = o));
        }
        return a.tail !== null
          ? ((l = a.tail),
            (a.rendering = l),
            (a.tail = l.sibling),
            (a.renderingStartTime = xe()),
            (l.sibling = null),
            (r = de.current),
            re(de, n ? (r & 1) | 2 : r & 1),
            l)
          : (we(l), null);
      case 22:
      case 23:
        return (
          jr(),
          (n = l.memoizedState !== null),
          t !== null && (t.memoizedState !== null) !== n && (l.flags |= 8192),
          n && (l.mode & 1) !== 0
            ? (Oe & 1073741824) !== 0 &&
              (we(l), l.subtreeFlags & 6 && (l.flags |= 8192))
            : we(l),
          null
        );
      case 24:
        return null;
      case 25:
        return null;
    }
    throw Error(u(156, l.tag));
  }
  function ba(t, l) {
    switch ((wl(l), l.tag)) {
      case 1:
        return (
          Ae(l.type) && Q2(),
          (t = l.flags),
          t & 65536 ? ((l.flags = (t & -65537) | 128), l) : null
        );
      case 3:
        return (
          Nt(),
          ne(Ge),
          ne(Me),
          Tl(),
          (t = l.flags),
          (t & 65536) !== 0 && (t & 128) === 0
            ? ((l.flags = (t & -65537) | 128), l)
            : null
        );
      case 5:
        return (Sl(l), null);
      case 13:
        if (
          (ne(de), (t = l.memoizedState), t !== null && t.dehydrated !== null)
        ) {
          if (l.alternate === null) throw Error(u(340));
          Mt();
        }
        return (
          (t = l.flags),
          t & 65536 ? ((l.flags = (t & -65537) | 128), l) : null
        );
      case 19:
        return (ne(de), null);
      case 4:
        return (Nt(), null);
      case 10:
        return (El(l.type._context), null);
      case 22:
      case 23:
        return (jr(), null);
      case 24:
        return null;
      default:
        return null;
    }
  }
  var u0 = !1,
    ke = !1,
    Fa = typeof WeakSet == "function" ? WeakSet : Set,
    Z = null;
  function yt(t, l) {
    var r = t.ref;
    if (r !== null)
      if (typeof r == "function")
        try {
          r(null);
        } catch (n) {
          fe(t, l, n);
        }
      else r.current = null;
  }
  function sr(t, l, r) {
    try {
      r();
    } catch (n) {
      fe(t, l, n);
    }
  }
  var sn = !1;
  function Ma(t, l) {
    if (((jl = E2), (t = R3()), cl(t))) {
      if ("selectionStart" in t)
        var r = { start: t.selectionStart, end: t.selectionEnd };
      else
        e: {
          r = ((r = t.ownerDocument) && r.defaultView) || window;
          var n = r.getSelection && r.getSelection();
          if (n && n.rangeCount !== 0) {
            r = n.anchorNode;
            var s = n.anchorOffset,
              a = n.focusNode;
            n = n.focusOffset;
            try {
              (r.nodeType, a.nodeType);
            } catch {
              r = null;
              break e;
            }
            var o = 0,
              d = -1,
              c = -1,
              v = 0,
              m = 0,
              _ = t,
              j = null;
            t: for (;;) {
              for (
                var w;
                _ !== r || (s !== 0 && _.nodeType !== 3) || (d = o + s),
                  _ !== a || (n !== 0 && _.nodeType !== 3) || (c = o + n),
                  _.nodeType === 3 && (o += _.nodeValue.length),
                  (w = _.firstChild) !== null;
              )
                ((j = _), (_ = w));
              for (;;) {
                if (_ === t) break t;
                if (
                  (j === r && ++v === s && (d = o),
                  j === a && ++m === n && (c = o),
                  (w = _.nextSibling) !== null)
                )
                  break;
                ((_ = j), (j = _.parentNode));
              }
              _ = w;
            }
            r = d === -1 || c === -1 ? null : { start: d, end: c };
          } else r = null;
        }
      r = r || { start: 0, end: 0 };
    } else r = null;
    for (
      Vl = { focusedElem: t, selectionRange: r }, E2 = !1, Z = l;
      Z !== null;
    )
      if (((l = Z), (t = l.child), (l.subtreeFlags & 1028) !== 0 && t !== null))
        ((t.return = l), (Z = t));
      else
        for (; Z !== null; ) {
          l = Z;
          try {
            var B = l.alternate;
            if ((l.flags & 1024) !== 0)
              switch (l.tag) {
                case 0:
                case 11:
                case 15:
                  break;
                case 1:
                  if (B !== null) {
                    var E = B.memoizedProps,
                      he = B.memoizedState,
                      x = l.stateNode,
                      p = x.getSnapshotBeforeUpdate(
                        l.elementType === l.type ? E : s1(l.type, E),
                        he,
                      );
                    x.__reactInternalSnapshotBeforeUpdate = p;
                  }
                  break;
                case 3:
                  var h = l.stateNode.containerInfo;
                  h.nodeType === 1
                    ? (h.textContent = "")
                    : h.nodeType === 9 &&
                      h.documentElement &&
                      h.removeChild(h.documentElement);
                  break;
                case 5:
                case 6:
                case 4:
                case 17:
                  break;
                default:
                  throw Error(u(163));
              }
          } catch (b) {
            fe(l, l.return, b);
          }
          if (((t = l.sibling), t !== null)) {
            ((t.return = l.return), (Z = t));
            break;
          }
          Z = l.return;
        }
    return ((B = sn), (sn = !1), B);
  }
  function h2(t, l, r) {
    var n = l.updateQueue;
    if (((n = n !== null ? n.lastEffect : null), n !== null)) {
      var s = (n = n.next);
      do {
        if ((s.tag & t) === t) {
          var a = s.destroy;
          ((s.destroy = void 0), a !== void 0 && sr(l, r, a));
        }
        s = s.next;
      } while (s !== n);
    }
  }
  function x0(t, l) {
    if (
      ((l = l.updateQueue), (l = l !== null ? l.lastEffect : null), l !== null)
    ) {
      var r = (l = l.next);
      do {
        if ((r.tag & t) === t) {
          var n = r.create;
          r.destroy = n();
        }
        r = r.next;
      } while (r !== l);
    }
  }
  function ar(t) {
    var l = t.ref;
    if (l !== null) {
      var r = t.stateNode;
      switch (t.tag) {
        case 5:
          t = r;
          break;
        default:
          t = r;
      }
      typeof l == "function" ? l(t) : (l.current = t);
    }
  }
  function an(t) {
    var l = t.alternate;
    (l !== null && ((t.alternate = null), an(l)),
      (t.child = null),
      (t.deletions = null),
      (t.sibling = null),
      t.tag === 5 &&
        ((l = t.stateNode),
        l !== null &&
          (delete l[x1],
          delete l[i2],
          delete l[bl],
          delete l[aa],
          delete l[oa])),
      (t.stateNode = null),
      (t.return = null),
      (t.dependencies = null),
      (t.memoizedProps = null),
      (t.memoizedState = null),
      (t.pendingProps = null),
      (t.stateNode = null),
      (t.updateQueue = null));
  }
  function on(t) {
    return t.tag === 5 || t.tag === 3 || t.tag === 4;
  }
  function dn(t) {
    e: for (;;) {
      for (; t.sibling === null; ) {
        if (t.return === null || on(t.return)) return null;
        t = t.return;
      }
      for (
        t.sibling.return = t.return, t = t.sibling;
        t.tag !== 5 && t.tag !== 6 && t.tag !== 18;
      ) {
        if (t.flags & 2 || t.child === null || t.tag === 4) continue e;
        ((t.child.return = t), (t = t.child));
      }
      if (!(t.flags & 2)) return t.stateNode;
    }
  }
  function or(t, l, r) {
    var n = t.tag;
    if (n === 5 || n === 6)
      ((t = t.stateNode),
        l
          ? r.nodeType === 8
            ? r.parentNode.insertBefore(t, l)
            : r.insertBefore(t, l)
          : (r.nodeType === 8
              ? ((l = r.parentNode), l.insertBefore(t, r))
              : ((l = r), l.appendChild(t)),
            (r = r._reactRootContainer),
            r != null || l.onclick !== null || (l.onclick = O2)));
    else if (n !== 4 && ((t = t.child), t !== null))
      for (or(t, l, r), t = t.sibling; t !== null; )
        (or(t, l, r), (t = t.sibling));
  }
  function dr(t, l, r) {
    var n = t.tag;
    if (n === 5 || n === 6)
      ((t = t.stateNode), l ? r.insertBefore(t, l) : r.appendChild(t));
    else if (n !== 4 && ((t = t.child), t !== null))
      for (dr(t, l, r), t = t.sibling; t !== null; )
        (dr(t, l, r), (t = t.sibling));
  }
  var _e = null,
    a1 = !1;
  function H1(t, l, r) {
    for (r = r.child; r !== null; ) (cn(t, l, r), (r = r.sibling));
  }
  function cn(t, l, r) {
    if (u1 && typeof u1.onCommitFiberUnmount == "function")
      try {
        u1.onCommitFiberUnmount(w2, r);
      } catch {}
    switch (r.tag) {
      case 5:
        ke || yt(r, l);
      case 6:
        var n = _e,
          s = a1;
        ((_e = null),
          H1(t, l, r),
          (_e = n),
          (a1 = s),
          _e !== null &&
            (a1
              ? ((t = _e),
                (r = r.stateNode),
                t.nodeType === 8
                  ? t.parentNode.removeChild(r)
                  : t.removeChild(r))
              : _e.removeChild(r.stateNode)));
        break;
      case 18:
        _e !== null &&
          (a1
            ? ((t = _e),
              (r = r.stateNode),
              t.nodeType === 8
                ? _l(t.parentNode, r)
                : t.nodeType === 1 && _l(t, r),
              Qt(t))
            : _l(_e, r.stateNode));
        break;
      case 4:
        ((n = _e),
          (s = a1),
          (_e = r.stateNode.containerInfo),
          (a1 = !0),
          H1(t, l, r),
          (_e = n),
          (a1 = s));
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        if (
          !ke &&
          ((n = r.updateQueue), n !== null && ((n = n.lastEffect), n !== null))
        ) {
          s = n = n.next;
          do {
            var a = s,
              o = a.destroy;
            ((a = a.tag),
              o !== void 0 && ((a & 2) !== 0 || (a & 4) !== 0) && sr(r, l, o),
              (s = s.next));
          } while (s !== n);
        }
        H1(t, l, r);
        break;
      case 1:
        if (
          !ke &&
          (yt(r, l),
          (n = r.stateNode),
          typeof n.componentWillUnmount == "function")
        )
          try {
            ((n.props = r.memoizedProps),
              (n.state = r.memoizedState),
              n.componentWillUnmount());
          } catch (d) {
            fe(r, l, d);
          }
        H1(t, l, r);
        break;
      case 21:
        H1(t, l, r);
        break;
      case 22:
        r.mode & 1
          ? ((ke = (n = ke) || r.memoizedState !== null), H1(t, l, r), (ke = n))
          : H1(t, l, r);
        break;
      default:
        H1(t, l, r);
    }
  }
  function pn(t) {
    var l = t.updateQueue;
    if (l !== null) {
      t.updateQueue = null;
      var r = t.stateNode;
      (r === null && (r = t.stateNode = new Fa()),
        l.forEach(function (n) {
          var s = Ga.bind(null, t, n);
          r.has(n) || (r.add(n), n.then(s, s));
        }));
    }
  }
  function o1(t, l) {
    var r = l.deletions;
    if (r !== null)
      for (var n = 0; n < r.length; n++) {
        var s = r[n];
        try {
          var a = t,
            o = l,
            d = o;
          e: for (; d !== null; ) {
            switch (d.tag) {
              case 5:
                ((_e = d.stateNode), (a1 = !1));
                break e;
              case 3:
                ((_e = d.stateNode.containerInfo), (a1 = !0));
                break e;
              case 4:
                ((_e = d.stateNode.containerInfo), (a1 = !0));
                break e;
            }
            d = d.return;
          }
          if (_e === null) throw Error(u(160));
          (cn(a, o, s), (_e = null), (a1 = !1));
          var c = s.alternate;
          (c !== null && (c.return = null), (s.return = null));
        } catch (v) {
          fe(s, l, v);
        }
      }
    if (l.subtreeFlags & 12854)
      for (l = l.child; l !== null; ) (fn(l, t), (l = l.sibling));
  }
  function fn(t, l) {
    var r = t.alternate,
      n = t.flags;
    switch (t.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        if ((o1(l, t), L1(t), n & 4)) {
          try {
            (h2(3, t, t.return), x0(3, t));
          } catch (E) {
            fe(t, t.return, E);
          }
          try {
            h2(5, t, t.return);
          } catch (E) {
            fe(t, t.return, E);
          }
        }
        break;
      case 1:
        (o1(l, t), L1(t), n & 512 && r !== null && yt(r, r.return));
        break;
      case 5:
        if (
          (o1(l, t),
          L1(t),
          n & 512 && r !== null && yt(r, r.return),
          t.flags & 32)
        ) {
          var s = t.stateNode;
          try {
            Dt(s, "");
          } catch (E) {
            fe(t, t.return, E);
          }
        }
        if (n & 4 && ((s = t.stateNode), s != null)) {
          var a = t.memoizedProps,
            o = r !== null ? r.memoizedProps : a,
            d = t.type,
            c = t.updateQueue;
          if (((t.updateQueue = null), c !== null))
            try {
              (d === "input" &&
                a.type === "radio" &&
                a.name != null &&
                Ir(s, a),
                T0(d, o));
              var v = T0(d, a);
              for (o = 0; o < c.length; o += 2) {
                var m = c[o],
                  _ = c[o + 1];
                m === "style"
                  ? Qr(s, _)
                  : m === "dangerouslySetInnerHTML"
                    ? Or(s, _)
                    : m === "children"
                      ? Dt(s, _)
                      : e1(s, m, _, v);
              }
              switch (d) {
                case "input":
                  A0(s, a);
                  break;
                case "textarea":
                  Pr(s, a);
                  break;
                case "select":
                  var j = s._wrapperState.wasMultiple;
                  s._wrapperState.wasMultiple = !!a.multiple;
                  var w = a.value;
                  w != null
                    ? ct(s, !!a.multiple, w, !1)
                    : j !== !!a.multiple &&
                      (a.defaultValue != null
                        ? ct(s, !!a.multiple, a.defaultValue, !0)
                        : ct(s, !!a.multiple, a.multiple ? [] : "", !1));
              }
              s[i2] = a;
            } catch (E) {
              fe(t, t.return, E);
            }
        }
        break;
      case 6:
        if ((o1(l, t), L1(t), n & 4)) {
          if (t.stateNode === null) throw Error(u(162));
          ((s = t.stateNode), (a = t.memoizedProps));
          try {
            s.nodeValue = a;
          } catch (E) {
            fe(t, t.return, E);
          }
        }
        break;
      case 3:
        if (
          (o1(l, t), L1(t), n & 4 && r !== null && r.memoizedState.isDehydrated)
        )
          try {
            Qt(l.containerInfo);
          } catch (E) {
            fe(t, t.return, E);
          }
        break;
      case 4:
        (o1(l, t), L1(t));
        break;
      case 13:
        (o1(l, t),
          L1(t),
          (s = t.child),
          s.flags & 8192 &&
            ((a = s.memoizedState !== null),
            (s.stateNode.isHidden = a),
            !a ||
              (s.alternate !== null && s.alternate.memoizedState !== null) ||
              (fr = xe())),
          n & 4 && pn(t));
        break;
      case 22:
        if (
          ((m = r !== null && r.memoizedState !== null),
          t.mode & 1 ? ((ke = (v = ke) || m), o1(l, t), (ke = v)) : o1(l, t),
          L1(t),
          n & 8192)
        ) {
          if (
            ((v = t.memoizedState !== null),
            (t.stateNode.isHidden = v) && !m && (t.mode & 1) !== 0)
          )
            for (Z = t, m = t.child; m !== null; ) {
              for (_ = Z = m; Z !== null; ) {
                switch (((j = Z), (w = j.child), j.tag)) {
                  case 0:
                  case 11:
                  case 14:
                  case 15:
                    h2(4, j, j.return);
                    break;
                  case 1:
                    yt(j, j.return);
                    var B = j.stateNode;
                    if (typeof B.componentWillUnmount == "function") {
                      ((n = j), (r = j.return));
                      try {
                        ((l = n),
                          (B.props = l.memoizedProps),
                          (B.state = l.memoizedState),
                          B.componentWillUnmount());
                      } catch (E) {
                        fe(n, r, E);
                      }
                    }
                    break;
                  case 5:
                    yt(j, j.return);
                    break;
                  case 22:
                    if (j.memoizedState !== null) {
                      hn(_);
                      continue;
                    }
                }
                w !== null ? ((w.return = j), (Z = w)) : hn(_);
              }
              m = m.sibling;
            }
          e: for (m = null, _ = t; ; ) {
            if (_.tag === 5) {
              if (m === null) {
                m = _;
                try {
                  ((s = _.stateNode),
                    v
                      ? ((a = s.style),
                        typeof a.setProperty == "function"
                          ? a.setProperty("display", "none", "important")
                          : (a.display = "none"))
                      : ((d = _.stateNode),
                        (c = _.memoizedProps.style),
                        (o =
                          c != null && c.hasOwnProperty("display")
                            ? c.display
                            : null),
                        (d.style.display = Ur("display", o))));
                } catch (E) {
                  fe(t, t.return, E);
                }
              }
            } else if (_.tag === 6) {
              if (m === null)
                try {
                  _.stateNode.nodeValue = v ? "" : _.memoizedProps;
                } catch (E) {
                  fe(t, t.return, E);
                }
            } else if (
              ((_.tag !== 22 && _.tag !== 23) ||
                _.memoizedState === null ||
                _ === t) &&
              _.child !== null
            ) {
              ((_.child.return = _), (_ = _.child));
              continue;
            }
            if (_ === t) break e;
            for (; _.sibling === null; ) {
              if (_.return === null || _.return === t) break e;
              (m === _ && (m = null), (_ = _.return));
            }
            (m === _ && (m = null),
              (_.sibling.return = _.return),
              (_ = _.sibling));
          }
        }
        break;
      case 19:
        (o1(l, t), L1(t), n & 4 && pn(t));
        break;
      case 21:
        break;
      default:
        (o1(l, t), L1(t));
    }
  }
  function L1(t) {
    var l = t.flags;
    if (l & 2) {
      try {
        e: {
          for (var r = t.return; r !== null; ) {
            if (on(r)) {
              var n = r;
              break e;
            }
            r = r.return;
          }
          throw Error(u(160));
        }
        switch (n.tag) {
          case 5:
            var s = n.stateNode;
            n.flags & 32 && (Dt(s, ""), (n.flags &= -33));
            var a = dn(t);
            dr(t, a, s);
            break;
          case 3:
          case 4:
            var o = n.stateNode.containerInfo,
              d = dn(t);
            or(t, d, o);
            break;
          default:
            throw Error(u(161));
        }
      } catch (c) {
        fe(t, t.return, c);
      }
      t.flags &= -3;
    }
    l & 4096 && (t.flags &= -4097);
  }
  function Ca(t, l, r) {
    ((Z = t), un(t));
  }
  function un(t, l, r) {
    for (var n = (t.mode & 1) !== 0; Z !== null; ) {
      var s = Z,
        a = s.child;
      if (s.tag === 22 && n) {
        var o = s.memoizedState !== null || u0;
        if (!o) {
          var d = s.alternate,
            c = (d !== null && d.memoizedState !== null) || ke;
          d = u0;
          var v = ke;
          if (((u0 = o), (ke = c) && !v))
            for (Z = s; Z !== null; )
              ((o = Z),
                (c = o.child),
                o.tag === 22 && o.memoizedState !== null
                  ? vn(s)
                  : c !== null
                    ? ((c.return = o), (Z = c))
                    : vn(s));
          for (; a !== null; ) ((Z = a), un(a), (a = a.sibling));
          ((Z = s), (u0 = d), (ke = v));
        }
        xn(t);
      } else
        (s.subtreeFlags & 8772) !== 0 && a !== null
          ? ((a.return = s), (Z = a))
          : xn(t);
    }
  }
  function xn(t) {
    for (; Z !== null; ) {
      var l = Z;
      if ((l.flags & 8772) !== 0) {
        var r = l.alternate;
        try {
          if ((l.flags & 8772) !== 0)
            switch (l.tag) {
              case 0:
              case 11:
              case 15:
                ke || x0(5, l);
                break;
              case 1:
                var n = l.stateNode;
                if (l.flags & 4 && !ke)
                  if (r === null) n.componentDidMount();
                  else {
                    var s =
                      l.elementType === l.type
                        ? r.memoizedProps
                        : s1(l.type, r.memoizedProps);
                    n.componentDidUpdate(
                      s,
                      r.memoizedState,
                      n.__reactInternalSnapshotBeforeUpdate,
                    );
                  }
                var a = l.updateQueue;
                a !== null && xi(l, a, n);
                break;
              case 3:
                var o = l.updateQueue;
                if (o !== null) {
                  if (((r = null), l.child !== null))
                    switch (l.child.tag) {
                      case 5:
                        r = l.child.stateNode;
                        break;
                      case 1:
                        r = l.child.stateNode;
                    }
                  xi(l, o, r);
                }
                break;
              case 5:
                var d = l.stateNode;
                if (r === null && l.flags & 4) {
                  r = d;
                  var c = l.memoizedProps;
                  switch (l.type) {
                    case "button":
                    case "input":
                    case "select":
                    case "textarea":
                      c.autoFocus && r.focus();
                      break;
                    case "img":
                      c.src && (r.src = c.src);
                  }
                }
                break;
              case 6:
                break;
              case 4:
                break;
              case 12:
                break;
              case 13:
                if (l.memoizedState === null) {
                  var v = l.alternate;
                  if (v !== null) {
                    var m = v.memoizedState;
                    if (m !== null) {
                      var _ = m.dehydrated;
                      _ !== null && Qt(_);
                    }
                  }
                }
                break;
              case 19:
              case 17:
              case 21:
              case 22:
              case 23:
              case 25:
                break;
              default:
                throw Error(u(163));
            }
          ke || (l.flags & 512 && ar(l));
        } catch (j) {
          fe(l, l.return, j);
        }
      }
      if (l === t) {
        Z = null;
        break;
      }
      if (((r = l.sibling), r !== null)) {
        ((r.return = l.return), (Z = r));
        break;
      }
      Z = l.return;
    }
  }
  function hn(t) {
    for (; Z !== null; ) {
      var l = Z;
      if (l === t) {
        Z = null;
        break;
      }
      var r = l.sibling;
      if (r !== null) {
        ((r.return = l.return), (Z = r));
        break;
      }
      Z = l.return;
    }
  }
  function vn(t) {
    for (; Z !== null; ) {
      var l = Z;
      try {
        switch (l.tag) {
          case 0:
          case 11:
          case 15:
            var r = l.return;
            try {
              x0(4, l);
            } catch (c) {
              fe(l, r, c);
            }
            break;
          case 1:
            var n = l.stateNode;
            if (typeof n.componentDidMount == "function") {
              var s = l.return;
              try {
                n.componentDidMount();
              } catch (c) {
                fe(l, s, c);
              }
            }
            var a = l.return;
            try {
              ar(l);
            } catch (c) {
              fe(l, a, c);
            }
            break;
          case 5:
            var o = l.return;
            try {
              ar(l);
            } catch (c) {
              fe(l, o, c);
            }
        }
      } catch (c) {
        fe(l, l.return, c);
      }
      if (l === t) {
        Z = null;
        break;
      }
      var d = l.sibling;
      if (d !== null) {
        ((d.return = l.return), (Z = d));
        break;
      }
      Z = l.return;
    }
  }
  var wa = Math.ceil,
    h0 = Fe.ReactCurrentDispatcher,
    cr = Fe.ReactCurrentOwner,
    Je = Fe.ReactCurrentBatchConfig,
    X = 0,
    me = null,
    ve = null,
    be = 0,
    Oe = 0,
    Bt = S1(0),
    je = 0,
    v2 = null,
    nt = 0,
    v0 = 0,
    pr = 0,
    L2 = null,
    Re = null,
    fr = 0,
    Et = 1 / 0,
    N1 = null,
    L0 = !1,
    ur = null,
    W1 = null,
    j0 = !1,
    O1 = null,
    V0 = 0,
    j2 = 0,
    xr = null,
    m0 = -1,
    g0 = 0;
  function ye() {
    return (X & 6) !== 0 ? xe() : m0 !== -1 ? m0 : (m0 = xe());
  }
  function U1(t) {
    return (t.mode & 1) === 0
      ? 1
      : (X & 2) !== 0 && be !== 0
        ? be & -be
        : ca.transition !== null
          ? (g0 === 0 && (g0 = o3()), g0)
          : ((t = ee),
            t !== 0 ||
              ((t = window.event), (t = t === void 0 ? 16 : L3(t.type))),
            t);
  }
  function d1(t, l, r, n) {
    if (50 < j2) throw ((j2 = 0), (xr = null), Error(u(185)));
    (Pt(t, r, n),
      ((X & 2) === 0 || t !== me) &&
        (t === me && ((X & 2) === 0 && (v0 |= r), je === 4 && Q1(t, be)),
        Se(t, n),
        r === 1 &&
          X === 0 &&
          (l.mode & 1) === 0 &&
          ((Et = xe() + 500), X2 && T1())));
  }
  function Se(t, l) {
    var r = t.callbackNode;
    cs(t, l);
    var n = Z2(t, t === me ? be : 0);
    if (n === 0)
      (r !== null && n3(r), (t.callbackNode = null), (t.callbackPriority = 0));
    else if (((l = n & -n), t.callbackPriority !== l)) {
      if ((r != null && n3(r), l === 1))
        (t.tag === 0 ? da(jn.bind(null, t)) : li(jn.bind(null, t)),
          na(function () {
            (X & 6) === 0 && T1();
          }),
          (r = null));
      else {
        switch (d3(n)) {
          case 1:
            r = Q0;
            break;
          case 4:
            r = s3;
            break;
          case 16:
            r = C2;
            break;
          case 536870912:
            r = a3;
            break;
          default:
            r = C2;
        }
        r = Cn(r, Ln.bind(null, t));
      }
      ((t.callbackPriority = l), (t.callbackNode = r));
    }
  }
  function Ln(t, l) {
    if (((m0 = -1), (g0 = 0), (X & 6) !== 0)) throw Error(u(327));
    var r = t.callbackNode;
    if (Gt() && t.callbackNode !== r) return null;
    var n = Z2(t, t === me ? be : 0);
    if (n === 0) return null;
    if ((n & 30) !== 0 || (n & t.expiredLanes) !== 0 || l) l = _0(t, n);
    else {
      l = n;
      var s = X;
      X |= 2;
      var a = mn();
      (me !== t || be !== l) && ((N1 = null), (Et = xe() + 500), at(t, l));
      do
        try {
          Za();
          break;
        } catch (d) {
          Vn(t, d);
        }
      while (!0);
      (Bl(),
        (h0.current = a),
        (X = s),
        ve !== null ? (l = 0) : ((me = null), (be = 0), (l = je)));
    }
    if (l !== 0) {
      if (
        (l === 2 && ((s = $0(t)), s !== 0 && ((n = s), (l = hr(t, s)))),
        l === 1)
      )
        throw ((r = v2), at(t, 0), Q1(t, n), Se(t, xe()), r);
      if (l === 6) Q1(t, n);
      else {
        if (
          ((s = t.current.alternate),
          (n & 30) === 0 &&
            !ka(s) &&
            ((l = _0(t, n)),
            l === 2 && ((a = $0(t)), a !== 0 && ((n = a), (l = hr(t, a)))),
            l === 1))
        )
          throw ((r = v2), at(t, 0), Q1(t, n), Se(t, xe()), r);
        switch (((t.finishedWork = s), (t.finishedLanes = n), l)) {
          case 0:
          case 1:
            throw Error(u(345));
          case 2:
            ot(t, Re, N1);
            break;
          case 3:
            if (
              (Q1(t, n),
              (n & 130023424) === n && ((l = fr + 500 - xe()), 10 < l))
            ) {
              if (Z2(t, 0) !== 0) break;
              if (((s = t.suspendedLanes), (s & n) !== n)) {
                (ye(), (t.pingedLanes |= t.suspendedLanes & s));
                break;
              }
              t.timeoutHandle = gl(ot.bind(null, t, Re, N1), l);
              break;
            }
            ot(t, Re, N1);
            break;
          case 4:
            if ((Q1(t, n), (n & 4194240) === n)) break;
            for (l = t.eventTimes, s = -1; 0 < n; ) {
              var o = 31 - r1(n);
              ((a = 1 << o), (o = l[o]), o > s && (s = o), (n &= ~a));
            }
            if (
              ((n = s),
              (n = xe() - n),
              (n =
                (120 > n
                  ? 120
                  : 480 > n
                    ? 480
                    : 1080 > n
                      ? 1080
                      : 1920 > n
                        ? 1920
                        : 3e3 > n
                          ? 3e3
                          : 4320 > n
                            ? 4320
                            : 1960 * wa(n / 1960)) - n),
              10 < n)
            ) {
              t.timeoutHandle = gl(ot.bind(null, t, Re, N1), n);
              break;
            }
            ot(t, Re, N1);
            break;
          case 5:
            ot(t, Re, N1);
            break;
          default:
            throw Error(u(329));
        }
      }
    }
    return (Se(t, xe()), t.callbackNode === r ? Ln.bind(null, t) : null);
  }
  function hr(t, l) {
    var r = L2;
    return (
      t.current.memoizedState.isDehydrated && (at(t, l).flags |= 256),
      (t = _0(t, l)),
      t !== 2 && ((l = Re), (Re = r), l !== null && vr(l)),
      t
    );
  }
  function vr(t) {
    Re === null ? (Re = t) : Re.push.apply(Re, t);
  }
  function ka(t) {
    for (var l = t; ; ) {
      if (l.flags & 16384) {
        var r = l.updateQueue;
        if (r !== null && ((r = r.stores), r !== null))
          for (var n = 0; n < r.length; n++) {
            var s = r[n],
              a = s.getSnapshot;
            s = s.value;
            try {
              if (!i1(a(), s)) return !1;
            } catch {
              return !1;
            }
          }
      }
      if (((r = l.child), l.subtreeFlags & 16384 && r !== null))
        ((r.return = l), (l = r));
      else {
        if (l === t) break;
        for (; l.sibling === null; ) {
          if (l.return === null || l.return === t) return !0;
          l = l.return;
        }
        ((l.sibling.return = l.return), (l = l.sibling));
      }
    }
    return !0;
  }
  function Q1(t, l) {
    for (
      l &= ~pr,
        l &= ~v0,
        t.suspendedLanes |= l,
        t.pingedLanes &= ~l,
        t = t.expirationTimes;
      0 < l;
    ) {
      var r = 31 - r1(l),
        n = 1 << r;
      ((t[r] = -1), (l &= ~n));
    }
  }
  function jn(t) {
    if ((X & 6) !== 0) throw Error(u(327));
    Gt();
    var l = Z2(t, 0);
    if ((l & 1) === 0) return (Se(t, xe()), null);
    var r = _0(t, l);
    if (t.tag !== 0 && r === 2) {
      var n = $0(t);
      n !== 0 && ((l = n), (r = hr(t, n)));
    }
    if (r === 1) throw ((r = v2), at(t, 0), Q1(t, l), Se(t, xe()), r);
    if (r === 6) throw Error(u(345));
    return (
      (t.finishedWork = t.current.alternate),
      (t.finishedLanes = l),
      ot(t, Re, N1),
      Se(t, xe()),
      null
    );
  }
  function Lr(t, l) {
    var r = X;
    X |= 1;
    try {
      return t(l);
    } finally {
      ((X = r), X === 0 && ((Et = xe() + 500), X2 && T1()));
    }
  }
  function st(t) {
    O1 !== null && O1.tag === 0 && (X & 6) === 0 && Gt();
    var l = X;
    X |= 1;
    var r = Je.transition,
      n = ee;
    try {
      if (((Je.transition = null), (ee = 1), t)) return t();
    } finally {
      ((ee = n), (Je.transition = r), (X = l), (X & 6) === 0 && T1());
    }
  }
  function jr() {
    ((Oe = Bt.current), ne(Bt));
  }
  function at(t, l) {
    ((t.finishedWork = null), (t.finishedLanes = 0));
    var r = t.timeoutHandle;
    if ((r !== -1 && ((t.timeoutHandle = -1), ia(r)), ve !== null))
      for (r = ve.return; r !== null; ) {
        var n = r;
        switch ((wl(n), n.tag)) {
          case 1:
            ((n = n.type.childContextTypes), n != null && Q2());
            break;
          case 3:
            (Nt(), ne(Ge), ne(Me), Tl());
            break;
          case 5:
            Sl(n);
            break;
          case 4:
            Nt();
            break;
          case 13:
            ne(de);
            break;
          case 19:
            ne(de);
            break;
          case 10:
            El(n.type._context);
            break;
          case 22:
          case 23:
            jr();
        }
        r = r.return;
      }
    if (
      ((me = t),
      (ve = t = $1(t.current, null)),
      (be = Oe = l),
      (je = 0),
      (v2 = null),
      (pr = v0 = nt = 0),
      (Re = L2 = null),
      lt !== null)
    ) {
      for (l = 0; l < lt.length; l++)
        if (((r = lt[l]), (n = r.interleaved), n !== null)) {
          r.interleaved = null;
          var s = n.next,
            a = r.pending;
          if (a !== null) {
            var o = a.next;
            ((a.next = s), (n.next = o));
          }
          r.pending = n;
        }
      lt = null;
    }
    return t;
  }
  function Vn(t, l) {
    do {
      var r = ve;
      try {
        if ((Bl(), (n0.current = d0), s0)) {
          for (var n = ce.memoizedState; n !== null; ) {
            var s = n.queue;
            (s !== null && (s.pending = null), (n = n.next));
          }
          s0 = !1;
        }
        if (
          ((it = 0),
          (Ve = Le = ce = null),
          (c2 = !1),
          (p2 = 0),
          (cr.current = null),
          r === null || r.return === null)
        ) {
          ((je = 1), (v2 = l), (ve = null));
          break;
        }
        e: {
          var a = t,
            o = r.return,
            d = r,
            c = l;
          if (
            ((l = be),
            (d.flags |= 32768),
            c !== null && typeof c == "object" && typeof c.then == "function")
          ) {
            var v = c,
              m = d,
              _ = m.tag;
            if ((m.mode & 1) === 0 && (_ === 0 || _ === 11 || _ === 15)) {
              var j = m.alternate;
              j
                ? ((m.updateQueue = j.updateQueue),
                  (m.memoizedState = j.memoizedState),
                  (m.lanes = j.lanes))
                : ((m.updateQueue = null), (m.memoizedState = null));
            }
            var w = Hi(o);
            if (w !== null) {
              ((w.flags &= -257),
                Wi(w, o, d, a, l),
                w.mode & 1 && Pi(a, v, l),
                (l = w),
                (c = v));
              var B = l.updateQueue;
              if (B === null) {
                var E = new Set();
                (E.add(c), (l.updateQueue = E));
              } else B.add(c);
              break e;
            } else {
              if ((l & 1) === 0) {
                (Pi(a, v, l), Vr());
                break e;
              }
              c = Error(u(426));
            }
          } else if (oe && d.mode & 1) {
            var he = Hi(o);
            if (he !== null) {
              ((he.flags & 65536) === 0 && (he.flags |= 256),
                Wi(he, o, d, a, l),
                Zl(Zt(c, d)));
              break e;
            }
          }
          ((a = c = Zt(c, d)),
            je !== 4 && (je = 2),
            L2 === null ? (L2 = [a]) : L2.push(a),
            (a = o));
          do {
            switch (a.tag) {
              case 3:
                ((a.flags |= 65536), (l &= -l), (a.lanes |= l));
                var x = Ti(a, c, l);
                ui(a, x);
                break e;
              case 1:
                d = c;
                var p = a.type,
                  h = a.stateNode;
                if (
                  (a.flags & 128) === 0 &&
                  (typeof p.getDerivedStateFromError == "function" ||
                    (h !== null &&
                      typeof h.componentDidCatch == "function" &&
                      (W1 === null || !W1.has(h))))
                ) {
                  ((a.flags |= 65536), (l &= -l), (a.lanes |= l));
                  var b = zi(a, d, l);
                  ui(a, b);
                  break e;
                }
            }
            a = a.return;
          } while (a !== null);
        }
        _n(r);
      } catch (G) {
        ((l = G), ve === r && r !== null && (ve = r = r.return));
        continue;
      }
      break;
    } while (!0);
  }
  function mn() {
    var t = h0.current;
    return ((h0.current = d0), t === null ? d0 : t);
  }
  function Vr() {
    ((je === 0 || je === 3 || je === 2) && (je = 4),
      me === null ||
        ((nt & 268435455) === 0 && (v0 & 268435455) === 0) ||
        Q1(me, be));
  }
  function _0(t, l) {
    var r = X;
    X |= 2;
    var n = mn();
    (me !== t || be !== l) && ((N1 = null), at(t, l));
    do
      try {
        Na();
        break;
      } catch (s) {
        Vn(t, s);
      }
    while (!0);
    if ((Bl(), (X = r), (h0.current = n), ve !== null)) throw Error(u(261));
    return ((me = null), (be = 0), je);
  }
  function Na() {
    for (; ve !== null; ) gn(ve);
  }
  function Za() {
    for (; ve !== null && !ts(); ) gn(ve);
  }
  function gn(t) {
    var l = Mn(t.alternate, t, Oe);
    ((t.memoizedProps = t.pendingProps),
      l === null ? _n(t) : (ve = l),
      (cr.current = null));
  }
  function _n(t) {
    var l = t;
    do {
      var r = l.alternate;
      if (((t = l.return), (l.flags & 32768) === 0)) {
        if (((r = _a(r, l, Oe)), r !== null)) {
          ve = r;
          return;
        }
      } else {
        if (((r = ba(r, l)), r !== null)) {
          ((r.flags &= 32767), (ve = r));
          return;
        }
        if (t !== null)
          ((t.flags |= 32768), (t.subtreeFlags = 0), (t.deletions = null));
        else {
          ((je = 6), (ve = null));
          return;
        }
      }
      if (((l = l.sibling), l !== null)) {
        ve = l;
        return;
      }
      ve = l = t;
    } while (l !== null);
    je === 0 && (je = 5);
  }
  function ot(t, l, r) {
    var n = ee,
      s = Je.transition;
    try {
      ((Je.transition = null), (ee = 1), ya(t, l, r, n));
    } finally {
      ((Je.transition = s), (ee = n));
    }
    return null;
  }
  function ya(t, l, r, n) {
    do Gt();
    while (O1 !== null);
    if ((X & 6) !== 0) throw Error(u(327));
    r = t.finishedWork;
    var s = t.finishedLanes;
    if (r === null) return null;
    if (((t.finishedWork = null), (t.finishedLanes = 0), r === t.current))
      throw Error(u(177));
    ((t.callbackNode = null), (t.callbackPriority = 0));
    var a = r.lanes | r.childLanes;
    if (
      (ps(t, a),
      t === me && ((ve = me = null), (be = 0)),
      ((r.subtreeFlags & 2064) === 0 && (r.flags & 2064) === 0) ||
        j0 ||
        ((j0 = !0),
        Cn(C2, function () {
          return (Gt(), null);
        })),
      (a = (r.flags & 15990) !== 0),
      (r.subtreeFlags & 15990) !== 0 || a)
    ) {
      ((a = Je.transition), (Je.transition = null));
      var o = ee;
      ee = 1;
      var d = X;
      ((X |= 4),
        (cr.current = null),
        Ma(t, r),
        fn(r, t),
        Ks(Vl),
        (E2 = !!jl),
        (Vl = jl = null),
        (t.current = r),
        Ca(r),
        ls(),
        (X = d),
        (ee = o),
        (Je.transition = a));
    } else t.current = r;
    if (
      (j0 && ((j0 = !1), (O1 = t), (V0 = s)),
      (a = t.pendingLanes),
      a === 0 && (W1 = null),
      ns(r.stateNode),
      Se(t, xe()),
      l !== null)
    )
      for (n = t.onRecoverableError, r = 0; r < l.length; r++)
        ((s = l[r]), n(s.value, { componentStack: s.stack, digest: s.digest }));
    if (L0) throw ((L0 = !1), (t = ur), (ur = null), t);
    return (
      (V0 & 1) !== 0 && t.tag !== 0 && Gt(),
      (a = t.pendingLanes),
      (a & 1) !== 0 ? (t === xr ? j2++ : ((j2 = 0), (xr = t))) : (j2 = 0),
      T1(),
      null
    );
  }
  function Gt() {
    if (O1 !== null) {
      var t = d3(V0),
        l = Je.transition,
        r = ee;
      try {
        if (((Je.transition = null), (ee = 16 > t ? 16 : t), O1 === null))
          var n = !1;
        else {
          if (((t = O1), (O1 = null), (V0 = 0), (X & 6) !== 0))
            throw Error(u(331));
          var s = X;
          for (X |= 4, Z = t.current; Z !== null; ) {
            var a = Z,
              o = a.child;
            if ((Z.flags & 16) !== 0) {
              var d = a.deletions;
              if (d !== null) {
                for (var c = 0; c < d.length; c++) {
                  var v = d[c];
                  for (Z = v; Z !== null; ) {
                    var m = Z;
                    switch (m.tag) {
                      case 0:
                      case 11:
                      case 15:
                        h2(8, m, a);
                    }
                    var _ = m.child;
                    if (_ !== null) ((_.return = m), (Z = _));
                    else
                      for (; Z !== null; ) {
                        m = Z;
                        var j = m.sibling,
                          w = m.return;
                        if ((an(m), m === v)) {
                          Z = null;
                          break;
                        }
                        if (j !== null) {
                          ((j.return = w), (Z = j));
                          break;
                        }
                        Z = w;
                      }
                  }
                }
                var B = a.alternate;
                if (B !== null) {
                  var E = B.child;
                  if (E !== null) {
                    B.child = null;
                    do {
                      var he = E.sibling;
                      ((E.sibling = null), (E = he));
                    } while (E !== null);
                  }
                }
                Z = a;
              }
            }
            if ((a.subtreeFlags & 2064) !== 0 && o !== null)
              ((o.return = a), (Z = o));
            else
              e: for (; Z !== null; ) {
                if (((a = Z), (a.flags & 2048) !== 0))
                  switch (a.tag) {
                    case 0:
                    case 11:
                    case 15:
                      h2(9, a, a.return);
                  }
                var x = a.sibling;
                if (x !== null) {
                  ((x.return = a.return), (Z = x));
                  break e;
                }
                Z = a.return;
              }
          }
          var p = t.current;
          for (Z = p; Z !== null; ) {
            o = Z;
            var h = o.child;
            if ((o.subtreeFlags & 2064) !== 0 && h !== null)
              ((h.return = o), (Z = h));
            else
              e: for (o = p; Z !== null; ) {
                if (((d = Z), (d.flags & 2048) !== 0))
                  try {
                    switch (d.tag) {
                      case 0:
                      case 11:
                      case 15:
                        x0(9, d);
                    }
                  } catch (G) {
                    fe(d, d.return, G);
                  }
                if (d === o) {
                  Z = null;
                  break e;
                }
                var b = d.sibling;
                if (b !== null) {
                  ((b.return = d.return), (Z = b));
                  break e;
                }
                Z = d.return;
              }
          }
          if (
            ((X = s), T1(), u1 && typeof u1.onPostCommitFiberRoot == "function")
          )
            try {
              u1.onPostCommitFiberRoot(w2, t);
            } catch {}
          n = !0;
        }
        return n;
      } finally {
        ((ee = r), (Je.transition = l));
      }
    }
    return !1;
  }
  function bn(t, l, r) {
    ((l = Zt(r, l)),
      (l = Ti(t, l, 1)),
      (t = P1(t, l, 1)),
      (l = ye()),
      t !== null && (Pt(t, 1, l), Se(t, l)));
  }
  function fe(t, l, r) {
    if (t.tag === 3) bn(t, t, r);
    else
      for (; l !== null; ) {
        if (l.tag === 3) {
          bn(l, t, r);
          break;
        } else if (l.tag === 1) {
          var n = l.stateNode;
          if (
            typeof l.type.getDerivedStateFromError == "function" ||
            (typeof n.componentDidCatch == "function" &&
              (W1 === null || !W1.has(n)))
          ) {
            ((t = Zt(r, t)),
              (t = zi(l, t, 1)),
              (l = P1(l, t, 1)),
              (t = ye()),
              l !== null && (Pt(l, 1, t), Se(l, t)));
            break;
          }
        }
        l = l.return;
      }
  }
  function Ba(t, l, r) {
    var n = t.pingCache;
    (n !== null && n.delete(l),
      (l = ye()),
      (t.pingedLanes |= t.suspendedLanes & r),
      me === t &&
        (be & r) === r &&
        (je === 4 || (je === 3 && (be & 130023424) === be && 500 > xe() - fr)
          ? at(t, 0)
          : (pr |= r)),
      Se(t, l));
  }
  function Fn(t, l) {
    l === 0 &&
      ((t.mode & 1) === 0
        ? (l = 1)
        : ((l = N2), (N2 <<= 1), (N2 & 130023424) === 0 && (N2 = 4194304)));
    var r = ye();
    ((t = C1(t, l)), t !== null && (Pt(t, l, r), Se(t, r)));
  }
  function Ea(t) {
    var l = t.memoizedState,
      r = 0;
    (l !== null && (r = l.retryLane), Fn(t, r));
  }
  function Ga(t, l) {
    var r = 0;
    switch (t.tag) {
      case 13:
        var n = t.stateNode,
          s = t.memoizedState;
        s !== null && (r = s.retryLane);
        break;
      case 19:
        n = t.stateNode;
        break;
      default:
        throw Error(u(314));
    }
    (n !== null && n.delete(l), Fn(t, r));
  }
  var Mn;
  Mn = function (t, l, r) {
    if (t !== null)
      if (t.memoizedProps !== l.pendingProps || Ge.current) De = !0;
      else {
        if ((t.lanes & r) === 0 && (l.flags & 128) === 0)
          return ((De = !1), ga(t, l, r));
        De = (t.flags & 131072) !== 0;
      }
    else ((De = !1), oe && (l.flags & 1048576) !== 0 && ri(l, K2, l.index));
    switch (((l.lanes = 0), l.tag)) {
      case 2:
        var n = l.type;
        (f0(t, l), (t = l.pendingProps));
        var s = _t(l, Me.current);
        (kt(l, r), (s = Hl(null, l, n, t, s, r)));
        var a = Wl();
        return (
          (l.flags |= 1),
          typeof s == "object" &&
          s !== null &&
          typeof s.render == "function" &&
          s.$$typeof === void 0
            ? ((l.tag = 1),
              (l.memoizedState = null),
              (l.updateQueue = null),
              Ae(n) ? ((a = !0), $2(l)) : (a = !1),
              (l.memoizedState =
                s.state !== null && s.state !== void 0 ? s.state : null),
              Dl(l),
              (s.updater = c0),
              (l.stateNode = s),
              (s._reactInternals = l),
              Yl(l, n, t, r),
              (l = er(null, l, n, !0, a, r)))
            : ((l.tag = 0), oe && a && Cl(l), Ze(null, l, s, r), (l = l.child)),
          l
        );
      case 16:
        n = l.elementType;
        e: {
          switch (
            (f0(t, l),
            (t = l.pendingProps),
            (s = n._init),
            (n = s(n._payload)),
            (l.type = n),
            (s = l.tag = Da(n)),
            (t = s1(n, t)),
            s)
          ) {
            case 0:
              l = ql(null, l, n, t, r);
              break e;
            case 1:
              l = Yi(null, l, n, t, r);
              break e;
            case 11:
              l = Oi(null, l, n, t, r);
              break e;
            case 14:
              l = Ui(null, l, n, s1(n.type, t), r);
              break e;
          }
          throw Error(u(306, n, ""));
        }
        return l;
      case 0:
        return (
          (n = l.type),
          (s = l.pendingProps),
          (s = l.elementType === n ? s : s1(n, s)),
          ql(t, l, n, s, r)
        );
      case 1:
        return (
          (n = l.type),
          (s = l.pendingProps),
          (s = l.elementType === n ? s : s1(n, s)),
          Yi(t, l, n, s, r)
        );
      case 3:
        e: {
          if ((Ki(l), t === null)) throw Error(u(387));
          ((n = l.pendingProps),
            (a = l.memoizedState),
            (s = a.element),
            fi(t, l),
            r0(l, n, null, r));
          var o = l.memoizedState;
          if (((n = o.element), a.isDehydrated))
            if (
              ((a = {
                element: n,
                isDehydrated: !1,
                cache: o.cache,
                pendingSuspenseBoundaries: o.pendingSuspenseBoundaries,
                transitions: o.transitions,
              }),
              (l.updateQueue.baseState = a),
              (l.memoizedState = a),
              l.flags & 256)
            ) {
              ((s = Zt(Error(u(423)), l)), (l = Ji(t, l, n, r, s)));
              break e;
            } else if (n !== s) {
              ((s = Zt(Error(u(424)), l)), (l = Ji(t, l, n, r, s)));
              break e;
            } else
              for (
                We = R1(l.stateNode.containerInfo.firstChild),
                  He = l,
                  oe = !0,
                  n1 = null,
                  r = ci(l, null, n, r),
                  l.child = r;
                r;
              )
                ((r.flags = (r.flags & -3) | 4096), (r = r.sibling));
          else {
            if ((Mt(), n === s)) {
              l = k1(t, l, r);
              break e;
            }
            Ze(t, l, n, r);
          }
          l = l.child;
        }
        return l;
      case 5:
        return (
          hi(l),
          t === null && Nl(l),
          (n = l.type),
          (s = l.pendingProps),
          (a = t !== null ? t.memoizedProps : null),
          (o = s.children),
          ml(n, s) ? (o = null) : a !== null && ml(n, a) && (l.flags |= 32),
          Xi(t, l),
          Ze(t, l, o, r),
          l.child
        );
      case 6:
        return (t === null && Nl(l), null);
      case 13:
        return qi(t, l, r);
      case 4:
        return (
          Rl(l, l.stateNode.containerInfo),
          (n = l.pendingProps),
          t === null ? (l.child = Ct(l, null, n, r)) : Ze(t, l, n, r),
          l.child
        );
      case 11:
        return (
          (n = l.type),
          (s = l.pendingProps),
          (s = l.elementType === n ? s : s1(n, s)),
          Oi(t, l, n, s, r)
        );
      case 7:
        return (Ze(t, l, l.pendingProps, r), l.child);
      case 8:
        return (Ze(t, l, l.pendingProps.children, r), l.child);
      case 12:
        return (Ze(t, l, l.pendingProps.children, r), l.child);
      case 10:
        e: {
          if (
            ((n = l.type._context),
            (s = l.pendingProps),
            (a = l.memoizedProps),
            (o = s.value),
            re(e0, n._currentValue),
            (n._currentValue = o),
            a !== null)
          )
            if (i1(a.value, o)) {
              if (a.children === s.children && !Ge.current) {
                l = k1(t, l, r);
                break e;
              }
            } else
              for (a = l.child, a !== null && (a.return = l); a !== null; ) {
                var d = a.dependencies;
                if (d !== null) {
                  o = a.child;
                  for (var c = d.firstContext; c !== null; ) {
                    if (c.context === n) {
                      if (a.tag === 1) {
                        ((c = w1(-1, r & -r)), (c.tag = 2));
                        var v = a.updateQueue;
                        if (v !== null) {
                          v = v.shared;
                          var m = v.pending;
                          (m === null
                            ? (c.next = c)
                            : ((c.next = m.next), (m.next = c)),
                            (v.pending = c));
                        }
                      }
                      ((a.lanes |= r),
                        (c = a.alternate),
                        c !== null && (c.lanes |= r),
                        Gl(a.return, r, l),
                        (d.lanes |= r));
                      break;
                    }
                    c = c.next;
                  }
                } else if (a.tag === 10) o = a.type === l.type ? null : a.child;
                else if (a.tag === 18) {
                  if (((o = a.return), o === null)) throw Error(u(341));
                  ((o.lanes |= r),
                    (d = o.alternate),
                    d !== null && (d.lanes |= r),
                    Gl(o, r, l),
                    (o = a.sibling));
                } else o = a.child;
                if (o !== null) o.return = a;
                else
                  for (o = a; o !== null; ) {
                    if (o === l) {
                      o = null;
                      break;
                    }
                    if (((a = o.sibling), a !== null)) {
                      ((a.return = o.return), (o = a));
                      break;
                    }
                    o = o.return;
                  }
                a = o;
              }
          (Ze(t, l, s.children, r), (l = l.child));
        }
        return l;
      case 9:
        return (
          (s = l.type),
          (n = l.pendingProps.children),
          kt(l, r),
          (s = Ye(s)),
          (n = n(s)),
          (l.flags |= 1),
          Ze(t, l, n, r),
          l.child
        );
      case 14:
        return (
          (n = l.type),
          (s = s1(n, l.pendingProps)),
          (s = s1(n.type, s)),
          Ui(t, l, n, s, r)
        );
      case 15:
        return Qi(t, l, l.type, l.pendingProps, r);
      case 17:
        return (
          (n = l.type),
          (s = l.pendingProps),
          (s = l.elementType === n ? s : s1(n, s)),
          f0(t, l),
          (l.tag = 1),
          Ae(n) ? ((t = !0), $2(l)) : (t = !1),
          kt(l, r),
          Si(l, n, s),
          Yl(l, n, s, r),
          er(null, l, n, !0, t, r)
        );
      case 19:
        return tn(t, l, r);
      case 22:
        return $i(t, l, r);
    }
    throw Error(u(156, l.tag));
  };
  function Cn(t, l) {
    return i3(t, l);
  }
  function Aa(t, l, r, n) {
    ((this.tag = t),
      (this.key = r),
      (this.sibling =
        this.child =
        this.return =
        this.stateNode =
        this.type =
        this.elementType =
          null),
      (this.index = 0),
      (this.ref = null),
      (this.pendingProps = l),
      (this.dependencies =
        this.memoizedState =
        this.updateQueue =
        this.memoizedProps =
          null),
      (this.mode = n),
      (this.subtreeFlags = this.flags = 0),
      (this.deletions = null),
      (this.childLanes = this.lanes = 0),
      (this.alternate = null));
  }
  function qe(t, l, r, n) {
    return new Aa(t, l, r, n);
  }
  function mr(t) {
    return ((t = t.prototype), !(!t || !t.isReactComponent));
  }
  function Da(t) {
    if (typeof t == "function") return mr(t) ? 1 : 0;
    if (t != null) {
      if (((t = t.$$typeof), t === p1)) return 11;
      if (t === f1) return 14;
    }
    return 2;
  }
  function $1(t, l) {
    var r = t.alternate;
    return (
      r === null
        ? ((r = qe(t.tag, l, t.key, t.mode)),
          (r.elementType = t.elementType),
          (r.type = t.type),
          (r.stateNode = t.stateNode),
          (r.alternate = t),
          (t.alternate = r))
        : ((r.pendingProps = l),
          (r.type = t.type),
          (r.flags = 0),
          (r.subtreeFlags = 0),
          (r.deletions = null)),
      (r.flags = t.flags & 14680064),
      (r.childLanes = t.childLanes),
      (r.lanes = t.lanes),
      (r.child = t.child),
      (r.memoizedProps = t.memoizedProps),
      (r.memoizedState = t.memoizedState),
      (r.updateQueue = t.updateQueue),
      (l = t.dependencies),
      (r.dependencies =
        l === null ? null : { lanes: l.lanes, firstContext: l.firstContext }),
      (r.sibling = t.sibling),
      (r.index = t.index),
      (r.ref = t.ref),
      r
    );
  }
  function b0(t, l, r, n, s, a) {
    var o = 2;
    if (((n = t), typeof t == "function")) mr(t) && (o = 1);
    else if (typeof t == "string") o = 5;
    else
      e: switch (t) {
        case Be:
          return dt(r.children, s, a, l);
        case Qe:
          ((o = 8), (s |= 8));
          break;
        case Z1:
          return (
            (t = qe(12, r, l, s | 2)),
            (t.elementType = Z1),
            (t.lanes = a),
            t
          );
        case Te:
          return (
            (t = qe(13, r, l, s)),
            (t.elementType = Te),
            (t.lanes = a),
            t
          );
        case l1:
          return (
            (t = qe(19, r, l, s)),
            (t.elementType = l1),
            (t.lanes = a),
            t
          );
        case pe:
          return F0(r, s, a, l);
        default:
          if (typeof t == "object" && t !== null)
            switch (t.$$typeof) {
              case g1:
                o = 10;
                break e;
              case Y1:
                o = 9;
                break e;
              case p1:
                o = 11;
                break e;
              case f1:
                o = 14;
                break e;
              case Ee:
                ((o = 16), (n = null));
                break e;
            }
          throw Error(u(130, t == null ? t : typeof t, ""));
      }
    return (
      (l = qe(o, r, l, s)),
      (l.elementType = t),
      (l.type = n),
      (l.lanes = a),
      l
    );
  }
  function dt(t, l, r, n) {
    return ((t = qe(7, t, n, l)), (t.lanes = r), t);
  }
  function F0(t, l, r, n) {
    return (
      (t = qe(22, t, n, l)),
      (t.elementType = pe),
      (t.lanes = r),
      (t.stateNode = { isHidden: !1 }),
      t
    );
  }
  function gr(t, l, r) {
    return ((t = qe(6, t, null, l)), (t.lanes = r), t);
  }
  function _r(t, l, r) {
    return (
      (l = qe(4, t.children !== null ? t.children : [], t.key, l)),
      (l.lanes = r),
      (l.stateNode = {
        containerInfo: t.containerInfo,
        pendingChildren: null,
        implementation: t.implementation,
      }),
      l
    );
  }
  function Ra(t, l, r, n, s) {
    ((this.tag = l),
      (this.containerInfo = t),
      (this.finishedWork =
        this.pingCache =
        this.current =
        this.pendingChildren =
          null),
      (this.timeoutHandle = -1),
      (this.callbackNode = this.pendingContext = this.context = null),
      (this.callbackPriority = 0),
      (this.eventTimes = X0(0)),
      (this.expirationTimes = X0(-1)),
      (this.entangledLanes =
        this.finishedLanes =
        this.mutableReadLanes =
        this.expiredLanes =
        this.pingedLanes =
        this.suspendedLanes =
        this.pendingLanes =
          0),
      (this.entanglements = X0(0)),
      (this.identifierPrefix = n),
      (this.onRecoverableError = s),
      (this.mutableSourceEagerHydrationData = null));
  }
  function br(t, l, r, n, s, a, o, d, c) {
    return (
      (t = new Ra(t, l, r, d, c)),
      l === 1 ? ((l = 1), a === !0 && (l |= 8)) : (l = 0),
      (a = qe(3, null, null, l)),
      (t.current = a),
      (a.stateNode = t),
      (a.memoizedState = {
        element: n,
        isDehydrated: r,
        cache: null,
        transitions: null,
        pendingSuspenseBoundaries: null,
      }),
      Dl(a),
      t
    );
  }
  function Sa(t, l, r) {
    var n =
      3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
      $$typeof: Ne,
      key: n == null ? null : "" + n,
      children: t,
      containerInfo: l,
      implementation: r,
    };
  }
  function wn(t) {
    if (!t) return I1;
    t = t._reactInternals;
    e: {
      if (K1(t) !== t || t.tag !== 1) throw Error(u(170));
      var l = t;
      do {
        switch (l.tag) {
          case 3:
            l = l.stateNode.context;
            break e;
          case 1:
            if (Ae(l.type)) {
              l = l.stateNode.__reactInternalMemoizedMergedChildContext;
              break e;
            }
        }
        l = l.return;
      } while (l !== null);
      throw Error(u(171));
    }
    if (t.tag === 1) {
      var r = t.type;
      if (Ae(r)) return ei(t, r, l);
    }
    return l;
  }
  function kn(t, l, r, n, s, a, o, d, c) {
    return (
      (t = br(r, n, !0, t, s, a, o, d, c)),
      (t.context = wn(null)),
      (r = t.current),
      (n = ye()),
      (s = U1(r)),
      (a = w1(n, s)),
      (a.callback = l ?? null),
      P1(r, a, s),
      (t.current.lanes = s),
      Pt(t, s, n),
      Se(t, n),
      t
    );
  }
  function M0(t, l, r, n) {
    var s = l.current,
      a = ye(),
      o = U1(s);
    return (
      (r = wn(r)),
      l.context === null ? (l.context = r) : (l.pendingContext = r),
      (l = w1(a, o)),
      (l.payload = { element: t }),
      (n = n === void 0 ? null : n),
      n !== null && (l.callback = n),
      (t = P1(s, l, o)),
      t !== null && (d1(t, s, o, a), l0(t, s, o)),
      o
    );
  }
  function C0(t) {
    if (((t = t.current), !t.child)) return null;
    switch (t.child.tag) {
      case 5:
        return t.child.stateNode;
      default:
        return t.child.stateNode;
    }
  }
  function Nn(t, l) {
    if (((t = t.memoizedState), t !== null && t.dehydrated !== null)) {
      var r = t.retryLane;
      t.retryLane = r !== 0 && r < l ? r : l;
    }
  }
  function Fr(t, l) {
    (Nn(t, l), (t = t.alternate) && Nn(t, l));
  }
  function Ia() {
    return null;
  }
  var Zn =
    typeof reportError == "function"
      ? reportError
      : function (t) {
          console.error(t);
        };
  function Mr(t) {
    this._internalRoot = t;
  }
  ((w0.prototype.render = Mr.prototype.render =
    function (t) {
      var l = this._internalRoot;
      if (l === null) throw Error(u(409));
      M0(t, l, null, null);
    }),
    (w0.prototype.unmount = Mr.prototype.unmount =
      function () {
        var t = this._internalRoot;
        if (t !== null) {
          this._internalRoot = null;
          var l = t.containerInfo;
          (st(function () {
            M0(null, t, null, null);
          }),
            (l[_1] = null));
        }
      }));
  function w0(t) {
    this._internalRoot = t;
  }
  w0.prototype.unstable_scheduleHydration = function (t) {
    if (t) {
      var l = f3();
      t = { blockedOn: null, target: t, priority: l };
      for (var r = 0; r < G1.length && l !== 0 && l < G1[r].priority; r++);
      (G1.splice(r, 0, t), r === 0 && h3(t));
    }
  };
  function Cr(t) {
    return !(!t || (t.nodeType !== 1 && t.nodeType !== 9 && t.nodeType !== 11));
  }
  function k0(t) {
    return !(
      !t ||
      (t.nodeType !== 1 &&
        t.nodeType !== 9 &&
        t.nodeType !== 11 &&
        (t.nodeType !== 8 || t.nodeValue !== " react-mount-point-unstable "))
    );
  }
  function yn() {}
  function Ta(t, l, r, n, s) {
    if (s) {
      if (typeof n == "function") {
        var a = n;
        n = function () {
          var v = C0(o);
          a.call(v);
        };
      }
      var o = kn(l, n, t, 0, null, !1, !1, "", yn);
      return (
        (t._reactRootContainer = o),
        (t[_1] = o.current),
        l2(t.nodeType === 8 ? t.parentNode : t),
        st(),
        o
      );
    }
    for (; (s = t.lastChild); ) t.removeChild(s);
    if (typeof n == "function") {
      var d = n;
      n = function () {
        var v = C0(c);
        d.call(v);
      };
    }
    var c = br(t, 0, !1, null, null, !1, !1, "", yn);
    return (
      (t._reactRootContainer = c),
      (t[_1] = c.current),
      l2(t.nodeType === 8 ? t.parentNode : t),
      st(function () {
        M0(l, c, r, n);
      }),
      c
    );
  }
  function N0(t, l, r, n, s) {
    var a = r._reactRootContainer;
    if (a) {
      var o = a;
      if (typeof s == "function") {
        var d = s;
        s = function () {
          var c = C0(o);
          d.call(c);
        };
      }
      M0(l, o, t, s);
    } else o = Ta(r, l, t, s, n);
    return C0(o);
  }
  ((c3 = function (t) {
    switch (t.tag) {
      case 3:
        var l = t.stateNode;
        if (l.current.memoizedState.isDehydrated) {
          var r = zt(l.pendingLanes);
          r !== 0 &&
            (Y0(l, r | 1),
            Se(l, xe()),
            (X & 6) === 0 && ((Et = xe() + 500), T1()));
        }
        break;
      case 13:
        (st(function () {
          var n = C1(t, 1);
          if (n !== null) {
            var s = ye();
            d1(n, t, 1, s);
          }
        }),
          Fr(t, 1));
    }
  }),
    (K0 = function (t) {
      if (t.tag === 13) {
        var l = C1(t, 134217728);
        if (l !== null) {
          var r = ye();
          d1(l, t, 134217728, r);
        }
        Fr(t, 134217728);
      }
    }),
    (p3 = function (t) {
      if (t.tag === 13) {
        var l = U1(t),
          r = C1(t, l);
        if (r !== null) {
          var n = ye();
          d1(r, t, l, n);
        }
        Fr(t, l);
      }
    }),
    (f3 = function () {
      return ee;
    }),
    (u3 = function (t, l) {
      var r = ee;
      try {
        return ((ee = t), l());
      } finally {
        ee = r;
      }
    }),
    (H0 = function (t, l, r) {
      switch (l) {
        case "input":
          if ((A0(t, r), (l = r.name), r.type === "radio" && l != null)) {
            for (r = t; r.parentNode; ) r = r.parentNode;
            for (
              r = r.querySelectorAll(
                "input[name=" + JSON.stringify("" + l) + '][type="radio"]',
              ),
                l = 0;
              l < r.length;
              l++
            ) {
              var n = r[l];
              if (n !== t && n.form === t.form) {
                var s = U2(n);
                if (!s) throw Error(u(90));
                (Rr(n), A0(n, s));
              }
            }
          }
          break;
        case "textarea":
          Pr(t, r);
          break;
        case "select":
          ((l = r.value), l != null && ct(t, !!r.multiple, l, !1));
      }
    }),
    (Kr = Lr),
    (Jr = st));
  var za = { usingClientEntryPoint: !1, Events: [n2, mt, U2, Xr, Yr, Lr] },
    V2 = {
      findFiberByHostInstance: J1,
      bundleType: 0,
      version: "18.3.1",
      rendererPackageName: "react-dom",
    },
    Pa = {
      bundleType: V2.bundleType,
      version: V2.version,
      rendererPackageName: V2.rendererPackageName,
      rendererConfig: V2.rendererConfig,
      overrideHookState: null,
      overrideHookStateDeletePath: null,
      overrideHookStateRenamePath: null,
      overrideProps: null,
      overridePropsDeletePath: null,
      overridePropsRenamePath: null,
      setErrorHandler: null,
      setSuspenseHandler: null,
      scheduleUpdate: null,
      currentDispatcherRef: Fe.ReactCurrentDispatcher,
      findHostInstanceByFiber: function (t) {
        return ((t = l3(t)), t === null ? null : t.stateNode);
      },
      findFiberByHostInstance: V2.findFiberByHostInstance || Ia,
      findHostInstancesForRefresh: null,
      scheduleRefresh: null,
      scheduleRoot: null,
      setRefreshHandler: null,
      getCurrentFiber: null,
      reconcilerVersion: "18.3.1-next-f1338f8080-20240426",
    };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var Z0 = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Z0.isDisabled && Z0.supportsFiber)
      try {
        ((w2 = Z0.inject(Pa)), (u1 = Z0));
      } catch {}
  }
  return (
    (Ie.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = za),
    (Ie.createPortal = function (t, l) {
      var r =
        2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
      if (!Cr(l)) throw Error(u(200));
      return Sa(t, l, null, r);
    }),
    (Ie.createRoot = function (t, l) {
      if (!Cr(t)) throw Error(u(299));
      var r = !1,
        n = "",
        s = Zn;
      return (
        l != null &&
          (l.unstable_strictMode === !0 && (r = !0),
          l.identifierPrefix !== void 0 && (n = l.identifierPrefix),
          l.onRecoverableError !== void 0 && (s = l.onRecoverableError)),
        (l = br(t, 1, !1, null, null, r, !1, n, s)),
        (t[_1] = l.current),
        l2(t.nodeType === 8 ? t.parentNode : t),
        new Mr(l)
      );
    }),
    (Ie.findDOMNode = function (t) {
      if (t == null) return null;
      if (t.nodeType === 1) return t;
      var l = t._reactInternals;
      if (l === void 0)
        throw typeof t.render == "function"
          ? Error(u(188))
          : ((t = Object.keys(t).join(",")), Error(u(268, t)));
      return ((t = l3(l)), (t = t === null ? null : t.stateNode), t);
    }),
    (Ie.flushSync = function (t) {
      return st(t);
    }),
    (Ie.hydrate = function (t, l, r) {
      if (!k0(l)) throw Error(u(200));
      return N0(null, t, l, !0, r);
    }),
    (Ie.hydrateRoot = function (t, l, r) {
      if (!Cr(t)) throw Error(u(405));
      var n = (r != null && r.hydratedSources) || null,
        s = !1,
        a = "",
        o = Zn;
      if (
        (r != null &&
          (r.unstable_strictMode === !0 && (s = !0),
          r.identifierPrefix !== void 0 && (a = r.identifierPrefix),
          r.onRecoverableError !== void 0 && (o = r.onRecoverableError)),
        (l = kn(l, null, t, 1, r ?? null, s, !1, a, o)),
        (t[_1] = l.current),
        l2(t),
        n)
      )
        for (t = 0; t < n.length; t++)
          ((r = n[t]),
            (s = r._getVersion),
            (s = s(r._source)),
            l.mutableSourceEagerHydrationData == null
              ? (l.mutableSourceEagerHydrationData = [r, s])
              : l.mutableSourceEagerHydrationData.push(r, s));
      return new w0(l);
    }),
    (Ie.render = function (t, l, r) {
      if (!k0(l)) throw Error(u(200));
      return N0(null, t, l, !1, r);
    }),
    (Ie.unmountComponentAtNode = function (t) {
      if (!k0(t)) throw Error(u(40));
      return t._reactRootContainer
        ? (st(function () {
            N0(null, null, t, !1, function () {
              ((t._reactRootContainer = null), (t[_1] = null));
            });
          }),
          !0)
        : !1;
    }),
    (Ie.unstable_batchedUpdates = Lr),
    (Ie.unstable_renderSubtreeIntoContainer = function (t, l, r, n) {
      if (!k0(r)) throw Error(u(200));
      if (t == null || t._reactInternals === void 0) throw Error(u(38));
      return N0(t, l, r, !1, n);
    }),
    (Ie.version = "18.3.1-next-f1338f8080-20240426"),
    Ie
  );
}
var In;
function Ya() {
  if (In) return Nr.exports;
  In = 1;
  function L() {
    if (
      !(
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" ||
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"
      )
    )
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(L);
      } catch (F) {
        console.error(F);
      }
  }
  return (L(), (Nr.exports = Xa()), Nr.exports);
}
var Tn;
function Ka() {
  if (Tn) return y0;
  Tn = 1;
  var L = Ya();
  return ((y0.createRoot = L.createRoot), (y0.hydrateRoot = L.hydrateRoot), y0);
}
var Ja = Ka(),
  $ = Er();
const i = {
    p10087700: "M2.87237 3.32229V38.741L0 37.108V1.66117L2.87237 3.32229Z",
    p100c3900:
      "M178.369 118.56V134.608L182.536 132.187V116.167L178.369 118.56Z",
    p101c5a00:
      "M141.619 27.5916L47.1688 82.1274L2.06711e-06 54.6202L94.563 0L141.619 27.5916Z",
    p10390980:
      "M2.87237 3.2941V139.084L2.72756e-06 137.423V1.63294L2.87237 3.2941Z",
    p103b2000:
      "M23.2606 2.42131L4.16778 34.1236L8.33552 31.7023L27.4283 0.0281562L23.2606 2.42131Z",
    p103d4680: "M2.95686 15.1754V49.2427L0 47.4126V13.3735L2.95686 15.1754Z",
    p105f6c00:
      "M4.19593 45.5544V50.3689L29.3432 7.23582V2.42133L4.19593 45.5544Z",
    p106a9870:
      "M29.0617 68.585L30.2162 69.0918L119.429 17.287L118.274 16.8365L29.0617 68.585Z",
    p10a44c00:
      "M23.1761 15.1754V49.2427L26.1611 47.4126V13.3454L23.1761 15.1754Z",
    p10b20b00:
      "M208.979 75.1169L222.693 83.3381L226.861 80.9168L213.147 72.6674L208.979 75.1169Z",
    p10bee600:
      "M19.2055 31.9275L16.2205 30.1256L4.75913 36.6293L7.7723 38.4875L19.2055 31.9275Z",
    p10d1b200: "M25.1473 50.6222V55.4367L0 7.23572V2.42129L25.1473 50.6222Z",
    p10d9ad80:
      "M25.1473 16.9492V21.7636L29.3432 19.3424V14.5279L25.1473 16.9492Z",
    p10dfd080:
      "M2.87237 3.32228V38.741L1.28326e-05 37.0798V1.66116L2.87237 3.32228Z",
    p11032c0: "M77.554 166.958V171.772L81.7499 169.351V164.536L77.554 166.958Z",
    p11079380:
      "M38.0448 96.2893L43.339 99.527V100.597L36.665 96.4863V77.7634L38.0448 78.6081V96.2893Z",
    p1110ea70:
      "M533.726 712.034C533.247 712.034 532.768 711.78 532.487 711.302C532.121 710.626 532.346 709.753 533.022 709.387L634.935 652.374C635.611 652.008 636.455 652.233 636.85 652.909C637.216 653.585 636.99 654.457 636.315 654.823L534.402 711.837C534.176 711.949 533.951 712.006 533.726 712.006V712.034Z",
    p1119bc00:
      "M38.0448 52.396L43.339 55.6338V56.7037L36.665 52.5931V40.2331L38.0448 41.1059V52.396Z",
    p11297d00:
      "M2.95686 15.1754V49.2426L26.1611 35.8973V1.83004L2.95686 15.1754ZM19.0365 31.7586L10.1378 36.8827V19.3141L19.0365 14.1899V31.7586Z",
    p112a81f0:
      "M110.277 40.571L69.6409 64.2492V56.2532L110.277 32.6032V40.571Z",
    p11351700:
      "M126.469 63.6298L120.048 67.5714V74.9761L126.469 71.0344V63.6298ZM114.754 70.3587L108.333 74.3004V81.7051L114.754 77.7634V70.3587ZM103.067 77.1159L96.6468 81.0575V88.4622L103.067 84.5206V77.1159ZM73.2454 94.5155V101.92L79.666 97.9785V90.5739L73.2454 94.5155ZM91.3526 83.8449L84.9321 87.7865V95.1912L91.3526 91.2496V83.8449Z",
    p11426b00:
      "M31.1737 85.3934L36.665 82.0148V64.4181L37.8477 63.6861V82.4089L31.1737 86.5196V85.3934Z",
    p11541af0:
      "M24.4152 67.2336L25.3726 68.0219V113.576L24.4152 112.76V67.2336Z",
    p1169e300:
      "M2.87238 3.32224V38.7409L9.24748e-06 37.0798V1.66112L2.87238 3.32224Z",
    p117b2580:
      "M66.7404 76.6936V365.449L2.44181e-06 327.102V38.3468L66.7404 76.6936Z",
    p11a66500:
      "M4.19593 11.1493V15.9637L18.783 7.23577V2.42131L4.19593 11.1493Z",
    p11a6900:
      "M141.197 162.819V167.633L282.309 86.0691V81.3109L141.197 162.819Z",
    p11aed000: "M2.87236 3.2941V139.085L0 137.423V1.63298L2.87236 3.2941Z",
    p11bde100:
      "M18.9521 67.6559L24.4434 64.2773V53.0717L25.6261 52.3397V64.6715L18.9521 68.7821V67.6559Z",
    p11ce2580:
      "M2.84422 3.2941V139.085L5.68843 137.423V1.66112L2.84422 3.2941Z",
    p11dceb40:
      "M0 13.3453L2.98501 15.1754L26.1893 1.83004L23.1761 0L0 13.3453Z",
    p11f9a900:
      "M26.1611 13.3735L23.1761 15.1754L0 1.83004L2.98502 0L26.1611 13.3735Z",
    p120e9380:
      "M50.2665 78.5518L55.5607 81.8177V82.8594L48.8585 78.7489V66.4171L50.2665 67.2617V78.5518Z",
    p121e1800:
      "M183.184 64.5589C182.705 64.5589 182.227 64.3055 181.945 63.8268C181.579 63.1511 181.804 62.2783 182.48 61.9123L284.393 4.89894C285.069 4.53293 285.913 4.75816 286.308 5.43388C286.674 6.10959 286.449 6.98239 285.773 7.3484L183.86 64.3618C183.635 64.4744 183.409 64.5307 183.184 64.5307V64.5589Z",
    p12251300: "M2.84421 3.2941V38.7128L0 37.0798V1.63298L2.84421 3.2941Z",
    p1230cc0c:
      "M5.71658 1.66116L2.87236 3.32228L0 1.66116L2.87236 0L5.71658 1.66116Z",
    p12422e00:
      "M154.122 132.581V148.629L158.29 146.208V130.188L154.122 132.581Z",
    p125bb700:
      "M187.999 158.905L134.044 189.847V192.438L187.999 161.496V158.905Z",
    p12734300:
      "M82.8482 48.8204L81.8626 49.6087V95.1631L82.8482 94.3747V48.8204Z",
    p1277c900:
      "M8.36372 2.42131L4.19598 4.84262L4.88466e-05 2.42131L4.19598 0L8.36372 2.42131Z",
    p12ad4080:
      "M50.0694 3.25285e-06L43.3672 4.11057V16.4705L50.0694 12.3599V0.0281425V3.25285e-06ZM37.8477 7.03869L31.1455 11.1493V23.5092L37.8477 19.3986V7.06683V7.03869ZM25.6261 14.0774L18.9239 18.1879V30.5479L25.6261 26.4373V14.1055V14.0774Z",
    p12b32820:
      "M1.41119e-05 2.42131L25.1473 16.9491L29.3432 14.5278L4.16776 0L1.41119e-05 2.42131Z",
    p12bf7980:
      "M126.469 258.883L120.048 262.825V270.229L126.469 266.288V258.883ZM114.754 265.612L108.333 269.554V276.958L114.754 273.017V265.612ZM103.067 272.369L96.6468 276.311V283.716L103.067 279.774V272.369ZM73.2454 289.797V297.202L79.666 293.26V285.855L73.2454 289.797ZM91.3526 279.098L84.9321 283.04V290.444L91.3526 286.503V279.098Z",
    p12c6c100:
      "M33.4265 72.4703L34.384 73.2868V118.813L33.4265 118.025V72.4703Z",
    p12de5680:
      "M39.5937 177.544V193.592L43.7614 191.171V175.151L39.5937 177.544Z",
    p1306380:
      "M5.71658 1.66112L2.87237 3.32224L0 1.66112L2.87237 0L5.71658 1.66112Z",
    p1321f600: "M2.87237 3.32224V257.898L0 256.236V1.66112L2.87237 3.32224Z",
    p132cb00:
      "M9.94065 30.0974V11.0367L6.95564 12.8667V31.9275L9.94065 30.0974Z",
    p133c5a00:
      "M2.95686 15.1754V49.2427L26.1611 35.8973V1.83009L2.95686 15.1754ZM19.0083 31.7586L10.1096 36.8828V19.3142L19.0083 14.19V31.7586Z",
    p133ff400:
      "M8.31378 6.18345C17.4819 9.89388 23.7488 14.2847 30.9556 21.0215C36.4568 26.4375 40.6353 31.5105 44.8139 37.9915C40.7623 31.4253 36.6691 26.2234 31.2549 20.7222C23.4512 13.089 16.5021 8.18653 6.22541 4.30555C6.95117 4.90248 8.31559 6.18163 8.31559 6.18163M6.01131 4.05154C16.5439 7.71842 23.7071 12.5374 31.8083 20.127C38.5452 26.7786 43.5765 33.1326 48.2667 41.3191C43.747 33.0038 38.801 26.5228 32.1494 19.7859C23.2371 11.1295 15.2647 5.80061 3.32601 2.09018C4.22232 2.73066 6.01313 4.05154 6.01313 4.05154H6.01131ZM3.19719 2.0049C15.3064 5.50123 23.4512 10.7466 32.6194 19.2743C39.9114 26.481 45.4961 33.6007 50.3151 42.64C45.7102 33.4719 40.1672 26.2234 33.004 18.8896C22.896 9.12457 13.7715 3.32578 0.000234489 0C1.10883 0.64048 2.13214 1.27915 3.19901 2.0049H3.19719ZM10.1481 8.23008C18.1224 11.8552 23.7071 15.905 30.1028 21.8743C35.0488 26.6933 38.801 31.213 42.682 36.9265C38.9298 31.1277 35.2194 26.5228 30.4022 21.5767C23.4948 14.7546 17.3966 10.2767 8.48614 6.39754C9.04135 7.03802 10.1499 8.23189 10.1499 8.23189L10.1481 8.23008Z",
    p13568280:
      "M246.77 69.5422V74.3567L233.084 66.1074V61.3211L246.77 69.5422Z",
    p13667100:
      "M43.677 50.2281V57.7736L86.7625 32.6595V25.1422L43.677 50.2281Z",
    p13a12d80:
      "M24.5 17.5H3.5C2.85567 17.5 2.33333 18.0223 2.33333 18.6667V21C2.33333 21.6443 2.85567 22.1667 3.5 22.1667H24.5C25.1443 22.1667 25.6667 21.6443 25.6667 21V18.6667C25.6667 18.0223 25.1443 17.5 24.5 17.5Z",
    p13a47380:
      "M827.581 380.146C826.792 380.146 826.173 379.526 826.173 378.738V373.107C826.173 372.319 826.792 371.699 827.581 371.699C828.369 371.699 828.989 372.319 828.989 373.107V378.738C828.989 379.526 828.369 380.146 827.581 380.146ZM827.581 366.068C826.792 366.068 826.173 365.449 826.173 364.66V359.029C826.173 358.241 826.792 357.622 827.581 357.622C828.369 357.622 828.989 358.241 828.989 359.029V364.66C828.989 365.449 828.369 366.068 827.581 366.068ZM827.581 351.991C826.792 351.991 826.173 351.371 826.173 350.583V344.952C826.173 344.164 826.792 343.544 827.581 343.544C828.369 343.544 828.989 344.164 828.989 344.952V350.583C828.989 351.371 828.369 351.991 827.581 351.991ZM827.581 337.913C826.792 337.913 826.173 337.294 826.173 336.506V330.875C826.173 330.086 826.792 329.467 827.581 329.467C828.369 329.467 828.989 330.086 828.989 330.875V336.506C828.989 337.294 828.369 337.913 827.581 337.913ZM827.581 323.836C826.792 323.836 826.173 323.217 826.173 322.428V316.797C826.173 316.009 826.792 315.39 827.581 315.39C828.369 315.39 828.989 316.009 828.989 316.797V322.428C828.989 323.217 828.369 323.836 827.581 323.836ZM827.581 309.759C826.792 309.759 826.173 309.139 826.173 308.351V302.72C826.173 301.932 826.792 301.312 827.581 301.312C828.369 301.312 828.989 301.932 828.989 302.72V308.351C828.989 309.139 828.369 309.759 827.581 309.759ZM827.581 295.681C826.792 295.681 826.173 295.062 826.173 294.274V288.643C826.173 287.854 826.792 287.235 827.581 287.235C828.369 287.235 828.989 287.854 828.989 288.643V294.274C828.989 295.062 828.369 295.681 827.581 295.681ZM827.581 281.604C826.792 281.604 826.173 280.985 826.173 280.196V274.565C826.173 273.777 826.792 273.157 827.581 273.157C828.369 273.157 828.989 273.777 828.989 274.565V280.196C828.989 280.985 828.369 281.604 827.581 281.604ZM826.961 267.555C826.285 267.555 825.694 267.076 825.581 266.4C825.272 264.627 824.821 262.853 824.286 261.135C824.061 260.403 824.455 259.615 825.187 259.362C825.919 259.108 826.708 259.531 826.961 260.263C827.552 262.093 828.003 264.007 828.341 265.922C828.482 266.682 827.975 267.414 827.186 267.555C827.102 267.555 827.017 267.555 826.933 267.555H826.961ZM822.258 254.378C821.78 254.378 821.301 254.125 821.019 253.646C820.146 252.07 819.132 250.521 818.062 249.085C817.584 248.466 817.724 247.593 818.344 247.114C818.964 246.636 819.836 246.776 820.315 247.396C821.47 248.944 822.54 250.577 823.497 252.267C823.863 252.942 823.638 253.815 822.962 254.181C822.737 254.294 822.512 254.35 822.286 254.35L822.258 254.378ZM813.444 243.454C813.106 243.454 812.768 243.342 812.515 243.088C811.163 241.906 809.699 240.779 808.206 239.766C807.559 239.344 807.39 238.471 807.812 237.823C808.234 237.176 809.107 237.007 809.755 237.429C811.36 238.499 812.909 239.71 814.373 240.977C814.965 241.483 815.021 242.384 814.486 242.976C814.204 243.285 813.81 243.454 813.444 243.454ZM801.729 235.712C801.476 235.712 801.251 235.655 801.025 235.515L796.154 232.671C795.478 232.277 795.252 231.404 795.647 230.756C796.041 230.081 796.914 229.855 797.562 230.25L802.433 233.093C803.109 233.487 803.334 234.36 802.94 235.008C802.687 235.458 802.208 235.712 801.729 235.712ZM789.592 228.617C789.339 228.617 789.113 228.56 788.888 228.42L784.016 225.576C783.341 225.182 783.115 224.309 783.51 223.661C783.904 222.986 784.777 222.76 785.424 223.155L790.296 225.998C790.972 226.392 791.197 227.265 790.803 227.913C790.55 228.363 790.071 228.617 789.592 228.617ZM777.427 221.522C777.173 221.522 776.948 221.465 776.723 221.325L771.851 218.481C771.175 218.087 770.95 217.214 771.344 216.566C771.738 215.891 772.611 215.665 773.259 216.06L778.131 218.903C778.807 219.297 779.032 220.17 778.638 220.818C778.384 221.268 777.906 221.522 777.427 221.522ZM765.261 214.427C765.008 214.427 764.783 214.37 764.557 214.23L759.686 211.386C759.01 210.992 758.785 210.119 759.179 209.471C759.573 208.796 760.446 208.57 761.094 208.965L765.965 211.808C766.641 212.202 766.867 213.075 766.472 213.723C766.219 214.173 765.74 214.427 765.261 214.427ZM753.096 207.303C752.843 207.303 752.617 207.247 752.392 207.106L747.52 204.263C746.845 203.869 746.619 202.996 747.013 202.348C747.408 201.673 748.281 201.447 748.928 201.841L753.8 204.685C754.476 205.079 754.701 205.952 754.307 206.6C754.054 207.05 753.575 207.303 753.096 207.303ZM740.931 200.209C740.677 200.209 740.452 200.152 740.227 200.011L735.355 197.168C734.679 196.774 734.454 195.901 734.848 195.253C735.242 194.578 736.115 194.352 736.763 194.746L741.635 197.59C742.311 197.984 742.536 198.857 742.142 199.505C741.888 199.955 741.409 200.209 740.931 200.209Z",
    p13a64380:
      "M126.469 314.658L120.048 318.599V326.004L126.469 322.062V314.658ZM114.754 321.415L108.333 325.356V332.761L114.754 328.819V321.415ZM103.067 328.144L96.6468 332.085V339.49L103.067 335.548V328.144ZM73.2454 345.571V352.976L79.666 349.035V341.63L73.2454 345.571ZM91.3526 334.901L84.9321 338.842V346.247L91.3526 342.306V334.901Z",
    p13ae7500:
      "M2.87238 3.2941V139.085L9.25864e-06 137.423V1.63298L2.87238 3.2941Z",
    p13af0600:
      "M254.965 74.1596L250.797 76.5809L246.63 74.1596L250.797 71.7383L254.965 74.1596Z",
    p13b83180:
      "M23.3169 2.42131L4.16778 34.2925L8.33553 31.8712L27.4847 0L23.3169 2.42131Z",
    p13cf9c00:
      "M15 7.5C15 9.48912 14.2098 11.3968 12.8033 12.8033C11.3968 14.2098 9.48912 15 7.5 15",
    p13fe1700:
      "M4.19593 16.9492V21.7636L29.3432 7.20762V2.42132L4.19593 16.9492Z",
    p1404ee40:
      "M23.2887 182.612L4.22407 214.314L0 211.893L19.0928 180.19L23.2887 182.612Z",
    p140ae980:
      "M4.19589 16.9491V21.7636L29.3432 7.23576V2.42132L4.19589 16.9491Z",
    p1412a600:
      "M33.5996 22.8398H36.2422C36.9431 22.8398 37.6153 23.1183 38.1109 23.6139C38.6065 24.1094 38.8849 24.7816 38.8849 25.4825V37.3743C38.8849 38.0752 38.6065 38.7474 38.1109 39.243C37.6153 39.7386 36.9431 40.017 36.2422 40.017H33.5996",
    p141cce00:
      "M77.554 166.958V171.772L63.8398 163.523V158.708L77.554 166.958Z",
    p14209f00:
      "M5.71658 1.66112L2.87237 3.2941L0 1.63298L2.87237 0L5.71658 1.66112Z",
    p1436a070: "M2.87237 3.2941V38.741L0 37.0798V1.66116L2.87237 3.2941Z",
    p143c0800:
      "M1.41119e-05 2.42131L25.1473 16.9492L29.3432 14.5278L4.16776 0L1.41119e-05 2.42131Z",
    p143e1e80:
      "M40.8891 133.482L46.9717 151.979L53.0544 140.492L40.9172 133.482H40.8891Z",
    p14414b00:
      "M9.94065 30.0974V11.0366L6.95565 12.8667V31.9275L9.94065 30.0974Z",
    p145d8400:
      "M81.581 173.996V190.045L85.7487 187.623V171.575L81.581 173.996Z",
    p145db100:
      "M4.19593 16.9774V21.7919L29.3432 7.23583V2.44953L4.19593 16.9774Z",
    p146a6600:
      "M14.9706 28.9411C22.6863 28.9411 28.9411 22.6863 28.9411 14.9706C28.9411 7.25484 22.6863 1 14.9706 1C7.25484 1 1 7.25484 1 14.9706C1 22.6863 7.25484 28.9411 14.9706 28.9411Z",
    p14736580: "M343.305 13.092V17.9064L347.5 15.4851V10.6707L343.305 13.092Z",
    p1496b000:
      "M323.114 34.3206V50.3689L318.889 47.9757V31.9275L323.114 34.3206Z",
    p149fbf0:
      "M26.1611 13.3735L23.2043 15.1755L0 1.83004L3.01318 0L26.1611 13.3735Z",
    p14bb7000:
      "M3.32292 1.91452V358.354L7.77228 360.944V364.125L0 359.593V0L3.32292 1.91452Z",
    p14cf4d00:
      "M319.058 27.479V32.2935L323.254 29.8722V25.0577L319.058 27.479Z",
    p14cff680: "M4.19593 45.5825V50.397L0 47.9757V43.1612L4.19593 45.5825Z",
    p14d24500:
      "M10 18.3333C14.6024 18.3333 18.3333 14.6024 18.3333 10C18.3333 5.39763 14.6024 1.66667 10 1.66667C5.39763 1.66667 1.66667 5.39763 1.66667 10C1.66667 14.6024 5.39763 18.3333 10 18.3333Z",
    p14dfec80:
      "M26.1611 13.3735L23.2042 15.1754L1.0988e-08 1.83004L2.98501 0L26.1611 13.3735Z",
    p14ffa500:
      "M2.87236 3.29411V257.869L5.71658 256.208V1.66112L2.87236 3.29411Z",
    p1513b780:
      "M6.95565 31.9275L9.94066 30.1256L21.402 36.6294L18.3888 38.4876L6.95565 31.9275Z",
    p1555f080:
      "M112.304 131.117L126.018 139.338L130.186 136.917L116.472 128.695L112.304 131.117Z",
    p156d5d00:
      "M1.41119e-05 2.44949L25.1473 50.6223L29.3432 48.201L4.16776 0L1.41119e-05 2.44949Z",
    p157ffe80:
      "M29.3432 2.44945L4.1959 16.9773L1.41119e-05 14.556L25.1755 0L29.3432 2.44945Z",
    p1589c600:
      "M38.0448 166L43.339 169.266V170.308L36.665 166.198V134.72L38.0448 135.593V166Z",
    p158b7140:
      "M29.7375 70.2462L30.695 71.0626V116.589L29.7375 115.801V70.2462Z",
    p158f0b70:
      "M0 1.83012V35.8973L23.2042 49.2427V15.1754L0 1.83012ZM16.0515 36.8827L7.15277 31.7586V14.19L16.0515 19.3142V36.8827Z",
    p159380b0:
      "M0 24.4665L42.0436 4.22912e-07L84.1154 24.2131L42.0436 48.7077L0 24.4665Z",
    p15ad6800:
      "M23.1761 15.1754V49.2145L26.1611 47.3844V13.3453L23.1761 15.1754Z",
    p15c2980: "M2.84421 3.2941V139.084L5.68842 137.423V1.66112L2.84421 3.2941Z",
    p15de4e00:
      "M23.2042 15.1754V49.2426L26.1611 47.4126V13.3453L23.2042 15.1754Z",
    p15de7200:
      "M275.072 62.5599V78.6081L270.848 76.1868V60.1386L275.072 62.5599Z",
    p15efbb80:
      "M53.167 299.792V307.197L59.5876 311.138V303.733L53.167 299.792ZM41.4523 300.468L47.8728 304.409V297.005L41.4523 293.063V300.468ZM6.36426 280.224L12.7848 284.166V276.761L6.36426 272.82V280.224ZM18.0509 286.981L24.4715 290.923V283.518L18.0509 279.577V286.981ZM29.7656 293.71L36.1862 297.652V290.247L29.7656 286.306V293.71Z",
    p15f99840:
      "M187.999 272.538L134.044 303.48V306.098L187.999 275.128V272.538Z",
    p15fa3500:
      "M53.3078 180.979V185.793L39.5937 177.544V172.729L53.3078 180.979Z",
    p15fdf880:
      "M9.94067 30.1255V11.0366L6.95566 12.8667V31.9275L9.94067 30.1255Z",
    p16083f0:
      "M126.469 217.045L120.048 220.987V228.391L126.469 224.45V217.045ZM114.754 223.774L108.333 227.716V235.12L114.754 231.179V223.774ZM103.067 230.531L96.6468 234.473V241.877L103.067 237.936V230.531ZM73.2454 247.931V255.335L79.666 251.394V243.989L73.2454 247.931ZM91.3526 237.26L84.9321 241.202V248.606L91.3526 244.665V237.26Z",
    p161f4f00: "M4.19593 16.9492V21.7636L0 19.3424V14.5279L4.19593 16.9492Z",
    p163b1000:
      "M5.71658 1.66112L2.87238 3.32228L5.49154e-06 1.66112L2.87238 0L5.71658 1.66112Z",
    p16402400:
      "M13.4325 89.3443C13.4325 91.6811 15.094 92.6384 17.1216 91.4559C19.1491 90.2734 20.8106 87.4297 20.8106 85.0929C20.8106 82.756 19.1491 81.7988 17.1216 82.9813C15.0659 84.1638 13.4325 87.0074 13.4325 89.3443Z",
    p16489f00:
      "M31.1737 155.105L36.665 151.726V121.375L37.8477 120.643V152.12L31.1737 156.231V155.105Z",
    p164e7700: "M0 0V33.2789L10.1941 27.3383L0 0Z",
    p16553400:
      "M6.67407 55.9717L7.82861 56.4785L97.0411 4.67371L95.8583 4.22323L6.67407 55.9717Z",
    p165a1bf0:
      "M53.167 285.855V293.26L59.5876 297.202V289.797L53.167 285.855ZM41.4523 286.503L47.8728 290.444V283.04L41.4523 279.098V286.503ZM6.36426 266.288L12.7848 270.229V262.825L6.36426 258.883V266.288ZM18.0509 273.017L24.4715 276.958V269.554L18.0509 265.612V273.017ZM29.7656 279.774L36.1862 283.716V276.311L29.7656 272.369V279.774Z",
    p165cb300:
      "M46.0074 6.18359C36.8393 9.89402 30.5724 14.2848 23.3656 21.0217C17.8644 26.4376 13.6858 31.5107 9.50727 37.9917C13.5588 31.4254 17.6521 26.2653 23.1098 20.7223C30.9135 13.0892 37.8208 8.22841 48.0957 4.30569C47.37 4.90263 46.0056 6.18177 46.0056 6.18177M48.3098 4.05168C37.7773 7.71856 30.6141 12.5376 22.5128 20.1272C15.8177 26.7787 10.7447 33.1327 6.05448 41.3193C10.5741 33.0039 15.5202 26.5229 22.1717 19.7861C31.084 11.1296 39.0564 5.80075 50.9951 2.09032C50.0988 2.7308 48.308 4.05168 48.308 4.05168H48.3098ZM51.124 2.00504C39.0147 5.50138 30.8699 10.7468 21.7018 19.2744C14.4098 26.4812 8.82506 33.6009 4.00604 42.6402C8.61096 33.472 14.1539 26.2235 21.3171 18.8898C31.4233 9.12472 40.5479 3.32592 54.3627 0.00014251C53.2541 0.640623 52.1872 1.27929 51.1222 2.00504H51.124ZM44.173 8.23022C36.1988 11.8554 30.6141 15.9051 24.2184 21.8744C19.3141 26.7352 15.5202 31.2548 11.6392 36.9684C15.3913 31.1696 19.1018 26.5646 23.919 21.6186C30.8264 14.7965 36.9245 10.3186 45.835 6.43942C45.2798 7.03635 44.1712 8.23022 44.1712 8.23022H44.173Z",
    p166b4180:
      "M126.469 244.918L120.048 248.86V256.265L126.469 252.323V244.918ZM114.754 251.675L108.333 255.617V263.022L114.754 259.08V251.675ZM103.067 258.404L96.6468 262.346V269.751L103.067 265.809V258.404ZM73.2454 275.832V283.237L79.666 279.295V271.89L73.2454 275.832ZM91.3526 265.161L84.9321 269.103V276.508L91.3526 272.566V265.161Z",
    p168629f0:
      "M32.7788 70.6685L33.9616 71.1752L123.174 19.3705L121.991 18.9481L32.7788 70.6685Z",
    p16a61f80:
      "M53.167 244.017V251.422L59.5876 255.364V247.959L53.167 244.017ZM41.4523 244.665L47.8728 248.606V241.202L41.4523 237.26V244.665ZM6.36426 224.45L12.7848 228.391V220.987L6.36426 217.045V224.45ZM18.0509 231.179L24.4715 235.12V227.716L18.0509 223.774V231.179ZM29.7656 237.936L36.1862 241.877V234.473L29.7656 230.531V237.936Z",
    p16acf880: "M2.87236 3.2941V138.916L0 137.254V1.63298L2.87236 3.2941Z",
    p16b9f400:
      "M26.7355 33.8983L26.8644 34.1124C26.9496 34.1124 27.0785 34.0688 27.1637 34.0688V33.8547C27.0349 33.8547 26.9079 33.8547 26.7374 33.8983M27.0331 35.2627C26.8626 35.5621 26.7337 35.7326 26.7337 35.7326C26.7773 35.6473 26.819 35.6038 26.9043 35.5621C26.9896 35.5185 27.0748 35.4768 27.1601 35.4768V35.2627C27.1166 35.2191 27.0748 35.2191 27.0313 35.2627H27.0331ZM27.2037 35.0069L27.0331 35.221C26.9478 35.221 26.9043 35.2645 26.819 35.3062C26.6902 35.3915 26.6049 35.4351 26.5632 35.5621L27.0748 34.7946L26.6902 34.1541C26.7755 34.1106 26.8607 34.1106 26.9043 34.1106L27.2037 34.5805V35.0069ZM25.6269 34.8799C25.7975 34.6658 25.9681 34.4952 26.2674 34.3246C26.3963 34.2394 26.5233 34.1958 26.6521 34.1541L26.5233 33.94C26.3944 33.9835 26.2674 34.0253 26.1822 34.1106C26.1386 34.1106 26.1386 34.1541 26.0969 34.1541C25.8828 34.4952 25.7122 34.751 25.6269 34.8799ZM27.2037 37.6504C26.8626 37.6504 26.6485 37.5652 26.3926 37.4363C26.1368 37.2658 25.9662 37.0952 25.7957 36.8811C19.0153 25.9222 12.1515 15.0504 5.20053 4.21846C5.20053 3.7068 5.24408 2.89577 5.54164 2.46938C5.79747 2.38411 6.01156 2.46938 6.18212 2.81049C7.07843 4.17491 7.37599 3.83381 7.88765 5.53933C11.1717 12.6608 20.3815 26.4756 25.4981 34.6621L26.2239 33.51C20.8932 24.9388 15.5208 16.4112 10.1484 7.88353C9.93428 6.81666 10.0631 7.07249 10.1484 7.20132C10.7036 8.09763 11.0864 8.52401 11.5981 9.50378C16.1613 17.3492 21.4484 25.494 26.3509 33.2959L27.0331 32.229C22.2994 24.5542 17.4821 16.921 12.6631 9.33141C12.5343 8.3081 12.6631 8.56392 12.7067 8.6492C13.2183 9.46023 13.603 9.88661 14.0294 10.7811C17.9956 17.6885 22.8128 25.0658 27.2055 31.9732V32.3996L26.5233 33.4664L26.7791 33.8511C26.6938 33.8511 26.6085 33.8946 26.565 33.8946L26.3509 33.6805L26.0515 34.1505C25.8374 34.2793 25.6251 34.4498 25.4963 34.6621L25.6251 34.8762C25.5816 34.9198 25.5816 34.9615 25.5816 34.9615C25.6106 34.9325 25.6251 34.904 25.6251 34.8762C25.9662 35.3879 26.2656 35.8995 26.5632 36.3695C26.6485 36.4983 26.692 36.54 26.819 36.6253C26.9478 36.7106 27.0331 36.7106 27.1601 36.7106L27.2037 37.6486V37.6504Z",
    p16f5be00:
      "M51.055 37.84L86.0585 18.92L51.0268 39.1633L17.8819 20.2433L51.055 37.84Z",
    p170ea2c0:
      "M4.19593 45.5826V50.3971L29.3432 7.23583V2.44953L4.19593 45.5826Z",
    p1720a500:
      "M126.469 147.306L120.048 151.247V158.652L126.469 154.71V147.306ZM114.754 154.035L108.333 157.976V165.381L114.754 161.439V154.035ZM103.067 160.792L96.6468 164.733V172.138L103.067 168.197V160.792ZM73.2454 178.22V185.624L79.666 181.683V174.278L73.2454 178.22ZM91.3526 167.521L84.9321 171.462V178.867L91.3526 174.926V167.521Z",
    p1746a600: "M72.1754 41.5001V439.27L0 397.77V0L72.1754 41.5001Z",
    p174b2500: "M2.98503 15.1754V49.2427L0 47.4126V13.3454L2.98503 15.1754Z",
    p1751f280:
      "M26.1611 13.3735L23.2043 15.1754L0 1.85822L3.01318 0L26.1611 13.3735Z",
    p1753a80:
      "M4.19589 16.9492V21.7636L29.3432 7.20764V2.42134L4.19589 16.9492Z",
    p17787a00:
      "M279.211 60.1386L275.044 62.5599L270.848 60.1386L275.044 57.7172L279.211 60.1386Z",
    p17a0c440:
      "M7.34988 88.021L3.85798 23.2932C3.82982 22.899 3.80166 22.5049 3.80166 22.0544C3.80166 15.1002 8.72975 6.62558 14.7843 3.13439C16.5865 2.09267 18.3325 1.55774 19.9658 1.55774C24.0772 1.55774 26.7243 4.85183 26.7243 9.94784C26.7243 10.3702 26.7243 10.7925 26.668 11.1585L23.1761 79.8843C23.1479 84.5579 19.7968 90.3015 15.7417 92.6384C14.5026 93.3704 13.2917 93.7082 12.1372 93.7082C9.23664 93.7082 7.34988 91.4559 7.32172 87.9928L7.34988 88.021ZM15.7417 4.82368C10.2222 8.00516 5.74473 15.7477 5.74473 22.0544C5.74473 22.4204 5.74473 22.7583 5.80106 23.1524L9.29296 87.9365C9.29296 90.3297 10.3912 91.7656 12.1653 91.7656C12.9538 91.7656 13.855 91.484 14.7843 90.9491C18.248 88.9501 21.2048 83.8822 21.2612 79.828L24.7531 11.0177C24.7531 10.6799 24.7812 10.3139 24.7812 9.94784C24.7812 5.97802 22.9508 3.50042 19.9658 3.50042C18.6986 3.50042 17.2342 3.95089 15.7699 4.79554L15.7417 4.82368Z",
    p17a6b5c0:
      "M2.87238 3.29411V139.084L1.83242e-05 137.423V1.66112L2.87238 3.29411Z",
    p17b02e00:
      "M2.84422 3.32228V38.741L5.71658 37.108V1.66112L2.84422 3.32228Z",
    p17b33000:
      "M29.3432 2.44947L4.19595 16.9492L1.82804e-05 14.556L25.1755 0L29.3432 2.44947Z",
    p17c06500:
      "M2.87238 3.32224V38.7409L5.71659 37.0798V1.66112L2.87238 3.32224Z",
    p17c10f80:
      "M5.71658 1.66112L2.87236 3.2941L0 1.63298L2.87236 0L5.71658 1.66112Z",
    p17c56b00: "M2.84421 3.29416V257.869L0 256.208V1.63299L2.84421 3.29416Z",
    p17c7bd80:
      "M261.47 49.6931L257.302 52.0863L253.135 49.665L257.302 47.2718L261.47 49.6931Z",
    p17cde880:
      "M0.203612 0.456664C14.5841 6.86845 67.7036 13.9567 96.7036 0.456664",
    p17e77000:
      "M65.3887 23.6782L41.1707 37.8963L0 14.2182L24.2744 0L65.3887 23.6782Z",
    p17f45e80:
      "M69.3312 56.7037L68.3455 57.492V103.046L69.3312 102.258V56.7037Z",
    p18162800:
      "M25.1473 50.6223V55.4368L29.3432 53.0155V48.201L25.1473 50.6223Z",
    p1817b500:
      "M5.71658 1.66112L2.87236 3.32224L0 1.66112L2.87236 0L5.71658 1.66112Z",
    p181aa200:
      "M53.167 188.215V195.619L59.5876 199.561V192.156L53.167 188.215ZM41.4523 188.89L47.8728 192.832V185.427L41.4523 181.486V188.89ZM6.36426 168.647L12.7848 172.589V165.184L6.36426 161.242V168.647ZM18.0509 175.404L24.4715 179.346V171.941L18.0509 167.999V175.404ZM29.7656 182.133L36.1862 186.075V178.67L29.7656 174.728V182.133Z",
    p18346b50:
      "M31.1737 60.6172L36.665 57.2386V46.033L37.8477 45.301V57.6328L31.1737 61.7434V60.6172Z",
    p18403f00:
      "M4.22407 214.23L17.9382 222.451L22.106 220.058L8.39184 211.808L4.22407 214.23Z",
    p185ea980:
      "M116.472 133.51L112.304 135.931L108.108 133.51L112.304 131.089L116.472 133.51Z",
    p186e9e80:
      "M13.6297 38.3186L18.9239 41.5564V42.6263L12.2216 38.5157V26.1558L13.6297 27.0285V38.3186Z",
    p1885e4c0:
      "M2.87238 3.2941V38.7409L9.24748e-06 37.0798V1.66112L2.87238 3.2941Z",
    p1890e900:
      "M4.19593 45.5944V50.4088L29.3432 7.24763V2.4613L4.19593 45.5944Z",
    p18949900:
      "M42.0155 7.23577V0H42.0436L84.1154 24.2131L77.8638 27.8732L42.0155 7.23577Z",
    p189a3500: "M4.19593 45.5944V50.4088L0 47.9876V43.1731L4.19593 45.5944Z",
    p18a4e00:
      "M1.82804e-05 2.44945L25.1474 16.9773L29.3432 14.556L4.16776 0L1.82804e-05 2.44945Z",
    p18bf7900:
      "M39.6218 177.544V193.592L35.3977 191.171V175.123L39.6218 177.544Z",
    p18bfe500:
      "M17.8538 62.2783L19.0365 62.7851L108.249 10.9803L107.066 10.5299L17.8538 62.2783Z",
    p18c4f180: "M2.87237 3.2941V257.869L0 256.236V1.66112L2.87237 3.2941Z",
    p18d92200:
      "M327.253 31.9275L323.085 34.3206L318.889 31.9275L323.085 29.5062L327.253 31.9275Z",
    p18d9c100:
      "M51.3084 67.2336L50.351 68.0219V113.576L51.3084 112.76V67.2336Z",
    p18dc0a00:
      "M1.41119e-05 2.42131L25.1473 50.5941L29.3432 48.2009L4.16776 0L1.41119e-05 2.42131Z",
    p18f31100:
      "M26.1611 13.3735L23.2043 15.1755L0 1.85822L3.01318 0L26.1611 13.3735Z",
    p18f74f00:
      "M187.999 309.252L134.044 340.166V351.54L187.999 320.598V309.252Z",
    p18f7eec0:
      "M71.753 58.8716L80.5109 68.6413L60.4324 67.1209L71.753 58.8716Z",
    p191cb00:
      "M43.3672 109.494L48.8867 106.115V82.1556L50.0694 81.4236V106.509L43.3672 110.62V109.494Z",
    p191e4080:
      "M23.2042 15.1754V49.2426L26.1892 47.3844V13.3453L23.2042 15.1754Z",
    p191e8d00:
      "M160.627 103.3L174.342 111.521L178.538 109.1L164.795 100.878L160.627 103.3Z",
    p19254200:
      "M39.5937 172.729L53.3078 180.979L57.5037 178.557L43.7614 170.308L39.5937 172.729Z",
    p19278bc0:
      "M351.556 33.9828L21.8807 224.844L17.6848 222.423L347.388 31.5333L351.556 33.9828Z",
    p19314b80:
      "M25.1473 50.6222V55.4367L29.3432 53.0154V48.201L25.1473 50.6222Z",
    p19364d80:
      "M3.32296 1.94268V358.354L7.77228 360.972V364.154L0 359.621V0L3.32296 1.94268Z",
    p19533400:
      "M8.36367 2.42131L4.19589 4.84262L0 2.42131L4.19589 0L8.36367 2.42131Z",
    p1968b2:
      "M6.95566 31.9275L9.94067 30.1255L21.402 36.6294L18.3888 38.4594L6.95566 31.9275Z",
    p1968c6f0: "M7.77232 4.53292L0 0V359.593L7.77232 364.125V4.53292Z",
    p196c280: "M2.84421 3.2941V38.7128L5.68842 37.0798V1.66112L2.84421 3.2941Z",
    p19761280:
      "M2.84421 3.32224V38.7409L5.68842 37.0798V1.66112L2.84421 3.32224Z",
    p19979c80:
      "M25.3163 66.4734L26.499 66.9802L115.712 15.1754L114.529 14.7249L25.3163 66.4734Z",
    p19ba7700:
      "M7.26541 33.3071L10.3912 31.3925L22.3313 38.206L19.2054 40.1205L7.26541 33.3071Z",
    p19ce0500:
      "M130.073 21.5384L37.7632 75.1451V77.3411L130.073 23.7063V21.5384Z",
    p19d28c00:
      "M45.9861 70.2462L45.0286 71.0626V116.589L45.9861 115.801V70.2462Z",
    p19eaab80:
      "M150.095 125.542V130.357L154.291 127.935V123.121L150.095 125.542Z",
    p19ed3500:
      "M16.2204 30.0974V11.0367L19.2055 12.8667V31.9276L16.2204 30.0974Z",
    p19face00:
      "M25.8232 120.39L31.1455 123.628V124.697L24.4433 120.587V95.4727L25.8232 96.3456V120.39Z",
    p19fe0840: "M25.1473 16.9492V21.7636L0 7.20761V2.42131L25.1473 16.9492Z",
    p1a0db000:
      "M2.87238 3.32228V257.898L6.59268e-06 256.236V1.66116L2.87238 3.32228Z",
    p1a109e00:
      "M2.98501 15.1754V49.2426L26.1893 35.8973V1.83003L2.98501 15.1754ZM19.0365 31.7586L10.1378 36.8827V19.3141L19.0365 14.19V31.7586Z",
    p1a2140c0:
      "M24.4434 255.561V168.056L25.6261 167.324V255.955L18.9521 260.065V258.939L24.4434 255.561Z",
    p1a246e00:
      "M0 241.906L6.70221 246.016V157.385L0 153.274V241.906ZM12.2216 248.944L18.9239 253.055V164.424L12.2216 160.313V248.944ZM24.4433 255.983L31.1455 260.094V171.462L24.4433 167.352V255.983ZM48.8585 181.429V270.06L55.5607 274.171V185.54L48.8585 181.429ZM36.665 263.022L43.3671 267.132V178.501L36.665 174.391V263.022Z",
    p1a29e700:
      "M30.9765 58.5056L30.0472 58.027L88.5084 22.9743L89.4377 23.4529L30.9765 58.5056Z",
    p1a426680: "M4.16667 0.833333H0.833333V10.8333H4.16667V0.833333Z",
    p1a50b2f0:
      "M7.46395 3.67773C7.56679 4.37126 7.44833 5.07957 7.12541 5.70191C6.8025 6.32424 6.29157 6.8289 5.6653 7.14412C5.03904 7.45934 4.32932 7.56906 3.6371 7.45767C2.94489 7.34628 2.30542 7.01946 1.80965 6.52369C1.31388 6.02793 0.98706 5.38845 0.875672 4.69624C0.764285 4.00402 0.874004 3.2943 1.18922 2.66804C1.50444 2.04177 2.0091 1.53084 2.63144 1.20793C3.25377 0.885011 3.96208 0.76655 4.65562 0.869393C5.36305 0.974297 6.01799 1.30395 6.52369 1.80965C7.0294 2.31535 7.35905 2.97029 7.46395 3.67773Z",
    p1a56be00:
      "M285.435 35.4468L281.267 37.84L277.071 35.4187L281.267 33.0255L285.435 35.4468Z",
    p1a834500: "M2.87236 3.2941V38.7409L0 37.0798V1.66112L2.87236 3.2941Z",
    p1a888c00:
      "M134.213 143.983L130.045 146.377L125.849 143.955L130.045 141.534L134.213 143.983Z",
    p1a989080:
      "M44.9442 51.6921V84.2672L89.297 58.4211V25.8742L44.9442 51.6921Z",
    p1aaf0300:
      "M13.3333 0.833333H5C2.69881 0.833333 0.833333 2.69881 0.833333 5V13.3333C0.833333 15.6345 2.69881 17.5 5 17.5H13.3333C15.6345 17.5 17.5 15.6345 17.5 13.3333V5C17.5 2.69881 15.6345 0.833333 13.3333 0.833333Z",
    p1ab55000:
      "M53.167 132.44V139.845L59.5876 143.786V136.382L53.167 132.44ZM41.4523 133.088L47.8728 137.029V129.624L41.4523 125.683V133.088ZM6.36426 112.872L12.7848 116.814V109.409L6.36426 105.468V112.872ZM18.0509 119.601L24.4715 123.543V116.138L18.0509 112.197V119.601ZM29.7656 126.359L36.1862 130.3V122.896L29.7656 118.954V126.359Z",
    p1ab5de00:
      "M33.1449 102.455L86.0585 71.9073V18.92L51.0268 39.1633L33.1449 86.1536V102.455Z",
    p1ad76b80: "M7.13506 16.9506L9.58893 19.4044L14.4967 14.4967",
    p1ae30880:
      "M1.40802 577.172C0.619531 577.172 0 576.553 0 575.765V570.134C0 569.345 0.619531 568.726 1.40802 568.726C2.19652 568.726 2.81605 569.345 2.81605 570.134V575.765C2.81605 576.553 2.19652 577.172 1.40802 577.172ZM1.40802 563.095C0.619531 563.095 0 562.476 0 561.687V556.056C0 555.268 0.619531 554.649 1.40802 554.649C2.19652 554.649 2.81605 555.268 2.81605 556.056V561.687C2.81605 562.476 2.19652 563.095 1.40802 563.095ZM1.40802 549.018C0.619531 549.018 0 548.398 0 547.61V541.979C0 541.191 0.619531 540.571 1.40802 540.571C2.19652 540.571 2.81605 541.191 2.81605 541.979V547.61C2.81605 548.398 2.19652 549.018 1.40802 549.018ZM1.40802 534.94C0.619531 534.94 0 534.321 0 533.533V527.902C0 527.113 0.619531 526.494 1.40802 526.494C2.19652 526.494 2.81605 527.113 2.81605 527.902V533.533C2.81605 534.321 2.19652 534.94 1.40802 534.94ZM1.40802 520.863C0.619531 520.863 0 520.244 0 519.455V513.824C0 513.036 0.619531 512.417 1.40802 512.417C2.19652 512.417 2.81605 513.036 2.81605 513.824V519.455C2.81605 520.244 2.19652 520.863 1.40802 520.863ZM1.40802 506.786C0.619531 506.786 0 506.166 0 505.378V499.747C0 498.959 0.619531 498.339 1.40802 498.339C2.19652 498.339 2.81605 498.959 2.81605 499.747V505.378C2.81605 506.166 2.19652 506.786 1.40802 506.786ZM1.40802 492.708C0.619531 492.708 0 492.089 0 491.3V485.67C0 484.881 0.619531 484.262 1.40802 484.262C2.19652 484.262 2.81605 484.881 2.81605 485.67V491.3C2.81605 492.089 2.19652 492.708 1.40802 492.708ZM1.40802 478.631C0.619531 478.631 0 478.011 0 477.223V471.592C0 470.804 0.619531 470.184 1.40802 470.184C2.19652 470.184 2.81605 470.804 2.81605 471.592V477.223C2.81605 478.011 2.19652 478.631 1.40802 478.631ZM1.40802 464.553C0.619531 464.553 0 463.934 0 463.146V457.515C0 456.726 0.619531 456.107 1.40802 456.107C2.19652 456.107 2.81605 456.726 2.81605 457.515V463.146C2.81605 463.934 2.19652 464.553 1.40802 464.553ZM1.40802 450.476C0.619531 450.476 0 449.857 0 449.068V443.437C0 442.649 0.619531 442.03 1.40802 442.03C2.19652 442.03 2.81605 442.649 2.81605 443.437V449.068C2.81605 449.857 2.19652 450.476 1.40802 450.476ZM1.40802 436.399C0.619531 436.399 0 435.779 0 434.991V429.36C0 428.572 0.619531 427.952 1.40802 427.952C2.19652 427.952 2.81605 428.572 2.81605 429.36V434.991C2.81605 435.779 2.19652 436.399 1.40802 436.399ZM1.40802 422.321C0.619531 422.321 0 421.702 0 420.914V415.255C0 414.466 0.675852 413.903 1.43619 413.875C2.22468 413.875 2.84421 414.522 2.81605 415.311V420.914C2.81605 421.702 2.16836 422.321 1.40802 422.321ZM2.36548 408.3C2.36548 408.3 2.16836 408.3 2.08388 408.272C1.32354 408.103 0.844815 407.371 0.985617 406.611C1.37986 404.725 1.91491 402.838 2.5626 401.036C2.81605 400.304 3.6327 399.91 4.36488 400.164C5.09705 400.417 5.4913 401.233 5.23785 401.965C4.64648 403.683 4.13959 405.429 3.77351 407.202C3.6327 407.85 3.04133 408.328 2.39364 408.328L2.36548 408.3ZM7.40621 395.236C7.15277 395.236 6.92748 395.18 6.7022 395.039C6.02635 394.645 5.80106 393.772 6.19531 393.125C7.18093 391.464 8.27918 389.831 9.43376 388.31C9.91249 387.691 10.7855 387.578 11.405 388.057C12.0245 388.536 12.1372 389.408 11.6584 390.028C10.5602 391.464 9.51825 392.984 8.61711 394.533C8.36367 394.983 7.88494 395.236 7.40621 395.236ZM16.3331 384.425C15.9388 384.425 15.5446 384.256 15.263 383.946C14.7561 383.355 14.8124 382.482 15.4038 381.947C16.8681 380.68 18.417 379.47 19.9939 378.4C20.6416 377.978 21.5146 378.147 21.937 378.794C22.3594 379.442 22.1905 380.314 21.5428 380.737C20.0503 381.75 18.5859 382.848 17.2342 384.059C16.9808 384.284 16.6429 384.397 16.3049 384.397L16.3331 384.425ZM28.0478 376.654C27.5691 376.654 27.0904 376.401 26.8369 375.95C26.4427 375.275 26.668 374.43 27.3438 374.036L32.2156 371.22C32.8915 370.826 33.7363 371.052 34.1305 371.727C34.5248 372.403 34.2995 373.248 33.6236 373.642L28.7519 376.457C28.5266 376.57 28.2731 376.654 28.0478 376.654ZM40.2695 369.644C39.7908 369.644 39.312 369.39 39.0586 368.94C38.6644 368.264 38.8896 367.42 39.5655 367.025L44.4373 364.21C45.1131 363.816 45.9579 364.041 46.3522 364.717C46.7464 365.392 46.5211 366.265 45.8453 366.631L40.9735 369.447C40.7482 369.587 40.5229 369.644 40.2695 369.644ZM52.463 362.605C51.9843 362.605 51.5055 362.352 51.2521 361.901C50.8578 361.226 51.0831 360.381 51.759 359.987L56.6307 357.171C57.3066 356.777 58.1514 357.002 58.5457 357.678C58.9399 358.354 58.7146 359.198 58.0388 359.593L53.167 362.408C52.9417 362.549 52.7164 362.605 52.463 362.605ZM64.6565 355.566C64.1778 355.566 63.699 355.313 63.4456 354.863C63.0513 354.187 63.2766 353.342 63.9525 352.948L68.8242 350.133C69.5001 349.738 70.3449 349.992 70.7392 350.639C71.1334 351.315 70.9081 352.16 70.2323 352.554L65.3605 355.369C65.1352 355.482 64.9099 355.566 64.6565 355.566ZM76.85 348.528C76.3713 348.528 75.8925 348.274 75.6391 347.824C75.2448 347.148 75.4701 346.304 76.146 345.909L81.0177 343.094C81.6936 342.7 82.5384 342.925 82.9326 343.601C83.3269 344.276 83.1016 345.121 82.4258 345.515L77.554 348.331C77.3287 348.443 77.1034 348.528 76.85 348.528Z",
    p1aeccf00: "M2.87237 3.2941V139.085L0 137.423V1.63298L2.87237 3.2941Z",
    p1af88c00:
      "M46.2113 13.4017L23.2606 26.7752L0 13.4017L22.9789 0L46.2113 13.4017Z",
    p1b0d5700:
      "M6.95565 31.9276L9.94065 30.0974L21.402 36.6294L18.3888 38.4594L6.95565 31.9276Z",
    p1b0e680:
      "M187.999 377.414L134.044 408.357V419.731L187.999 388.761V377.414Z",
    p1b14800: "M2.87238 3.2941V257.869L5.71658 256.236V1.66112L2.87238 3.2941Z",
    p1b209e00:
      "M4.19589 16.9492V21.7636L29.3432 7.23577V2.42131L4.19589 16.9492Z",
    p1b215e00:
      "M18.9521 123.571L24.4434 120.193V96.2048L25.6261 95.4727V120.587L18.9521 124.697V123.571Z",
    p1b228440:
      "M23.3333 15.1667C23.3333 21 19.25 23.9167 14.3967 25.6083C14.1425 25.6945 13.8665 25.6903 13.615 25.5967C8.75 23.9167 4.66667 21 4.66667 15.1667V7C4.66667 6.69058 4.78958 6.39384 5.00838 6.17504C5.22717 5.95625 5.52391 5.83333 5.83333 5.83333C8.16667 5.83333 11.0833 4.43333 13.1133 2.66C13.3605 2.44883 13.6749 2.33281 14 2.33281C14.3251 2.33281 14.6395 2.44883 14.8867 2.66C16.9283 4.445 19.8333 5.83333 22.1667 5.83333C22.4761 5.83333 22.7728 5.95625 22.9916 6.17504C23.2104 6.39384 23.3333 6.69058 23.3333 7V15.1667Z",
    p1b256e00:
      "M41.4804 72.8926L40.5229 73.681V119.235L41.4804 118.419V72.8926Z",
    p1b274bf0:
      "M5.71658 1.66116L2.84422 3.2941L3.29492e-06 1.66116L2.84422 0L5.71658 1.66116Z",
    p1b300f80:
      "M4.44932 1.94268V358.354L0 360.972V364.154L7.77228 359.621V0L4.44932 1.94268Z",
    p1b42a1f0:
      "M5.71658 1.66112L2.87238 3.2941L5.48037e-06 1.63298L2.87238 0L5.71658 1.66112Z",
    p1b5fef70: "M2.87237 3.32224V139.084L0 137.452V1.66112L2.87237 3.32224Z",
    p1b63b80: "M4.19593 45.5543V50.3688L0 47.9475V43.133L4.19593 45.5543Z",
    p1b68a400:
      "M2.87237 3.2941V38.7409L5.78178e-06 37.0798V1.63298L2.87237 3.2941Z",
    p1b68f700:
      "M110.277 32.6032L69.6409 56.2533L28.4984 32.5751L69.5283 54.6766L110.277 32.6032Z",
    p1b83fb80: "M4.19593 16.9492V21.7637L0 19.3424V14.5279L4.19593 16.9492Z",
    p1b891800:
      "M1.37678e-06 13.3454L2.98503 15.1754L26.1893 1.83004L23.1761 0L1.37678e-06 13.3454Z",
    p1b8f9600:
      "M65.3887 31.6459L41.1707 45.8923V37.8963L65.3887 23.7063V31.6459Z",
    p1b947000:
      "M1.41119e-05 2.42131L25.1473 50.5941L29.3432 48.1728L4.16776 0L1.41119e-05 2.42131Z",
    p1b9ab680:
      "M10.3912 58.0551L11.574 58.5619L100.758 6.78532L99.6037 6.33483L10.3912 58.0551Z",
    p1bbf8f80:
      "M0 13.3454L2.95684 15.1754L26.1611 1.83008L23.1761 0L0 13.3454Z",
    p1bfdf200:
      "M187.999 249.817L134.044 280.759V283.349L187.999 252.407V249.817Z",
    p1bfeac80:
      "M38.9741 63.0948L38.0448 62.588L96.506 27.5353L97.4353 28.0421L38.9741 63.0948Z",
    p1c009000:
      "M2.87238 3.2941V38.7409L4.62374e-06 37.0798V1.66112L2.87238 3.2941Z",
    p1c0bef80:
      "M23.2324 182.555V187.37L333.871 7.23577V2.42131L23.2324 182.555Z",
    p1c10f180:
      "M4.19593 45.5543V50.3688L29.3432 7.2357V2.42121L4.19593 45.5543Z",
    p1c24f280: "M25.1473 16.9492V21.7637L0 7.23582V2.44952L25.1473 16.9492Z",
    p1c26ec00:
      "M9.94067 30.0974V11.0366L6.95566 12.8667V31.9275L9.94067 30.0974Z",
    p1c2e16c0:
      "M1.82804e-05 2.42131L25.1474 16.9491L29.3432 14.5278L4.16776 0L1.82804e-05 2.42131Z",
    p1c340040: "M20.8388 5.85617L8.33553 14.19L0 0L20.8388 5.85617Z",
    p1c3e4800:
      "M38.0448 262.796L43.339 266.062V267.104L36.665 262.994V174.362L38.0448 175.235V262.796Z",
    p1c461b80: "M2.87238 3.2941V38.741L5.71659 37.0798V1.66112L2.87238 3.2941Z",
    p1c53bb00:
      "M116.951 337.125L127.032 340.954L134.326 332.254L116.951 337.125Z",
    p1c658c00:
      "M65.3887 31.6459L41.1707 45.8641V37.8963L65.3887 23.6782V31.6459Z",
    p1c7d0c00:
      "M25.6261 255.955L18.9521 260.065V171.434L25.6261 167.324V255.955Z",
    p1c89f480:
      "M5.68842 1.66112L2.84421 3.2941L0 1.63294L2.84421 0L5.68842 1.66112Z",
    p1ca04bc0:
      "M9.94065 30.0974V11.0085L6.95564 12.8667V31.9275L9.94065 30.0974Z",
    p1ca17240:
      "M1.41119e-05 2.42131L25.1473 16.9492L29.3432 14.5279L4.16776 0L1.41119e-05 2.42131Z",
    p1ccda00:
      "M112.304 135.931V151.979L108.108 149.558V133.51L112.304 135.931Z",
    p1ce034f0:
      "M2.87237 3.32229V38.741L5.71658 37.0799V1.66117L2.87237 3.32229Z",
    p1cecd580:
      "M88.0579 165.831L101.772 174.053L105.968 171.631L92.2256 163.41L88.0579 165.831Z",
    p1cf49170:
      "M2.87236 3.2941V38.7128L5.71658 37.0798V1.66112L2.87236 3.2941Z",
    p1d0165f0:
      "M6.95564 31.9275L9.94065 30.0974L21.402 36.6293L18.417 38.4594L6.95564 31.9275Z",
    p1d06e500:
      "M0 13.3454L2.98501 15.1755L26.1611 1.83013L23.1761 0L0 13.3454Z",
    p1d1b6000:
      "M0 1.83004V35.8973L23.2042 49.2426V15.1754L0 1.83004ZM16.0515 36.8546L7.15277 31.7304V14.1618L16.0515 19.2859V36.8546Z",
    p1d1c8bb0:
      "M347.332 20.2996V36.3478L343.136 33.9546V17.9064L347.332 20.2996Z",
    p1d35e200:
      "M5.71658 1.66112L2.87237 3.32228L0 1.66112L2.87237 0L5.71658 1.66112Z",
    p1d5e2f00:
      "M2.87236 3.32224V38.7409L5.71658 37.0798V1.66112L2.87236 3.32224Z",
    p1d632c80:
      "M53.167 90.602V98.0067L59.5876 101.948V94.5437L53.167 90.602ZM41.4523 91.2496L47.8728 95.1912V87.7865L41.4523 83.8449V91.2496ZM6.36426 71.0344L12.7848 74.9761V67.5714L6.36426 63.6298V71.0344ZM18.0509 77.7634L24.4715 81.7051V74.3004L18.0509 70.3587V77.7634ZM29.7656 84.5206L36.1862 88.4622V81.0575L29.7656 77.1159V84.5206Z",
    p1d7b3680:
      "M25.0347 46.1738L19.0647 42.7952V63.9113L25.0347 67.2899V46.1738Z",
    p1d860680:
      "M2.46328e-07 1.85822V35.9255L23.2043 49.2708V15.2036L2.46328e-07 1.85822ZM16.0515 36.8827L7.15277 31.7586V14.19L16.0515 19.3142V36.8827Z",
    p1d920a00:
      "M25.8232 255.758L31.1455 259.024V260.065L24.4433 255.955V167.324L25.8232 168.196V255.758Z",
    p1dd748d0:
      "M13.6297 248.719L18.9239 251.985V253.027L12.2216 248.916V160.285L13.6297 161.158V248.719Z",
    p1df8c480:
      "M65.3887 23.7063L41.1707 37.8963L0 14.2182L24.2744 0L65.3887 23.7063Z",
    p1e06ebc0:
      "M2.87236 3.2941V139.084L5.71658 137.423V1.66112L2.87236 3.2941Z",
    p1e13a3c0:
      "M2.87238 3.32224V257.898L5.71658 256.236V1.66112L2.87238 3.32224Z",
    p1e26bc80:
      "M53.167 76.6372V84.0419L59.5876 87.9836V80.5789L53.167 76.6372ZM41.4523 77.313L47.8728 81.2546V73.8499L41.4523 69.9082V77.313ZM6.36426 57.0697L12.7848 61.0114V53.6066L6.36426 49.665V57.0697ZM18.0509 63.8268L24.4715 67.7685V60.3638L18.0509 56.4221V63.8268ZM29.7656 70.5558L36.1862 74.4975V67.0928L29.7656 63.1511V70.5558Z",
    p1e27bf00:
      "M7.15276 89.2316C7.15276 93.4549 10.1378 95.1441 13.7986 93.0325C17.4595 90.9209 20.4445 85.7686 20.4445 81.5454C20.4445 77.3222 17.4595 75.6329 13.7986 77.7445C10.1378 79.8561 7.15276 85.0084 7.15276 89.2316Z",
    p1e281180:
      "M50.0694 38.2623L43.3672 42.3729V54.7328L50.0694 50.6222V38.2904V38.2623ZM37.8477 45.301L31.1455 49.4116V61.7715L37.8477 57.6609V45.3291V45.301ZM25.6261 52.3397L18.9239 56.4503V68.8102L25.6261 64.6996V52.3678V52.3397Z",
    p1e337500:
      "M10.8981 59.3502L11.8837 60.1386V105.693L10.8981 104.876V59.3502Z",
    p1e41a000:
      "M50.2665 173.039L55.5607 176.305V177.347L48.8585 173.236V141.759L50.2665 142.632V173.039Z",
    p1e41ec80:
      "M69.641 80.044V339.856L3.92426e-05 299.82V40.0079L69.641 80.044Z",
    p1e7c9100:
      "M50.0694 56.6474L43.3672 60.758V79.4809L50.0694 75.3703V56.6474ZM37.8477 63.686L31.1455 67.7967V86.5196L37.8477 82.4089V63.686ZM25.6261 70.7247L18.9239 74.8353V93.5582L25.6261 89.4476V70.7247Z",
    p1e7f4200:
      "M26.1611 13.3735L23.1761 15.1754L0 1.85822L2.98502 0L26.1611 13.3735Z",
    p1e931800:
      "M2.95686 15.1754V49.2426L26.1611 35.8973V1.83004L2.95686 15.1754ZM19.0083 31.7586L10.1096 36.8828V19.3142L19.0083 14.19V31.7586Z",
    p1e97ab80:
      "M19.2055 31.9276L16.2204 30.0974L4.75915 36.6294L7.7723 38.4594L19.2055 31.9276Z",
    p1ea2b00:
      "M2.87238 3.32228V257.898L5.71658 256.236V1.66112L2.87238 3.32228Z",
    p1eb4f80: "M4.19593 16.9492V21.7637L0 19.3423V14.5279L4.19593 16.9492Z",
    p1ec2d720:
      "M4.19592 214.342V219.157L334.181 27.9577V23.1714L4.19592 214.342Z",
    p1ed79900:
      "M62.9669 76.8062L62.0376 76.3276L120.527 41.2749L121.428 41.7535L62.9669 76.8062Z",
    p1ee0cc00:
      "M29.3432 2.44945L4.19595 45.5825L1.82804e-05 43.1612L25.1755 0L29.3432 2.44945Z",
    p1ef22380:
      "M2.84422 3.2941V38.7409L5.68843 37.0798V1.66112L2.84422 3.2941Z",
    p1f0d51a0:
      "M4.19594 11.1493V15.9637L1.28475e-05 13.5424V8.72797L4.19594 11.1493Z",
    p1f199900:
      "M136.916 45.3573L69.8381 84.4643V78.214L136.916 39.1352V45.3573Z",
    p1f228100:
      "M187.999 61.9123L107.263 108.171V461.879L187.999 415.592V61.9123Z",
    p1f4110f0: "M25.1473 16.9492V21.7636L0 7.23577V2.44946L25.1473 16.9492Z",
    p1f43f100:
      "M2.8724 3.32229V139.085L3.70011e-05 137.423V1.66117L2.8724 3.32229Z",
    p1f47bf00:
      "M17.7443 26.8037H15.1016C14.4007 26.8037 13.7286 27.0821 13.233 27.5777C12.7374 28.0733 12.459 28.7455 12.459 29.4463V37.3743C12.459 38.0751 12.7374 38.7473 13.233 39.2429C13.7286 39.7385 14.4007 40.0169 15.1016 40.0169H17.7443",
    p1f4cd000:
      "M329.59 4.87077L343.305 13.092L347.5 10.6707L333.758 2.44946L329.59 4.87077Z",
    p1f4e1900:
      "M127.088 22.9461L126.103 23.7345V69.2889L127.088 68.4724V22.9461Z",
    p1f5a7680:
      "M3.5 5.83333V22.1667C3.5 22.7855 3.74583 23.379 4.18342 23.8166C4.621 24.2542 5.2145 24.5 5.83333 24.5H23.3333C23.6428 24.5 23.9395 24.3771 24.1583 24.1583C24.3771 23.9395 24.5 23.6428 24.5 23.3333V18.6667",
    p1f60c9e0:
      "M5.71658 1.66112L2.87237 3.2941L2.29464e-06 1.66112L2.87237 0L5.71658 1.66112Z",
    p1f6ac980: "M25.1473 50.6222V55.4367L0 7.23578V2.42132L25.1473 50.6222Z",
    p1f6b4680:
      "M13.6297 82.2119L18.9239 85.4497V86.5196L12.2216 82.4089V63.6861L13.6297 64.5307V82.2119Z",
    p1f8d4600:
      "M305.344 39.9516L319.058 48.1728L323.254 45.7515L309.512 37.5021L305.344 39.9516Z",
    p1f99cd00:
      "M2.87236 3.32224V38.7409L3.06539e-06 37.0798V1.66112L2.87236 3.32224Z",
    p1f9b1b00: "M4.19593 16.9773V21.7918L0 19.3705V14.556L4.19593 16.9773Z",
    p1fb4eb00:
      "M29.3432 2.44945L4.19595 45.5826L1.82804e-05 43.1612L25.1755 0L29.3432 2.44945Z",
    p1fd30940:
      "M69.6691 64.2492L28.4984 40.571V32.5751L69.6691 56.2532V64.2492Z",
    p1fdfa000:
      "M29.3432 2.44949L4.19595 45.5826L1.82804e-05 43.1612L25.1755 0L29.3432 2.44949Z",
    p1feb2a00:
      "M3.32296 1.94269V358.354L7.77232 360.944V364.125L0 359.593V0L3.32296 1.94269Z",
    p1ffa8100:
      "M46.9717 67.9374L46.0424 67.4306V437.187L46.9717 437.666V67.9374Z",
    p20169e00:
      "M2.95684 15.1754V49.2427L1.37991e-06 47.4126V13.3454L2.95684 15.1754Z",
    p20254000: "M25.1473 16.9491V21.7636L0 7.23577V2.42131L25.1473 16.9491Z",
    p2055e500:
      "M130.045 146.377V162.425L125.849 160.003V143.955L130.045 146.377Z",
    p20580040:
      "M17.9382 222.451V227.265L4.22407 219.044V214.23L17.9382 222.451Z",
    p20698100:
      "M2.84421 3.2941V38.7409L5.68842 37.0798V1.66112L2.84421 3.2941Z",
    p206e7000:
      "M0 13.3735L2.98501 15.1754L26.1611 1.85822L23.1761 0L0 13.3735Z",
    p20826600:
      "M126.469 133.369L120.048 137.311V144.715L126.469 140.774V133.369ZM114.754 140.098L108.333 144.04V151.444L114.754 147.503V140.098ZM103.067 146.855L96.6468 150.797V158.202L103.067 154.26V146.855ZM73.2454 164.255V171.66L79.666 167.718V160.313L73.2454 164.255ZM91.3526 153.584L84.9321 157.526V164.931L91.3526 160.989V153.584Z",
    p208e63c0:
      "M2.87237 3.2941V38.741L7.39986e-06 37.0798V1.63298L2.87237 3.2941Z",
    p2090f600:
      "M2.87238 3.32224V38.7409L4.62374e-06 37.0798V1.66112L2.87238 3.32224Z",
    p2091dd80:
      "M46.9717 67.6559L46.0424 67.1773L104.532 32.1246L105.433 32.6032L46.9717 67.6559Z",
    p20a08b00:
      "M21.386 3.54826H6.09651C4.68915 3.54826 3.54826 4.68915 3.54826 6.09651V21.386C3.54826 22.7934 4.68915 23.9343 6.09651 23.9343H21.386C22.7934 23.9343 23.9343 22.7934 23.9343 21.386V6.09651C23.9343 4.68915 22.7934 3.54826 21.386 3.54826Z",
    p20a0ff00:
      "M16.2486 30.0974V11.0366L19.2054 12.8667V31.9275L16.2486 30.0974Z",
    p20a12a00:
      "M29.3432 2.44949L4.19595 16.9492L1.82804e-05 14.5279L25.1755 0L29.3432 2.44949Z",
    p20a6c100:
      "M54.9974 65.0093L54.04 65.7977V111.352L54.9974 110.536V65.0093Z",
    p20a86800:
      "M78.3425 51.4669L77.3569 52.2552V97.8096L78.3425 96.9932V51.4669Z",
    p20ae0100:
      "M76.7937 39.2196L82.8764 35.6158V56.7318L76.7937 60.3356V39.2196Z",
    p20ae7100:
      "M53.2515 61.2366V70.4432L1.7179e-07 39.8108V30.6042L53.2515 61.2366Z",
    p20b42bf0:
      "M19.2055 31.9275L16.2205 30.0974L4.75913 36.6293L7.74414 38.4594L19.2055 31.9275Z",
    p20b81300:
      "M12.9538 19.4642C12.9538 22.8146 15.3193 24.166 18.248 22.4767C21.1767 20.7874 23.5422 16.705 23.5422 13.3264C23.5422 9.94784 21.1767 8.62457 18.248 10.3139C15.3193 12.0031 12.9538 16.0856 12.9538 19.4642Z",
    p20cf700:
      "M250.826 76.5809V92.6292L246.63 90.2078V74.1596L250.826 76.5809Z",
    p20d73380:
      "M22.9789 54.1979L22.0497 53.7193V423.448L22.9789 423.926V54.1979Z",
    p20d8d300:
      "M50.0694 241.877L43.3672 245.988V157.357L50.0694 153.246V241.877Z",
    p20eb3e80:
      "M53.167 160.341V167.746L59.5876 171.688V164.283L53.167 160.341ZM41.4523 160.989L47.8728 164.931V157.526L41.4523 153.584V160.989ZM6.36426 140.774L12.7848 144.715V137.311L6.36426 133.369V140.774ZM18.0509 147.503L24.4715 151.444V144.04L18.0509 140.098V147.503ZM29.7656 154.26L36.1862 158.202V150.797L29.7656 146.855V154.26Z",
    p20f5fb00:
      "M25.1473 16.9492V21.7636L29.3432 19.3423V14.556L25.1473 16.9492Z",
    p20f74f80:
      "M2.95686 15.1754V49.2427L26.1611 35.8973V1.83012L2.95686 15.1754ZM19.0365 31.7586L10.1378 36.8827V19.3142L19.0365 14.19V31.7586Z",
    p21117880:
      "M31.1737 41.5001L36.665 38.1215V26.8878L37.8477 26.1558V38.5157L31.1737 42.6263V41.5001Z",
    p2111ab70:
      "M10.3912 31.3925V11.4871L7.26543 13.4016V33.2789L10.3912 31.3925Z",
    p21177600:
      "M9.68722 21.2005V273.242L7.56023e-06 279.183V27.1412L9.68722 21.2005Z",
    p21478900:
      "M21.8807 224.844V229.658L351.556 38.7691V33.9828L21.8807 224.844Z",
    p214b4390:
      "M31.1737 22.3548L36.665 18.9763V7.7707L37.8477 7.03869V19.3704L31.1737 23.4811V22.3548Z",
    p2173e500:
      "M2.87236 3.2941V38.7409L5.71658 37.0798V1.66112L2.87236 3.2941Z",
    p2178fea0:
      "M2.46328e-07 1.83004V35.8973L23.2043 49.2426V15.1755L2.46328e-07 1.83004ZM16.0515 36.8828L7.15277 31.7586V14.19L16.0515 19.3142V36.8828Z",
    p217c880: "M2.95686 15.1754V49.2426L0 47.4126V13.3735L2.95686 15.1754Z",
    p21836480:
      "M5.83333 0.833333C7.15942 0.833333 8.43119 1.36012 9.36887 2.2978C10.3065 3.23548 10.8333 4.50725 10.8333 5.83333V11.6667H7.5V5.83333C7.5 5.39131 7.3244 4.96738 7.01184 4.65482C6.69928 4.34226 6.27536 4.16667 5.83333 4.16667C5.39131 4.16667 4.96738 4.34226 4.65482 4.65482C4.34226 4.96738 4.16667 5.39131 4.16667 5.83333V11.6667H0.833333V5.83333C0.833333 4.50725 1.36012 3.23548 2.2978 2.2978C3.23548 1.36012 4.50725 0.833333 5.83333 0.833333Z",
    p2183b700:
      "M233.084 61.3211L246.77 69.5422L250.966 67.1209L237.252 58.8716L233.084 61.3211Z",
    p218b5900:
      "M2.87237 3.32224V38.7409L7.39986e-06 37.0798V1.66112L2.87237 3.32224Z",
    p21c42d80:
      "M319.058 48.1728V52.9872L305.344 44.7379V39.9516L319.058 48.1728Z",
    p21d81e00:
      "M43.3672 15.3162L48.8867 11.9376V0.732011L50.0694 3.25285e-06V12.3318L43.3672 16.4705V15.3162Z",
    p21ddeb00:
      "M0 50.6223L6.70221 54.7328V42.3729L0 38.2623V50.5941V50.6223ZM12.2216 57.661L18.9239 61.7715V49.4116L12.2216 45.301V57.6328V57.661ZM24.4433 64.6997L31.1455 68.8102V56.4503L24.4433 52.3397V64.6715V64.6997ZM48.8585 66.4452V78.777L55.5607 82.8876V70.5277L48.8585 66.4171V66.4452ZM36.665 71.7383L43.3671 75.8489V63.489L36.665 59.3784V71.7102V71.7383Z",
    p21e58580:
      "M2.87238 3.2941V257.869L1.10115e-06 256.236V1.66112L2.87238 3.2941Z",
    p21f09400: "M25.1473 16.9491V21.7636L0 7.23576V2.42132L25.1473 16.9491Z",
    p22094680:
      "M1.41119e-05 2.44945L25.1473 16.9491L29.3432 14.5278L4.16776 0L1.41119e-05 2.44945Z",
    p222ea600:
      "M140.549 119.714L136.409 122.135L132.214 119.714L136.409 117.293L140.549 119.714Z",
    p224c9a80:
      "M65.3887 31.6459L41.1707 45.8923V37.9245L65.3887 23.7063V31.6459Z",
    p224da4b0:
      "M52.5193 53.4377L58.4894 49.9465V71.0626L52.5193 74.5538V53.4377Z",
    p22664200:
      "M0 13.3735L2.98501 15.1755L26.1611 1.85822L23.1761 0L0 13.3735Z",
    p22676000:
      "M19.2055 31.9276L16.2486 30.0974L4.75913 36.6294L7.7723 38.4594L19.2055 31.9276Z",
    p2268f500:
      "M64.6565 46.3427L70.6829 42.7952V63.9113L64.6565 67.4306V46.3427Z",
    p226d3820:
      "M15.5294 30.0588C23.5538 30.0588 30.0588 23.5538 30.0588 15.5294C30.0588 7.50503 23.5538 1 15.5294 1C7.50503 1 1 7.50503 1 15.5294C1 23.5538 7.50503 30.0588 15.5294 30.0588Z",
    p2274ef60:
      "M230.888 87.9555L226.72 90.3768L222.524 87.9555L226.72 85.5342L230.888 87.9555Z",
    p227bec00: "M2.87237 3.2941V38.7409L0 37.0798V1.66112L2.87237 3.2941Z",
    p22a59e00:
      "M12.7849 38.8817L6.89931 35.6158V56.7318L12.7849 59.9978V38.8817Z",
    p22c98080:
      "M343.305 34.1517V38.9662L347.5 36.5449V31.7304L343.305 34.1517Z",
    p22d08000:
      "M138.268 40.0642L69.6127 80.044L0 40.0079L68.7398 0L138.268 40.0642Z",
    p22e08080: "M25.1473 50.6222V55.4367L0 7.23574V2.4213L25.1473 50.6222Z",
    p22e23ff0:
      "M187.999 104.707L134.044 135.621V146.996L187.999 116.026V104.707Z",
    p22e60800:
      "M2.95684 15.1754V49.2427L26.1611 35.8973V1.83009L2.95684 15.1754ZM19.0083 31.7586L10.1096 36.8828V19.3142L19.0083 14.19V31.7586Z",
    p2317d900:
      "M281.267 53.7474L294.981 61.9686L299.149 59.5473L285.435 51.298L281.267 53.7474Z",
    p231a59f0:
      "M10 0.833333H7.5C6.39493 0.833333 5.33512 1.27232 4.55372 2.05372C3.77232 2.83512 3.33333 3.89493 3.33333 5V7.5H0.833333V10.8333H3.33333V17.5H6.66667V10.8333H9.16667L10 7.5H6.66667V5C6.66667 4.77899 6.75446 4.56702 6.91074 4.41074C7.06703 4.25446 7.27899 4.16667 7.5 4.16667H10V0.833333Z",
    p231c5010:
      "M5.68842 1.66116L2.84421 3.2941L0 1.63298L2.84421 0L5.68842 1.66116Z",
    p2321fc00:
      "M50.0694 19.1171L43.3672 23.2277V35.5876L50.0694 31.477V19.1452V19.1171ZM37.8477 26.1558L31.1455 30.2664V42.6263L37.8477 38.5157V26.1839V26.1558ZM25.6261 33.1944L18.9239 37.3051V49.665L25.6261 45.5544V33.2226V33.1944Z",
    p233ab600:
      "M5.71658 1.66116L2.87237 3.32228L0 1.66116L2.87237 0L5.71658 1.66116Z",
    p233cda00:
      "M23.1761 15.1754V49.2145L26.1611 47.3844V13.3454L23.1761 15.1754Z",
    p2345bb00:
      "M46.9154 144.406C46.1269 144.406 45.5074 143.786 45.5074 142.998V138.718C45.5074 137.93 46.1269 137.311 46.9154 137.311C47.7039 137.311 48.3234 137.93 48.3234 138.718V142.998C48.3234 143.786 47.7039 144.406 46.9154 144.406ZM46.9154 131.68C46.1269 131.68 45.5074 131.06 45.5074 130.272V124.641C45.5074 123.853 46.1269 123.233 46.9154 123.233C47.7039 123.233 48.3234 123.853 48.3234 124.641V130.272C48.3234 131.06 47.7039 131.68 46.9154 131.68ZM46.9154 117.602C46.1269 117.602 45.5074 116.983 45.5074 116.195V110.564C45.5074 109.775 46.1269 109.156 46.9154 109.156C47.7039 109.156 48.3234 109.775 48.3234 110.564V116.195C48.3234 116.983 47.7039 117.602 46.9154 117.602ZM46.9154 103.525C46.1269 103.525 45.5074 102.906 45.5074 102.117V96.4863C45.5074 95.698 46.1269 95.0786 46.9154 95.0786C47.7039 95.0786 48.3234 95.698 48.3234 96.4863V102.117C48.3234 102.906 47.7039 103.525 46.9154 103.525ZM46.9154 89.4477C46.1269 89.4477 45.5074 88.8283 45.5074 88.0399V82.409C45.5074 81.6206 46.1269 81.0012 46.9154 81.0012C47.7039 81.0012 48.3234 81.6206 48.3234 82.409V88.0399C48.3234 88.8283 47.7039 89.4477 46.9154 89.4477ZM46.9154 75.3703C46.1269 75.3703 45.5074 74.7509 45.5074 73.9625V68.3316C45.5074 67.5433 46.1269 66.9239 46.9154 66.9239C47.7039 66.9239 48.3234 67.5433 48.3234 68.3316V73.9625C48.3234 74.7509 47.7039 75.3703 46.9154 75.3703ZM46.9154 61.2929C46.1269 61.2929 45.5074 60.6735 45.5074 59.8852V54.2542C45.5074 53.4659 46.1269 52.8465 46.9154 52.8465C47.7039 52.8465 48.3234 53.4659 48.3234 54.2542V59.8852C48.3234 60.6735 47.7039 61.2929 46.9154 61.2929Z",
    p23579880:
      "M19.2054 31.9275L16.2486 30.1255L4.78729 36.6294L7.77229 38.4875L19.2054 31.9275Z",
    p235c6900: "M2.98501 15.1754V49.2426L0 47.4126V13.3735L2.98501 15.1754Z",
    p235e69f0:
      "M2.84422 3.32224V38.7409L5.68843 37.0798V1.66112L2.84422 3.32224Z",
    p235f4ef0:
      "M5.26601 88.1336C5.26601 83.9104 8.25102 78.7862 11.9119 76.6465C13.7986 75.5484 15.5164 75.4921 16.7273 76.2241L18.6986 77.3503L17.4032 79.5464C17.4032 79.5464 17.4032 79.7998 17.4032 79.9124C17.4032 84.1356 14.4182 89.2598 10.7573 91.3996C10.5883 91.484 10.4194 91.5685 10.2504 91.653L9.18032 93.483L7.77229 92.6102C6.25163 92.1034 5.26601 90.4986 5.26601 88.0773V88.1336Z",
    p23643600:
      "M278.085 4.84263L288.166 8.67167L295.46 9.67648e-06L278.085 4.84263Z",
    p236a4000:
      "M27.2875 13.9366L24.1617 15.823L1.43744e-06 1.91459L3.12582 0L27.2875 13.9366Z",
    p236b8f00:
      "M282.309 81.3109L141.197 162.791L0 81.5643L141.253 0L282.309 81.3109Z",
    p2370f880:
      "M187.999 136.185L134.044 167.098V169.717L187.999 138.775V136.185Z",
    p237a9140:
      "M23.1761 15.1754V49.2426L26.1611 47.4126V13.3735L23.1761 15.1754Z",
    p237f6f00:
      "M2.87239 3.2941V38.741L1.8495e-05 37.0798V1.63298L2.87239 3.2941Z",
    p23899a00:
      "M343.305 34.1517V38.9662L329.59 30.7168V25.9305L343.305 34.1517Z",
    p23afbc00:
      "M187.999 263.782L134.044 294.724V306.098L187.999 275.128V263.782Z",
    p23b2f900:
      "M6.95564 31.9275L9.94065 30.1256L21.402 36.6293L18.3888 38.4594L6.95564 31.9275Z",
    p23c96f40:
      "M53.167 327.693V335.098L59.5876 339.04V331.635L53.167 327.693ZM41.4523 328.341L47.8728 332.282V324.878L41.4523 320.936V328.341ZM6.36426 308.126L12.7848 312.067V304.663L6.36426 300.721V308.126ZM18.0509 314.855L24.4715 318.796V311.392L18.0509 307.45V314.855ZM29.7656 321.612L36.1862 325.553V318.149L29.7656 314.207V321.612Z",
    p23db8980:
      "M25.1473 50.6223V55.4367L29.3432 53.0154V48.2009L25.1473 50.6223Z",
    p23e11200:
      "M2.84423 3.32228V38.741L5.7166 37.0798V1.66116L2.84423 3.32228Z",
    p23e58680:
      "M222.693 104.032V108.846L208.979 100.597V95.8106L222.693 104.032Z",
    p23e7ae00:
      "M48.8303 44.9632L33.1449 86.1536L0 67.2336L15.7417 25.8461L48.8303 44.9632Z",
    p23f21980:
      "M23.2887 26.7752V36.2633L4.1225e-06 22.8898V13.4017L23.2887 26.7752Z",
    p24482e80:
      "M233.084 66.1074V82.1556L237.224 79.7343V63.7142L233.084 66.1074Z",
    p244f8080:
      "M19.2055 31.9275L16.2204 30.0974L4.75911 36.6293L7.77228 38.4594L19.2055 31.9275Z",
    p246a0500:
      "M92.2256 147.531L88.0579 149.952L83.8619 147.531L88.0579 145.11L92.2256 147.531Z",
    p2482d800:
      "M53.167 341.63V349.035L59.5876 352.976V345.571L53.167 341.63ZM41.4523 342.306L47.8728 346.247V338.842L41.4523 334.901V342.306ZM6.36426 322.062L12.7848 326.004V318.599L6.36426 314.658V322.062ZM18.0509 328.819L24.4715 332.761V325.356L18.0509 321.415V328.819ZM29.7656 335.548L36.1862 339.49V332.085L29.7656 328.144V335.548Z",
    p2485f800:
      "M6.95564 31.9274L9.94065 30.0974L21.402 36.6293L18.3888 38.4594L6.95564 31.9274Z",
    p24878700:
      "M105.799 160.398V176.446L101.603 174.025V157.976L105.799 160.398Z",
    p24984480:
      "M19.2055 31.9275L16.2205 30.1256L4.75913 36.6294L7.7723 38.4594L19.2055 31.9275Z",
    p24a37280: "M271.017 55.5212V60.3356L257.302 52.0863V47.3L271.017 55.5212Z",
    p24a80b00:
      "M184.733 89.1379L198.447 97.3591L202.643 94.9378L188.901 86.6885L184.733 89.1379Z",
    p24a80c40: "M4.22407 4.81446V624.557L0 622.136V2.4213L4.22407 4.81446Z",
    p24bea170:
      "M1.37678e-06 13.3453L2.98503 15.1754L26.1893 1.83004L23.1761 0L1.37678e-06 13.3453Z",
    p24c2f800:
      "M50.2665 134.467L55.5607 137.705V138.775L48.8585 134.664V109.55L50.2665 110.423V134.467Z",
    p24d02700:
      "M105.377 35.7002L104.391 36.4886V82.0429L105.377 81.2265V35.7002Z",
    p24d05200:
      "M0 1.83004V35.8973L23.2042 49.2426V15.1754L0 1.83004ZM16.0515 36.8546L7.15276 31.7304V14.1618L16.0515 19.286V36.8546Z",
    p24f0a8d0:
      "M126.469 161.242L120.048 165.184V172.589L126.469 168.647V161.242ZM114.754 167.999L108.333 171.941V179.346L114.754 175.404V167.999ZM103.067 174.728L96.6468 178.67V186.075L103.067 182.133V174.728ZM73.2454 192.156V199.561L79.666 195.619V188.215L73.2454 192.156ZM91.3526 181.486L84.9321 185.427V192.832L91.3526 188.89V181.486Z",
    p250c6600:
      "M319.058 27.479V32.2935L305.344 24.0442V19.2579L319.058 27.479Z",
    p25209b80:
      "M85.7487 171.575L81.581 173.996L77.385 171.575L81.581 169.154L85.7487 171.575Z",
    p2524e7c0:
      "M208.979 95.8106L222.693 104.032L226.861 101.611L213.147 93.3612L208.979 95.8106Z",
    p25298c00:
      "M4.19593 45.5543V50.3688L29.3432 7.20756V2.42126L4.19593 45.5543Z",
    p252daf00:
      "M2.84422 3.32224V257.898L5.71658 256.236V1.66112L2.84422 3.32224Z",
    p2534d00:
      "M4.44936 1.94269V358.354L0 360.944V364.125L7.77232 359.593V0L4.44936 1.94269Z",
    p25355d80: "M25.1473 16.9491V21.7636L0 7.23571V2.42127L25.1473 16.9491Z",
    p25367fc0:
      "M202.474 104.398V120.446L198.278 118.025V101.977L202.474 104.398Z",
    p25398f00:
      "M6.95565 31.9275L9.94066 30.1256L21.402 36.6294L18.3888 38.4594L6.95565 31.9275Z",
    p253b3100: "M2.87238 3.32224V257.898L0 256.236V1.66112L2.87238 3.32224Z",
    p254f7900:
      "M25.8232 158.962L31.1455 162.228V163.269L24.4433 159.159V127.682L25.8232 128.555V158.962Z",
    p25507280:
      "M282.309 81.3109L141.197 162.819L0 81.5925L141.253 0L282.309 81.3109Z",
    p2564d480:
      "M16.2205 30.0974V11.0366L19.2055 12.8667V31.9275L16.2205 30.0974Z",
    p2566b300:
      "M16.2204 30.0974V11.0366L19.2055 12.8667V31.9275L16.2204 30.0974Z",
    p25cf8d00:
      "M28.9208 69.852L29.8783 70.6403V116.195L28.9208 115.378V69.852Z",
    p25e3bd00: "M25.1473 16.9773V21.7918L0 7.23577V2.44945L25.1473 16.9773Z",
    p25fc4100:
      "M16.6667 10.8333C16.6667 15 13.75 17.0833 10.2833 18.2917C10.1018 18.3532 9.90461 18.3502 9.725 18.2833C6.25 17.0833 3.33333 15 3.33333 10.8333V5C3.33333 4.77899 3.42113 4.56703 3.57741 4.41074C3.73369 4.25446 3.94565 4.16667 4.16667 4.16667C5.83333 4.16667 7.91667 3.16667 9.36667 1.9C9.54321 1.74917 9.76779 1.66629 10 1.66629C10.2322 1.66629 10.4568 1.74917 10.6333 1.9C12.0917 3.175 14.1667 4.16667 15.8333 4.16667C16.0543 4.16667 16.2663 4.25446 16.4226 4.41074C16.5789 4.56703 16.6667 4.77899 16.6667 5V10.8333Z",
    p25fcdf40:
      "M16.2205 62.3628L17.1779 63.1511V108.705L16.2205 107.917V62.3628Z",
    p26000a00:
      "M10.3912 31.3925V11.5153L7.26541 13.4299V33.3071L10.3912 31.3925Z",
    p2613df00: "M2.87237 3.32229V38.741L0 37.0799V1.66117L2.87237 3.32229Z",
    p261b9000:
      "M4.19616 45.5936V50.408L29.3435 7.27496V2.46049L4.19616 45.5936Z",
    p263cd080:
      "M41.1988 45.8923L2.89889e-06 22.2141V14.2182L41.1988 37.8963V45.8923Z",
    p264f7780:
      "M25.8232 26.2121L31.1455 29.478V30.5197L24.4433 26.4091V14.0774L25.8232 14.922V26.2121Z",
    p26551a00:
      "M1.40802 75.1732L6.70221 78.411V79.4809L0 75.3702V56.6474L1.40802 57.492V75.1732Z",
    p2669e880:
      "M23.2606 26.7752V36.2633L46.2113 22.8898V13.4017L23.2606 26.7752Z",
    p2675700: "M125.99 160.032V164.846L130.186 162.425V157.61L125.99 160.032Z",
    p267e0e00:
      "M14.4963 1H3.45388C2.80307 1 2.17891 1.25853 1.71872 1.71872C1.25853 2.17891 1 2.80307 1 3.45388V23.0849C1 23.7357 1.25853 24.3598 1.71872 24.82C2.17891 25.2802 2.80307 25.5388 3.45388 25.5388H18.1771C18.8279 25.5388 19.4521 25.2802 19.9123 24.82C20.3725 24.3598 20.631 23.7357 20.631 23.0849V7.13469L14.4963 1Z",
    p268aa880:
      "M187.999 295.259L134.044 326.201V328.819L187.999 297.849V295.259Z",
    p268b2380: "M109.066 33.476L108.08 34.2643V79.8188L109.066 79.0022V33.476Z",
    p26b0370:
      "M4.19593 16.9491V21.7636L29.3432 7.23577V2.42131L4.19593 16.9491Z",
    p26b0f000:
      "M2.95686 15.1754V49.2427L26.1611 35.8974V1.83009L2.95686 15.1754ZM19.0083 31.7586L10.1096 36.8827V19.3142L19.0083 14.19V31.7586Z",
    p26b8c970:
      "M101.772 174.053V178.867L88.0579 170.646V165.832L101.772 174.053Z",
    p26d31d00:
      "M23.1761 15.1754V49.2426L26.1611 47.4126V13.3453L23.1761 15.1754Z",
    p26ddc800:
      "M16.6667 8.33333C16.6667 12.4942 12.0508 16.8275 10.5008 18.1658C10.3564 18.2744 10.1807 18.3331 10 18.3331C9.81933 18.3331 9.64356 18.2744 9.49917 18.1658C7.94917 16.8275 3.33333 12.4942 3.33333 8.33333C3.33333 6.56522 4.03571 4.86953 5.28595 3.61929C6.5362 2.36905 8.23189 1.66667 10 1.66667C11.7681 1.66667 13.4638 2.36905 14.714 3.61929C15.9643 4.86953 16.6667 6.56522 16.6667 8.33333Z",
    p26ded9f0:
      "M1.82804e-05 2.42131L25.1474 16.9492L29.3432 14.5278L4.16776 0L1.82804e-05 2.42131Z",
    p26e1fe00:
      "M39.5937 193.451L53.3078 201.672L57.5037 199.251L43.7614 191.002L39.5937 193.451Z",
    p26e95700: "M141.281 162.819V167.633L0 86.4069V81.5925L141.281 162.819Z",
    p26ecd000: "M4.19593 45.5544V50.3688L0 47.9475V43.1331L4.19593 45.5544Z",
    p26fbcd00:
      "M187.999 150.149L134.044 181.091V192.438L187.999 161.496V150.149Z",
    p270320f0:
      "M19.2054 31.9275L16.2486 30.0974L4.78729 36.6294L7.77229 38.4594L19.2054 31.9275Z",
    p27158d00:
      "M21.5991 24.8606V38.572L42.9447 26.1558V12.4444L21.5991 24.8606Z",
    p2718dd30:
      "M126.469 300.721L120.048 304.663V312.067L126.469 308.126V300.721ZM114.754 307.45L108.333 311.392V318.796L114.754 314.855V307.45ZM103.067 314.207L96.6468 318.149V325.553L103.067 321.612V314.207ZM73.2454 331.635V339.04L79.666 335.098V327.693L73.2454 331.635ZM91.3526 320.936L84.9321 324.878V332.282L91.3526 328.341V320.936Z",
    p271cf400:
      "M5.71658 1.66116L2.84422 3.2941L0 1.63298L2.84422 0L5.71658 1.66116Z",
    p271fcf00: "M4.19593 16.9492V21.7637L0 19.3705V14.556L4.19593 16.9492Z",
    p2726fe00:
      "M2.70343 54.4794L3.66087 55.2678V100.822L2.70343 100.034V54.4794Z",
    p272dd300:
      "M187.999 409.455L107.263 455.713V461.879L187.999 415.592V409.455Z",
    p27492500:
      "M2.84422 3.2941V38.7409L5.71658 37.0798V1.66112L2.84422 3.2941Z",
    p27493c00:
      "M27.5879 33.8983L27.4591 34.1124C27.3738 34.1124 27.245 34.0688 27.1597 34.0688V33.8547C27.2886 33.8547 27.4591 33.8547 27.5861 33.8983M27.2886 35.2627C27.4591 35.5621 27.5879 35.7326 27.5879 35.7326C27.5444 35.6473 27.5027 35.6038 27.4174 35.5621C27.3321 35.5185 27.2468 35.4768 27.1616 35.4768V35.2627C27.2051 35.2191 27.2468 35.2191 27.2904 35.2627H27.2886ZM27.118 35.0069L27.2886 35.221C27.3738 35.221 27.4174 35.2645 27.5027 35.3062C27.6315 35.3915 27.6732 35.4351 27.7585 35.5621L27.2468 34.7946L27.6315 34.1541C27.5879 34.1124 27.5462 34.1124 27.4609 34.1124L27.1616 34.5823C27.118 34.5823 27.118 35.0087 27.118 35.0087V35.0069ZM28.6965 34.8799C28.526 34.6658 28.3554 34.4952 28.056 34.3246C27.9272 34.2394 27.8002 34.1958 27.6714 34.1541L27.8002 33.94C27.929 33.9835 28.056 34.0253 28.1413 34.1106C28.1849 34.1106 28.1849 34.1541 28.2266 34.1541C28.4824 34.4952 28.6113 34.751 28.6965 34.8799ZM27.118 37.6504C27.4591 37.6504 27.6732 37.5652 27.929 37.4363C28.1849 37.2658 28.3554 37.0952 28.526 36.8811C35.3064 25.9222 42.1702 15.0504 49.1211 4.21846C49.1211 3.7068 49.0776 2.89577 48.78 2.46938C48.5242 2.38411 48.3101 2.46938 48.1395 2.81049C47.2432 4.17491 46.9457 3.83381 46.434 5.53933C43.15 12.6608 33.9401 26.4756 28.8235 34.6621L28.0978 33.51C33.4285 24.9824 38.8009 16.4112 44.1733 7.88353C44.3874 6.81666 44.2586 7.07249 44.1733 7.20132C43.6181 8.09763 43.2352 8.52401 42.7236 9.50378C38.1604 17.3492 32.8733 25.494 27.9708 33.2959L27.2886 32.229C32.064 24.5542 36.8395 16.921 41.6585 9.33141C41.7874 8.3081 41.7021 8.56392 41.615 8.6492C41.1033 9.46023 40.7187 9.88661 40.2923 10.7811C36.326 17.6885 31.5088 25.0658 27.1162 31.9732V32.3996L27.7984 33.4664L27.5426 33.8511C27.6279 33.8511 27.7131 33.8946 27.7567 33.8946L27.9272 33.6388L28.2266 34.1087C28.4407 34.2376 28.6113 34.4081 28.7818 34.6204L28.653 34.8345C28.6965 34.878 28.6965 34.9198 28.6965 34.9198C28.6675 34.8907 28.653 34.8623 28.653 34.8345C28.3119 35.3462 28.0125 35.8578 27.7149 36.3277C27.6297 36.4566 27.5861 36.4983 27.4591 36.5836C27.3303 36.6688 27.245 36.6688 27.118 36.6688V37.6504Z",
    p274d9e80:
      "M77.5258 51.8611L76.5684 52.6494V98.2038L77.5258 97.3873V51.8611Z",
    p275e0300: "M18.6667 8.16667H25.6667V15.1667",
    p27681a00: "M2.87237 3.3223V38.741L5.71658 37.0799V1.66118L2.87237 3.3223Z",
    p27725200:
      "M5.68842 1.66116L2.84421 3.29414L0 1.63298L2.84421 0L5.68842 1.66116Z",
    p27762b00:
      "M71.753 62.8696V31.7023L72.9638 30.9984V63.2356L33.1449 86.238V86.1536L33.6236 84.8866L71.753 62.8696Z",
    p2779300:
      "M2.87237 3.32224V38.7409L1.39309e-05 37.1079V1.66112L2.87237 3.32224Z",
    p277b1d00:
      "M8.36369 2.42131L4.19595 4.81447L1.71208e-05 2.42131L4.19595 0L8.36369 2.42131Z",
    p27c00570:
      "M26.1893 13.3454L23.2043 15.1754L1.06014e-06 1.83008L3.01317 0L26.1893 13.3454Z",
    p27df5b00:
      "M92.282 0L4.92502e-05 53.5222L37.7915 75.1451L130.073 21.5384L92.282 0Z",
    p27ea0700:
      "M2.87237 3.2941V257.869L1.80932e-06 256.208V1.63298L2.87237 3.2941Z",
    p280c7780:
      "M105.743 30.6605L53.2234 61.2366L0 30.6042L52.5756 0L105.743 30.6605Z",
    p28142300:
      "M29.3432 2.42131L4.1959 16.9491L1.41119e-05 14.5278L25.1755 0L29.3432 2.42131Z",
    p281a3160:
      "M19.2055 31.9275L16.2204 30.1256L4.75911 36.6294L7.77229 38.4594L19.2055 31.9275Z",
    p28214700:
      "M1.82804e-05 2.42131L25.1474 16.9492L29.3432 14.5279L4.16776 0L1.82804e-05 2.42131Z",
    p28226980:
      "M43.3672 53.5785L48.8867 50.1999V38.9943L50.0694 38.2623V50.5941L43.3672 54.7047V53.5785Z",
    p28289380:
      "M40.9172 193.085V197.9L36.7213 195.478V190.664L40.9172 193.085Z",
    p28289f00:
      "M109.967 158.004L105.799 160.398L101.603 157.976L105.799 155.555L109.967 158.004Z",
    p2829b680:
      "M5.71658 1.66112L2.87236 3.2941L0 1.66112L2.87236 0L5.71658 1.66112Z",
    p282f10f0:
      "M1.40802 106.312L6.70221 109.578V110.62L0 106.509V81.4236L1.40802 82.2682V106.312Z",
    p28429200:
      "M26.1611 13.3453L23.1761 15.1754L0 1.83004L2.98502 0L26.1611 13.3453Z",
    p28652000:
      "M187.999 340.729L134.044 371.643V374.261L187.999 343.319V340.729Z",
    p2872cf00:
      "M50.2665 103.328L55.5607 106.566V107.636L48.8585 103.525V84.8021L50.2665 85.6468V103.328Z",
    p28829200:
      "M21.5991 64.3618L22.7537 64.8686L111.966 13.0638L110.783 12.6415L21.5991 64.3618Z",
    p289ab400:
      "M208.979 79.9032V95.9514L204.783 93.5301V77.4819L208.979 79.9032Z",
    p289b300:
      "M4.19593 16.9492V21.7637L29.3432 7.23582V2.44952L4.19593 16.9492Z",
    p289d0800:
      "M305.344 19.2579L319.058 27.479L323.254 25.0577L309.512 16.8084L305.344 19.2579Z",
    p28a7f00:
      "M16.2486 30.1255V11.0366L19.2054 12.8667V31.9275L16.2486 30.1255Z",
    p28bf7f00: "M25.1473 16.9491V21.7636L0 7.23577V2.42128L25.1473 16.9491Z",
    p290a0300:
      "M46.8028 69.852L45.8453 70.6403V116.195L46.8028 115.378V69.852Z",
    p29109270: "M88.0579 149.952V166L83.8619 163.579V147.531L88.0579 149.952Z",
    p29189980:
      "M18.7831 2.42131L4.19594 11.1493L1.55526e-05 8.72797L14.6153 0L18.7831 2.42131Z",
    p291f6900:
      "M17.8819 20.2433L51.0268 39.1633L33.1449 86.1536L0 67.2336L17.8819 20.2433Z",
    p29322a00:
      "M299.008 48.3136V64.3618L294.812 61.9405V45.8923L299.008 48.3136Z",
    p29327700:
      "M25.5416 208.064C25.5416 210.71 23.6548 211.78 21.3457 210.457C19.0365 209.133 17.1498 205.896 17.1498 203.249C17.1498 200.603 19.0365 199.533 21.3457 200.856C23.6548 202.179 25.5416 205.417 25.5416 208.064Z",
    p2935c972:
      "M187.999 181.626L134.044 212.568V215.187L187.999 184.217V181.626Z",
    p2943fb80: "M2.84422 3.2941V38.741L5.71658 37.0798V1.66116L2.84422 3.2941Z",
    p294758c0: "M81.581 173.996V190.045L77.385 187.623V171.575L81.581 173.996Z",
    p2951ca00:
      "M5.71658 1.66112L2.84422 3.2941L0 1.66112L2.84422 0L5.71658 1.66112Z",
    p29532d00:
      "M4.44936 1.91452V358.354L0 360.944V364.125L7.77228 359.593V0L4.44936 1.91452Z",
    p29624900:
      "M21.5991 26.5781V31.7304L42.9447 19.286V14.1618L21.5991 26.5781Z",
    p2970d080: "M12.1372 87.871V70.9218L25.6261 78.608V95.6417L12.1372 87.871Z",
    p2971ccf0: "M7.77228 4.50476L0 0V359.593L7.77228 364.125V4.50476Z",
    p297b67c0: "M41.1988 45.8641L0 22.2141V14.2182L41.1988 37.8963V45.8641Z",
    p298a5000:
      "M299.008 48.3136V64.3618L303.148 61.9405V45.8923L299.008 48.3136Z",
    p298c6c00: "M0 4.53292L7.77228 0V359.621L0 364.154V4.53292Z",
    p29972e00:
      "M4.20096 45.5896V50.404L0.00502743 47.9827V43.1683L4.20096 45.5896Z",
    p299a0450:
      "M347.332 20.2996V36.3478L351.499 33.9546V17.9064L347.332 20.2996Z",
    p29a557f0:
      "M0 1.83004V35.8973L23.2042 49.2427V15.1754L0 1.83004ZM16.0515 36.8827L7.15277 31.7586V14.19L16.0515 19.3142V36.8827Z",
    p29a75800:
      "M2.87237 3.32228V38.7409L5.71659 37.108V1.6893L2.87237 3.32228Z",
    p29ccbff0:
      "M2.87236 3.32228V38.741L3.06539e-06 37.108V1.66116L2.87236 3.32228Z",
    p29e100:
      "M76.315 78.2702V62.8977L77.4414 62.2502V79.2274L63.9525 86.9982V85.3652L76.315 78.2702Z",
    p29efb800:
      "M2.5 4.16667C3.42047 4.16667 4.16667 3.42047 4.16667 2.5C4.16667 1.57953 3.42047 0.833333 2.5 0.833333C1.57953 0.833333 0.833333 1.57953 0.833333 2.5C0.833333 3.42047 1.57953 4.16667 2.5 4.16667Z",
    p29f10780:
      "M5.71659 1.66112L2.87237 3.2941L1.09719e-05 1.63298L2.87237 0L5.71659 1.66112Z",
    p29fded00:
      "M187.999 286.531L134.044 317.445V328.819L187.999 297.849V286.531Z",
    p2a0f0b00:
      "M101.744 174.053V178.867L105.968 176.446V171.631L101.744 174.053Z",
    p2a111700:
      "M323.085 34.3206V50.3689L327.253 47.9757V31.9275L323.085 34.3206Z",
    p2a259280:
      "M13.2636 86.9137V71.5693L12.1372 70.9218V87.871L25.6261 95.6417V94.0087L13.2636 86.9137Z",
    p2a27c800:
      "M0.957446 161.843C1.4925 161.843 1.94307 161.392 1.94307 160.857L13.3481 109.278C13.7423 108.912 13.7705 108.292 13.3762 107.898C13.0101 107.504 12.3906 107.476 11.9964 107.87L0 160.857C0 161.392 0.450564 161.843 0.985613 161.843H0.957446Z",
    p2a499900:
      "M5.71659 1.66112L2.87237 3.2941L1.31685e-05 1.63298L2.87237 0L5.71659 1.66112Z",
    p2a49ea80:
      "M23.2042 15.1754V49.2426L26.1892 47.4126V13.3453L23.2042 15.1754Z",
    p2a5b1000:
      "M23.2887 182.612L4.19592 214.314L8.36367 211.893L27.4565 180.219L23.2887 182.612Z",
    p2a5c8d00:
      "M4.19593 16.9492V21.7637L29.3432 7.2358V2.42136L4.19593 16.9492Z",
    p2a622180: "M25.1594 0L0 43.15L4.18451 45.5889L29.3439 2.43886L25.1594 0Z",
    p2a628b00: "M14.9693 6.5882V14.9705L20.5576 17.7647",
    p2a84bc00: "M4.19593 16.9774V21.7919L0 19.3706V14.5561L4.19593 16.9774Z",
    p2ac66f00:
      "M29.3432 2.44945L4.19595 16.9491L1.82804e-05 14.5278L25.1755 0L29.3432 2.44945Z",
    p2ac8c600:
      "M25.1594 0L1.10127e-05 43.15L4.18452 45.5889L29.3439 2.43886L25.1594 0Z",
    p2aed5800:
      "M26.1611 13.3454L23.2042 15.1754L1.0988e-08 1.83004L2.98501 0L26.1611 13.3454Z",
    p2b13aa70:
      "M136.409 122.135V138.184L140.549 135.762V119.714L136.409 122.135Z",
    p2b249e00:
      "M2.95684 15.1755V49.2426L26.1611 35.8973V1.83005L2.95684 15.1755ZM19.0083 31.7586L10.1096 36.8828V19.3142L19.0083 14.19V31.7586Z",
    p2b280c80:
      "M150.095 146.236V151.05L136.409 142.829V138.015L150.095 146.236Z",
    p2b2f9f20:
      "M126.469 286.756L120.048 290.698V298.103L126.469 294.161V286.756ZM114.754 293.513L108.333 297.455V304.86L114.754 300.918V293.513ZM103.067 300.242L96.6468 304.184V311.589L103.067 307.647V300.242ZM73.2454 317.67V325.075L79.666 321.133V313.728L73.2454 317.67ZM91.3526 306.999L84.9321 310.941V318.346L91.3526 314.404V306.999Z",
    p2b306100:
      "M38.0448 127.428L43.339 130.666V131.736L36.665 127.626V102.511L38.0448 103.384V127.428Z",
    p2b33b270:
      "M2.87237 3.2941V38.7409L5.71658 37.0798V1.66112L2.87237 3.2941Z",
    p2b4a9d40:
      "M1.41119e-05 2.42131L25.1473 50.6222L29.3432 48.2009L4.16776 0L1.41119e-05 2.42131Z",
    p2b6fe370:
      "M4.19593 16.9492V21.7636L29.3432 7.23577V2.42131L4.19593 16.9492Z",
    p2baa5780:
      "M118.865 27.8169L117.908 28.6053V74.1596L118.865 73.3431V27.8169Z",
    p2bab3680:
      "M213.147 77.5101L208.979 79.9032L204.783 77.4819L208.979 75.0887L213.147 77.5101Z",
    p2bb0c000:
      "M2.95686 15.1754V49.2427L26.1611 35.8973V1.83004L2.95686 15.1754ZM19.0365 31.7586L10.1378 36.8827V19.3142L19.0365 14.19V31.7586Z",
    p2bb21500:
      "M0 1.83004V35.8973L23.2042 49.2426V15.1754L0 1.83004ZM16.0515 36.8827L7.15276 31.7586V14.19L16.0515 19.3141V36.8827Z",
    p2bedc000:
      "M19.2055 31.9275L16.2205 30.0974L4.75913 36.6293L7.74414 38.4593L19.2055 31.9275Z",
    p2bf4800:
      "M2.98501 15.1755V49.2426L3.88815e-06 47.4126V13.3735L2.98501 15.1755Z",
    p2c0ab400:
      "M0 1.91459V37.4177L24.1899 51.3262V15.823L0 1.91459ZM16.7555 38.4594L7.46251 33.1382V14.8376L16.7555 20.1588V38.4594Z",
    p2c0b8900:
      "M322.912 38.2946L34.8033 205.405L35.7783 207.086L323.887 39.975L322.912 38.2946Z",
    p2c20ef80:
      "M2.87237 3.32224V38.7409L1.39309e-05 37.0798V1.66112L2.87237 3.32224Z",
    p2c3e680: "M4.19593 45.5825V50.3969L0 47.9756V43.1611L4.19593 45.5825Z",
    p2c4b3400:
      "M130.045 146.377V162.425L134.213 160.003V143.983L130.045 146.377Z",
    p2c5ed9f0: "M25.1473 16.9492V21.7637L0 7.20766V2.42136L25.1473 16.9492Z",
    p2c626f00:
      "M70.9644 81.3954L70.0351 80.9168L128.524 45.8641L129.426 46.3427L70.9644 81.3954Z",
    p2c62ca00:
      "M2.95686 15.1754V49.2426L26.1611 35.8973V1.83004L2.95686 15.1754ZM19.0083 31.7586L10.1096 36.8827V19.3141L19.0083 14.19V31.7586Z",
    p2c671600:
      "M101.744 153.359V158.173L105.968 155.752V150.938L101.744 153.359Z",
    p2c75bd70:
      "M2.87236 3.2941V139.085L5.71658 137.423V1.66112L2.87236 3.2941Z",
    p2c790bb0:
      "M9.94066 30.1256V11.0367L6.95565 12.8667V31.9275L9.94066 30.1256Z",
    p2c7ebf70:
      "M184.733 93.9243V109.972L180.537 107.551V91.503L184.733 93.9243Z",
    p2c83b380:
      "M25.1473 50.6223V55.4367L29.3432 53.0154V48.201L25.1473 50.6223Z",
    p2c9ab900:
      "M4.19593 45.5544V50.3688L29.3432 7.23576V2.4213L4.19593 45.5544Z",
    p2ca4c980:
      "M25.8232 64.4744L31.1455 67.7403V68.7821L24.4433 64.6715V52.3397L25.8232 53.1843V64.4744Z",
    p2cacf180:
      "M208.979 79.9032V95.9514L213.147 93.5301V77.51L208.979 79.9032Z",
    p2cad6900: "M2.84421 3.32224V38.7409L0 37.0798V1.66112L2.84421 3.32224Z",
    p2cb11e30:
      "M26.8651 105.721L21.1485 88.2652L15.432 99.1048L26.8933 105.721H26.8651Z",
    p2ccbc680:
      "M73.8368 54.0853L72.8512 54.8736V100.428L73.8368 99.6116V54.0853Z",
    p2cdac100:
      "M2.87237 3.32225V38.7409L5.71658 37.0798V1.66112L2.87237 3.32225Z",
    p2ce61780:
      "M2.84421 3.29416V257.869L5.68842 256.208V1.66118L2.84421 3.29416Z",
    p2cf1f872:
      "M2.87237 3.2941V38.741L1.39309e-05 37.0798V1.66112L2.87237 3.2941Z",
    p2cfb6100:
      "M66.684 76.6936V365.449L132.495 327.102V38.4031L66.684 76.6936Z",
    p2d00b800:
      "M16.2486 30.0974V11.0367L19.2055 12.8667V31.9276L16.2486 30.0974Z",
    p2d08de00:
      "M8.72975 21.9136C8.72975 27.9669 13.0101 30.3882 18.2762 27.3475C23.5422 24.3068 27.8226 16.9302 27.8226 10.9051C27.8226 4.87999 23.5422 2.43052 18.2762 5.47124C13.0101 8.51195 8.72975 15.8885 8.72975 21.9136Z",
    p2d18300: "M25.1473 50.6222V55.4367L0 7.23576V2.4213L25.1473 50.6222Z",
    p2d295a00:
      "M1.41119e-05 2.44947L25.1473 16.9492L29.3432 14.5279L4.16776 0L1.41119e-05 2.44947Z",
    p2d3b2cc0:
      "M5.71658 1.66112L2.87237 3.2941L0 1.66112L2.87237 0L5.71658 1.66112Z",
    p2d420400: "M4.19589 16.9773V21.7918L0 19.3705V14.556L4.19589 16.9773Z",
    p2d4244b0:
      "M25.1473 16.9491V21.7636L29.3432 19.3423V14.5278L25.1473 16.9491Z",
    p2d47fa00:
      "M6.95564 31.9275L9.94065 30.0974L21.402 36.6294L18.3888 38.4594L6.95564 31.9275Z",
    p2d4b3c80:
      "M222.665 83.3381V88.1525L226.861 85.7312V80.9168L222.665 83.3381Z",
    p2d51dd00:
      "M4.19593 45.5825V50.397L29.3432 7.23578V2.44946L4.19593 45.5825Z",
    p2d52baf0: "M25.1473 16.9492V21.7637L0 7.23579V2.44949L25.1473 16.9492Z",
    p2d58d480:
      "M17.9101 222.451V227.265L22.106 224.872V220.058L17.9101 222.451Z",
    p2d59300:
      "M160.627 108.114V124.162L164.795 121.741V105.693L160.627 108.114Z",
    p2d618300:
      "M4.22409 4.84262V624.585L1.75653e-05 622.164V2.42131L4.22409 4.84262Z",
    p2d739b00:
      "M5.71658 1.66112L2.87238 3.2941L6.57868e-06 1.63298L2.87238 0L5.71658 1.66112Z",
    p2d78d00:
      "M52.9136 1.89082e-06L86.0585 18.92L51.0268 39.1633L17.8819 20.2433L52.9136 1.89082e-06Z",
    p2d7932f0:
      "M2.84422 3.32224V139.084L5.71658 137.452V1.66112L2.84422 3.32224Z",
    p2d92cf00:
      "M63.8398 163.523V179.571L68.0076 177.15V161.13L63.8398 163.523Z",
    p2dbf2c00: "M25.1473 50.5941V55.4086L0 7.23579V2.42133L25.1473 50.5941Z",
    p2dc3db80:
      "M9.94065 30.1256V11.0367L6.95564 12.8667V31.9275L9.94065 30.1256Z",
    p2de3080:
      "M4.19593 16.9491V21.7636L29.3432 7.23575V2.44945L4.19593 16.9491Z",
    p2df4700:
      "M126.469 175.207L120.048 179.149V186.553L126.469 182.612V175.207ZM114.754 181.936L108.333 185.878V193.282L114.754 189.341V181.936ZM103.067 188.693L96.6468 192.635V200.04L103.067 196.098V188.693ZM73.2454 206.093V213.498L79.666 209.556V202.151L73.2454 206.093ZM91.3526 195.422L84.9321 199.364V206.769L91.3526 202.827V195.422Z",
    p2df86e80:
      "M4.19593 45.5825V50.3969L29.3432 7.2357V2.4494L4.19593 45.5825Z",
    p2dfe7f00:
      "M1.70562e-05 1.83004V35.8973L23.2043 49.2426V15.1754L1.70562e-05 1.83004ZM16.0515 36.8827L7.15278 31.7586V14.19L16.0515 19.3141V36.8827Z",
    p2e0e7700:
      "M26.1893 13.3453L23.2043 15.1754L1.06014e-06 1.83004L3.01317 0L26.1893 13.3453Z",
    p2e0e8180:
      "M40.9454 193.113L21.7681 225.013L17.5722 222.591L36.7213 190.692L40.9454 193.113Z",
    p2e313df0:
      "M17.7071 8.07107C18.0976 7.68054 18.0976 7.04738 17.7071 6.65685L11.3431 0.292893C10.9526 -0.097631 10.3195 -0.097631 9.92893 0.292893C9.53841 0.683418 9.53841 1.31658 9.92893 1.70711L15.5858 7.36396L9.92893 13.0208C9.53841 13.4113 9.53841 14.0445 9.92893 14.435C10.3195 14.8256 10.9526 14.8256 11.3431 14.435L17.7071 8.07107ZM0 7.36396V8.36396H17V7.36396V6.36396H0V7.36396Z",
    p2e34d9c0:
      "M77.4414 79.2274V62.2502L63.9525 69.9646V86.9982L77.4414 79.2274Z",
    p2e52cb80: "M25.1473 16.9492V21.7636L0 7.23578V2.42132L25.1473 16.9492Z",
    p2e5fec00:
      "M4.19589 16.9773V21.7918L29.3432 7.23577V2.44945L4.19589 16.9773Z",
    p2e61eb80:
      "M3.94246 19.2952C3.94246 25.3485 8.22286 27.7698 13.4889 24.7291C18.7549 21.6884 23.0353 14.3118 23.0353 8.28671C23.0353 2.2616 18.7549 -0.187868 13.4889 2.85284C8.22286 5.89356 3.94246 13.2701 3.94246 19.2952Z",
    p2e7a2380:
      "M133.086 42.4855V42.4574L74.3155 8.61535V14.7531L127.539 45.6952L133.086 42.4855Z",
    p2e865e00:
      "M0 13.3735L2.98501 15.1755L26.1611 1.83004L23.1761 0L0 13.3735Z",
    p2ea22900: "M72.1754 41.5001V58.3648L0 16.8647V0L72.1754 41.5001Z",
    p2eafc500:
      "M5.71658 1.66112L2.84422 3.32224L0 1.66112L2.84422 0L5.71658 1.66112Z",
    p2ebfac00:
      "M53.167 216.116V223.521L59.5876 227.462V220.058L53.167 216.116ZM41.4523 216.763L47.8728 220.705V213.3L41.4523 209.359V216.763ZM6.36426 196.548L12.7848 200.49V193.085L6.36426 189.144V196.548ZM18.0509 203.277L24.4715 207.219V199.814L18.0509 195.873V203.277ZM29.7656 210.034L36.1862 213.976V206.571L29.7656 202.63V210.034Z",
    p2ec10380:
      "M5.71659 1.66112L2.8724 3.32224L1.30593e-05 1.66112L2.8724 0L5.71659 1.66112Z",
    p2ee37600:
      "M5.71658 1.66116L2.87238 3.32228L5.49154e-06 1.66116L2.87238 0L5.71658 1.66116Z",
    p2ee6ec00:
      "M333.758 7.43285L329.59 9.85416L325.423 7.43285L329.59 5.01155L333.758 7.43285Z",
    p2eecfa00: "M141.281 162.819V167.633L0 86.4069V81.5924L141.281 162.819Z",
    p2f0c0c00: "M25.1473 16.9492V21.7636L0 7.23577V2.44947L25.1473 16.9492Z",
    p2f20f940:
      "M4.19593 16.9492V21.7636L29.3432 7.23577V2.44947L4.19593 16.9492Z",
    p2f299100:
      "M814.852 444.535C814.064 444.535 813.444 443.916 813.444 443.128V299.51C813.444 298.722 814.064 298.103 814.852 298.103C815.641 298.103 816.26 298.722 816.26 299.51V443.128C816.26 443.916 815.641 444.535 814.852 444.535Z",
    p2f314600:
      "M2.87238 3.32229V139.084L5.7166 137.452V1.66117L2.87238 3.32229Z",
    p2f335580:
      "M37.2564 53.4377L31.2018 49.9465V71.0626L37.2564 74.5538V53.4377Z",
    p2f3c0300:
      "M126.018 139.338V144.152L112.304 135.931V131.117L126.018 139.338Z",
    p2f3d9500:
      "M250.797 76.5809V92.6292L254.965 90.2078V74.1596L250.797 76.5809Z",
    p2f479880:
      "M63.8398 158.708L77.554 166.958L81.7499 164.536L68.0076 156.287L63.8398 158.708Z",
    p2f55ab72: "M25.1473 50.6223V55.4367L0 7.23577V2.42131L25.1473 50.6223Z",
    p2f5e1780:
      "M25.1473 16.9773V21.7918L29.3432 19.3705V14.556L25.1473 16.9773Z",
    p2f609000: "M4.19593 4.84262V641.028L0 638.606V2.42131L4.19593 4.84262Z",
    p2f637d80:
      "M282.309 81.311L141.197 162.791L0 81.5643L141.253 0L282.309 81.311Z",
    p2f680180: "M246.77 90.236V95.0505L250.966 92.6291V87.8147L246.77 90.236Z",
    p2f7d8f00:
      "M31.1737 116.533L36.665 113.154V89.1661L37.8477 88.4622V113.548L31.1737 117.659V116.533Z",
    p2fa52f40:
      "M1.41119e-05 2.44947L25.1473 16.9492L29.3432 14.556L4.16776 0L1.41119e-05 2.44947Z",
    p2fdbf200:
      "M22.1667 8.16667V4.66667C22.1667 4.35725 22.0438 4.0605 21.825 3.84171C21.6062 3.62292 21.3094 3.5 21 3.5H5.83333C5.2145 3.5 4.621 3.74583 4.18342 4.18342C3.74583 4.621 3.5 5.2145 3.5 5.83333C3.5 6.45217 3.74583 7.04566 4.18342 7.48325C4.621 7.92083 5.2145 8.16667 5.83333 8.16667H23.3333C23.6428 8.16667 23.9395 8.28958 24.1583 8.50838C24.3771 8.72717 24.5 9.02391 24.5 9.33333V14M24.5 14H21C20.3812 14 19.7877 14.2458 19.3501 14.6834C18.9125 15.121 18.6667 15.7145 18.6667 16.3333C18.6667 16.9522 18.9125 17.5457 19.3501 17.9832C19.7877 18.4208 20.3812 18.6667 21 18.6667H24.5C24.8094 18.6667 25.1062 18.5438 25.325 18.325C25.5438 18.1062 25.6667 17.8094 25.6667 17.5V15.1667C25.6667 14.8572 25.5438 14.5605 25.325 14.3417C25.1062 14.1229 24.8094 14 24.5 14Z",
    p2fe22300:
      "M5.71658 1.66112L2.84422 3.32228L3.29492e-06 1.66112L2.84422 0L5.71658 1.66112Z",
    p2fe79180:
      "M26.1611 13.3454L23.1761 15.1754L1.74098e-06 1.83004L2.98501 0L26.1611 13.3454Z",
    p2fff8680:
      "M158.29 130.188L154.122 132.581L149.955 130.159L154.122 127.738L158.29 130.188Z",
    p3004e80:
      "M150.095 146.236V151.05L154.291 148.629V143.814L150.095 146.236Z",
    p30084680:
      "M24.1617 15.823V51.3543L27.2875 49.4397V13.9366L24.1617 15.823Z",
    p30250200: "M2.95686 15.1754V49.2427L0 47.4126V13.3454L2.95686 15.1754Z",
    p3027fe00:
      "M0 1.83004V35.8973L23.2042 49.2426V15.1754L0 1.83004ZM16.0515 36.8827L7.15276 31.7586V14.1899L16.0515 19.3141V36.8827Z",
    p302b8c80:
      "M0 1.91455V37.4177L24.1899 51.3261V15.823L0 1.91455ZM16.7555 38.4594L7.46254 33.1382V14.8376L16.7555 20.1588V38.4594Z",
    p304ae300:
      "M6.95564 31.9275L9.94065 30.0974L21.402 36.6293L18.3888 38.4594L6.95564 31.9275Z",
    p304bef00:
      "M5.71661 1.66112L2.87239 3.2941L2.7329e-05 1.63298L2.87239 0L5.71661 1.66112Z",
    p305a66f2: "M25.1473 16.9492V21.7636L0 7.20764V2.42134L25.1473 16.9492Z",
    p306a6c00: "M343.305 13.092V17.9064L329.59 9.65708V4.87077L343.305 13.092Z",
    p306affb0:
      "M16.2486 30.0974V11.0366L19.2055 12.8667V31.9275L16.2486 30.0974Z",
    p30796000: "M4.19589 16.9492V21.7636L0 19.3423V14.556L4.19589 16.9492Z",
    p30842b80:
      "M13.0743 14.8755L15.0046 25.7387C15.0262 25.8666 15.0083 25.9981 14.9532 26.1155C14.8981 26.233 14.8084 26.3308 14.6962 26.3959C14.584 26.461 14.4546 26.4903 14.3253 26.4799C14.196 26.4695 14.0729 26.4198 13.9726 26.3376L9.4112 22.914C9.191 22.7495 8.9235 22.6606 8.64863 22.6606C8.37377 22.6606 8.10627 22.7495 7.88607 22.914L3.31705 26.3363C3.2168 26.4184 3.0939 26.468 2.96474 26.4784C2.83559 26.4888 2.70632 26.4596 2.59419 26.3947C2.48205 26.3298 2.39238 26.2322 2.33714 26.115C2.2819 25.9978 2.26371 25.8665 2.285 25.7387L4.21403 14.8755",
    p309c5c00:
      "M63.8398 179.43L77.554 187.651L81.7499 185.23L68.0076 176.981L63.8398 179.43Z",
    p309e840: "M10.5 14L12.8333 16.3333L17.5 11.6667",
    p30a13880:
      "M1.82013e-07 13.3453L2.95686 15.1754L26.1611 1.83004L23.1479 0L1.82013e-07 13.3453Z",
    p30a8d480:
      "M4.19593 45.5825V50.397L29.3432 7.23576V2.44944L4.19593 45.5825Z",
    p30abc480: "M25.1473 50.5941V55.4086L0 7.20762V2.42132L25.1473 50.5941Z",
    p30c9b580:
      "M7.26541 33.3071L10.3631 31.3926L22.3313 38.206L19.2055 40.1205L7.26541 33.3071Z",
    p30cb0680:
      "M4.19589 16.9491V21.7636L29.3432 7.23577V2.42128L4.19589 16.9491Z",
    p30d1d600: "M41.1988 45.8923L0 22.2141V14.2182L41.1988 37.8963V45.8923Z",
    p30e0cd70:
      "M4.45137e-07 12.3599L6.70221 16.4705V4.11061L4.45137e-07 0V12.3318V12.3599ZM12.2216 19.3986L18.9239 23.5092V11.1493L12.2216 7.03869V19.3705V19.3986ZM24.4433 26.4373L31.1455 30.5479V18.188L24.4433 14.0774V26.4092V26.4373ZM48.8585 28.1829V40.5147L55.5607 44.6253V32.2654L48.8585 28.1548V28.1829ZM36.665 33.476L43.3671 37.5866V25.2267L36.665 21.1161V33.4479V33.476Z",
    p30e2d500:
      "M25.1473 16.9774V21.7919L29.3432 19.3706V14.5561L25.1473 16.9774Z",
    p30e5b400:
      "M11.7148 59.7444L12.6722 60.5327V106.087L11.7148 105.271V59.7444Z",
    p30ff3970:
      "M10.4757 91.0617C10.4757 95.2849 13.4607 96.9742 17.1216 94.8626C20.8106 92.751 23.7674 87.5987 23.7674 83.3755C23.7674 79.1522 20.7824 77.463 17.1216 79.5746C13.4326 81.6862 10.4757 86.8385 10.4757 91.0617Z",
    p31026900:
      "M16.2205 30.0974V11.0367L19.2055 12.8667V31.9275L16.2205 30.0974Z",
    p3126a4c0:
      "M2.95688 15.1754V49.2427L26.1611 35.8973V1.83012L2.95688 15.1754ZM19.0084 31.7586L10.1096 36.8827V19.3142L19.0084 14.19V31.7586Z",
    p312b0dc0:
      "M100.054 38.7128L99.0686 39.5011V85.0555L100.054 84.2672V38.7128Z",
    p312ffef0: "M25.1473 16.9492V21.7636L0 7.23578V2.42134L25.1473 16.9492Z",
    p313abf80:
      "M29.3432 2.42131L4.19595 45.5544L1.82804e-05 43.1331L25.1755 0L29.3432 2.42131Z",
    p3145c00:
      "M53.167 146.377V153.781L59.5876 157.723V150.318L53.167 146.377ZM41.4523 147.052L47.8728 150.994V143.589L41.4523 139.648V147.052ZM6.36426 126.809L12.7848 130.751V123.346L6.36426 119.404V126.809ZM18.0509 133.566L24.4715 137.508V130.103L18.0509 126.161V133.566ZM29.7656 140.295L36.1862 144.237V136.832L29.7656 132.89V140.295Z",
    p3151f500:
      "M126.469 77.5664L120.048 81.508V88.9127L126.469 84.9711V77.5664ZM114.754 84.3235L108.333 88.2652V95.6699L114.754 91.7282V84.3235ZM103.067 91.0525L96.6468 94.9942V102.399L103.067 98.4572V91.0525ZM73.2454 108.48V115.885L79.666 111.943V104.539L73.2454 108.48ZM91.3526 97.8096L84.9321 101.751V109.156L91.3526 105.214V97.8096Z",
    p31678700:
      "M123.371 25.1704L122.414 25.9587V71.5131L123.371 70.6966V25.1704Z",
    p316bce00:
      "M19.2055 31.9275L16.2204 30.1256L4.75911 36.6294L7.77229 38.4876L19.2055 31.9275Z",
    p318a6700:
      "M25.1473 16.9492V21.7637L29.3432 19.3423V14.5279L25.1473 16.9492Z",
    p31908600: "M55.8141 64.587L54.8567 65.3754V110.93L55.8141 110.141V64.587Z",
    p319bed00: "M88.0579 149.952V166L92.2256 163.579V147.531L88.0579 149.952Z",
    p31a15f00:
      "M271.017 76.2149V81.0294L257.302 72.78V67.9937L271.017 76.2149Z",
    p31a1c100:
      "M126.469 91.503L120.048 95.4446V102.849L126.469 98.9077V91.503ZM114.754 98.2601L108.333 102.202V109.606L114.754 105.665V98.2601ZM103.067 104.989L96.6468 108.931V116.335L103.067 112.394V104.989ZM73.2454 122.417V129.822L79.666 125.88V118.475L73.2454 122.417ZM91.3526 111.746L84.9321 115.688V123.093L91.3526 119.151V111.746Z",
    p31bd7028:
      "M13.269 1V5.90775C13.269 6.55856 13.5275 7.18271 13.9877 7.6429C14.4479 8.1031 15.0721 8.36163 15.7229 8.36163H20.6306",
    p31d37580:
      "M59.5031 62.3628L58.5457 63.1511V108.705L59.5031 107.917V62.3628Z",
    p31d9ee80:
      "M9.49008 113.473C12.8693 111.53 15.6009 108.321 15.6009 104.548C15.6009 99.3955 10.5883 101.479 10.5883 98.945V93.5393L14.3618 91.3714V97.1431C17.544 96.6082 19.7405 99.0013 19.3181 103.422C18.9239 107.56 16.136 112.375 12.7285 114.768C10.1378 116.598 7.74412 116.795 6.1953 115.669C5.82921 115.387 6.30794 114.346 6.84299 114.318C7.65964 114.289 8.56078 114.008 9.49008 113.473Z",
    p31e72500:
      "M6.95565 31.9275L9.94065 30.0974L21.402 36.6293L18.3888 38.4594L6.95565 31.9275Z",
    p31e91280:
      "M187.999 127.428L134.044 158.37V169.717L187.999 138.775V127.428Z",
    p31f9e100:
      "M1.40802 144.884L6.70221 148.15V149.192L0 145.081V113.604L1.40802 114.477V144.884Z",
    p32268ae0: "M33.1449 86.1536V102.455L0 83.5352V67.2336L33.1449 86.1536Z",
    p3234a700:
      "M126.469 49.665L120.048 53.6066V61.0114L126.469 57.0697V49.665ZM114.754 56.4221L108.333 60.3638V67.7685L114.754 63.8268V56.4221ZM103.067 63.1511L96.6468 67.0928V74.4975L103.067 70.5558V63.1511ZM73.2454 80.5789V87.9836L79.666 84.0419V76.6372L73.2454 80.5789ZM91.3527 69.9082L84.9321 73.8499V81.2546L91.3527 77.313V69.9082Z",
    p32366540:
      "M198.447 97.3591V102.174L184.733 93.9243V89.138L198.447 97.3591Z",
    p325ae800:
      "M86.5372 46.5961L85.5797 47.3845V92.9389L86.5372 92.1506V46.5961Z",
    p327dc070:
      "M187.999 386.171L134.044 417.113V419.731L187.999 388.761V386.171Z",
    p32820000:
      "M25.1473 50.5941V55.4086L29.3432 52.9873V48.1728L25.1473 50.5941Z",
    p328ade80:
      "M187.999 227.096L134.044 258.01V260.629L187.999 229.686V227.096Z",
    p329b0f80:
      "M2.87238 3.32228V257.898L4.23645e-06 256.236V1.66112L2.87238 3.32228Z",
    p32aa3d00:
      "M187.999 90.7146L134.044 121.657V124.275L187.999 93.3048V90.7146Z",
    p32b8d580:
      "M126.469 189.144L120.048 193.085V200.49L126.469 196.548V189.144ZM114.754 195.873L108.333 199.814V207.219L114.754 203.277V195.873ZM103.067 202.63L96.6468 206.571V213.976L103.067 210.034V202.63ZM73.2454 220.058V227.462L79.666 223.521V216.116L73.2454 220.058ZM91.3526 209.359L84.9321 213.3V220.705L91.3526 216.763V209.359Z",
    p32bcc600:
      "M160.627 123.994L174.342 132.215L178.538 129.793L164.795 121.572L160.627 123.994Z",
    p32bf9400: "M25.1473 16.9492V21.7637L0 7.23586V2.42138L25.1473 16.9492Z",
    p32cda280:
      "M187.999 113.464L134.044 144.378V146.996L187.999 116.026V113.464Z",
    p32f19380:
      "M29.3432 2.42131L4.19595 16.9492L1.82804e-05 14.5278L25.1755 0L29.3432 2.42131Z",
    p33022f00:
      "M34.2432 72.8926L35.2006 73.681V119.235L34.2432 118.419V72.8926Z",
    p33057380:
      "M2.87236 3.2941V38.7128L3.06539e-06 37.0798V1.63298L2.87236 3.2941Z",
    p330aa80: "M2.84422 3.2941V257.869L5.68843 256.236V1.66112L2.84422 3.2941Z",
    p33103f00:
      "M187.999 204.347L134.044 235.289V237.908L187.999 206.937V204.347Z",
    p33193a70: "M4.19593 16.9492V21.7636L0 19.3423V14.5279L4.19593 16.9492Z",
    p331eb800:
      "M1.88679 54.0853L2.87238 54.8736V100.428L1.88679 99.6116V54.0853Z",
    p33283700:
      "M136.916 39.1352L69.8381 78.214L1.83045 39.0788L69.6128 76.8625L136.916 39.1352Z",
    p333cd800:
      "M226.72 90.3768V106.425L222.524 104.004V87.9555L226.72 90.3768Z",
    p333d2800: "M114.36 30.4353L113.402 31.2236V76.778L114.36 75.9616V30.4353Z",
    p33535800: "M2.87236 3.32228V38.741L5.71658 37.108V1.6893L2.87236 3.32228Z",
    p335ca600:
      "M294.981 41.2749V46.0893L281.267 37.84V33.0537L294.981 41.2749Z",
    p3362cc00:
      "M2.98501 15.1754V49.2426L26.1893 35.8973V1.83004L2.98501 15.1754ZM19.0365 31.7586L10.1378 36.8827V19.3141L19.0365 14.19V31.7586Z",
    p336ec200:
      "M4.19593 45.5544V50.3688L29.3432 7.2076V2.42131L4.19593 45.5544Z",
    p33724a00:
      "M29.3432 2.42131L4.1959 16.9492L1.41119e-05 14.5279L25.1755 0L29.3432 2.42131Z",
    p3372b00:
      "M26.1611 13.3453L23.1761 15.1754L1.74098e-06 1.83004L2.98501 0L26.1611 13.3453Z",
    p33736180:
      "M26.1611 13.3454L23.1761 15.1755L3.32378e-06 1.83013L2.98501 0L26.1611 13.3454Z",
    p337a2580:
      "M148.913 42.1758L75.3856 0L0 43.8651L7.01194 48.0883L74.4845 8.67167L133.143 42.4574L65.9237 81.6206L73.527 86.1817L148.913 42.1758Z",
    p33990140:
      "M53.167 104.539V111.943L59.5876 115.885V108.48L53.167 104.539ZM41.4523 105.214L47.8728 109.156V101.751L41.4523 97.8096V105.214ZM6.36426 84.9711L12.7848 88.9127V81.508L6.36426 77.5664V84.9711ZM18.0509 91.7282L24.4715 95.6699V88.2652L18.0509 84.3235V91.7282ZM29.7656 98.4572L36.1862 102.399V94.9942L29.7656 91.0525V98.4572Z",
    p33b05f80:
      "M2.87236 3.2941V138.916L5.71658 137.254V1.66112L2.87236 3.2941Z",
    p33bbfbb1:
      "M23.345 2.42131L4.19589 34.2925L0 31.8712L19.1491 1.58395e-06L23.345 2.42131Z",
    p33cc9500:
      "M4.19593 16.9492V21.7637L29.3432 7.20766V2.42136L4.19593 16.9492Z",
    p33d06200:
      "M53.2234 61.2366V70.4432L105.743 39.839V30.6605L53.2234 61.2366Z",
    p33d2900:
      "M5.71658 1.66112L2.87238 3.2941L0 1.66112L2.87238 0L5.71658 1.66112Z",
    p33f7b200:
      "M4.19589 16.9492V21.7636L29.3432 7.23579V2.42133L4.19589 16.9492Z",
    p34002200: "M25.1473 16.9492V21.7636L0 7.23577V2.42131L25.1473 16.9492Z",
    p34124300: "M21.6273 24.8606V38.572L0 26.1276V12.4444L21.6273 24.8606Z",
    p3415f00:
      "M95.5486 41.3594L94.5629 42.1477V87.7021L95.5486 86.8855V41.3594Z",
    p341a5300: "M68.5145 57.126L67.557 57.9143V103.469L68.5145 102.652V57.126Z",
    p342317b0:
      "M16.2204 30.1256V11.0367L19.2055 12.8667V31.9275L16.2204 30.1256Z",
    p34322480: "M281.267 37.84V53.8882L277.071 51.4669V35.4187L281.267 37.84Z",
    p34560180:
      "M44.9723 51.6921V84.2672L1.03947e-06 58.393V25.8461L44.9723 51.6921Z",
    p34573ff0: "M2.87236 3.29411V257.869L0 256.208V1.63299L2.87236 3.29411Z",
    p34796580:
      "M110.277 32.6032L69.6409 56.2533L28.4984 32.5751L69.1341 8.89693L110.277 32.6032Z",
    p349f9500:
      "M2.87237 3.32229V38.741L5.71658 37.108V1.66117L2.87237 3.32229Z",
    p34aa080:
      "M38.0448 33.2508L43.339 36.5167V37.5584L36.665 33.4478V21.1161L38.0448 21.9607V33.2508Z",
    p34c84680: "M2.87237 3.32228V38.741L0 37.108V1.66112L2.87237 3.32228Z",
    p34c9a000:
      "M9.94065 30.0974V11.0366L6.95564 12.8667V31.9274L9.94065 30.0974Z",
    p34c9bb80:
      "M5 17.5C6.38071 17.5 7.5 16.3807 7.5 15C7.5 13.6193 6.38071 12.5 5 12.5C3.61929 12.5 2.5 13.6193 2.5 15C2.5 16.3807 3.61929 17.5 5 17.5Z",
    p34dbf300:
      "M2.87239 3.32224V257.898L3.29776e-06 256.236V1.66112L2.87239 3.32224Z",
    p34dcbb80:
      "M4.19593 16.9492V21.7636L29.3432 7.20761V2.42131L4.19593 16.9492Z",
    p34e30300:
      "M187.999 195.619L134.044 226.533V237.908L187.999 206.937V195.619Z",
    p34f29000: "M7.77228 4.53292L0 0V359.621L7.77228 364.154V4.53292Z",
    p3501f0c0:
      "M0 31.5052L6.70221 35.6158V23.2559L0 19.1452V31.477V31.5052ZM12.2216 38.5439L18.9239 42.6545V30.2945L12.2216 26.1839V38.5157V38.5439ZM24.4433 45.5826L31.1455 49.6932V37.3332L24.4433 33.2226V45.5544V45.5826ZM48.8585 47.3V59.6318L55.5607 63.7424V51.3824L48.8585 47.2719V47.3ZM36.665 52.6212L43.3671 56.7319V44.3719L36.665 40.2613V52.5931V52.6212Z",
    p351ca100:
      "M5.35882 27.1525C7.76613 27.1525 9.71764 25.201 9.71764 22.7937C9.71764 20.3864 7.76613 18.4349 5.35882 18.4349C2.95151 18.4349 1 20.3864 1 22.7937C1 25.201 2.95151 27.1525 5.35882 27.1525Z",
    p351ca200: "M2.87237 3.32229V38.741L0 37.108V1.66112L2.87237 3.32229Z",
    p3528ca80:
      "M257.331 52.0863V68.1345L253.135 65.7132V49.665L257.331 52.0863Z",
    p3539d100:
      "M1.41119e-05 2.44945L25.1473 16.9773L29.3432 14.556L4.16776 0L1.41119e-05 2.44945Z",
    p35461bc0: "M25.1473 50.5941V55.4086L0 7.20758V2.42128L25.1473 50.5941Z",
    p35474000: "M2.95686 15.1754V49.2426L0 47.4126V13.3453L2.95686 15.1754Z",
    p354dfe80:
      "M329.619 9.85416V25.9024L325.423 23.4811V7.43285L329.619 9.85416Z",
    p355b9680:
      "M25.1473 16.9492V21.7637L29.3432 19.3705V14.556L25.1473 16.9492Z",
    p357c9cc0:
      "M136.409 138.015L150.095 146.236L154.291 143.815L140.549 135.593L136.409 138.015Z",
    p35821900:
      "M187.999 318.008L134.044 348.922V351.54L187.999 320.598V318.008Z",
    p35825a00:
      "M10.4475 113.867C13.8268 111.924 16.5584 108.715 16.5584 104.942C16.5584 99.7897 11.5458 101.873 11.5458 99.3392V93.9335L15.3193 91.7656V97.5373C18.5014 97.0024 20.6979 99.3955 20.2755 103.816C19.8813 107.955 17.0934 112.769 13.686 115.162C11.0952 116.992 8.70158 117.189 7.15275 116.063C6.78667 115.782 7.26539 114.74 7.80044 114.712C8.6171 114.684 9.51824 114.402 10.4475 113.867Z",
    p35863680:
      "M101.772 153.359V158.173L88.0579 149.952V145.138L101.772 153.359Z",
    p35951b00:
      "M27.2875 13.9085L24.1899 15.823L0 1.9145L3.15398 0L27.2875 13.9085Z",
    p359c3280:
      "M4.19593 16.9492V21.7637L29.3432 7.23579V2.44949L4.19593 16.9492Z",
    p35a59700: "M40.889 193.085V197.9L351.556 17.7375V12.9512L40.889 193.085Z",
    p35a87000:
      "M178.397 118.56V134.608L174.173 132.187V116.138L178.397 118.56Z",
    p35b16b00:
      "M5.71658 1.6893L2.87236 3.32228L0 1.66116L2.87236 0L5.71658 1.6893Z",
    p35ba4680:
      "M10 10.8333C11.3807 10.8333 12.5 9.71405 12.5 8.33333C12.5 6.95262 11.3807 5.83333 10 5.83333C8.61929 5.83333 7.5 6.95262 7.5 8.33333C7.5 9.71405 8.61929 10.8333 10 10.8333Z",
    p35db2a00:
      "M72.9638 30.9984V63.2356L33.1449 86.238V86.1536L48.8303 44.935L72.9638 30.9984Z",
    p35f8a980:
      "M4.19589 16.9492V21.7636L29.3432 7.23578V2.42132L4.19589 16.9492Z",
    p3601e400: "M2.87236 3.2941V38.7128L0 37.0798V1.63298L2.87236 3.2941Z",
    p3605c00: "M14.925 386.818V388.761L77.3287 424.433V422.49L14.925 386.818Z",
    p3620ac00:
      "M198.419 118.053V122.867L202.643 120.446V115.632L198.419 118.053Z",
    p36334180:
      "M2.95684 15.1754V49.2426L1.37991e-06 47.4126V13.3453L2.95684 15.1754Z",
    p363c19f0:
      "M126.469 230.982L120.048 234.923V242.328L126.469 238.386V230.982ZM114.754 237.739L108.333 241.68V249.085L114.754 245.143V237.739ZM103.067 244.468L96.6468 248.409V255.814L103.067 251.872V244.468ZM73.2454 261.896V269.3L79.666 265.359V257.954L73.2454 261.896ZM91.3526 251.225L84.9321 255.167V262.571L91.3526 258.63V251.225Z",
    p363c980:
      "M5.68842 1.66112L2.84421 3.2941L0 1.63298L2.84421 0L5.68842 1.66112Z",
    p363e4700:
      "M65.9237 456.586L73.527 461.597V86.1817L65.9237 81.6206V456.586Z",
    p36824500: "M2.87237 3.2941V139.084L0 137.423V1.63298L2.87237 3.2941Z",
    p3691fdc0:
      "M187.999 172.87L134.044 203.812V215.187L187.999 184.217V172.87Z",
    p3693ea00:
      "M17.5001 0.839622C17.5001 0.839622 16.9167 2.58962 15.8334 3.67296C17.1667 12.0063 8.00007 18.0896 0.833404 13.3396C2.66674 13.423 4.50007 12.8396 5.8334 11.673C1.66674 10.423 -0.416595 5.50629 1.66674 1.67296C3.50007 3.83962 6.3334 5.08962 9.16674 5.00629C8.41674 1.50629 12.5001 -0.493711 15.0001 1.83962C15.9167 1.83962 17.5001 0.839622 17.5001 0.839622Z",
    p36968600:
      "M63.8398 163.523V179.571L59.6439 177.15V161.102L63.8398 163.523Z",
    p36a19400: "M4.22407 214.342V219.157L0 216.735V211.921L4.22407 214.342Z",
    p36b9f6f0:
      "M29.3432 2.42127L4.19595 45.5544L1.82804e-05 43.1331L25.1755 0L29.3432 2.42127Z",
    p36f3a280:
      "M2.84422 3.2941V257.869L5.71658 256.208V1.66112L2.84422 3.2941Z",
    p36fc8280:
      "M62.9669 77.0877L62.0376 76.6091V446.337L62.9669 446.816V77.0877Z",
    p3736dc00:
      "M2.95684 15.1754V49.2426L26.1611 35.8973V1.83008L2.95684 15.1754ZM19.0083 31.7586L10.1096 36.8827V19.3142L19.0083 14.19V31.7586Z",
    p373b1c80:
      "M12.4083 65.759C12.9434 65.759 13.3939 65.3086 13.3939 64.7736L1.65101 0.271084C1.25676 -0.0949274 0.637226 -0.0949214 0.27114 0.299245C-0.0949468 0.693412 -0.0949408 1.31281 0.299306 1.67882L11.4509 64.7455C11.4509 65.2804 11.9014 65.7309 12.4365 65.7309L12.4083 65.759Z",
    p3797c600:
      "M0 75.3984L6.70221 79.509V60.7861L0 56.6755V75.3984ZM12.2216 82.4371L18.9239 86.5477V67.8248L12.2216 63.7142V82.4371ZM24.4433 89.4758L31.1455 93.5864V74.8635L24.4433 70.7529V89.4758ZM48.8585 84.8303V103.553L55.5607 107.664V88.9409L48.8585 84.8303ZM36.665 96.5145L43.3671 100.625V81.9022L36.665 77.7916V96.5145Z",
    p37b63000:
      "M38.0448 71.5131L43.339 74.779V75.8207L36.665 71.7102V59.3784L38.0448 60.223V71.5131Z",
    p37c96d00:
      "M93.8026 449.772V96.3737L148.913 64.1647V42.1477L73.4989 86.1817V461.597L93.8308 449.772H93.8026Z",
    p37cc9780:
      "M0 106.538L6.70221 110.648V85.5342L0 81.4235V106.509V106.538ZM12.2216 113.576L18.9239 117.687V92.5728L12.2216 88.4622V113.548V113.576ZM24.4433 120.615L31.1455 124.726V99.6115L24.4433 95.5009V120.587V120.615ZM48.8585 109.578V134.664L55.5607 138.775V113.661L48.8585 109.55V109.578ZM36.665 127.654L43.3671 131.764V106.65L36.665 102.54V127.626V127.654Z",
    p37edd800:
      "M9.94065 30.0974V11.0367L6.95565 12.8667V31.9275L9.94065 30.0974Z",
    p3802400:
      "M5.71658 1.66112L2.87237 3.2941L6.76062e-06 1.63298L2.87237 0L5.71658 1.66112Z",
    p380efb40:
      "M2.87237 3.32228V38.7409L1.28326e-05 37.108V1.66112L2.87237 3.32228Z",
    p3810db00:
      "M257.302 52.0863V68.1345L261.47 65.7132V49.6931L257.302 52.0863Z",
    p38341d80:
      "M27.2875 13.9366L24.1899 15.823L5.56202e-07 1.91455L3.15398 0L27.2875 13.9366Z",
    p383de300:
      "M75.0758 14.1618L14.9532 49.3271L84.932 89.5884L145.055 54.3105L75.0758 14.1618Z",
    p384ce780:
      "M0 1.83009V35.8973L23.2042 49.2427V15.1754L0 1.83009ZM16.0515 36.8828L7.15276 31.7586V14.19L16.0515 19.3142V36.8828Z",
    p384d5f00:
      "M20.7261 65.0093L21.6836 65.7977V111.352L20.7261 110.536V65.0093Z",
    p38567d40:
      "M0 13.3735L2.98501 15.1754L26.1893 1.83004L23.1761 0L0 13.3735Z",
    p385f4200:
      "M2.87237 3.2941V257.869L5.71658 256.208V1.66112L2.87237 3.2941Z",
    p38698680: "M281.267 37.84V53.8882L285.435 51.4669V35.4468L281.267 37.84Z",
    p38781f0:
      "M6.39244 56.7037L7.37808 57.492V103.046L6.39244 102.258V56.7037Z",
    p38814e10:
      "M271.017 76.2149V81.0294L275.213 78.6081V73.7936L271.017 76.2149Z",
    p3884aec0:
      "M4.66667 17.5V14C4.66667 12.1435 5.40417 10.363 6.71692 9.05025C8.02967 7.7375 9.81015 7 11.6667 7",
    p388cb400:
      "M25.1677 0L0.00833608 43.15L4.19284 45.5889L29.3522 2.43886L25.1677 0Z",
    p388dab00:
      "M22.7935 9.71757C22.7935 13.1857 21.4158 16.5117 18.9635 18.964C16.5112 21.4163 13.1852 22.794 9.71708 22.794",
    p3896ff00:
      "M29.3432 2.42131L4.1959 16.9492L1.41119e-05 14.5278L25.1755 0L29.3432 2.42131Z",
    p38b0100:
      "M2.87238 3.2941V38.741L9.24748e-06 37.0798V1.63298L2.87238 3.2941Z",
    p38bd6400:
      "M4.19589 16.9492V21.7636L29.3432 7.20763V2.42132L4.19589 16.9492Z",
    p38d0f100:
      "M43.3672 34.4614L48.8867 31.0828V19.8491L50.0694 19.1171V31.477L43.3672 35.5876V34.4614Z",
    p38e01d80:
      "M53.167 271.89V279.295L59.5876 283.237V275.832L53.167 271.89ZM41.4523 272.566L47.8728 276.508V269.103L41.4523 265.161V272.566ZM6.36426 252.323L12.7848 256.265V248.86L6.36426 244.918V252.323ZM18.0509 259.08L24.4715 263.022V255.617L18.0509 251.675V259.08ZM29.7656 265.809L36.1862 269.751V262.346L29.7656 258.404V265.809Z",
    p38e7c400:
      "M5.71658 1.66112L2.84422 3.2941L3.29492e-06 1.66112L2.84422 0L5.71658 1.66112Z",
    p38f96300:
      "M15.4038 61.9686L16.3894 62.7569V108.311L15.4038 107.495V61.9686Z",
    p39243580:
      "M11.6667 11.6667V5.83333C11.6667 5.52391 11.7896 5.22717 12.0084 5.00838C12.2272 4.78958 12.5239 4.66667 12.8333 4.66667H15.1667C15.4761 4.66667 15.7728 4.78958 15.9916 5.00838C16.2104 5.22717 16.3333 5.52391 16.3333 5.83333V11.6667",
    p394b7940:
      "M2.87237 3.2941V38.7128L5.71659 37.0798V1.66112L2.87237 3.2941Z",
    p394f8700:
      "M16.3333 2.33333V7C16.3333 7.61884 16.5792 8.21233 17.0168 8.64992C17.4543 9.0875 18.0478 9.33333 18.6667 9.33333H23.3333",
    p396da500:
      "M233.084 82.0148L246.77 90.236L250.966 87.8147L237.252 79.5653L233.084 82.0148Z",
    p397e6e00: "M25.1473 16.9492V21.7636L0 7.23579V2.42133L25.1473 16.9492Z",
    p398ea300:
      "M53.167 257.954V265.359L59.5876 269.3V261.896L53.167 257.954ZM41.4523 258.63L47.8728 262.571V255.167L41.4523 251.225V258.63ZM6.36426 238.386L12.7848 242.328V234.923L6.36426 230.982V238.386ZM18.0509 245.143L24.4715 249.085V241.68L18.0509 237.739V245.143ZM29.7656 251.872L36.1862 255.814V248.409L29.7656 244.468V251.872Z",
    p3997a780: "M25.6667 8.16667L15.75 18.0833L9.91667 12.25L2.33333 19.8333",
    p39ae5000:
      "M4.19593 16.9492V21.7636L29.3432 7.23578V2.42134L4.19593 16.9492Z",
    p39b50300:
      "M67.2191 66.8394C66.5151 66.8394 65.8956 66.3045 65.8111 65.5724C65.7266 64.8123 66.2898 64.1084 67.0783 64.0239C68.9369 63.8268 70.7673 63.6016 72.5696 63.2919C73.33 63.1793 74.0621 63.6861 74.1748 64.4462C74.2874 65.2064 73.7805 65.9384 73.0202 66.0511C71.1616 66.3608 69.2467 66.6142 67.3599 66.7831C67.3036 66.7831 67.2754 66.7831 67.2191 66.7831V66.8394ZM81.0459 64.3336C80.4264 64.3336 79.8632 63.9113 79.6942 63.2919C79.4971 62.5317 79.9477 61.7715 80.6798 61.5745C82.4821 61.0958 84.2562 60.5609 85.974 59.9415C86.7062 59.6881 87.4947 60.0822 87.7763 60.8143C88.0297 61.5463 87.6355 62.3628 86.9033 62.6162C85.1292 63.2356 83.2706 63.7987 81.412 64.3055C81.2994 64.3336 81.1586 64.3618 81.0459 64.3618V64.3336ZM94.1969 59.3784C93.69 59.3784 93.1831 59.0968 92.9297 58.6182C92.5917 57.9143 92.8452 57.0697 93.5492 56.7318C94.4503 56.2814 95.2951 55.8027 96.1399 55.3241C96.8721 54.9018 97.6043 54.4513 98.2802 54.0008C98.9278 53.5785 99.8008 53.7756 100.223 54.4232C100.646 55.0707 100.449 55.9435 99.8008 56.3658C99.0686 56.8444 98.3083 57.2949 97.5198 57.7454C96.6187 58.2522 95.7176 58.759 94.7883 59.2376C94.5911 59.3502 94.3658 59.3784 94.1406 59.3784H94.1969ZM17.9101 57.8017C17.6848 57.8017 17.4314 57.7454 17.2061 57.6046C15.4601 56.5911 13.855 55.5493 12.3625 54.4232C11.7429 53.9727 11.6021 53.0717 12.0809 52.4523C12.5596 51.8329 13.4326 51.6921 14.0521 52.1708C15.4601 53.2125 16.9808 54.2261 18.6141 55.1552C19.2899 55.5493 19.5152 56.394 19.121 57.0697C18.8675 57.5202 18.3888 57.7736 17.9101 57.7736V57.8017ZM105.686 51.3261C105.32 51.3261 104.954 51.1854 104.701 50.9038C104.138 50.3407 104.138 49.4679 104.701 48.9048C106.024 47.5815 107.179 46.2019 108.136 44.7942C108.559 44.1466 109.46 43.9777 110.108 44.4282C110.755 44.8787 110.924 45.7515 110.474 46.3709C109.404 47.9194 108.136 49.4398 106.7 50.9038C106.419 51.1854 106.052 51.3261 105.715 51.3261H105.686ZM7.01198 48.9611C6.61773 48.9611 6.22347 48.7922 5.94187 48.4543C4.61832 46.8777 3.4919 45.2165 2.61893 43.5554C2.25284 42.8797 2.50628 42.0069 3.2103 41.6409C3.88615 41.2749 4.75914 41.5283 5.09707 42.2321C5.88556 43.7243 6.89933 45.2165 8.08207 46.6243C8.58896 47.2155 8.50449 48.1165 7.91312 48.5951C7.65967 48.8204 7.32175 48.933 7.01198 48.933V48.9611ZM112.67 39.3322C112.67 39.3322 112.473 39.3322 112.36 39.304C111.6 39.1351 111.121 38.3749 111.29 37.6148C111.572 36.3759 111.713 35.109 111.713 33.842C111.713 33.3634 111.713 32.8847 111.656 32.4343C111.6 31.6459 112.163 30.9702 112.952 30.9139C113.712 30.8576 114.416 31.4207 114.472 32.209C114.529 32.744 114.529 33.3071 114.529 33.842C114.529 35.3061 114.36 36.7701 114.05 38.206C113.909 38.8536 113.318 39.304 112.67 39.304V39.3322ZM1.46436 36.2915C0.732185 36.2915 0.112654 35.7284 0.056333 34.9964C0.0281725 34.4896 0 33.9828 0 33.4478C0 31.9556 0.168964 30.4634 0.50689 28.9712C0.675853 28.2111 1.4362 27.7324 2.19654 27.9014C2.95687 28.0703 3.43559 28.8305 3.26663 29.5907C2.98502 30.8576 2.84422 32.1809 2.84422 33.4478C2.84422 33.8983 2.84423 34.3206 2.90055 34.7711C2.95687 35.5595 2.36548 36.2352 1.60515 36.2915C1.57699 36.2915 1.52069 36.2915 1.49252 36.2915H1.46436ZM110.614 25.7053C110.108 25.7053 109.629 25.4237 109.375 24.9451C108.587 23.4529 107.573 21.9607 106.362 20.553C105.855 19.9617 105.94 19.0608 106.531 18.5821C107.123 18.0753 108.024 18.1598 108.531 18.7511C109.854 20.3277 110.981 21.9607 111.882 23.6218C112.248 24.2976 111.994 25.1704 111.29 25.5364C111.065 25.649 110.84 25.7053 110.614 25.7053ZM5.29419 23.0306C5.01258 23.0306 4.73098 22.9461 4.5057 22.7772C3.85801 22.3267 3.68903 21.4539 4.1396 20.8064C5.2097 19.2579 6.47693 17.7375 7.91312 16.3016C8.47633 15.7385 9.3493 15.7667 9.91251 16.3016C10.4757 16.8647 10.4476 17.7375 9.91251 18.3006C8.58896 19.6239 7.43438 21.0034 6.47692 22.4112C6.19532 22.8054 5.7729 23.0306 5.32233 23.0306H5.29419ZM101.265 15.3725C100.984 15.3725 100.674 15.288 100.42 15.091C99.0405 14.0774 97.5198 13.092 95.9147 12.1629L97.2382 9.68524L96.5342 10.8959L97.2945 9.71338C99.0123 10.6988 100.617 11.7405 102.082 12.8386C102.701 13.289 102.842 14.19 102.392 14.8094C102.11 15.1754 101.688 15.3725 101.265 15.3725ZM15.5446 13.4861C15.094 13.4861 14.6153 13.2609 14.3619 12.8386C13.9395 12.191 14.1366 11.3182 14.7843 10.8959C15.4883 10.4454 16.2205 9.99494 16.9526 9.57262C17.8819 9.03768 18.8394 8.53089 19.7968 8.0241C20.5009 7.68624 21.3457 7.93964 21.6836 8.64351C22.0215 9.34738 21.7681 10.192 21.0641 10.5299C20.1348 10.9803 19.2336 11.4871 18.3607 11.9939C17.6566 12.4163 16.9526 12.8104 16.3049 13.2609C16.0796 13.4017 15.7981 13.4861 15.5446 13.4861ZM88.9309 8.61535C88.7619 8.61535 88.5929 8.58719 88.3958 8.50273C86.7343 7.82701 84.9884 7.20762 83.1861 6.64452C82.4539 6.41929 82.0316 5.63096 82.2568 4.87078C82.4821 4.13876 83.2706 3.71643 84.0309 3.94167C85.8895 4.53292 87.6918 5.18048 89.4378 5.85619C90.1699 6.13774 90.5079 6.95423 90.2262 7.68626C90.001 8.2212 89.4659 8.55905 88.9309 8.55905V8.61535ZM28.1887 7.43285C27.5973 7.43285 27.0622 7.06685 26.8651 6.4756C26.6117 5.74358 27.0059 4.92707 27.7381 4.67368C29.5122 4.05427 31.3708 3.49118 33.2294 2.9844C33.9897 2.78731 34.7501 3.23779 34.9472 3.99797C35.1443 4.75815 34.6938 5.51833 33.9616 5.71541C32.1593 6.19404 30.3852 6.72898 28.6674 7.32023C28.5266 7.37654 28.3576 7.40469 28.2168 7.40469L28.1887 7.43285ZM75.4702 4.64554C75.4702 4.64554 75.273 4.64554 75.1885 4.64554C73.3863 4.27953 71.5558 3.96982 69.7254 3.71643C68.9651 3.60381 68.43 2.89995 68.5145 2.13977C68.6271 1.37959 69.3593 0.844648 70.0915 0.929112C71.9782 1.1825 73.865 1.52035 75.7236 1.88636C76.4839 2.02714 76.9908 2.78733 76.8219 3.54751C76.6811 4.22322 76.0897 4.67368 75.442 4.67368L75.4702 4.64554ZM41.8465 4.02613C41.1707 4.02613 40.5793 3.54751 40.4666 2.84364C40.3258 2.08346 40.8609 1.35144 41.6212 1.23882C43.508 0.929114 45.3947 0.70387 47.2815 0.506786C48.07 0.450477 48.7458 0.985409 48.8303 1.77374C48.9148 2.53392 48.3516 3.2378 47.5631 3.32226C45.7045 3.49119 43.8741 3.74458 42.0718 4.02613C41.9873 4.02613 41.931 4.02613 41.8465 4.02613ZM61.5025 2.9281H61.4462C59.9537 2.87179 58.433 2.81548 56.9405 2.81548H55.8986C55.1383 2.84363 54.4906 2.19608 54.4624 1.4359C54.4624 0.647565 55.0819 0.0281548 55.8423 0H56.9124C58.4612 0 60.01 0.0281573 61.5589 0.112622C62.3473 0.140776 62.9387 0.816481 62.9106 1.57666C62.8824 2.33684 62.2629 2.9281 61.5025 2.9281Z",
    p39d74c00:
      "M43.7614 175.151L39.5937 177.544L35.3977 175.123L39.5937 172.701L43.7614 175.151Z",
    p39d9b500:
      "M2.95684 15.1755V49.2426L26.1611 35.8973V1.83004L2.95684 15.1755ZM19.0083 31.7586L10.1096 36.8828V19.3142L19.0083 14.19V31.7586Z",
    p39daa800:
      "M16.2895 9.9189H11.193C10.4893 9.9189 9.9189 10.4893 9.9189 11.193V16.2895C9.9189 16.9932 10.4893 17.5637 11.193 17.5637H16.2895C16.9932 17.5637 17.5637 16.9932 17.5637 16.2895V11.193C17.5637 10.4893 16.9932 9.9189 16.2895 9.9189Z",
    p39e90300:
      "M222.693 83.3381V88.1525L208.979 79.9032V75.1169L222.693 83.3381Z",
    p3a0dff00:
      "M1.40803 0.844608V12.1347L6.70221 15.4007V16.4705L4.45137e-07 12.3318V0L1.40803 0.844608Z",
    p3a11bf00: "M2.95686 15.1754V49.2427L0 47.3845V13.3454L2.95686 15.1754Z",
    p3a22fe00:
      "M50.2665 40.2894L55.5607 43.5554V44.5971L48.8585 40.4865V28.1548L50.2665 28.9994V40.2894Z",
    p3a2d5900:
      "M4.20096 45.5896V50.404L29.3483 7.24281V2.45651L4.20096 45.5896Z",
    p3a3cf580:
      "M15 7.5C16.3807 7.5 17.5 6.38071 17.5 5C17.5 3.61929 16.3807 2.5 15 2.5C13.6193 2.5 12.5 3.61929 12.5 5C12.5 6.38071 13.6193 7.5 15 7.5Z",
    p3a477c00:
      "M13.6297 57.4357L18.9239 60.7017V61.7434L12.2216 57.6328V45.301L13.6297 46.1456V57.4357Z",
    p3a4cd400:
      "M2.87237 3.2941V38.7128L1.28326e-05 37.0798V1.63298L2.87237 3.2941Z",
    p3a5d500: "M174.342 111.521V116.335L178.538 113.914V109.1L174.342 111.521Z",
    p3a6fc100:
      "M21.5428 206.656C20.7543 206.656 20.1348 206.037 20.1348 205.248V201.138C20.1348 200.349 20.7543 199.73 21.5428 199.73C22.3313 199.73 22.9508 200.349 22.9508 201.138V205.248C22.9508 206.037 22.3313 206.656 21.5428 206.656ZM21.5428 194.099C20.7543 194.099 20.1348 193.479 20.1348 192.691V187.06C20.1348 186.272 20.7543 185.652 21.5428 185.652C22.3313 185.652 22.9508 186.272 22.9508 187.06V192.691C22.9508 193.479 22.3313 194.099 21.5428 194.099ZM21.5428 180.022C20.7543 180.022 20.1348 179.402 20.1348 178.614V172.983C20.1348 172.194 20.7543 171.575 21.5428 171.575C22.3313 171.575 22.9508 172.194 22.9508 172.983V178.614C22.9508 179.402 22.3313 180.022 21.5428 180.022ZM21.5428 165.944C20.7543 165.944 20.1348 165.325 20.1348 164.536V158.905C20.1348 158.117 20.7543 157.498 21.5428 157.498C22.3313 157.498 22.9508 158.117 22.9508 158.905V164.536C22.9508 165.325 22.3313 165.944 21.5428 165.944ZM21.5428 151.867C20.7543 151.867 20.1348 151.247 20.1348 150.459V144.828C20.1348 144.04 20.7543 143.42 21.5428 143.42C22.3313 143.42 22.9508 144.04 22.9508 144.828V150.459C22.9508 151.247 22.3313 151.867 21.5428 151.867ZM21.5428 137.789C20.7543 137.789 20.1348 137.17 20.1348 136.382V130.751C20.1348 129.962 20.7543 129.343 21.5428 129.343C22.3313 129.343 22.9508 129.962 22.9508 130.751V136.382C22.9508 137.17 22.3313 137.789 21.5428 137.789ZM21.5428 123.712C20.7543 123.712 20.1348 123.093 20.1348 122.304V116.673C20.1348 115.885 20.7543 115.266 21.5428 115.266C22.3313 115.266 22.9508 115.885 22.9508 116.673V122.304C22.9508 123.093 22.3313 123.712 21.5428 123.712ZM21.5428 109.635C20.7543 109.635 20.1348 109.015 20.1348 108.227V102.596C20.1348 101.808 20.7543 101.188 21.5428 101.188C22.3313 101.188 22.9508 101.808 22.9508 102.596V108.227C22.9508 109.015 22.3313 109.635 21.5428 109.635Z",
    p3a723d80: "M2.87237 3.3223V38.741L0 37.0799V1.66118L2.87237 3.3223Z",
    p3a748900:
      "M53.167 174.278V181.683L59.5876 185.624V178.22L53.167 174.278ZM41.4523 174.926L47.8728 178.867V171.462L41.4523 167.521V174.926ZM6.36426 154.71L12.7848 158.652V151.247L6.36426 147.306V154.71ZM18.0509 161.439L24.4715 165.381V157.976L18.0509 154.035V161.439ZM29.7656 168.197L36.1862 172.138V164.733L29.7656 160.792V168.197Z",
    p3a824b00:
      "M294.953 61.9686V66.7831L299.149 64.3618V59.5473L294.953 61.9686Z",
    p3a92a700:
      "M8.47634 272.848V21.9325L9.68722 21.2005V273.242L7.56023e-06 279.183V278.056L8.47634 272.848Z",
    p3a983880:
      "M22.9789 53.9164L22.0497 53.4377L80.5108 18.3851L81.4401 18.8637L22.9789 53.9164Z",
    p3aa3d700:
      "M329.59 9.85416V25.9024L333.758 23.4811V7.43285L329.59 9.85416Z",
    p3aa5ae00:
      "M4.19589 16.9491V21.7636L29.3432 7.23571V2.42127L4.19589 16.9491Z",
    p3abba800:
      "M19.2054 31.9275L16.2486 30.1255L4.78729 36.6294L7.77229 38.4594L19.2054 31.9275Z",
    p3abc7000:
      "M9.04248e-07 2.42131L25.1473 16.9492L29.3432 14.5279L4.16774 0L9.04248e-07 2.42131Z",
    p3abd5e00:
      "M6.95565 31.9275L9.94065 30.0974L21.402 36.6293L18.3888 38.4593L6.95565 31.9275Z",
    p3ac7ec00:
      "M19.2055 31.9275L16.2205 30.0974L4.75913 36.6294L7.74414 38.4594L19.2055 31.9275Z",
    p3ac92100: "M4.19593 45.5826V50.397L0 47.9757V43.1612L4.19593 45.5826Z",
    p3ad41980: "M25.1473 16.9492V21.7637L0 7.23581V2.42133L25.1473 16.9492Z",
    p3adf5d00:
      "M10.3631 31.3926V11.5153L7.26541 13.4298V33.3071L10.3631 31.3926Z",
    p3aeb3380:
      "M25.8232 89.2506L31.1455 92.4884V93.5583L24.4433 89.4476V70.7247L25.8232 71.5694V89.2506Z",
    p3aeef300:
      "M16.2486 30.0974V11.0367L19.2055 12.8667V31.9275L16.2486 30.0974Z",
    p3afb9670:
      "M2.87239 3.2941V38.7128L1.8495e-05 37.0798V1.63293L2.87239 3.2941Z",
    p3affdb00:
      "M351.556 12.9512L40.889 193.085L36.7213 190.664L347.388 10.5017L351.556 12.9512Z",
    p3b124d80: "M43.7051 50.2281V52.0863L0 26.9723V25.114L43.7051 50.2281Z",
    p3b1c4280: "M2.84421 3.29414V138.916L0 137.254V1.63298L2.84421 3.29414Z",
    p3b214100:
      "M233.084 66.1074V82.1556L228.889 79.7343V63.6861L233.084 66.1074Z",
    p3b266100:
      "M130.073 64.3899L37.7632 117.997V120.671L130.073 67.0646V64.3899Z",
    p3b2caf60:
      "M5.71658 1.66116L2.84422 3.32228L0 1.66116L2.84422 0L5.71658 1.66116Z",
    p3b36bd00:
      "M303.148 45.8923L299.008 48.3136L294.812 45.8923L299.008 43.4709L303.148 45.8923Z",
    p3b39e00: "M25.1473 16.9492V21.7637L0 7.20766V2.42132L25.1473 16.9492Z",
    p3b3cb870: "M21.6273 26.5781V31.7304L0 19.286V14.1618L21.6273 26.5781Z",
    p3b41dd80: "M4.19593 16.9491V21.7636L0 19.3423V14.5278L4.19593 16.9491Z",
    p3b4ad400:
      "M27.2875 13.9366L24.1899 15.823L0 1.91459L3.15396 0L27.2875 13.9366Z",
    p3b4c0300:
      "M2.95684 15.1754V49.2426L26.1611 35.8973V1.83004L2.95684 15.1754ZM19.0083 31.7586L10.1096 36.8827V19.3141L19.0083 14.1899V31.7586Z",
    p3b4e6d80:
      "M0.203612 0.456664C14.5841 6.86845 55.3167 18.6796 103.204 14.6301",
    p3b50b980:
      "M24.1899 15.823V51.3261L27.2875 49.4116V13.9085L24.1899 15.823Z",
    p3b878e80: "M25.1473 50.6223V55.4368L0 7.23583V2.42135L25.1473 50.6223Z",
    p3b92e870:
      "M2.98502 15.1754V49.2427L1.71642e-05 47.4127V13.3454L2.98502 15.1754Z",
    p3b959a00:
      "M1.70562e-05 1.83003V35.8973L23.2043 49.2426V15.1754L1.70562e-05 1.83003ZM16.0515 36.8827L7.15278 31.7586V14.19L16.0515 19.3141V36.8827Z",
    p3b9e8fc0:
      "M1.41119e-05 2.44949L25.1473 16.9492L29.3432 14.5279L4.16776 0L1.41119e-05 2.44949Z",
    p3bb0780: "M25.1473 16.9491V21.7636L0 7.23573V2.42127L25.1473 16.9491Z",
    p3bb9d100: "M4.19589 16.9492V21.7636L0 19.3423V14.5279L4.19589 16.9492Z",
    p3bc23dc0:
      "M54.9693 72.2451L54.04 71.7665L112.529 36.7138L113.43 37.1924L54.9693 72.2451Z",
    p3bdffe00:
      "M57.3348 188.017V204.066L53.1389 201.644V185.596L57.3348 188.017Z",
    p3be3bb00:
      "M64.0088 59.7444L63.0513 60.5327V106.087L64.0088 105.271V59.7444Z",
    p3be78e80: "M4.19593 45.5544V50.3689L0 47.9476V43.1331L4.19593 45.5544Z",
    p3bf09300: "M25.1473 16.9491V21.7636L0 7.23576V2.4213L25.1473 16.9491Z",
    p3c03a8c0:
      "M126.469 119.404L120.048 123.346V130.751L126.469 126.809V119.404ZM114.754 126.161L108.333 130.103V137.508L114.754 133.566V126.161ZM103.067 132.89L96.6468 136.832V144.237L103.067 140.295V132.89ZM73.2454 150.318V157.723L79.666 153.781V146.377L73.2454 150.318ZM91.3526 139.648L84.9321 143.589V150.994L91.3526 147.052V139.648Z",
    p3c2fd6f0:
      "M0 145.11L6.70221 149.22V117.743L0 113.633V145.11ZM12.2216 152.148L18.9239 156.259V124.782L12.2216 120.671V152.148ZM24.4433 159.187L31.1455 163.298V131.821L24.4433 127.71V159.187ZM48.8585 141.787V173.264L55.5607 177.375V145.898L48.8585 141.787ZM36.665 166.226L43.3671 170.336V138.859L36.665 134.749V166.226Z",
    p3c429080:
      "M2.87239 3.32228V38.741L1.8495e-05 37.0798V1.66116L2.87239 3.32228Z",
    p3c4b1300:
      "M2.87237 3.32228V38.741L5.71659 37.0798V1.66116L2.87237 3.32228Z",
    p3c4b8a80:
      "M65.3887 23.7063L41.1707 37.9245L0 14.2463L24.2744 0L65.3887 23.7063Z",
    p3c55c380: "M2.84423 3.2941V38.7128L5.7166 37.0798V1.66112L2.84423 3.2941Z",
    p3c55f000:
      "M22.794 9.71764C25.2013 9.71764 27.1528 7.76613 27.1528 5.35882C27.1528 2.95151 25.2013 1 22.794 1C20.3866 1 18.4351 2.95151 18.4351 5.35882C18.4351 7.76613 20.3866 9.71764 22.794 9.71764Z",
    p3c75bc00: "M25.1473 16.9491V21.7636L0 7.23572V2.42128L25.1473 16.9491Z",
    p3c846980:
      "M4.19593 16.9491V21.7636L29.3432 7.23572V2.42128L4.19593 16.9491Z",
    p3c86a300: "M25.1473 50.6222V55.4367L0 7.23577V2.42131L25.1473 50.6222Z",
    p3c9e00: "M43.7051 50.2281V57.7736L0 32.6595V25.114L43.7051 50.2281Z",
    p3ca0d600:
      "M174.342 132.215V137.029L160.627 128.808V123.994L174.342 132.215Z",
    p3ca38d80:
      "M16.3333 7C18.1898 7 19.9703 7.7375 21.2831 9.05025C22.5958 10.363 23.3333 12.1435 23.3333 14V17.5",
    p3cafda80:
      "M143.309 41.5283L72.1472 82.9721L0 41.472L71.2461 0L143.309 41.5283Z",
    p3cb38a80:
      "M2.98501 15.1754V49.2426L3.88815e-06 47.4126V13.3735L2.98501 15.1754Z",
    p3cf01600:
      "M126.469 105.468L120.048 109.409V116.814L126.469 112.872V105.468ZM114.754 112.197L108.333 116.138V123.543L114.754 119.601V112.197ZM103.067 118.954L96.6468 122.896V130.3L103.067 126.359V118.954ZM73.2454 136.382V143.786L79.666 139.845V132.44L73.2454 136.382ZM91.3526 125.683L84.9321 129.624V137.029L91.3526 133.088V125.683Z",
    p3d01e000:
      "M2.87238 3.29411V139.084L5.7166 137.423V1.66112L2.87238 3.29411Z",
    p3d12dd00:
      "M38.9741 63.3482L38.0448 62.8696V432.598L38.9741 433.076V63.3482Z",
    p3d3b9772:
      "M50.2665 59.4347L55.5607 62.6725V63.7424L48.8585 59.6318V47.2718L50.2665 48.1446V59.4347Z",
    p3d3c3200:
      "M187.999 81.9866L134.044 112.901V124.275L187.999 93.3048V81.9866Z",
    p3d459b80:
      "M25.1473 50.6222V55.4366L29.3432 53.0154V48.2009L25.1473 50.6222Z",
    p3d5ca100:
      "M4.19589 16.9492V21.7637L29.3432 7.23586V2.42138L4.19589 16.9492Z",
    p3d843a80:
      "M53.167 118.475V125.88L59.5876 129.822V122.417L53.167 118.475ZM41.4523 119.151L47.8728 123.093V115.688L41.4523 111.746V119.151ZM6.36426 98.9077L12.7848 102.849V95.4446L6.36426 91.503V98.9077ZM18.0509 105.665L24.4715 109.606V102.202L18.0509 98.2601V105.665ZM29.7656 112.394L36.1862 116.335V108.931L29.7656 104.989V112.394Z",
    p3d9faef0:
      "M198.447 118.053V122.867L184.733 114.618V109.832L198.447 118.053Z",
    p3da22580: "M246.77 90.236V95.0505L233.084 86.8011V82.0148L246.77 90.236Z",
    p3da6200:
      "M17.5 2.33333H7C6.38116 2.33333 5.78767 2.57917 5.35008 3.01675C4.9125 3.45434 4.66667 4.04783 4.66667 4.66667V23.3333C4.66667 23.9522 4.9125 24.5457 5.35008 24.9832C5.78767 25.4208 6.38116 25.6667 7 25.6667H21C21.6188 25.6667 22.2123 25.4208 22.6499 24.9832C23.0875 24.5457 23.3333 23.9522 23.3333 23.3333V8.16667L17.5 2.33333Z",
    p3db98380: "M80.708 0L0 46.1456L107.291 108.171L187.999 61.9123L80.708 0Z",
    p3def9400:
      "M8.36369 2.42131L4.19595 4.81446L1.71208e-05 2.39315L4.19595 0L8.36369 2.42131Z",
    p3e038880:
      "M13.6297 113.351L18.9239 116.589V117.659L12.2216 113.548V88.4622L13.6297 89.3069V113.351Z",
    p3e04dd00: "M0 41.4438V439.214L71.1616 397.742V0L0 41.4438Z",
    p3e078e80:
      "M53.167 202.179V209.584L59.5876 213.526V206.121L53.167 202.179ZM41.4523 202.827L47.8728 206.769V199.364L41.4523 195.422V202.827ZM6.36426 182.612L12.7848 186.553V179.149L6.36426 175.207V182.612ZM18.0509 189.341L24.4715 193.282V185.878L18.0509 181.936V189.341ZM29.7656 196.098L36.1862 200.04V192.635L29.7656 188.693V196.098Z",
    p3e1a6980:
      "M1.40802 50.397L6.70221 53.663V54.7047L0 50.5941V38.2623L1.40802 39.107V50.397Z",
    p3e2c1500: "M25.1473 16.9491V21.7636L0 7.23575V2.44945L25.1473 16.9491Z",
    p3e2d9fc0:
      "M150.095 125.542V130.357L136.409 122.135V117.321L150.095 125.542Z",
    p3e3f42c0:
      "M7.20912 57.126L8.16657 57.9143V103.469L7.20912 102.652V57.126Z",
    p3e55bf00: "M69.6128 80.044V339.856L138.268 299.82V40.0642L69.6128 80.044Z",
    p3e568e80:
      "M202.474 104.398V120.446L206.642 118.025V101.977L202.474 104.398Z",
    p3e5c4740:
      "M25.1473 16.9492V21.7637L29.3432 19.3424V14.5279L25.1473 16.9492Z",
    p3e64f00:
      "M56.49 377.64C56.0112 377.64 55.5325 377.386 55.2791 376.936C54.8848 376.26 55.1383 375.415 55.8141 375.021L122.752 336.928C123.427 336.534 124.272 336.787 124.667 337.463C125.061 338.139 124.807 338.983 124.131 339.377L57.194 377.471C56.9687 377.583 56.7434 377.668 56.49 377.668V377.64Z",
    p3e6f3f30:
      "M2.87237 3.2941V257.869L5.71658 256.236V1.66112L2.87237 3.2941Z",
    p3e84d100: "M25.1473 16.9492V21.7636L0 7.20762V2.42132L25.1473 16.9492Z",
    p3e8cb100: "M4.19589 16.9491V21.7636L0 19.3423V14.5278L4.19589 16.9491Z",
    p3e976500:
      "M90.9303 55.7464V89.5885L104.419 81.8177V48.0602L90.9303 55.7746V55.7464ZM102.87 80.9168L92.4791 86.8856V56.6474L102.87 50.7067V80.9168Z",
    p3eab4e00:
      "M24.247 16.983C24.247 24.2477 19.1617 27.88 13.1175 29.9868C12.801 30.0941 12.4572 30.0889 12.144 29.9723C6.08529 27.88 1 24.2477 1 16.983V6.81241C1 6.42707 1.15308 6.05751 1.42556 5.78503C1.69804 5.51255 2.0676 5.35947 2.45294 5.35947C5.35882 5.35947 8.99117 3.61594 11.5193 1.40748C11.8271 1.14449 12.2187 1 12.6235 1C13.0284 1 13.4199 1.14449 13.7278 1.40748C16.2704 3.63047 19.8882 5.35947 22.7941 5.35947C23.1794 5.35947 23.549 5.51255 23.8215 5.78503C24.094 6.05751 24.247 6.42707 24.247 6.81241V16.983Z",
    p3ecce4f0:
      "M50.2665 269.835L55.5607 273.101V274.143L48.8585 270.032V181.401L50.2665 182.274V269.835Z",
    p3ef4cf80:
      "M104.56 36.0944L103.574 36.8827V82.4371L104.56 81.6206V36.0944Z",
    p3ef5e800:
      "M89.297 25.8742L44.9442 51.6921L0 25.8461L44.4091 0L89.297 25.8742Z",
    p3efbb800:
      "M5.71658 1.66112L2.84422 3.2941L0 1.63294L2.84422 0L5.71658 1.66112Z",
    p3f00900:
      "M9.94066 30.1256V11.0367L6.95565 12.8949V31.9275L9.94066 30.1256Z",
    p3f09a300: "M25.1473 16.9492V21.7636L0 7.20762V2.42131L25.1473 16.9492Z",
    p3f09ed40:
      "M50.0694 81.4236L43.3672 85.5341V110.648L50.0694 106.538V81.4517V81.4236ZM37.8477 88.4623L31.1455 92.5728V117.687L37.8477 113.576V88.4904V88.4623ZM25.6261 95.4728L18.9239 99.5834V124.697L25.6261 120.587V95.5009V95.4728Z",
    p3f0a3580: "M41.1988 45.8923L0 22.2141V14.2463L41.1988 37.9245V45.8923Z",
    p3f0e2000:
      "M187.999 354.694L134.044 385.636V396.982L187.999 366.04V354.694Z",
    p3f1a6a00:
      "M305.372 23.8752V39.9234L301.177 37.5021V21.4539L305.372 23.8752Z",
    p3f2a7900:
      "M1.37678e-06 13.3454L2.98503 15.1755L26.1893 1.83013L23.1761 0L1.37678e-06 13.3454Z",
    p3f2aba00:
      "M29.3432 2.44946L4.1959 16.9492L1.41119e-05 14.556L25.1755 0L29.3432 2.44946Z",
    p3f363170:
      "M6.02634 20.3651C6.02634 14.3119 10.3067 6.96345 15.5728 3.92273C18.2762 2.34607 20.7261 2.26161 22.4721 3.33149L25.3163 4.96447L23.4577 8.11781C23.4577 8.28674 23.4577 8.45565 23.4577 8.65273C23.4577 14.706 19.1773 22.0544 13.9113 25.0951C13.6578 25.2359 13.4325 25.3485 13.1791 25.4611L11.6303 28.0795L9.60273 26.8407C7.40621 26.1087 5.99818 23.8282 5.99818 20.3651H6.02634Z",
    p3f372540:
      "M19.2055 31.9275L16.2204 30.0974L4.75911 36.6294L7.77228 38.4594L19.2055 31.9275Z",
    p3f61f700:
      "M5.68842 1.66112L2.84421 3.2941L0 1.66112L2.84421 0L5.68842 1.66112Z",
    p3f66d730:
      "M53.167 313.728V321.133L59.5876 325.075V317.67L53.167 313.728ZM41.4523 314.404L47.8728 318.346V310.941L41.4523 306.999V314.404ZM6.36426 294.161L12.7848 298.103V290.698L6.36426 286.756V294.161ZM18.0509 300.918L24.4715 304.86V297.455L18.0509 293.513V300.918ZM29.7656 307.647L36.1862 311.589V304.184L29.7656 300.242V307.647Z",
    p3f6ea00:
      "M113.571 30.8295L112.586 31.6178V77.1722L113.571 76.3557V30.8295Z",
    p3f778400: "M0 4.50476L7.77228 0V359.593L0 364.125V4.50476Z",
    p3f804780:
      "M2.87237 3.32229V38.741L5.71658 37.108V1.66112L2.87237 3.32229Z",
    p3f827400:
      "M4.1959 4.84262V624.585L8.36369 622.164V2.42131L4.1959 4.84262Z",
    p3f829200: "M4.19589 16.9492V21.7637L0 19.3424V14.5279L4.19589 16.9492Z",
    p3f84b940:
      "M1.40802 241.68L6.70221 244.946V245.988L0 241.877V153.246L1.40802 154.119V241.68Z",
    p3f890400:
      "M8.64477 16.2895C12.8669 16.2895 16.2895 12.8669 16.2895 8.64477C16.2895 4.42268 12.8669 1 8.64477 1C4.42268 1 1 4.42268 1 8.64477C1 12.8669 4.42268 16.2895 8.64477 16.2895Z",
    p3f987c00:
      "M309.512 21.4539L305.344 23.8752L301.177 21.4539L305.344 19.0326L309.512 21.4539Z",
    p3fd5e780:
      "M8.6171 89.9637C8.6171 85.7404 11.6021 80.6163 15.263 78.4765C17.1497 77.3785 18.8675 77.3222 20.0784 78.0542L22.0497 79.1804L20.7543 81.3765C20.7543 81.3765 20.7543 81.6298 20.7543 81.7425C20.7543 85.9657 17.7693 91.0898 14.1084 93.2296C13.9394 93.3422 13.7705 93.3985 13.6015 93.483L12.5314 95.3131L11.1234 94.4403C9.60272 93.9335 8.6171 92.3286 8.6171 89.9073V89.9637Z",
    p3fe73bc0:
      "M2.87239 3.2941V139.084L1.85061e-05 137.423V1.66112L2.87239 3.2941Z",
    p40a6400: "M122.583 25.5927L121.597 26.381V71.9073L122.583 71.119V25.5927Z",
    p4182b00:
      "M2.95686 15.1754V49.2427L26.1611 35.8973V1.83004L2.95686 15.1754ZM19.0083 31.7586L10.1096 36.8827V19.3142L19.0083 14.19V31.7586Z",
    p41dc580: "M2.84423 3.2941V139.084L5.7166 137.423V1.66112L2.84423 3.2941Z",
    p4370a00:
      "M42.9448 12.4444L21.5991 24.8606L4.10087e-06 12.4444L21.3457 0L42.9448 12.4444Z",
    p443c300: "M4.19593 45.5826V50.3971L0 47.9758V43.1613L4.19593 45.5826Z",
    p44cc900:
      "M5.30317e-06 13.3735L2.95687 15.1754L26.1611 1.85822L23.1761 0L5.30317e-06 13.3735Z",
    p456a100:
      "M37.8477 248.916L31.1737 253.027V164.396L37.8477 160.285V248.916Z",
    p45bd80:
      "M1.82804e-05 2.44946L25.1474 16.9492L29.3432 14.556L4.16776 0L1.82804e-05 2.44946Z",
    p461f000:
      "M53.167 230.053V237.457L59.5876 241.399V233.994L53.167 230.053ZM41.4523 230.728L47.8728 234.67V227.265L41.4523 223.324V230.728ZM6.36426 210.485L12.7848 214.427V207.022L6.36426 203.08V210.485ZM18.0509 217.242L24.4715 221.184V213.779L18.0509 209.837V217.242ZM29.7656 223.971L36.1862 227.913V220.508L29.7656 216.566V223.971Z",
    p4729600:
      "M47.1688 82.1274V96.0077L141.619 41.4156V27.5916L47.1688 82.1274Z",
    p48eebf2: "M141.281 162.791V167.633L0 86.407V81.5643L141.281 162.791Z",
    p49407b0:
      "M7.23727 33.3071L10.3631 31.3925L22.3031 38.206L19.1773 40.1205L7.23727 33.3071Z",
    p4a2be80: "M77.554 187.651V192.466L63.8398 184.217V179.43L77.554 187.651Z",
    p4ade000:
      "M27.2875 411.651V58.2803L82.3976 26.0713V4.05429L6.98379 48.0883V423.476L27.3438 411.679L27.2875 411.651Z",
    p4b04980:
      "M77.5822 27.7043L42.2971 48.2572L6.53321 27.6761L41.8747 7.09499L77.5822 27.7043Z",
    p4cb1700: "M4.19593 16.9492V21.7636L0 19.3423V14.5278L4.19593 16.9492Z",
    p4e93200:
      "M294.981 61.9686V66.7831L281.267 58.5337V53.7474L294.981 61.9686Z",
    p4e9fe00:
      "M130.073 21.5384L37.7632 75.1451V120.671L130.073 67.0646V21.5384Z",
    p4eb7300:
      "M588.751 696.661C588.273 696.661 587.794 696.408 587.512 695.929C587.146 695.254 587.372 694.381 588.047 694.015L592.975 691.256C593.651 690.89 594.524 691.115 594.89 691.791C595.256 692.466 595.031 693.339 594.355 693.705L589.427 696.464C589.202 696.577 588.977 696.633 588.751 696.633V696.661ZM601.058 689.791C600.579 689.791 600.1 689.538 599.818 689.06C599.452 688.384 599.678 687.511 600.354 687.145L605.282 684.386C605.957 684.02 606.802 684.245 607.197 684.921C607.563 685.596 607.337 686.469 606.661 686.835L601.733 689.594C601.508 689.707 601.283 689.763 601.058 689.763V689.791ZM613.336 682.894C612.857 682.894 612.378 682.64 612.096 682.162C611.73 681.486 611.956 680.613 612.632 680.247L617.56 677.488C618.235 677.122 619.08 677.347 619.474 678.023C619.841 678.699 619.615 679.571 618.939 679.937L614.011 682.697C613.786 682.809 613.561 682.865 613.336 682.865V682.894ZM625.613 676.024C625.135 676.024 624.656 675.77 624.374 675.292C624.008 674.616 624.234 673.743 624.909 673.377L629.838 670.618C630.513 670.252 631.358 670.477 631.752 671.153C632.119 671.829 631.893 672.702 631.217 673.068L626.289 675.827C626.064 675.939 625.839 675.996 625.613 675.996V676.024ZM637.92 669.154C637.441 669.154 636.962 668.901 636.681 668.422C636.314 667.746 636.54 666.874 637.216 666.508L642.144 663.748C642.82 663.382 643.693 663.608 644.059 664.283C644.425 664.959 644.199 665.832 643.524 666.198L638.595 668.957C638.37 669.07 638.145 669.126 637.92 669.126V669.154ZM650.198 662.284C649.719 662.284 649.24 662.031 648.959 661.552C648.592 660.877 648.818 660.004 649.494 659.638L654.422 656.879C655.098 656.513 655.942 656.738 656.337 657.414C656.703 658.089 656.477 658.934 655.802 659.328L650.873 662.087C650.648 662.2 650.423 662.256 650.198 662.256V662.284ZM662.476 655.415C661.997 655.415 661.518 655.161 661.237 654.682C660.87 654.007 661.096 653.134 661.772 652.768L666.7 650.009C667.376 649.643 668.248 649.868 668.615 650.544C668.981 651.22 668.755 652.092 668.08 652.458L663.151 655.217C662.926 655.33 662.701 655.386 662.476 655.386V655.415ZM674.782 648.517C674.303 648.517 673.824 648.263 673.543 647.785C673.177 647.109 673.402 646.236 674.078 645.87L679.006 643.111C679.682 642.745 680.526 642.97 680.921 643.646C681.287 644.322 681.062 645.194 680.386 645.56L675.458 648.32C675.232 648.432 675.007 648.488 674.782 648.488V648.517ZM687.06 641.647C686.581 641.647 686.102 641.393 685.821 640.915C685.455 640.239 685.68 639.395 686.356 639L691.284 636.241C691.96 635.875 692.833 636.1 693.199 636.776C693.565 637.452 693.339 638.325 692.664 638.691L687.736 641.45C687.51 641.562 687.285 641.619 687.06 641.619V641.647ZM699.338 634.777C698.859 634.777 698.38 634.524 698.099 634.045C697.733 633.369 697.958 632.497 698.634 632.131L703.562 629.371C704.238 629.005 705.082 629.231 705.477 629.906C705.843 630.582 705.617 631.455 704.942 631.821L700.014 634.58C699.788 634.693 699.563 634.749 699.338 634.749V634.777ZM711.644 627.907C711.165 627.907 710.686 627.654 710.405 627.175C710.039 626.5 710.264 625.627 710.94 625.261L715.868 622.502C716.544 622.136 717.417 622.361 717.783 623.037C718.149 623.712 717.924 624.585 717.248 624.951L712.32 627.71C712.094 627.823 711.869 627.879 711.644 627.879V627.907Z",
    p4f13e80:
      "M141.197 162.791V167.633L282.309 86.0409V81.3109L141.197 162.791Z",
    p4f8a000:
      "M6.95564 31.9275L9.94065 30.1255L21.402 36.6294L18.3888 38.4594L6.95564 31.9275Z",
    p50c0a00:
      "M25.1473 50.5941V55.4086L29.3432 52.9872V48.1728L25.1473 50.5941Z",
    p50fd780:
      "M18.9521 92.4321L24.4434 89.0535V71.4568L25.6261 70.7247V89.4476L18.9521 93.5583V92.4321Z",
    p53cec00: "M0 4.53292L7.77232 0V359.593L0 364.125V4.53292Z",
    p55714f0:
      "M182.536 116.167L178.369 118.56L174.173 116.138L178.369 113.717L182.536 116.167Z",
    p5593400:
      "M26.1611 13.3454L23.1761 15.1754L3.32378e-06 1.83004L2.98501 0L26.1611 13.3454Z",
    p55a5d00:
      "M187.999 241.061L134.044 272.003V283.349L187.999 252.407V241.061Z",
    p55b4d00: "M70.9644 81.677L70.0351 81.1702V450.898L70.9644 451.405V81.677Z",
    p5625400:
      "M334.181 23.1714L4.19592 214.342L0 211.921L330.013 20.7219L334.181 23.1714Z",
    p5669f00:
      "M25.1473 16.9492V21.7636L29.3432 19.3423V14.5279L25.1473 16.9492Z",
    p5690ab0:
      "M2.87237 3.32224V257.898L5.71658 256.236V1.66112L2.87237 3.32224Z",
    p576f680:
      "M810.572 298.806L819.358 302.044L815.19 288.643L810.572 298.806Z",
    p58595b0:
      "M17.7441 40.0172V16.2335C17.7441 15.5326 18.0226 14.8604 18.5182 14.3648C19.0137 13.8692 19.6859 13.5908 20.3868 13.5908H30.9573C31.6582 13.5908 32.3304 13.8692 32.8259 14.3648C33.3215 14.8604 33.6 15.5326 33.6 16.2335V40.0172H17.7441Z",
    p59a7780: "M77.554 187.651V192.466L81.7499 190.045V185.23L77.554 187.651Z",
    p5acb400:
      "M1.27633e-05 399.516L107.292 461.879V108.171L1.27633e-05 46.1456V399.516Z",
    p5ca5880:
      "M2.87238 3.32224V38.7409L4.62374e-06 37.1079V1.66112L2.87238 3.32224Z",
    p5dc8380:
      "M112.304 135.931V151.979L116.472 149.558V133.51L112.304 135.931Z",
    p5e1aa80:
      "M138.747 48.0321L69.8381 88.1526L3.65711e-05 47.9757L68.9932 7.7989L138.747 48.0321Z",
    p5e32e00: "M2.8724 3.32229V139.085L5.71661 137.423V1.66117L2.8724 3.32229Z",
    p5f37d00:
      "M136.409 117.321L150.095 125.542L154.291 123.121L140.549 114.9L136.409 117.321Z",
    p5f56200:
      "M2.87238 3.32224V38.7409L5.71659 37.1079V1.66112L2.87238 3.32224Z",
    p5f87d00:
      "M2.87237 3.29411V38.7409L5.71658 37.0798V1.66112L2.87237 3.29411Z",
    p5fdf500:
      "M1.85288e-07 1.9145V37.4176L24.1899 51.3261V15.823L1.85288e-07 1.9145ZM16.7555 38.4312L7.46254 33.1099V14.8093L16.7555 20.1306V38.4312Z",
    p5fe6200: "M2.98503 15.1754V49.2145L0 47.3844V13.3453L2.98503 15.1754Z",
    p620cb00: "M187.999 363.45L134.044 394.392V396.982L187.999 366.04V363.45Z",
    p6298e00:
      "M6.95566 31.9275L9.94067 30.1255L21.402 36.6294L18.3888 38.4875L6.95566 31.9275Z",
    p62f7900:
      "M2.84421 3.29414V138.916L5.68842 137.254V1.66116L2.84421 3.29414Z",
    p6356e00: "M2.87236 3.2941V139.084L0 137.423V1.63298L2.87236 3.2941Z",
    p649ff00:
      "M25.1473 50.6223V55.4368L29.3432 53.0154V48.201L25.1473 50.6223Z",
    p65cb2c0:
      "M61.4181 35.2498C58.9681 36.6575 54.9975 36.6575 52.5193 35.2498C50.0694 33.842 50.0412 31.5333 52.5193 30.1256C54.9693 28.7179 58.9399 28.7179 61.4181 30.1256C63.868 31.5333 63.8962 33.842 61.4181 35.2498Z",
    p663e280:
      "M112.304 151.81L126.018 160.032L130.186 157.61L116.472 149.389L112.304 151.81Z",
    p6713500:
      "M5.67378e-07 418.83L7.01194 423.476V48.0883L5.67378e-07 43.9214V418.83Z",
    p6740500: "M47.2252 82.1274V96.0077L0 68.5005V54.6202L47.2252 82.1274Z",
    p675540:
      "M112.191 196.408C111.403 196.408 110.783 195.788 110.783 195V189.369C110.783 188.581 111.403 187.961 112.191 187.961C112.98 187.961 113.599 188.581 113.599 189.369V195C113.599 195.788 112.98 196.408 112.191 196.408ZM112.191 182.33C111.403 182.33 110.783 181.711 110.783 180.922V175.292C110.783 174.503 111.403 173.884 112.191 173.884C112.98 173.884 113.599 174.503 113.599 175.292V180.922C113.599 181.711 112.98 182.33 112.191 182.33ZM112.191 168.253C111.403 168.253 110.783 167.633 110.783 166.845V161.186C110.783 160.398 111.487 159.75 112.22 159.806C113.008 159.806 113.628 160.454 113.599 161.242V166.845C113.599 167.633 112.952 168.253 112.191 168.253ZM112.614 154.175C112.614 154.175 112.529 154.175 112.501 154.175C111.713 154.119 111.149 153.443 111.206 152.655C111.347 150.769 111.544 148.882 111.797 146.996C111.91 146.236 112.614 145.701 113.374 145.785C114.134 145.898 114.698 146.602 114.585 147.362C114.36 149.192 114.163 151.05 114.022 152.88C113.966 153.612 113.346 154.175 112.614 154.175ZM114.557 140.239C114.557 140.239 114.388 140.239 114.275 140.239C113.515 140.098 113.008 139.338 113.177 138.578C113.543 136.72 113.966 134.861 114.416 133.031C114.585 132.271 115.345 131.821 116.106 131.99C116.866 132.187 117.317 132.947 117.148 133.679C116.697 135.481 116.303 137.283 115.937 139.113C115.796 139.788 115.205 140.239 114.557 140.239ZM118.049 126.64C118.049 126.64 117.767 126.64 117.626 126.584C116.894 126.359 116.472 125.57 116.697 124.81C117.26 123.008 117.88 121.206 118.556 119.432C118.809 118.7 119.654 118.334 120.358 118.588C121.09 118.869 121.456 119.658 121.203 120.39C120.555 122.135 119.964 123.881 119.4 125.655C119.203 126.246 118.668 126.64 118.049 126.64ZM123.061 113.492C122.864 113.492 122.667 113.464 122.498 113.379C121.794 113.07 121.456 112.225 121.794 111.521C122.583 109.775 123.371 108.058 124.244 106.369C124.582 105.665 125.427 105.411 126.131 105.749C126.835 106.087 127.116 106.96 126.75 107.636C125.906 109.297 125.117 110.958 124.357 112.675C124.131 113.21 123.596 113.52 123.061 113.52V113.492ZM129.51 100.991C129.257 100.991 129.031 100.935 128.806 100.794C128.13 100.4 127.905 99.5271 128.299 98.8514C129.257 97.2184 130.27 95.6136 131.312 94.0088C131.735 93.3612 132.608 93.1923 133.255 93.6146C133.903 94.0369 134.1 94.9097 133.65 95.5573C132.636 97.1058 131.65 98.6824 130.721 100.287C130.468 100.738 129.989 100.991 129.51 100.991ZM137.339 89.3069C137.029 89.3069 136.747 89.2224 136.494 89.0254C135.874 88.5467 135.762 87.6739 136.212 87.0545C137.367 85.5342 138.55 84.042 139.761 82.5779C140.267 81.9867 141.14 81.9022 141.732 82.3808C142.323 82.8876 142.408 83.7604 141.929 84.3517C140.746 85.7876 139.592 87.2235 138.465 88.7157C138.184 89.0817 137.761 89.2788 137.339 89.2788V89.3069ZM146.463 78.5799C146.125 78.5799 145.759 78.4392 145.505 78.1858C144.942 77.6508 144.914 76.7499 145.449 76.1868C146.744 74.8072 148.096 73.4558 149.476 72.1325C150.039 71.5976 150.94 71.6257 151.475 72.1607C152.01 72.7237 152.01 73.6247 151.447 74.1596C150.095 75.4548 148.8 76.778 147.505 78.1013C147.223 78.3829 146.857 78.5518 146.491 78.5518L146.463 78.5799ZM156.713 68.951C156.319 68.951 155.896 68.7821 155.643 68.4442C155.136 67.853 155.221 66.952 155.812 66.4734C157.276 65.2627 158.741 64.0802 160.261 62.9259C160.881 62.4473 161.754 62.5599 162.233 63.1793C162.711 63.7987 162.571 64.6715 161.979 65.1501C160.487 66.2763 159.05 67.4307 157.614 68.6413C157.361 68.8665 157.023 68.9792 156.713 68.9792V68.951ZM168.005 60.5327C167.555 60.5327 167.104 60.3075 166.823 59.9133C166.4 59.2658 166.569 58.393 167.217 57.9707C168.794 56.9289 170.399 55.9154 172.032 54.9299C172.68 54.5358 173.553 54.7329 173.976 55.4086C174.37 56.0843 174.173 56.9289 173.497 57.3513C171.892 58.3085 170.315 59.2939 168.766 60.3075C168.541 60.4764 168.259 60.5327 167.977 60.5327H168.005ZM180.115 53.3533C179.636 53.3533 179.157 53.0999 178.875 52.6494C178.481 51.9737 178.735 51.1009 179.41 50.7349L184.31 47.9757C184.986 47.5815 185.831 47.8349 186.225 48.5107C186.62 49.1864 186.366 50.0592 185.69 50.4252L180.79 53.1844C180.565 53.297 180.34 53.3533 180.086 53.3533H180.115ZM192.392 46.4554C191.914 46.4554 191.435 46.202 191.153 45.7515C190.759 45.0758 191.013 44.203 191.688 43.837L196.588 41.0778C197.264 40.6836 198.109 40.937 198.503 41.6127C198.898 42.2885 198.644 43.1613 197.968 43.5273L193.068 46.2864C192.843 46.3991 192.618 46.4554 192.364 46.4554H192.392ZM204.67 39.5574C204.192 39.5574 203.713 39.3041 203.431 38.8536C203.037 38.1779 203.291 37.3051 203.966 36.9391L208.866 34.1799C209.542 33.7857 210.387 34.0391 210.781 34.7148C211.176 35.3905 210.922 36.2633 210.246 36.6294L205.346 39.3885C205.121 39.5011 204.896 39.5574 204.642 39.5574H204.67ZM216.92 32.6314C216.442 32.6314 215.963 32.378 215.681 31.9275C215.287 31.2518 215.54 30.379 216.216 30.013L221.116 27.2538C221.792 26.8596 222.637 27.113 223.031 27.7888C223.425 28.4645 223.172 29.3373 222.496 29.7033L217.596 32.4624C217.371 32.5751 217.146 32.6314 216.892 32.6314H216.92ZM229.198 25.7335C228.72 25.7335 228.241 25.4801 227.959 25.0296C227.565 24.3539 227.818 23.4811 228.494 23.1151L233.394 20.3559C234.07 19.9617 234.915 20.2151 235.309 20.8908C235.703 21.5666 235.45 22.4394 234.774 22.8054L229.874 25.5645C229.649 25.6772 229.424 25.7335 229.17 25.7335H229.198Z",
    p6794900:
      "M132.495 38.4031L66.684 76.6936L0 38.3468L65.8674 0L132.495 38.4031Z",
    p69bd100:
      "M9.94065 30.1255V11.0366L6.95564 12.8667V31.9275L9.94065 30.1255Z",
    p6a42600:
      "M136.409 122.135V138.184L132.214 135.762V119.714L136.409 122.135Z",
    p6a49b00: "M2.98503 15.1754V49.2427L0 47.4127V13.3454L2.98503 15.1754Z",
    p6b0c300:
      "M82.0315 49.2427L81.0741 50.031V95.5854L82.0315 94.7689V49.2427Z",
    p6cc1de0:
      "M92.1411 2.11162L2.92872 53.8601L4.08331 54.3668L93.2957 2.56211L92.1411 2.11162Z",
    p6d52180: "M2.87237 3.2941V38.741L5.71658 37.0798V1.66112L2.87237 3.2941Z",
    p6eee700:
      "M164.795 105.693L160.627 108.114L156.46 105.693L160.627 103.272L164.795 105.693Z",
    p704c00:
      "M18.9521 48.5388L24.4434 45.1602V33.9264L25.6261 33.1944V45.5544L18.9521 49.665V48.5388Z",
    p70aabf0: "M246.77 69.5422V74.3567L250.966 71.9354V67.1209L246.77 69.5422Z",
    p710ce00:
      "M40.9172 193.113L21.7681 225.013L25.9358 222.591L45.085 190.72L40.9172 193.113Z",
    p7227f0:
      "M4.19594 11.1493V15.9637L18.7831 7.23577V2.44946L4.19594 11.1493Z",
    p75bcc00:
      "M4.19589 16.9491V21.7636L29.3432 7.23573V2.42127L4.19589 16.9491Z",
    p76ab400:
      "M53.3078 201.673V206.487L57.5037 204.066V199.251L53.3078 201.673Z",
    p77f4400:
      "M0.203612 0.456664C14.5841 6.86845 62.2036 13.9567 91.2036 0.456664",
    p788e900:
      "M16.2204 30.1256V11.0367L19.2055 12.8949V31.9275L16.2204 30.1256Z",
    p79a3400: "M109.882 33.0537L108.897 33.842V79.3965L109.882 78.608V33.0537Z",
    p7ae3500:
      "M281.267 33.0537L294.981 41.2749L299.149 38.8536L285.435 30.6042L281.267 33.0537Z",
    p7b51400:
      "M18.9521 29.3935L24.4434 26.015V14.8094L25.6261 14.0774V26.4091L18.9521 30.5197V29.3935Z",
    p7bd6e80:
      "M4.19593 16.9773V21.7918L29.3432 7.23577V2.44945L4.19593 16.9773Z",
    p7c75800:
      "M275.044 62.5599V78.6081L279.211 76.1868V60.1386L275.044 62.5599Z",
    p7c7b700:
      "M100.871 38.3186L99.8853 39.107V84.6614L100.871 83.8449V38.3186Z",
    p7d34880: "M4.19593 11.1493V15.9637L0 13.5424V8.72797L4.19593 11.1493Z",
    p7ea8d00: "M0 98.9077L37.7914 120.671V117.997L0 96.4019V98.9077Z",
    p7f4d0c0:
      "M2.87238 3.2941V257.869L6.43306e-06 256.236V1.66112L2.87238 3.2941Z",
    p7f67f00:
      "M9.94065 30.0974V11.0367L6.95565 12.8667V31.9276L9.94065 30.0974Z",
    p8068c00: "M4.22407 4.81446V334.732L0 332.311V2.39315L4.22407 4.81446Z",
    p8082e00:
      "M73.0202 54.4794L72.0627 55.2678V100.822L73.0202 100.034V54.4794Z",
    p8177d00:
      "M105.799 160.398V176.446L109.967 174.025V158.004L105.799 160.398Z",
    p818b5c0:
      "M0 1.83004V35.8973L23.2042 49.2427V15.1754L0 1.83004ZM16.0515 36.8827L7.15276 31.7586V14.19L16.0515 19.3142V36.8827Z",
    p828e800:
      "M57.3348 188.017V204.066L61.5025 201.644V185.596L57.3348 188.017Z",
    p8371900:
      "M174.342 132.215V137.029L178.538 134.608V129.793L174.342 132.215Z",
    p83e1200: "M24.1899 15.823V51.3543L27.2875 49.4397V13.9366L24.1899 15.823Z",
    p846200: "M187.999 218.34L134.044 249.254V260.629L187.999 229.686V218.34Z",
    p86e8180: "M19.9095 64.587L20.8669 65.3754V110.93L19.9095 110.141V64.587Z",
    p8733ff0:
      "M5.71658 1.66112L2.87238 3.2941L5.49154e-06 1.66112L2.87238 0L5.71658 1.66112Z",
    p8784a00: "M0 13.3453L2.95684 15.1754L26.1611 1.83004L23.1761 0L0 13.3453Z",
    p87ecf00:
      "M2.95684 15.1754V49.2426L1.37991e-06 47.3844V13.3453L2.95684 15.1754Z",
    p88b7b40:
      "M25.1473 50.5941V55.4086L29.3432 53.0154V48.201L25.1473 50.5941Z",
    p8ae3b00:
      "M16.2204 30.0974V11.0367L19.2055 12.8667V31.9275L16.2204 30.0974Z",
    p8cdbf80: "M0 13.3735L2.98501 15.1754L26.1893 1.85822L23.1761 0L0 13.3735Z",
    p8d0e620:
      "M294.953 41.2749V46.0893L299.149 43.668V38.8536L294.953 41.2749Z",
    p8dd83d0:
      "M16.2205 30.1256V11.0367L19.2055 12.8948V31.9275L16.2205 30.1256Z",
    p8f00200:
      "M19.2055 31.9275L16.2486 30.0974L4.75913 36.6293L7.7723 38.4593L19.2055 31.9275Z",
    p8fc7000:
      "M43.3672 78.3547L48.8867 74.9761V57.3794L50.0694 56.6474V75.3702L43.3672 79.4809V78.3547Z",
    p91e8500:
      "M1.41119e-05 2.42131L25.1473 50.6223L29.3432 48.201L4.16776 0L1.41119e-05 2.42131Z",
    p93096f0:
      "M92.5072 56.6474L102.87 50.7067V80.9168L92.5072 86.8855V56.6474Z",
    p937780: "M628.148 652.74L638.201 656.541L645.495 647.869L628.148 652.74Z",
    p93a9f00: "M25.1473 50.6223V55.4367L0 7.23581V2.42133L25.1473 50.6223Z",
    p94bb00:
      "M5.71658 1.66112L2.84422 3.32224L3.28376e-06 1.66112L2.84422 0L5.71658 1.66112Z",
    p94fbc00: "M127.877 22.552L126.919 23.3403V68.8947L127.877 68.0782V22.552Z",
    p95a4a80:
      "M118.077 28.2111L117.091 28.9994V74.5538L118.077 73.7373V28.2111Z",
    p9697c00: "M2.87237 3.2941V139.085L5.71658 137.423V1.66112L2.87237 3.2941Z",
    p97f2380:
      "M198.419 97.3591V102.174L202.643 99.7523V94.9378L198.419 97.3591Z",
    p9802b00:
      "M4.19589 16.9492V21.7637L29.3432 7.23581V2.42133L4.19589 16.9492Z",
    p9841c00:
      "M0 1.83V35.8973L23.2042 49.2426V15.1754L0 1.83ZM16.0515 36.8827L7.15277 31.7585V14.1899L16.0515 19.3141V36.8827Z",
    p98bc300:
      "M18.783 2.44946L4.19593 11.1493L0 8.72798L14.6153 0L18.783 2.44946Z",
    p9ab6e10:
      "M25.1473 16.9492V21.7636L29.3432 19.3423V14.5278L25.1473 16.9492Z",
    p9b71b00:
      "M160.656 108.114V124.162L156.46 121.741V105.693L160.656 108.114Z",
    p9c98680: "M2.87238 3.2941V257.869L0 256.208V1.63298L2.87238 3.2941Z",
    p9cf0e40: "M0 98.9077L37.7914 120.671V75.1451L0 53.5222V98.9077Z",
    p9cf1500:
      "M1.41119e-05 2.44945L25.1473 50.6222L29.3432 48.2009L4.16776 0L1.41119e-05 2.44945Z",
    p9ebd200:
      "M29.3432 2.42131L4.19595 16.9492L1.82804e-05 14.5279L25.1755 0L29.3432 2.42131Z",
    p9efe330:
      "M4.19593 4.84262V641.028L8.36367 638.606V2.42131L4.19593 4.84262Z",
    pa007420:
      "M2.87238 3.32229V139.084L2.0644e-05 137.452V1.66117L2.87238 3.32229Z",
    pa015f80:
      "M91.0429 43.9777L90.0854 44.7661V90.3204L91.0429 89.504V43.9777Z",
    pa04ceb0:
      "M2.46328e-07 1.85823V35.9255L23.2043 49.2708V15.2036L2.46328e-07 1.85823ZM16.0515 36.8828L7.15277 31.7586V14.19L16.0515 19.3142V36.8828Z",
    pa06c400: "M30.9765 58.759L30.0472 58.2804V428.009L30.9765 428.515V58.759Z",
    pa0a5600: "M0 41.4438V58.3085L71.1616 16.8084V0L0 41.4438Z",
    pa15eec0:
      "M51.1113 52.0863C51.1113 54.7328 49.2246 55.8027 46.9154 54.4795C44.6062 53.1562 42.7195 49.9184 42.7195 47.2718C42.7195 44.6253 44.6062 43.5554 46.9154 44.8787C49.2246 46.202 51.1113 49.4398 51.1113 52.0863Z",
    pa23be00:
      "M0 1.83005V35.8973L23.2042 49.2427V15.1754L0 1.83005ZM16.0515 36.8827L7.15277 31.7586V14.19L16.0515 19.3142V36.8827Z",
    pa483a00:
      "M2.87237 3.32224V38.7409L5.71658 37.0798V1.66112L2.87237 3.32224Z",
    pa5badf0:
      "M29.3432 2.42131L4.19595 16.9491L1.82804e-05 14.5278L25.1755 0L29.3432 2.42131Z",
    pa668f00: "M87.3539 46.202L86.3683 46.9903V92.5447L87.3539 91.7282V46.202Z",
    pa799980: "M4.19593 45.5544V50.3689L0 47.9475V43.1331L4.19593 45.5544Z",
    pa7c7e00:
      "M65.3887 31.6459L41.1707 45.8923V37.8963L65.3887 23.6782V31.6459Z",
    pa8a0100: "M25.1473 50.6223V55.4368L0 7.23584V2.44954L25.1473 50.6223Z",
    pa924e70:
      "M21.386 15.325C21.386 21.8362 16.9266 25.0917 11.6262 26.9799C11.3487 27.0761 11.0472 27.0715 10.7726 26.9669C5.45945 25.0917 1 21.8362 1 15.325V6.20948C1 5.86411 1.13424 5.53288 1.37318 5.28867C1.61213 5.04446 1.93621 4.90726 2.27413 4.90726C4.82238 4.90726 8.0077 3.34459 10.2247 1.36521C10.4946 1.1295 10.838 1 11.193 1C11.5481 1 11.8914 1.1295 12.1614 1.36521C14.3911 3.35761 17.5637 4.90726 20.1119 4.90726C20.4498 4.90726 20.7739 5.04446 21.0129 5.28867C21.2518 5.53288 21.386 5.86411 21.386 6.20948V15.325Z",
    pa971340: "M25.1473 16.9492V21.7636L0 7.20763V2.42132L25.1473 16.9492Z",
    paba8600:
      "M21.8807 224.844V229.658L17.6848 227.237V222.423L21.8807 224.844Z",
    pace4f00:
      "M50.4918 67.6277L49.5343 68.4161V113.97L50.4918 113.154V67.6277Z",
    padc200: "M25.1473 16.9492V21.7637L0 7.2358V2.42136L25.1473 16.9492Z",
    pae94800:
      "M69.8662 84.4643L1.83045 45.3573V39.0788L69.8662 78.214V84.4643Z",
    pb108600:
      "M237.224 63.7142L233.084 66.1074L228.888 63.6861L233.084 61.2929L237.224 63.7142Z",
    pb161cf0:
      "M25.8232 45.3573L31.1455 48.5951V49.665L24.4433 45.5544V33.1944L25.8232 34.0672V45.3573Z",
    pb189b00:
      "M19.2055 31.9275L16.2205 30.1256L4.75913 36.6294L7.7723 38.4876L19.2055 31.9275Z",
    pb2fe80: "M174.342 111.521V116.335L160.627 108.114V103.3L174.342 111.521Z",
    pb465bc0: "M10.5 17.5L12.8333 19.8333L17.5 15.1667",
    pb5b2400:
      "M29.3432 2.44947L4.19595 16.9492L1.82804e-05 14.5279L25.1755 0L29.3432 2.44947Z",
    pb716e00:
      "M61.5025 185.596L57.3348 188.017L53.1389 185.596L57.3348 183.175L61.5025 185.596Z",
    pb7c1400: "M2.98501 15.1754V49.2426L0 47.4126V13.3453L2.98501 15.1754Z",
    pb7ffe00: "M141.281 162.819V183.569L0 102.343V81.5925L141.281 162.819Z",
    pb80c440: "M2.84421 3.2941V38.7409L0 37.0798V1.63298L2.84421 3.2941Z",
    pb8b0000:
      "M305.344 23.8752V39.9234L309.512 37.5021V21.4539L305.344 23.8752Z",
    pbba0380:
      "M26.668 59.5755C24.218 60.9832 20.2474 60.9832 17.7693 59.5755C15.3193 58.1677 15.2912 55.859 17.7693 54.4513C20.2193 53.0436 24.1899 53.0436 26.668 54.4513C29.118 55.859 29.1461 58.1677 26.668 59.5755Z",
    pbc06d00: "M54.9693 72.4985L54.04 72.0199V441.748L54.9693 442.227V72.4985Z",
    pbc3e900:
      "M136.916 39.1351L69.8381 78.214L1.83045 39.0788L68.9932 1.62862e-05L136.916 39.1351Z",
    pbc49380:
      "M184.733 93.9243V109.972L188.901 107.551V91.5311L184.733 93.9243Z",
    pbed1c00:
      "M184.733 109.832L198.447 118.053L202.643 115.632L188.901 107.382L184.733 109.832Z",
    pbf97ce0: "M10.3349 0V33.2789L0 27.3383L10.3349 0Z",
    pbfe8c00:
      "M2.87237 3.29411V38.7409L5.78178e-06 37.0798V1.66112L2.87237 3.29411Z",
    pc02da00:
      "M2.87237 3.32225V38.7409L5.78178e-06 37.0798V1.66112L2.87237 3.32225Z",
    pc0cf280:
      "M48.8867 241.483V153.978L50.0694 153.246V241.877L43.3672 245.988V244.862L48.8867 241.483Z",
    pc149f30:
      "M14.1366 60.1667L15.2912 60.6735L104.504 8.86874L103.321 8.41826L14.1366 60.1667Z",
    pc14c500:
      "M125.737 21.0316L36.5242 72.7801L37.6788 73.2868L126.891 21.4821L125.737 21.0316Z",
    pc2b8700: "M226.72 90.3768V106.425L230.888 104.004V87.9555L226.72 90.3768Z",
    pc344500:
      "M6.95564 31.9275L9.94065 30.0974L21.402 36.6294L18.417 38.4594L6.95564 31.9275Z",
    pc3b3b00:
      "M126.469 203.08L120.048 207.022V214.427L126.469 210.485V203.08ZM114.754 209.837L108.333 213.779V221.184L114.754 217.242V209.837ZM103.067 216.566L96.6468 220.508V227.913L103.067 223.971V216.566ZM73.2454 233.994V241.399L79.666 237.457V230.053L73.2454 233.994ZM91.3526 223.324L84.9321 227.265V234.67L91.3526 230.728V223.324Z",
    pc3c3380:
      "M5.71658 1.66112L2.84422 3.2941L3.23333e-06 1.63298L2.84422 0L5.71658 1.66112Z",
    pc3fdb00:
      "M1.82013e-07 13.3454L2.95686 15.1754L26.1611 1.83008L23.1479 0L1.82013e-07 13.3454Z",
    pc45ee00:
      "M351.499 17.9064L347.331 20.2996L343.136 17.9064L347.331 15.4851L351.499 17.9064Z",
    pc563000: "M14.9532 419.14L74.1747 453.517V83.2818L14.9532 49.3271V419.14Z",
    pc722900:
      "M0 1.83005V35.8973L23.2042 49.2427V15.1754L0 1.83005ZM16.0515 36.8828L7.15277 31.7586V14.19L16.0515 19.3141V36.8828Z",
    pc776700:
      "M4.19615 45.5936V50.408L0.00022586 47.9867V43.1723L4.19615 45.5936Z",
    pc77aa40:
      "M1.23906 17.7467C1.23906 11.6935 5.51945 4.34506 10.7855 1.30434C13.4889 -0.272325 15.9388 -0.356787 17.6848 0.713094L20.529 2.34608L18.6704 5.49942C18.6704 5.66834 18.6704 5.83726 18.6704 6.03434C18.6704 12.0876 14.39 19.436 9.12399 22.4767C8.87055 22.6175 8.64527 22.7301 8.39183 22.8427L6.84299 25.4611L4.81544 24.2223C2.61892 23.4903 1.21089 21.2098 1.21089 17.7467H1.23906Z",
    pc804e00:
      "M19.2055 31.9275L16.2486 30.0974L4.75913 36.6293L7.7723 38.4594L19.2055 31.9275Z",
    pc83fa00:
      "M206.642 101.977L202.474 104.398L198.278 101.977L202.474 99.5552L206.642 101.977Z",
    pc89f000:
      "M271.017 55.5212V60.3356L275.213 57.9143V53.0999L271.017 55.5212Z",
    pc987e80:
      "M9.94065 30.0974V11.0366L6.95564 12.8667V31.9275L9.94065 30.0974Z",
    pca45c00:
      "M53.3078 201.673V206.487L39.5937 198.238V193.451L53.3078 201.673Z",
    pcac8500:
      "M4.19593 45.5825V50.397L29.3432 7.23577V2.44943L4.19593 45.5825Z",
    pcb29c80: "M125.99 139.338V144.152L130.186 141.731V136.917L125.99 139.338Z",
    pcb83780:
      "M5.68842 1.66112L2.84421 3.32224L0 1.66112L2.84421 0L5.68842 1.66112Z",
    pcc779a8: "M2.84422 3.2941V38.741L5.68843 37.0798V1.66116L2.84422 3.2941Z",
    pcc88e80:
      "M0 1.91459V37.4177L24.1899 51.3262V15.823L0 1.91459ZM16.7273 38.4594L7.43437 33.1382V14.8376L16.7273 20.1588V38.4594Z",
    pccadf80:
      "M91.8596 43.5836L90.8739 44.3719V89.9263L91.8596 89.1098V43.5836Z",
    pcd0eb80:
      "M13.6297 151.923L18.9239 155.189V156.231L12.2216 152.12V120.643L13.6297 121.516V151.923Z",
    pcf1780:
      "M141.197 162.819V183.569L282.309 101.976V81.3109L141.197 162.819Z",
    pcf5eb00:
      "M64.8255 59.3502L63.8399 60.1386V105.693L64.8255 104.876V59.3502Z",
    pcfdb680:
      "M18.9521 162.143L24.4434 158.765V128.414L25.6261 127.682V159.159L18.9521 163.269V162.143Z",
    pcffd080:
      "M23.2043 15.1754V49.2426L26.1611 47.4126V13.3735L23.2043 15.1754Z",
    pd0c71f0:
      "M36.665 248.522V161.017L37.8477 160.285V248.916L31.1737 253.027V251.901L36.665 248.522Z",
    pd0c8370:
      "M23.2043 15.1755V49.2426L26.1611 47.4126V13.3735L23.2043 15.1755Z",
    pd15d680:
      "M23.1761 15.1754V49.2427L26.1611 47.4127V13.3454L23.1761 15.1754Z",
    pd16a300:
      "M2.84422 3.32228V257.898L5.68843 256.236V1.66116L2.84422 3.32228Z",
    pd2a1570:
      "M43.3672 148.066L48.8867 144.687V114.336L50.0694 113.604V145.081L43.3672 149.192V148.066Z",
    pd59e80:
      "M23.2606 2.42131L4.19593 34.1236L0 31.7023L19.0647 0L23.2606 2.42131Z",
    pd5bbd00: "M96.3652 40.937L95.3796 41.7253V87.2797L96.3652 86.4914V40.937Z",
    pd61cf80:
      "M257.302 47.3L271.017 55.5212L275.213 53.0999L261.47 44.8505L257.302 47.3Z",
    pd669280:
      "M68.0076 161.13L63.8398 163.523L59.6439 161.102L63.8398 158.68L68.0076 161.13Z",
    pd788b00:
      "M53.3078 180.979V185.793L57.5037 183.372V178.557L53.3078 180.979Z",
    pd84bd80:
      "M4.19589 16.9491V21.7636L29.3432 7.23576V2.4213L4.19589 16.9491Z",
    pd917700:
      "M50.0694 113.604L43.3672 117.715V149.192L50.0694 145.081V113.604ZM37.8477 120.643L31.1455 124.754V156.231L37.8477 152.12V120.643ZM25.6261 127.682L18.9239 131.792V163.269L25.6261 159.159V127.682Z",
    pd990820:
      "M7.26543 33.2789L10.3912 31.3925L22.3313 38.1778L19.2055 40.0923L7.26543 33.2789Z",
    pda91bf2:
      "M4.19589 16.9492V21.7636L29.3432 7.23577V2.44946L4.19589 16.9492Z",
    pdbfd770:
      "M25.2318 67.6277L26.1893 68.4161V113.97L25.2318 113.154V67.6277Z",
    pdcd8180:
      "M154.151 132.581V148.629L149.955 146.208V130.159L154.151 132.581Z",
    pdd5b200:
      "M60.3198 61.9686L59.3342 62.7569V108.311L60.3198 107.495V61.9686Z",
    pddeea00:
      "M16.2205 30.1256V11.0367L19.2055 12.8667V31.9275L16.2205 30.1256Z",
    pdecae80: "M2.87237 3.2941V139.084L5.71658 137.423V1.66112L2.87237 3.2941Z",
    pdee15f0:
      "M1.40802 31.2799L6.70221 34.5177V35.5876L0 31.477V19.1171L1.40802 19.9899V31.2799Z",
    pdfe8040:
      "M4.19593 4.81446V624.557L8.36367 622.136V2.4213L4.19593 4.81446Z",
    pe06b900:
      "M222.665 104.032V108.846L226.861 106.425V101.611L222.665 104.032Z",
    pe06ba00: "M0 55.5775L37.7914 77.3411V75.1451L0 53.5222V55.5775Z",
    pe10d7f2:
      "M6.95566 31.9275L9.94067 30.0974L21.402 36.6294L18.3888 38.4594L6.95566 31.9275Z",
    pe1ba00:
      "M2.87238 3.2941V257.869L1.67968e-06 256.236V1.66112L2.87238 3.2941Z",
    pe258900:
      "M4.19589 16.9492V21.7637L29.3432 7.20766V2.42132L4.19589 16.9492Z",
    pe260e80:
      "M5.68842 1.66116L2.84422 3.32228L0 1.66116L2.84422 0L5.68842 1.66116Z",
    pe2ebc80:
      "M23.2324 182.555V187.37L19.0365 184.949V180.134L23.2324 182.555Z",
    pe35e600:
      "M187.999 331.973L134.044 362.915V374.261L187.999 343.319V331.973Z",
    pe381980:
      "M29.3432 2.44945L4.19595 16.9773L1.82804e-05 14.556L25.1755 0L29.3432 2.44945Z",
    pe3926c0:
      "M282.309 81.311L141.197 162.819L0 81.5925L141.253 0L282.309 81.311Z",
    pe3ba600: "M2.84423 3.2941V38.741L5.7166 37.0798V1.66116L2.84423 3.2941Z",
    pe45d900: "M47.2252 82.1274V96.0076L0 68.5005V54.6202L47.2252 82.1274Z",
    pe4a9c00:
      "M42.2971 72.4703L41.3396 73.2868V118.813L42.2971 118.025V72.4703Z",
    pe4c7a00:
      "M4.19593 16.9491V21.7636L29.3432 7.23576V2.4213L4.19593 16.9491Z",
    pe745280:
      "M126.469 272.82L120.048 276.761V284.166L126.469 280.224V272.82ZM114.754 279.577L108.333 283.518V290.923L114.754 286.981V279.577ZM103.067 286.306L96.6468 290.247V297.652L103.067 293.71V286.306ZM73.2454 303.733V311.138L79.666 307.197V299.792L73.2454 303.733ZM91.3526 293.063L84.9321 297.005V304.409L91.3526 300.468V293.063Z",
    pe7fb080:
      "M329.59 25.9305L343.305 34.1517L347.5 31.7304L333.758 23.4811L329.59 25.9305Z",
    pe8b7f00:
      "M42.0436 7.23577L6.25163 28.0703L0 24.4665L42.0436 4.22912e-07V7.23577Z",
    peb21080:
      "M5.68843 1.66112L2.84422 3.2941L0 1.66112L2.84422 0L5.68843 1.66112Z",
    peb54b00:
      "M4.19593 4.81446V334.732L8.36367 332.311V2.42131L4.19593 4.81446Z",
    peb96200:
      "M23.2042 15.1754V49.2427L26.1892 47.4126V13.3454L23.2042 15.1754Z",
    pebe8040:
      "M333.871 2.42131L23.2324 182.555L19.0365 180.134L329.703 0L333.871 2.42131Z",
    pec86500:
      "M88.0579 145.138L101.772 153.359L105.968 150.938L92.2256 142.716L88.0579 145.138Z",
    ped51400: "M25.1473 50.6222V55.4367L0 7.2358V2.44945L25.1473 50.6222Z",
    ped8e200:
      "M23.2042 15.1754V49.2426L26.1611 47.4126V13.3735L23.2042 15.1754Z",
    pedbc180:
      "M5.30317e-06 13.3735L2.95687 15.1754L26.1611 1.83004L23.1761 0L5.30317e-06 13.3735Z",
    pedf2e00:
      "M10.3631 31.3925V11.5153L7.23727 13.4299V33.3071L10.3631 31.3925Z",
    pf083500:
      "M13.6297 19.1734L18.9239 22.4393V23.4811L12.2216 19.3704V7.03869L13.6297 7.8833V19.1734Z",
    pf466b80:
      "M5.71658 1.66112L2.87237 3.2941L6.76062e-06 1.66112L2.87237 0L5.71658 1.66112Z",
    pf4e2bf0:
      "M257.302 67.9937L271.017 76.2149L275.213 73.7936L261.47 65.5443L257.302 67.9937Z",
    pf579400:
      "M2.95686 15.1754V49.2426L26.1611 35.8973V1.83004L2.95686 15.1754ZM19.0083 31.7586L10.1096 36.8827V19.3141L19.0083 14.1899V31.7586Z",
    pf5bedb0: "M0 67.2336L27.372 32.5751L38.6644 39.107L0 67.2336Z",
    pf777400:
      "M1.83132e-06 2.42131L25.1473 16.9492L29.3432 14.5279L4.16774 0L1.83132e-06 2.42131Z",
    pf9b0b00: "M43.677 50.2281V52.0863L86.7625 26.9723V25.1422L43.677 50.2281Z",
    pf9f4fd0:
      "M25.1473 50.6222V55.4367L29.3432 53.0154V48.2009L25.1473 50.6222Z",
    pfa99d00:
      "M5.71658 1.6893L2.87236 3.32228L0 1.66112L2.87236 0L5.71658 1.6893Z",
    pfaa9900:
      "M188.901 91.5311L184.733 93.9243L180.537 91.503L184.733 89.1098L188.901 91.5311Z",
    pfae3700:
      "M319.058 48.1728V52.9873L323.254 50.5659V45.7515L319.058 48.1728Z",
    pfe3b480:
      "M86.7625 25.1422L43.677 50.2281L2.22735e-06 25.114L43.1419 0L86.7625 25.1422Z",
    pfebc300:
      "M126.018 160.032V164.846L112.304 156.625V151.81L126.018 160.032Z",
    pff1c800:
      "M26.1611 13.3453L23.1761 15.1754L3.32378e-06 1.83004L2.98501 0L26.1611 13.3453Z",
    pffe0380: "M25.1473 16.9774V21.7919L0 7.23583V2.44953L25.1473 16.9774Z",
    pfffcb00:
      "M2.84422 3.32224V38.7409L5.68843 37.1079V1.66112L2.84422 3.32224Z",
  },
  Un = "/assets/00af332c1a9f3126ee7549c6a79f390066c45c4b-BBxVev8d.png",
  qa = "/assets/1a36bc184ac42a93ebf62d57aae0e30c740ff2ab-B2Jtxq84.png",
  V1 = "/assets/98f09ac846bcbc03282de0ae1ad4f2ddf9c2a40d-B9SoSyqK.png",
  B0 = "/assets/02eb02ba7669a0feb1767b41295d3a537ddbc7ac-BIFyo_yQ.png",
  Gr = "/assets/c62b040ae07497ba53905f657b9a0d79d61c6834-BHVBVufB.png",
  Ar = "/assets/d487899cf4044f5bc95ed6f09450da047fa3d3e8-DAxC9ocd.png",
  Dr = "/assets/3cbca7f201f5ca5ba3bd536029cc7d7f7312cf0e-THkfI-pg.png";
function e4() {
  return e.jsx("div", {
    className:
      "-translate-y-1/2 absolute h-[22.885px] left-[1041.29px] top-[calc(50%-3042.6px)] w-[78.795px]",
    "data-name": "Link",
  });
}
function t4() {
  return e.jsx("div", {
    className: "absolute h-[25.5px] left-[140.85px] top-0 w-[15.188px]",
    "data-name": "Text",
    children: e.jsx("p", {
      className:
        "-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[25.5px] left-[8.5px] not-italic text-[#f39130] text-[17px] text-center top-[0.5px] tracking-[-0.4316px]",
      children: "→",
    }),
  });
}
function l4() {
  return e.jsxs("div", {
    className: "h-[25.5px] relative shrink-0 w-full",
    "data-name": "Text",
    children: [
      e.jsx("p", {
        className:
          "-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[25.5px] left-[66.5px] not-italic text-[#1d1d1f] text-[17px] text-center top-[0.5px] tracking-[-0.4316px]",
        children: "Explore TruGenie",
      }),
      e.jsx(t4, {}),
    ],
  });
}
function r4() {
  return e.jsxs("div", {
    className:
      "absolute bg-[rgba(255,255,255,0.6)] content-stretch flex flex-col h-[59.5px] items-start left-[175.15px] pb-px pt-[17px] px-[37px] rounded-[16777200px] top-[24px] w-[230.039px]",
    "data-name": "Button",
    children: [
      e.jsx("div", {
        "aria-hidden": "true",
        className:
          "absolute border border-[rgba(0,0,0,0.08)] border-solid inset-0 pointer-events-none rounded-[16777200px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.04)]",
      }),
      e.jsx(l4, {}),
    ],
  });
}
function i4() {
  return e.jsx("div", {
    className:
      "content-stretch flex h-[20px] items-start relative shrink-0 w-full",
    "data-name": "Text",
    children: e.jsx("p", {
      className:
        "font-['Inter:Medium',sans-serif] font-medium leading-[25.5px] not-italic relative shrink-0 text-[17px] text-center text-white tracking-[-0.4316px] w-[88px] whitespace-pre-wrap",
      children: "Contact Us",
    }),
  });
}
function n4() {
  return e.jsx("div", {
    className:
      "absolute bg-[#286fed] content-stretch flex flex-col h-[57.5px] items-center left-0 overflow-clip pt-[16px] px-[36px] rounded-[16777200px] shadow-[0px_4px_16px_0px_rgba(40,111,237,0.3)] top-[25px] w-[159.148px]",
    "data-name": "Button",
    children: e.jsx(i4, {}),
  });
}
function s4() {
  return e.jsxs("div", {
    className: "absolute h-[83.5px] left-[109px] top-[583px] w-[704px]",
    "data-name": "Container",
    children: [e.jsx(r4, {}), e.jsx(n4, {})],
  });
}
function a4() {
  return e.jsx("div", {
    className: "absolute h-[73px] left-[109px] top-[286px] w-[620px]",
    "data-name": "Heading 1",
    children: e.jsx("p", {
      className:
        "absolute font-['Inter:Bold',sans-serif] font-bold leading-[72px] left-0 not-italic text-[#286fed] text-[64px] top-px tracking-[-1.0612px] w-[589px] whitespace-pre-wrap",
      children: "Unified Real Estate ",
    }),
  });
}
function o4() {
  return e.jsxs("div", {
    className: "absolute contents left-[109px] top-[286px]",
    children: [
      e.jsx(a4, {}),
      e.jsx("p", {
        className:
          "absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[72px] left-[109px] not-italic text-[#0c1b56] text-[52px] top-[358px] tracking-[-1.0612px] w-[814px] whitespace-pre-wrap",
        children: "Asset Management & Intelligence",
      }),
    ],
  });
}
function d4() {
  return e.jsxs("div", {
    className: "absolute contents left-[109px] top-[286px]",
    children: [
      e.jsx("p", {
        className:
          "absolute font-['Inter:Regular',sans-serif] font-normal leading-[34px] left-[109px] not-italic text-[#6e6e73] text-[21px] top-[464px] tracking-[-0.5689px] w-[840px] whitespace-pre-wrap",
        children:
          "TruBoard brings together execution, asset oversight, and real-time intelligence to help developers, lenders, and investors build better, monitor smarter, and protect capital across the real estate lifecycle.",
      }),
      e.jsx(s4, {}),
      e.jsx(o4, {}),
    ],
  });
}
function c4() {
  return e.jsx("div", {
    className: "h-[42px] relative shrink-0 w-[438px]",
    "data-name": "Image (TruBoard PropTech)",
    children: e.jsx("div", {
      className:
        "absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 overflow-hidden pointer-events-none",
      children: e.jsx("img", {
        alt: "",
        className:
          "absolute h-full left-[-0.06%] max-w-none top-[-0.43%] w-[99.18%]",
        src: Un,
      }),
    }),
  });
}
function p4() {
  return e.jsx("div", {
    className: "flex-[1_0_0] h-[42px] min-h-px min-w-px relative",
    "data-name": "Link",
    children: e.jsx("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative size-full",
      children: e.jsx(c4, {}),
    }),
  });
}
function f4() {
  return e.jsx("div", {
    className: "h-[42px] relative shrink-0 w-[376.438px]",
    "data-name": "Container",
    children: e.jsx("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative size-full",
      children: e.jsx(p4, {}),
    }),
  });
}
function u4() {
  return e.jsx("div", {
    className: "absolute left-[80.23px] size-[14px] top-[12.25px]",
    "data-name": "Icon",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 14 14",
      children: e.jsx("g", {
        id: "Icon",
        children: e.jsx("path", {
          d: "M3.5 5.25L7 8.75L10.5 5.25",
          id: "Vector",
          stroke: "var(--stroke-0, #061B45)",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "1.16667",
        }),
      }),
    }),
  });
}
function x4() {
  return e.jsx("div", {
    className: "absolute bg-[#286fed] h-[2px] left-0 top-[20.5px] w-0",
    "data-name": "Text",
  });
}
function h4() {
  return e.jsxs("div", {
    className: "absolute h-[22.5px] left-[16px] top-[8px] w-[60.227px]",
    "data-name": "Text",
    children: [
      e.jsx("p", {
        className:
          "-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[22.5px] left-[30.5px] not-italic text-[#061b45] text-[15px] text-center top-[-0.5px] tracking-[-0.2344px]",
        children: "Services",
      }),
      e.jsx(x4, {}),
    ],
  });
}
function v4() {
  return e.jsx("div", {
    className: "h-[38.5px] relative shrink-0 w-[110.227px]",
    "data-name": "NavItem",
    children: e.jsxs("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid relative size-full",
      children: [e.jsx(u4, {}), e.jsx(h4, {})],
    }),
  });
}
function L4() {
  return e.jsx("div", {
    className: "absolute left-[75.59px] size-[14px] top-[12.25px]",
    "data-name": "Icon",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 14 14",
      children: e.jsx("g", {
        id: "Icon",
        children: e.jsx("path", {
          d: "M3.5 5.25L7 8.75L10.5 5.25",
          id: "Vector",
          stroke: "var(--stroke-0, #061B45)",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "1.16667",
        }),
      }),
    }),
  });
}
function j4() {
  return e.jsx("div", {
    className: "absolute bg-[#286fed] h-[2px] left-0 top-[20.5px] w-0",
    "data-name": "Text",
  });
}
function V4() {
  return e.jsxs("div", {
    className: "absolute h-[22.5px] left-[16px] top-[8px] w-[55.586px]",
    "data-name": "Text",
    children: [
      e.jsx("p", {
        className:
          "-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[22.5px] left-[28px] not-italic text-[#061b45] text-[15px] text-center top-[-0.5px] tracking-[-0.2344px]",
        children: "Product",
      }),
      e.jsx(j4, {}),
    ],
  });
}
function m4() {
  return e.jsx("div", {
    className: "h-[38.5px] relative shrink-0 w-[105.586px]",
    "data-name": "NavItem",
    children: e.jsxs("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid relative size-full",
      children: [e.jsx(L4, {}), e.jsx(V4, {})],
    }),
  });
}
function g4() {
  return e.jsx("div", {
    className: "absolute left-[93.52px] size-[14px] top-[12.25px]",
    "data-name": "Icon",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 14 14",
      children: e.jsx("g", {
        id: "Icon",
        children: e.jsx("path", {
          d: "M3.5 5.25L7 8.75L10.5 5.25",
          id: "Vector",
          stroke: "var(--stroke-0, #061B45)",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "1.16667",
        }),
      }),
    }),
  });
}
function _4() {
  return e.jsx("div", {
    className: "absolute bg-[#286fed] h-[2px] left-0 top-[20.5px] w-0",
    "data-name": "Text",
  });
}
function b4() {
  return e.jsxs("div", {
    className: "absolute h-[22.5px] left-[16px] top-[8px] w-[73.516px]",
    "data-name": "Text",
    children: [
      e.jsx("p", {
        className:
          "-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[22.5px] left-[37px] not-italic text-[#061b45] text-[15px] text-center top-[-0.5px] tracking-[-0.2344px]",
        children: "Resources",
      }),
      e.jsx(_4, {}),
    ],
  });
}
function F4() {
  return e.jsx("div", {
    className: "h-[38.5px] relative shrink-0 w-[123.516px]",
    "data-name": "NavItem",
    children: e.jsxs("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid relative size-full",
      children: [e.jsx(g4, {}), e.jsx(b4, {})],
    }),
  });
}
function M4() {
  return e.jsx("div", {
    className:
      "bg-[#286fed] flex-[1_0_0] h-[42.5px] min-h-px min-w-px relative rounded-[10px]",
    "data-name": "Link",
    children: e.jsx("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid relative size-full",
      children: e.jsx("p", {
        className:
          "absolute font-['Inter:Medium',sans-serif] font-medium leading-[22.5px] left-[35.36px] not-italic text-[15px] text-white top-[9.5px] tracking-[-0.2344px]",
        children: "Contact Us",
      }),
    }),
  });
}
function C4() {
  return e.jsx("div", {
    className: "h-[42.5px] relative shrink-0 w-[513.688px]",
    "data-name": "Navigation",
    children: e.jsxs("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full",
      children: [e.jsx(v4, {}), e.jsx(m4, {}), e.jsx(F4, {}), e.jsx(M4, {})],
    }),
  });
}
function w4() {
  return e.jsxs("div", {
    className:
      "content-stretch flex h-[80px] items-center justify-between relative shrink-0 w-full",
    "data-name": "Container",
    children: [e.jsx(f4, {}), e.jsx(C4, {})],
  });
}
function k4() {
  return e.jsxs("div", {
    className:
      "absolute bg-white content-stretch flex flex-col h-[77.237px] items-start left-[52.86px] pb-px px-[56px] rounded-[16px] top-[42.91px] w-[1810.286px]",
    "data-name": "Redesign TruBoard Header",
    children: [
      e.jsx("div", {
        "aria-hidden": "true",
        className:
          "absolute border-[#f3f4f6] border-b border-solid inset-0 pointer-events-none rounded-[16px]",
      }),
      e.jsx(w4, {}),
    ],
  });
}
function N4() {
  return e.jsx("div", {
    className: "absolute h-[56px] left-0 top-0 w-[640px]",
    "data-name": "Image (TruBoard PropTech)",
    children: e.jsx("div", {
      className: "absolute inset-0 overflow-hidden pointer-events-none",
      children: e.jsx("img", {
        alt: "",
        className: "absolute h-full left-[0.05%] max-w-none top-0 w-[90.51%]",
        src: qa,
      }),
    }),
  });
}
function Z4() {
  return e.jsx("div", {
    className: "absolute h-[24px] left-0 top-[72px] w-[448px]",
    "data-name": "Paragraph",
    children: e.jsx("p", {
      className:
        "absolute font-['Inter:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#99a1af] text-[16px] top-[-0.5px] tracking-[-0.3125px]",
      children: "Real Estate Asset Management Services",
    }),
  });
}
function y4() {
  return e.jsxs("div", {
    className: "absolute h-[96px] left-[352px] top-[168px] w-[1216px]",
    "data-name": "Container",
    children: [e.jsx(N4, {}), e.jsx(Z4, {})],
  });
}
function B4() {
  return e.jsx("div", {
    className: "h-[27px] relative shrink-0 w-full",
    "data-name": "Heading 3",
    children: e.jsx("p", {
      className:
        "absolute font-['Inter:Medium',sans-serif] font-medium leading-[27px] left-0 not-italic text-[18px] text-white top-[0.5px] tracking-[-0.4395px]",
      children: "Quick Links",
    }),
  });
}
function E4() {
  return e.jsx("div", {
    className:
      "absolute content-stretch flex h-[19px] items-start left-0 top-[2.5px] w-[43.141px]",
    "data-name": "Link",
    children: e.jsx("p", {
      className:
        "font-['Inter:Regular',sans-serif] font-normal leading-[24px] not-italic relative shrink-0 text-[#99a1af] text-[16px] tracking-[-0.3125px]",
      children: "Home",
    }),
  });
}
function G4() {
  return e.jsx("div", {
    className: "h-[24px] relative shrink-0 w-full",
    "data-name": "List Item",
    children: e.jsx(E4, {}),
  });
}
function A4() {
  return e.jsx("div", {
    className:
      "absolute content-stretch flex h-[19px] items-start left-0 top-[2.5px] w-[67.148px]",
    "data-name": "Link",
    children: e.jsx("p", {
      className:
        "font-['Inter:Regular',sans-serif] font-normal leading-[24px] not-italic relative shrink-0 text-[#99a1af] text-[16px] tracking-[-0.3125px]",
      children: "Solutions",
    }),
  });
}
function D4() {
  return e.jsx("div", {
    className: "h-[24px] relative shrink-0 w-full",
    "data-name": "List Item",
    children: e.jsx(A4, {}),
  });
}
function R4() {
  return e.jsx("div", {
    className:
      "absolute content-stretch flex h-[19px] items-start left-0 top-[2.5px] w-[71.328px]",
    "data-name": "Link",
    children: e.jsx("p", {
      className:
        "font-['Inter:Regular',sans-serif] font-normal leading-[24px] not-italic relative shrink-0 text-[#99a1af] text-[16px] tracking-[-0.3125px]",
      children: "Industries",
    }),
  });
}
function S4() {
  return e.jsx("div", {
    className: "h-[24px] relative shrink-0 w-full",
    "data-name": "List Item",
    children: e.jsx(R4, {}),
  });
}
function I4() {
  return e.jsxs("div", {
    className:
      "content-stretch flex flex-col gap-[16px] h-[104px] items-start relative shrink-0 w-full",
    "data-name": "List",
    children: [e.jsx(G4, {}), e.jsx(D4, {}), e.jsx(S4, {})],
  });
}
function T4() {
  return e.jsxs("div", {
    className:
      "absolute content-stretch flex flex-col gap-[24px] h-[155px] items-start left-0 top-0 w-[373.328px]",
    "data-name": "Container",
    children: [e.jsx(B4, {}), e.jsx(I4, {})],
  });
}
function z4() {
  return e.jsx("div", {
    className: "h-[27px] relative shrink-0 w-full",
    "data-name": "Heading 3",
    children: e.jsx("p", {
      className:
        "absolute font-['Inter:Medium',sans-serif] font-medium leading-[27px] left-0 not-italic text-[18px] text-white top-[0.5px] tracking-[-0.4395px]",
      children: "Contact Us",
    }),
  });
}
function P4() {
  return e.jsx("div", {
    className: "absolute left-0 size-[20px] top-[4px]",
    "data-name": "Icon",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 20 20",
      children: e.jsxs("g", {
        id: "Icon",
        children: [
          e.jsx("path", {
            d: i.p26ddc800,
            id: "Vector",
            stroke: "var(--stroke-0, #005BAB)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.66667",
          }),
          e.jsx("path", {
            d: i.p35ba4680,
            id: "Vector_2",
            stroke: "var(--stroke-0, #005BAB)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.66667",
          }),
        ],
      }),
    }),
  });
}
function H4() {
  return e.jsx("div", {
    className: "absolute h-[52px] left-[32px] top-0 w-[762.672px]",
    "data-name": "Paragraph",
    children: e.jsx("p", {
      className:
        "absolute font-['Inter:Regular',sans-serif] font-normal leading-[26px] left-0 not-italic text-[#99a1af] text-[16px] top-[-0.5px] tracking-[-0.3125px] w-[711px] whitespace-pre-wrap",
      children:
        "321, SOLITAIRE COPRORATE PARK, ANDHERI GHATKOPAR LINK ROAD, CHAKALA, Chakala MIDC, Mumbai, Mumbai Suburban, Maharashtra, 400093",
    }),
  });
}
function W4() {
  return e.jsxs("div", {
    className: "h-[52px] relative shrink-0 w-full",
    "data-name": "Container",
    children: [e.jsx(P4, {}), e.jsx(H4, {})],
  });
}
function O4() {
  return e.jsxs("div", {
    className:
      "absolute content-stretch flex flex-col gap-[24px] h-[155px] items-start left-[421.33px] top-0 w-[794.672px]",
    "data-name": "Container",
    children: [e.jsx(z4, {}), e.jsx(W4, {})],
  });
}
function U4() {
  return e.jsxs("div", {
    className: "absolute h-[155px] left-[352px] top-[312px] w-[1216px]",
    "data-name": "Container",
    children: [e.jsx(T4, {}), e.jsx(O4, {})],
  });
}
function Q4() {
  return e.jsx("div", {
    className:
      "absolute border-[#364153] border-solid border-t h-px left-[352px] top-[531px] w-[1216px]",
    "data-name": "Container",
  });
}
function $4() {
  return e.jsx("div", {
    className: "h-[20px] relative shrink-0 w-[268.797px]",
    "data-name": "Paragraph",
    children: e.jsx("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid relative size-full",
      children: e.jsx("p", {
        className:
          "absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#99a1af] text-[14px] top-[0.5px] tracking-[-0.1504px]",
        children: "© 2025 TruBoard Technologies. All rights reserved.",
      }),
    }),
  });
}
function X4() {
  return e.jsx("div", {
    className: "h-[20px] overflow-clip relative shrink-0 w-full",
    "data-name": "Icon",
    children: e.jsx("div", {
      className: "absolute bottom-[8.33%] left-[29.17%] right-1/4 top-[8.33%]",
      "data-name": "Vector",
      children: e.jsx("div", {
        className: "absolute inset-[-5%_-9.09%]",
        children: e.jsx("svg", {
          className: "block size-full",
          fill: "none",
          preserveAspectRatio: "none",
          viewBox: "0 0 10.8333 18.3333",
          children: e.jsx("path", {
            d: i.p231a59f0,
            fill: "var(--fill-0, #D1D5DC)",
            id: "Vector",
            stroke: "var(--stroke-0, #D1D5DC)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.66667",
          }),
        }),
      }),
    }),
  });
}
function Y4() {
  return e.jsx("div", {
    className: "bg-[#1e2939] relative rounded-[10px] shrink-0 size-[40px]",
    "data-name": "Link",
    children: e.jsx("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[10px] px-[10px] relative size-full",
      children: e.jsx(X4, {}),
    }),
  });
}
function K4() {
  return e.jsx("div", {
    className: "h-[20px] overflow-clip relative shrink-0 w-full",
    "data-name": "Icon",
    children: e.jsx("div", {
      className: "absolute inset-[16.63%_8.33%_12.5%_8.33%]",
      "data-name": "Vector",
      children: e.jsx("div", {
        className: "absolute inset-[-5.88%_-5%_-5.91%_-5%]",
        children: e.jsx("svg", {
          className: "block size-full",
          fill: "none",
          preserveAspectRatio: "none",
          viewBox: "0 0 18.3335 15.8435",
          children: e.jsx("path", {
            d: i.p3693ea00,
            fill: "var(--fill-0, #D1D5DC)",
            id: "Vector",
            stroke: "var(--stroke-0, #D1D5DC)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.66667",
          }),
        }),
      }),
    }),
  });
}
function J4() {
  return e.jsx("div", {
    className: "bg-[#1e2939] relative rounded-[10px] shrink-0 size-[40px]",
    "data-name": "Link",
    children: e.jsx("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[10px] px-[10px] relative size-full",
      children: e.jsx(K4, {}),
    }),
  });
}
function q4() {
  return e.jsxs("div", {
    className: "h-[20px] overflow-clip relative shrink-0 w-full",
    "data-name": "Icon",
    children: [
      e.jsx("div", {
        className: "absolute inset-[33.33%_8.33%_12.5%_41.67%]",
        "data-name": "Vector",
        children: e.jsx("div", {
          className: "absolute inset-[-7.69%_-8.33%]",
          children: e.jsx("svg", {
            className: "block size-full",
            fill: "none",
            preserveAspectRatio: "none",
            viewBox: "0 0 11.6667 12.5",
            children: e.jsx("path", {
              d: i.p21836480,
              fill: "var(--fill-0, #D1D5DC)",
              id: "Vector",
              stroke: "var(--stroke-0, #D1D5DC)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "1.66667",
            }),
          }),
        }),
      }),
      e.jsx("div", {
        className: "absolute bottom-[12.5%] left-[8.33%] right-3/4 top-[37.5%]",
        "data-name": "Vector",
        children: e.jsx("div", {
          className: "absolute inset-[-8.33%_-25%]",
          children: e.jsx("svg", {
            className: "block size-full",
            fill: "none",
            preserveAspectRatio: "none",
            viewBox: "0 0 5 11.6667",
            children: e.jsx("path", {
              d: i.p1a426680,
              fill: "var(--fill-0, #D1D5DC)",
              id: "Vector",
              stroke: "var(--stroke-0, #D1D5DC)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "1.66667",
            }),
          }),
        }),
      }),
      e.jsx("div", {
        className: "absolute bottom-3/4 left-[8.33%] right-3/4 top-[8.33%]",
        "data-name": "Vector",
        children: e.jsx("div", {
          className: "absolute inset-[-25%]",
          children: e.jsx("svg", {
            className: "block size-full",
            fill: "none",
            preserveAspectRatio: "none",
            viewBox: "0 0 5 5",
            children: e.jsx("path", {
              d: i.p29efb800,
              fill: "var(--fill-0, #D1D5DC)",
              id: "Vector",
              stroke: "var(--stroke-0, #D1D5DC)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "1.66667",
            }),
          }),
        }),
      }),
    ],
  });
}
function e6() {
  return e.jsx("div", {
    className: "bg-[#1e2939] relative rounded-[10px] shrink-0 size-[40px]",
    "data-name": "Link",
    children: e.jsx("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[10px] px-[10px] relative size-full",
      children: e.jsx(q4, {}),
    }),
  });
}
function t6() {
  return e.jsxs("div", {
    className: "h-[20px] overflow-clip relative shrink-0 w-full",
    "data-name": "Icon",
    children: [
      e.jsx("div", {
        className: "absolute inset-[8.33%]",
        "data-name": "Vector",
        children: e.jsx("div", {
          className: "absolute inset-[-5%]",
          children: e.jsx("svg", {
            className: "block size-full",
            fill: "none",
            preserveAspectRatio: "none",
            viewBox: "0 0 18.3333 18.3333",
            children: e.jsx("path", {
              d: i.p1aaf0300,
              fill: "var(--fill-0, #D1D5DC)",
              id: "Vector",
              stroke: "var(--stroke-0, #D1D5DC)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "1.66667",
            }),
          }),
        }),
      }),
      e.jsx("div", {
        className: "absolute inset-[27.08%_27.04%_72.92%_72.92%]",
        "data-name": "Vector",
        children: e.jsx("div", {
          className: "absolute inset-[-0.83px]",
          children: e.jsx("svg", {
            className: "block size-full",
            fill: "none",
            preserveAspectRatio: "none",
            viewBox: "0 0 1.675 1.66667",
            children: e.jsx("path", {
              d: "M0.833333 0.833333H0.841667",
              id: "Vector",
              stroke: "var(--stroke-0, #1B2431)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "1.66667",
            }),
          }),
        }),
      }),
      e.jsx("div", {
        className: "absolute inset-[33.15%_33.15%_33.51%_33.51%]",
        "data-name": "Vector",
        children: e.jsx("div", {
          className: "absolute inset-[-12.5%]",
          children: e.jsx("svg", {
            className: "block size-full",
            fill: "none",
            preserveAspectRatio: "none",
            viewBox: "0 0 8.33334 8.33334",
            children: e.jsx("path", {
              d: i.p1a50b2f0,
              id: "Vector",
              stroke: "var(--stroke-0, #1B2431)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "1.66667",
            }),
          }),
        }),
      }),
    ],
  });
}
function l6() {
  return e.jsx("div", {
    className:
      "bg-[#1e2939] flex-[1_0_0] h-[40px] min-h-px min-w-px relative rounded-[10px]",
    "data-name": "Link",
    children: e.jsx("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[10px] px-[10px] relative size-full",
      children: e.jsx(t6, {}),
    }),
  });
}
function r6() {
  return e.jsx("div", {
    className: "h-[40px] relative shrink-0 w-[208px]",
    "data-name": "Container",
    children: e.jsxs("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-start relative size-full",
      children: [e.jsx(Y4, {}), e.jsx(J4, {}), e.jsx(e6, {}), e.jsx(l6, {})],
    }),
  });
}
function i6() {
  return e.jsx("div", {
    className: "h-[20px] relative shrink-0 w-[89.391px]",
    "data-name": "Link",
    children: e.jsx("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid relative size-full",
      children: e.jsx("p", {
        className:
          "absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#99a1af] text-[14px] top-[0.5px] tracking-[-0.1504px]",
        children: "Privacy Policy",
      }),
    }),
  });
}
function n6() {
  return e.jsx("div", {
    className: "flex-[1_0_0] h-[20px] min-h-px min-w-px relative",
    "data-name": "Link",
    children: e.jsx("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid relative size-full",
      children: e.jsx("p", {
        className:
          "absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#99a1af] text-[14px] top-[0.5px] tracking-[-0.1504px]",
        children: "Terms of Service",
      }),
    }),
  });
}
function s6() {
  return e.jsx("div", {
    className: "h-[20px] relative shrink-0 w-[221.883px]",
    "data-name": "Container",
    children: e.jsxs("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[24px] items-start relative size-full",
      children: [e.jsx(i6, {}), e.jsx(n6, {})],
    }),
  });
}
function a6() {
  return e.jsxs("div", {
    className:
      "absolute content-stretch flex h-[40px] items-center justify-between left-[352px] pr-[0.008px] top-[564px] w-[1216px]",
    "data-name": "Container",
    children: [e.jsx($4, {}), e.jsx(r6, {}), e.jsx(s6, {})],
  });
}
function o6() {
  return e.jsxs("div", {
    className: "absolute contents left-[352px] top-[168px]",
    children: [e.jsx(y4, {}), e.jsx(U4, {}), e.jsx(Q4, {}), e.jsx(a6, {})],
  });
}
function d6() {
  return e.jsx("div", {
    className:
      "absolute bg-[#0b192f] h-[724.984px] left-0 top-[5544px] w-[1920px]",
    "data-name": "Footer",
    children: e.jsx(o6, {}),
  });
}
function c6() {
  return e.jsx("div", {
    className: "absolute contents left-0 top-[5544px]",
    children: e.jsx(d6, {}),
  });
}
function p6() {
  return e.jsxs("div", {
    className: "absolute contents left-0 top-[5122px]",
    children: [
      e.jsx("div", {
        className: "absolute bottom-[13.51%] left-0 top-[80.59%] w-[1920px]",
      }),
      e.jsx(c6, {}),
    ],
  });
}
function f6() {
  return e.jsx("div", {
    className: "absolute contents inset-[22.53%_75.99%_77.03%_10.68%]",
    children: e.jsx("div", {
      className:
        "absolute flex flex-col font-['Avenir:Roman',sans-serif] inset-[22.53%_75.99%_77.03%_10.68%] justify-center leading-[0] not-italic text-[#1b2431] text-[24px] text-center tracking-[-0.6016px]",
      children: e.jsx("p", {
        className: "leading-[25.5px] whitespace-pre-wrap",
        children: "assets under oversight",
      }),
    }),
  });
}
function u6() {
  return e.jsxs("div", {
    className:
      "absolute contents inset-[21.24%_75.99%_77.03%_10.68%] leading-[0] text-center",
    children: [
      e.jsx("div", {
        className:
          "absolute flex flex-col font-['Roboto:Bold',sans-serif] font-bold inset-[21.24%_78.07%_77.71%_12.71%] justify-center text-[#286fed] text-[60px]",
        style: { fontVariationSettings: "'wdth' 100" },
        children: e.jsx("p", {
          className: "leading-[60px] whitespace-pre-wrap",
          children: "$4Bn+",
        }),
      }),
      e.jsx("div", {
        className:
          "absolute flex flex-col font-['Avenir:Roman',sans-serif] inset-[22.53%_75.99%_77.03%_10.68%] justify-center not-italic text-[#1b2431] text-[24px] tracking-[-0.6016px]",
        children: e.jsx("p", {
          className: "leading-[25.5px] whitespace-pre-wrap",
          children: "assets under oversight",
        }),
      }),
    ],
  });
}
function x6() {
  return e.jsxs("div", {
    className:
      "-translate-x-1/2 absolute contents left-[calc(50%+0.84px)] top-[1299px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-white border-[1.5px] border-[rgba(229,229,229,0.36)] border-solid h-[213px] left-[109px] rounded-[45px] top-[1299px] w-[483.681px]",
      }),
      e.jsx("div", {
        className:
          "absolute bg-white border-[1.5px] border-[rgba(229,229,229,0.36)] border-solid h-[213px] left-[719px] rounded-[45px] top-[1299px] w-[483.681px]",
      }),
      e.jsx("div", {
        className:
          "absolute bg-white border-[1.5px] border-[rgba(229,229,229,0.36)] border-solid h-[213px] left-[1329px] rounded-[45px] top-[1299px] w-[483.681px]",
      }),
      e.jsx(f6, {}),
      e.jsx(u6, {}),
    ],
  });
}
function h6() {
  return e.jsxs("div", {
    className:
      "-translate-x-1/2 absolute bottom-[77.03%] contents leading-[0] left-1/2 text-center top-[21.27%]",
    children: [
      e.jsx("div", {
        className:
          "-translate-x-1/2 absolute bottom-[77.67%] flex flex-col font-['Roboto:Bold',sans-serif] font-bold justify-center left-1/2 text-[#286fed] text-[60px] top-[21.27%] w-[534px]",
        style: { fontVariationSettings: "'wdth' 100" },
        children: e.jsx("p", {
          className: "leading-[60px] whitespace-pre-wrap",
          children: "~200Mn",
        }),
      }),
      e.jsx("div", {
        className:
          "-translate-x-1/2 absolute bottom-[77.03%] flex flex-col font-['Avenir:Roman',sans-serif] justify-center left-[calc(50%-0.5px)] not-italic text-[#1b2431] text-[24px] top-[22.53%] w-[341px]",
        children: e.jsx("p", {
          className: "leading-[28px] whitespace-pre-wrap",
          children: " sq ft overseeing valued",
        }),
      }),
    ],
  });
}
function v6() {
  return e.jsxs("div", {
    className:
      "absolute contents inset-[21.27%_10.73%_77.03%_75.05%] leading-[0] text-center",
    children: [
      e.jsx("div", {
        className:
          "absolute flex flex-col font-['Roboto:Bold',sans-serif] font-bold inset-[21.27%_13.18%_77.67%_76.09%] justify-center text-[#286fed] text-[60px]",
        style: { fontVariationSettings: "'wdth' 100" },
        children: e.jsx("p", {
          className: "leading-[60px] whitespace-pre-wrap",
          children: "~$5Bn",
        }),
      }),
      e.jsx("div", {
        className:
          "absolute flex flex-col font-['Avenir:Roman',sans-serif] inset-[22.53%_10.73%_77.03%_75.05%] justify-center not-italic text-[#1b2431] text-[24px]",
        children: e.jsx("p", {
          className: "leading-[28px] whitespace-pre-wrap",
          children: "across the USA and India",
        }),
      }),
    ],
  });
}
function L6() {
  return e.jsxs("div", {
    className: "absolute contents left-[639px] top-[1794px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-white border-[1.5px] border-solid border-white h-[138.708px] left-[639px] rounded-[20px] top-[1794px] w-[256.905px]",
      }),
      e.jsx("div", {
        className:
          "absolute h-[75.299px] left-[669.62px] top-[1828.35px] w-[186.356px]",
        children: e.jsx("div", {
          className: "absolute inset-0 overflow-hidden pointer-events-none",
          children: e.jsx("img", {
            alt: "",
            className:
              "absolute h-[688.89%] left-[-10.64%] max-w-none top-[-83.64%] w-[550.44%]",
            src: V1,
          }),
        }),
      }),
    ],
  });
}
function j6() {
  return e.jsxs("div", {
    className: "absolute contents left-[945px] top-[1794px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-white border-[1.5px] border-solid border-white h-[138.708px] left-[945px] rounded-[20px] top-[1794px] w-[256.905px]",
      }),
      e.jsx("div", {
        className:
          "absolute h-[75.299px] left-[980.94px] top-[1828.35px] w-[185.025px]",
        children: e.jsx("div", {
          className: "absolute inset-0 overflow-hidden pointer-events-none",
          children: e.jsx("img", {
            alt: "",
            className:
              "absolute h-[688.89%] left-[-129.76%] max-w-none top-[-83.64%] w-[550.44%]",
            src: V1,
          }),
        }),
      }),
    ],
  });
}
function V6() {
  return e.jsxs("div", {
    className: "absolute contents left-[1557.56px] top-[1794px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-white border-[1.5px] border-solid border-white h-[138.708px] left-[1557.56px] rounded-[20px] top-[1794px] w-[255.574px]",
      }),
      e.jsx("div", {
        className:
          "absolute h-[75.299px] left-[1592.17px] top-[1828.35px] w-[186.356px]",
        children: e.jsx("div", {
          className: "absolute inset-0 overflow-hidden pointer-events-none",
          children: e.jsx("img", {
            alt: "",
            className:
              "absolute h-[879.43%] left-[-122.07%] max-w-none top-[-287.96%] w-[702.68%]",
            src: V1,
          }),
        }),
      }),
    ],
  });
}
function m6() {
  return e.jsxs("div", {
    className: "absolute contents left-[639px] top-[1997.39px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-white border-[1.5px] border-solid border-white h-[138.708px] left-[639px] rounded-[20px] top-[1997.39px] w-[256.905px]",
      }),
      e.jsx("div", {
        className:
          "absolute h-[75.299px] left-[674.94px] top-[2034.38px] w-[186.356px]",
        children: e.jsx("div", {
          className: "absolute inset-0 overflow-hidden pointer-events-none",
          children: e.jsx("img", {
            alt: "",
            className:
              "absolute h-[879.43%] left-[-217.93%] max-w-none top-[-300.46%] w-[702.68%]",
            src: V1,
          }),
        }),
      }),
    ],
  });
}
function g6() {
  return e.jsxs("div", {
    className: "absolute contents left-[945px] top-[1997.39px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-white border-[1.5px] border-solid border-white h-[138.708px] left-[945px] rounded-[20px] top-[1997.39px] w-[256.905px]",
      }),
      e.jsx("div", {
        className:
          "absolute h-[109.645px] left-[996.91px] top-[2021.17px] w-[154.409px]",
        children: e.jsx("div", {
          className: "absolute inset-0 overflow-hidden pointer-events-none",
          children: e.jsx("img", {
            alt: "",
            className:
              "absolute h-[603.04%] left-[-12.8%] max-w-none top-[-369.29%] w-[848.07%]",
            src: V1,
          }),
        }),
      }),
    ],
  });
}
function _6() {
  return e.jsxs("div", {
    className: "absolute contents left-[1252px] top-[1997.39px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-white border-[1.5px] border-solid border-white h-[138.708px] left-[1252px] rounded-[20px] top-[1997.39px] w-[256.905px]",
      }),
      e.jsx("div", {
        className:
          "absolute h-[107.003px] left-[1281.28px] top-[2015.89px] w-[198.336px]",
        children: e.jsx("div", {
          className: "absolute inset-0 overflow-hidden pointer-events-none",
          children: e.jsx("img", {
            alt: "",
            className:
              "absolute h-[620.77%] left-[-105.02%] max-w-none top-[-353.21%] w-[661.13%]",
            src: V1,
          }),
        }),
      }),
    ],
  });
}
function b6() {
  return e.jsxs("div", {
    className: "absolute contents left-[1557.56px] top-[1997.39px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-white border-[1.5px] border-solid border-white h-[138.708px] left-[1557.56px] rounded-[20px] top-[1997.39px] w-[255.574px]",
      }),
      e.jsx("div", {
        className:
          "absolute h-[107.003px] left-[1614.8px] top-[2013.24px] w-[141.098px]",
        children: e.jsx("div", {
          className: "absolute inset-0 overflow-hidden pointer-events-none",
          children: e.jsx("img", {
            alt: "",
            className:
              "absolute h-[620.77%] left-[-285.41%] max-w-none top-[-411.78%] w-[924.58%]",
            src: V1,
          }),
        }),
      }),
    ],
  });
}
function F6() {
  return e.jsxs("div", {
    className: "absolute contents left-[1252px] top-[1794px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-white border-[1.5px] border-solid border-white h-[138.708px] left-[1252px] rounded-[20px] top-[1794px] w-[256.905px]",
      }),
      e.jsx("div", {
        className:
          "absolute h-[56.804px] left-[1290.6px] top-[1833.63px] w-[165.058px]",
        children: e.jsx("div", {
          className: "absolute inset-0 overflow-hidden pointer-events-none",
          children: e.jsx("img", {
            alt: "",
            className:
              "absolute h-[953.85%] left-[-7.65%] max-w-none top-[-296.74%] w-[621.46%]",
            src: V1,
          }),
        }),
      }),
    ],
  });
}
function M6() {
  return e.jsxs("div", {
    className: "absolute contents left-[639px] top-[1794px]",
    children: [
      e.jsx(L6, {}),
      e.jsx(j6, {}),
      e.jsx(V6, {}),
      e.jsx(m6, {}),
      e.jsx(g6, {}),
      e.jsx(_6, {}),
      e.jsx(b6, {}),
      e.jsx(F6, {}),
    ],
  });
}
function C6() {
  return e.jsxs("div", {
    className: "absolute contents left-[110px] top-[1704px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-[#fdfdfd] border border-[#f6f7f7] border-solid inset-[28.92%_73.07%_70.45%_6.09%] rounded-[14px] shadow-[0px_8px_31.5px_0px_rgba(0,38,114,0.1)]",
      }),
      e.jsx("p", {
        className:
          "absolute font-['Avenir:Medium',sans-serif] h-[28px] leading-[31px] left-[129px] not-italic text-[#005bab] text-[27px] top-[1843px] w-[389px] whitespace-pre-wrap",
        children: "Developers & Asset Owners ",
      }),
      e.jsx("div", {
        className:
          "absolute bg-[#fdfdfd] border border-[#f6f7f7] border-solid inset-[30.11%_73.39%_69.26%_5.78%] rounded-[14px]",
      }),
      e.jsx("div", {
        className:
          "absolute bg-[#fdfdfd] border border-[#f6f7f7] border-solid inset-[31.26%_73.39%_68.08%_5.78%] rounded-[14px]",
      }),
      e.jsx("div", {
        className:
          "absolute bg-[#fdfdfd] border border-[#f6f7f7] border-solid inset-[32.69%_73.39%_66.68%_5.78%] rounded-[14px]",
      }),
      e.jsx("p", {
        className:
          "absolute font-['Avenir:Roman',sans-serif] h-[26px] leading-[31px] left-[123px] not-italic text-[#1b2431] text-[27px] top-[1920px] w-[285px] whitespace-pre-wrap",
        children: "Lenders & Banks ",
      }),
      e.jsx("p", {
        className:
          "absolute font-['Avenir:Roman',sans-serif] h-[38px] leading-[31px] left-[123px] not-italic text-[#1b2431] text-[27px] top-[1995px] w-[430px] whitespace-pre-wrap",
        children: "NBFCs & Alternative Capital",
      }),
      e.jsx("p", {
        className:
          "absolute font-['Avenir:Roman',sans-serif] h-[38px] leading-[31px] left-[123px] not-italic text-[#1b2431] text-[27px] top-[2082px] w-[465px] whitespace-pre-wrap",
        children: "Funds & Institutional Investors",
      }),
      e.jsx(M6, {}),
      e.jsxs("p", {
        className:
          "absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[0] left-[110px] not-italic text-[#0c1b56] text-[45px] top-[1704px] w-[833px] whitespace-pre-wrap",
        children: [
          e.jsx("span", { className: "leading-[48px]", children: "TruBoard " }),
          e.jsx("span", {
            className: "leading-[48px]",
            children: "Technologies",
          }),
          e.jsx("span", { className: "leading-[48px]", children: " Trusted" }),
          e.jsx("span", { className: "leading-[48px]", children: " by" }),
        ],
      }),
      e.jsx("div", {
        className: "absolute h-0 left-[485px] top-[1861px] w-[17px]",
        children: e.jsx("div", {
          className: "absolute inset-[-7.36px_-5.88%_-7.36px_0]",
          children: e.jsx("svg", {
            className: "block size-full",
            fill: "none",
            preserveAspectRatio: "none",
            viewBox: "0 0 18 14.7279",
            children: e.jsx("path", {
              d: i.p2e313df0,
              fill: "var(--stroke-0, #F39130)",
              id: "Arrow 3",
            }),
          }),
        }),
      }),
    ],
  });
}
function w6() {
  return e.jsx("div", {
    className: "absolute inset-[67.09%_52.21%_30.39%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3f829200,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3d5ca100,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p33724a00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function k6() {
  return e.jsx("div", {
    className: "absolute inset-[67.09%_48.69%_30.39%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3e5c4740,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p32bf9400,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p28214700,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function N6() {
  return e.jsx("div", {
    className: "absolute inset-[71.58%_52.21%_25.9%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3e8cb100,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3aa5ae00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p28142300,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function Z6() {
  return e.jsx("div", {
    className: "absolute inset-[71.58%_48.69%_25.9%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2d4244b0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p25355d80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1c2e16c0,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function y6() {
  return e.jsx("div", {
    className: "absolute inset-[58.13%_52.21%_39.35%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3f829200,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p9802b00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p33724a00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function B6() {
  return e.jsx("div", {
    className: "absolute inset-[58.13%_48.69%_39.35%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3e5c4740,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3ad41980,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p28214700,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function E6() {
  return e.jsx("div", {
    className: "absolute inset-[62.61%_52.21%_34.86%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3e8cb100,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p140ae980,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p28142300,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function G6() {
  return e.jsx("div", {
    className: "absolute inset-[62.61%_48.69%_34.86%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2d4244b0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p21f09400,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1c2e16c0,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function A6() {
  return e.jsx("div", {
    className: "absolute inset-[49.17%_52.21%_48.31%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3e8cb100,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p30cb0680,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p33724a00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function D6() {
  return e.jsx("div", {
    className: "absolute inset-[49.17%_48.69%_48.31%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2d4244b0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p28bf7f00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p28214700,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function R6() {
  return e.jsx("div", {
    className: "absolute inset-[53.65%_52.21%_43.82%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3f829200,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pe258900,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p33724a00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function S6() {
  return e.jsx("div", {
    className: "absolute inset-[53.65%_48.69%_43.82%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3e5c4740,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3b39e00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p28214700,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function I6() {
  return e.jsx("div", {
    className: "absolute inset-[40.21%_52.21%_57.26%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3bb9d100,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p35f8a980,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3896ff00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function T6() {
  return e.jsx("div", {
    className: "absolute inset-[40.21%_48.69%_57.26%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p5669f00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2e52cb80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p26ded9f0,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function z6() {
  return e.jsx("div", {
    className: "absolute inset-[44.7%_52.21%_52.78%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3bb9d100,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1753a80,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p28142300,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function P6() {
  return e.jsx("div", {
    className: "absolute inset-[44.7%_48.69%_52.78%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p5669f00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p305a66f2,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1c2e16c0,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function H6() {
  return e.jsx("div", {
    className: "absolute inset-[23.96%_77.08%_57.26%_19.56%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 27.8226 161.843",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2a27c800,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p235f4ef0,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1e27bf00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.pc77aa40,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p2e61eb80,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_5",
          }),
          e.jsx("path", {
            d: i.p17a0c440,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_6",
          }),
          e.jsx("path", {
            d: i.p31d9ee80,
            fill: "var(--fill-0, #001A46)",
            id: "Vector_7",
          }),
          e.jsx("path", {
            d: i.p35825a00,
            fill: "var(--fill-0, #03336E)",
            id: "Vector_8",
          }),
          e.jsx("path", {
            d: i.p3f363170,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_9",
          }),
          e.jsx("path", {
            d: i.p2d08de00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_10",
          }),
          e.jsx("path", {
            d: i.p20b81300,
            fill: "var(--fill-0, #03336E)",
            id: "Vector_11",
          }),
          e.jsx("path", {
            d: i.p3fd5e780,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_12",
          }),
          e.jsx("path", {
            d: i.p30ff3970,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_13",
          }),
          e.jsx("path", {
            d: i.p16402400,
            fill: "var(--fill-0, #03336E)",
            id: "Vector_14",
          }),
        ],
      }),
    }),
  });
}
function W6() {
  return e.jsx("div", {
    className: "absolute inset-[6.86%_40.63%_87.82%_51.48%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 65.3889 45.8641",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p297b67c0,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1c658c00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p17e77000,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function O6() {
  return e.jsx("div", {
    className: "absolute inset-[5.69%_40.63%_88.99%_51.48%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 65.3889 45.8923",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p30d1d600,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1b8f9600,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1df8c480,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function U6() {
  return e.jsx("div", {
    className: "absolute inset-[4.54%_40.63%_90.13%_51.48%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 65.3889 45.8923",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3f0a3580,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p224c9a80,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3c4b8a80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function Q6() {
  return e.jsx("div", {
    className: "absolute inset-[3.35%_40.63%_91.32%_51.48%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 65.3889 45.8924",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p263cd080,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pa7c7e00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p17e77000,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function $6() {
  return e.jsxs("div", {
    className: "absolute contents inset-[3.35%_40.63%_87.82%_51.48%]",
    "data-name": "Group",
    children: [e.jsx(W6, {}), e.jsx(O6, {}), e.jsx(U6, {}), e.jsx(Q6, {})],
  });
}
function X6() {
  return e.jsx("div", {
    className: "absolute inset-[72.81%_43.89%_16.96%_39.37%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 138.747 88.1526",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p5e1aa80,
            fill: "var(--fill-0, #92B4D1)",
            id: "Vector",
            opacity: "0.2",
          }),
          e.jsx("path", {
            d: i.pae94800,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1f199900,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.pbc3e900,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p33283700,
            fill: "var(--fill-0, white)",
            id: "Vector_5",
          }),
          e.jsx("path", {
            d: i.p1fd30940,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_6",
          }),
          e.jsx("path", {
            d: i.p112a81f0,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_7",
          }),
          e.jsx("path", {
            d: i.p34796580,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_8",
          }),
          e.jsx("path", {
            d: i.p1b68f700,
            fill: "var(--fill-0, white)",
            id: "Vector_9",
          }),
        ],
      }),
    }),
  });
}
function Y6() {
  return e.jsx("div", {
    className: "absolute inset-[13.3%_52.21%_84.17%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p30796000,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pda91bf2,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3f2aba00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function K6() {
  return e.jsx("div", {
    className: "absolute inset-[17.8%_52.21%_79.67%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3bb9d100,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p38bd6400,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p33724a00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function J6() {
  return e.jsx("div", {
    className: "absolute inset-[22.28%_52.21%_75.19%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7918",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2d420400,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2e5fec00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p157ffe80,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function q6() {
  return e.jsx("div", {
    className: "absolute inset-[26.75%_52.21%_70.72%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3e8cb100,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pd84bd80,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3896ff00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function e5() {
  return e.jsx("div", {
    className: "absolute inset-[31.25%_52.21%_66.22%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3e8cb100,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p75bcc00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p33724a00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function t5() {
  return e.jsx("div", {
    className: "absolute inset-[35.74%_52.21%_61.74%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3bb9d100,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p33f7b200,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3896ff00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function l5() {
  return e.jsx("div", {
    className: "absolute inset-[8.83%_48.69%_88.64%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p5669f00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p34002200,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p26ded9f0,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function r5() {
  return e.jsx("div", {
    className: "absolute inset-[8.83%_52.21%_88.64%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3bb9d100,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1b209e00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3896ff00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function i5() {
  return e.jsx("div", {
    className: "absolute inset-[4.42%_55.25%_23.08%_43.74%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 8.36369 624.585",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2d618300,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3f827400,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p19533400,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function n5() {
  return e.jsx("div", {
    className: "absolute inset-[10.83%_52.21%_86.65%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p5669f00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3e84d100,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1ca17240,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function s5() {
  return e.jsx("div", {
    className: "absolute inset-[0.16%_39.98%_73.19%_17.61%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 351.556 229.658",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsxs("g", {
            id: "Group_2",
            children: [
              e.jsx("path", {
                d: i.p59a7780,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector",
              }),
              e.jsx("path", {
                d: i.p4a2be80,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_2",
              }),
              e.jsx("path", {
                d: i.p309c5c00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_3",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_3",
            children: [
              e.jsx("path", {
                d: i.p36968600,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_4",
              }),
              e.jsx("path", {
                d: i.p2d92cf00,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_5",
              }),
              e.jsx("path", {
                d: i.pd669280,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_6",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_4",
            children: [
              e.jsx("path", {
                d: i.p76ab400,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_7",
              }),
              e.jsx("path", {
                d: i.pca45c00,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_8",
              }),
              e.jsx("path", {
                d: i.p26e1fe00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_9",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_5",
            children: [
              e.jsx("path", {
                d: i.p18bf7900,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_10",
              }),
              e.jsx("path", {
                d: i.p12de5680,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_11",
              }),
              e.jsx("path", {
                d: i.p39d74c00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_12",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_6",
            children: [
              e.jsx("path", {
                d: i.p22c98080,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_13",
              }),
              e.jsx("path", {
                d: i.p23899a00,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_14",
              }),
              e.jsx("path", {
                d: i.pe7fb080,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_15",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_7",
            children: [
              e.jsx("path", {
                d: i.p354dfe80,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_16",
              }),
              e.jsx("path", {
                d: i.p3aa3d700,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_17",
              }),
              e.jsx("path", {
                d: i.p2ee6ec00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_18",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_8",
            children: [
              e.jsx("path", {
                d: i.p36a19400,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_19",
              }),
              e.jsx("path", {
                d: i.p1ec2d720,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_20",
              }),
              e.jsx("path", {
                d: i.p5625400,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_21",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_9",
            children: [
              e.jsx("path", {
                d: i.p3a824b00,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_22",
              }),
              e.jsx("path", {
                d: i.p4e93200,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_23",
              }),
              e.jsx("path", {
                d: i.p2317d900,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_24",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_10",
            children: [
              e.jsx("path", {
                d: i.p34322480,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_25",
              }),
              e.jsx("path", {
                d: i.p38698680,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_26",
              }),
              e.jsx("path", {
                d: i.p1a56be00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_27",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_11",
            children: [
              e.jsx("path", {
                d: i.pfae3700,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_28",
              }),
              e.jsx("path", {
                d: i.p21c42d80,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_29",
              }),
              e.jsx("path", {
                d: i.p1f8d4600,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_30",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_12",
            children: [
              e.jsx("path", {
                d: i.p3f1a6a00,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_31",
              }),
              e.jsx("path", {
                d: i.pb8b0000,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_32",
              }),
              e.jsx("path", {
                d: i.p3f987c00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_33",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_13",
            children: [
              e.jsx("path", {
                d: i.p2675700,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_34",
              }),
              e.jsx("path", {
                d: i.pfebc300,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_35",
              }),
              e.jsx("path", {
                d: i.p663e280,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_36",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_14",
            children: [
              e.jsx("path", {
                d: i.p1ccda00,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_37",
              }),
              e.jsx("path", {
                d: i.p5dc8380,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_38",
              }),
              e.jsx("path", {
                d: i.p185ea980,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_39",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_15",
            children: [
              e.jsx("path", {
                d: i.p3004e80,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_40",
              }),
              e.jsx("path", {
                d: i.p2b280c80,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_41",
              }),
              e.jsx("path", {
                d: i.p357c9cc0,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_42",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_16",
            children: [
              e.jsx("path", {
                d: i.p6a42600,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_43",
              }),
              e.jsx("path", {
                d: i.p2b13aa70,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_44",
              }),
              e.jsx("path", {
                d: i.p222ea600,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_45",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_17",
            children: [
              e.jsx("path", {
                d: i.p8371900,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_46",
              }),
              e.jsx("path", {
                d: i.p3ca0d600,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_47",
              }),
              e.jsx("path", {
                d: i.p32bcc600,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_48",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_18",
            children: [
              e.jsx("path", {
                d: i.p9b71b00,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_49",
              }),
              e.jsx("path", {
                d: i.p2d59300,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_50",
              }),
              e.jsx("path", {
                d: i.p6eee700,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_51",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_19",
            children: [
              e.jsx("path", {
                d: i.p3620ac00,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_52",
              }),
              e.jsx("path", {
                d: i.p3d9faef0,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_53",
              }),
              e.jsx("path", {
                d: i.pbed1c00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_54",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_20",
            children: [
              e.jsx("path", {
                d: i.p2c7ebf70,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_55",
              }),
              e.jsx("path", {
                d: i.pbc49380,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_56",
              }),
              e.jsx("path", {
                d: i.pfaa9900,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_57",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_21",
            children: [
              e.jsx("path", {
                d: i.pe06b900,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_58",
              }),
              e.jsx("path", {
                d: i.p23e58680,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_59",
              }),
              e.jsx("path", {
                d: i.p2524e7c0,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_60",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_22",
            children: [
              e.jsx("path", {
                d: i.p289ab400,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_61",
              }),
              e.jsx("path", {
                d: i.p2cacf180,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_62",
              }),
              e.jsx("path", {
                d: i.p2bab3680,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_63",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_23",
            children: [
              e.jsx("path", {
                d: i.p2f680180,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_64",
              }),
              e.jsx("path", {
                d: i.p3da22580,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_65",
              }),
              e.jsx("path", {
                d: i.p396da500,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_66",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_24",
            children: [
              e.jsx("path", {
                d: i.p3b214100,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_67",
              }),
              e.jsx("path", {
                d: i.p24482e80,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_68",
              }),
              e.jsx("path", {
                d: i.pb108600,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_69",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_25",
            children: [
              e.jsx("path", {
                d: i.p38814e10,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_70",
              }),
              e.jsx("path", {
                d: i.p31a15f00,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_71",
              }),
              e.jsx("path", {
                d: i.pf4e2bf0,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_72",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_26",
            children: [
              e.jsx("path", {
                d: i.p3528ca80,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_73",
              }),
              e.jsx("path", {
                d: i.p3810db00,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_74",
              }),
              e.jsx("path", {
                d: i.p17c7bd80,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_75",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_27",
            children: [
              e.jsx("path", {
                d: i.p2a0f0b00,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_76",
              }),
              e.jsx("path", {
                d: i.p26b8c970,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_77",
              }),
              e.jsx("path", {
                d: i.p1cecd580,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_78",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_28",
            children: [
              e.jsx("path", {
                d: i.paba8600,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_79",
              }),
              e.jsx("path", {
                d: i.p21478900,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_80",
              }),
              e.jsx("path", {
                d: i.p19278bc0,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_81",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_29",
            children: [
              e.jsx("path", {
                d: i.p29109270,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_82",
              }),
              e.jsx("path", {
                d: i.p319bed00,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_83",
              }),
              e.jsx("path", {
                d: i.p246a0500,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_84",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_30",
            children: [
              e.jsx("path", {
                d: i.pe2ebc80,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_85",
              }),
              e.jsx("path", {
                d: i.p1c0bef80,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_86",
              }),
              e.jsx("path", {
                d: i.pebe8040,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_87",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_31",
            children: [
              e.jsx("path", {
                d: i.p2d58d480,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_88",
              }),
              e.jsx("path", {
                d: i.p20580040,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_89",
              }),
              e.jsx("path", {
                d: i.p18403f00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_90",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_32",
            children: [
              e.jsx("path", {
                d: i.p1404ee40,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_91",
              }),
              e.jsx("path", {
                d: i.p2a5b1000,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_92",
              }),
            ],
          }),
          e.jsx("path", {
            d: i.p2c0b8900,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_93",
          }),
          e.jsxs("g", {
            id: "Group_33",
            children: [
              e.jsx("path", {
                d: i.p24878700,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_94",
              }),
              e.jsx("path", {
                d: i.p8177d00,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_95",
              }),
              e.jsx("path", {
                d: i.p28289f00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_96",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_34",
            children: [
              e.jsx("path", {
                d: i.p2c671600,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_97",
              }),
              e.jsx("path", {
                d: i.p35863680,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_98",
              }),
              e.jsx("path", {
                d: i.pec86500,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_99",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_35",
            children: [
              e.jsx("path", {
                d: i.p2055e500,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_100",
              }),
              e.jsx("path", {
                d: i.p2c4b3400,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_101",
              }),
              e.jsx("path", {
                d: i.p1a888c00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_102",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_36",
            children: [
              e.jsx("path", {
                d: i.pcb29c80,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_103",
              }),
              e.jsx("path", {
                d: i.p2f3c0300,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_104",
              }),
              e.jsx("path", {
                d: i.p1555f080,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_105",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_37",
            children: [
              e.jsx("path", {
                d: i.pdcd8180,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_106",
              }),
              e.jsx("path", {
                d: i.p12422e00,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_107",
              }),
              e.jsx("path", {
                d: i.p2fff8680,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_108",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_38",
            children: [
              e.jsx("path", {
                d: i.p3bdffe00,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_109",
              }),
              e.jsx("path", {
                d: i.p828e800,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_110",
              }),
              e.jsx("path", {
                d: i.pb716e00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_111",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_39",
            children: [
              e.jsx("path", {
                d: i.pd788b00,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_112",
              }),
              e.jsx("path", {
                d: i.p15fa3500,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_113",
              }),
              e.jsx("path", {
                d: i.p19254200,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_114",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_40",
            children: [
              e.jsx("path", {
                d: i.p294758c0,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_115",
              }),
              e.jsx("path", {
                d: i.p145d8400,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_116",
              }),
              e.jsx("path", {
                d: i.p25209b80,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_117",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_41",
            children: [
              e.jsx("path", {
                d: i.p11032c0,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_118",
              }),
              e.jsx("path", {
                d: i.p141cce00,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_119",
              }),
              e.jsx("path", {
                d: i.p2f479880,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_120",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_42",
            children: [
              e.jsx("path", {
                d: i.p19eaab80,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_121",
              }),
              e.jsx("path", {
                d: i.p3e2d9fc0,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_122",
              }),
              e.jsx("path", {
                d: i.p5f37d00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_123",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_43",
            children: [
              e.jsx("path", {
                d: i.p35a87000,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_124",
              }),
              e.jsx("path", {
                d: i.p100c3900,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_125",
              }),
              e.jsx("path", {
                d: i.p55714f0,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_126",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_44",
            children: [
              e.jsx("path", {
                d: i.p3a5d500,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_127",
              }),
              e.jsx("path", {
                d: i.pb2fe80,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_128",
              }),
              e.jsx("path", {
                d: i.p191e8d00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_129",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_45",
            children: [
              e.jsx("path", {
                d: i.p25367fc0,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_130",
              }),
              e.jsx("path", {
                d: i.p3e568e80,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_131",
              }),
              e.jsx("path", {
                d: i.pc83fa00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_132",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_46",
            children: [
              e.jsx("path", {
                d: i.p97f2380,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_133",
              }),
              e.jsx("path", {
                d: i.p32366540,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_134",
              }),
              e.jsx("path", {
                d: i.p24a80b00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_135",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_47",
            children: [
              e.jsx("path", {
                d: i.p333cd800,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_136",
              }),
              e.jsx("path", {
                d: i.pc2b8700,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_137",
              }),
              e.jsx("path", {
                d: i.p2274ef60,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_138",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_48",
            children: [
              e.jsx("path", {
                d: i.p2d4b3c80,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_139",
              }),
              e.jsx("path", {
                d: i.p39e90300,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_140",
              }),
              e.jsx("path", {
                d: i.p10b20b00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_141",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_49",
            children: [
              e.jsx("path", {
                d: i.p20cf700,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_142",
              }),
              e.jsx("path", {
                d: i.p2f3d9500,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_143",
              }),
              e.jsx("path", {
                d: i.p13af0600,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_144",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_50",
            children: [
              e.jsx("path", {
                d: i.p70aabf0,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_145",
              }),
              e.jsx("path", {
                d: i.p13568280,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_146",
              }),
              e.jsx("path", {
                d: i.p2183b700,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_147",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_51",
            children: [
              e.jsx("path", {
                d: i.p15de7200,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_148",
              }),
              e.jsx("path", {
                d: i.p7c75800,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_149",
              }),
              e.jsx("path", {
                d: i.p17787a00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_150",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_52",
            children: [
              e.jsx("path", {
                d: i.pc89f000,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_151",
              }),
              e.jsx("path", {
                d: i.p24a37280,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_152",
              }),
              e.jsx("path", {
                d: i.pd61cf80,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_153",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_53",
            children: [
              e.jsx("path", {
                d: i.p29322a00,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_154",
              }),
              e.jsx("path", {
                d: i.p298a5000,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_155",
              }),
              e.jsx("path", {
                d: i.p3b36bd00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_156",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_54",
            children: [
              e.jsx("path", {
                d: i.p8d0e620,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_157",
              }),
              e.jsx("path", {
                d: i.p335ca600,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_158",
              }),
              e.jsx("path", {
                d: i.p7ae3500,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_159",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_55",
            children: [
              e.jsx("path", {
                d: i.p1496b000,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_160",
              }),
              e.jsx("path", {
                d: i.p2a111700,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_161",
              }),
              e.jsx("path", {
                d: i.p18d92200,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_162",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_56",
            children: [
              e.jsx("path", {
                d: i.p14cf4d00,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_163",
              }),
              e.jsx("path", {
                d: i.p250c6600,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_164",
              }),
              e.jsx("path", {
                d: i.p289d0800,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_165",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_57",
            children: [
              e.jsx("path", {
                d: i.p1d1c8bb0,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_166",
              }),
              e.jsx("path", {
                d: i.p299a0450,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_167",
              }),
              e.jsx("path", {
                d: i.pc45ee00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_168",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_58",
            children: [
              e.jsx("path", {
                d: i.p14736580,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_169",
              }),
              e.jsx("path", {
                d: i.p306a6c00,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_170",
              }),
              e.jsx("path", {
                d: i.p1f4cd000,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_171",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_59",
            children: [
              e.jsx("path", {
                d: i.p28289380,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_172",
              }),
              e.jsx("path", {
                d: i.p35a59700,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_173",
              }),
              e.jsx("path", {
                d: i.p3affdb00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_174",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_60",
            children: [
              e.jsx("path", {
                d: i.p2e0e8180,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_175",
              }),
              e.jsx("path", {
                d: i.p710ce00,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_176",
              }),
            ],
          }),
        ],
      }),
    }),
  });
}
function a5() {
  return e.jsx("div", {
    className: "absolute inset-[0.6%_51.73%_60.55%_47.27%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 8.3637 334.732",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p8068c00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.peb54b00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3def9400,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function o5() {
  return e.jsx("div", {
    className: "absolute inset-[13.3%_48.69%_84.17%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p20f5fb00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1f4110f0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p45bd80,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function d5() {
  return e.jsx("div", {
    className: "absolute inset-[17.8%_48.69%_79.67%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p5669f00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pa971340,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p28214700,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function c5() {
  return e.jsx("div", {
    className: "absolute inset-[22.28%_48.69%_75.19%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7918",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2f5e1780,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p25e3bd00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p18a4e00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function p5() {
  return e.jsx("div", {
    className: "absolute inset-[26.75%_48.69%_70.72%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2d4244b0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3bf09300,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p26ded9f0,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function f5() {
  return e.jsx("div", {
    className: "absolute inset-[31.25%_48.69%_66.22%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2d4244b0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3bb0780,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p28214700,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function u5() {
  return e.jsx("div", {
    className: "absolute inset-[35.74%_48.69%_61.74%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p5669f00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p397e6e00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p26ded9f0,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function x5() {
  return e.jsx("div", {
    className: "absolute inset-[2.52%_48.19%_23.08%_50.81%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 8.36377 641.028",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2f609000,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p9efe330,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1277c900,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function h5() {
  return e.jsx("div", {
    className: "absolute inset-[73.57%_48.69%_23.91%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7919",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2a84bc00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p145db100,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pe381980,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function v5() {
  return e.jsx("div", {
    className: "absolute inset-[69.68%_48.69%_24.47%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3485 50.4041",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p29972e00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3a2d5900,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2a622180,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function L5() {
  return e.jsx("div", {
    className: "absolute inset-[69.08%_48.69%_28.39%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1b83fb80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p33cc9500,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p9ebd200,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function j5() {
  return e.jsx("div", {
    className: "absolute inset-[65.19%_48.69%_28.96%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 50.3689",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.pa799980,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p336ec200,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p313abf80,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function V5() {
  return e.jsx("div", {
    className: "absolute inset-[64.61%_48.69%_32.87%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p161f4f00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p34dcbb80,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p9ebd200,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function m5() {
  return e.jsx("div", {
    className: "absolute inset-[60.72%_48.69%_33.43%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 50.3688",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1b63b80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p25298c00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p313abf80,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function g5() {
  return e.jsx("div", {
    className: "absolute inset-[60.12%_48.69%_37.35%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3b41dd80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3c846980,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p9ebd200,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function _5() {
  return e.jsx("div", {
    className: "absolute inset-[56.23%_48.69%_37.92%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 50.3688",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1b63b80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1c10f180,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p36b9f6f0,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function b5() {
  return e.jsx("div", {
    className: "absolute inset-[55.64%_48.69%_41.83%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1eb4f80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2a5c8d00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pa5badf0,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function F5() {
  return e.jsx("div", {
    className: "absolute inset-[51.75%_48.69%_42.4%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 50.3971",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p443c300,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p170ea2c0,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1fdfa000,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function M5() {
  return e.jsx("div", {
    className: "absolute inset-[51.16%_48.69%_46.32%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1b83fb80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p289b300,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p20a12a00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function C5() {
  return e.jsx("div", {
    className: "absolute inset-[47.27%_48.69%_46.88%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 50.397",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p14cff680,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pcac8500,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1fb4eb00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function w5() {
  return e.jsx("div", {
    className: "absolute inset-[46.69%_48.69%_50.79%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p33193a70,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p39ae5000,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p9ebd200,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function k5() {
  return e.jsx("div", {
    className: "absolute inset-[73.57%_52.21%_23.91%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7919",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p30e2d500,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pffe0380,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3539d100,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function N5() {
  return e.jsx("div", {
    className: "absolute inset-[69.66%_52.21%_23.91%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 55.4367",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.pf9f4fd0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p22e08080,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2b4a9d40,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function Z5() {
  return e.jsx("div", {
    className: "absolute inset-[69.08%_52.21%_28.39%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3e5c4740,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2c5ed9f0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1ca17240,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function y5() {
  return e.jsx("div", {
    className: "absolute inset-[65.17%_52.21%_28.39%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 55.4368",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p649ff00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3b878e80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p91e8500,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function B5() {
  return e.jsx("div", {
    className: "absolute inset-[64.61%_52.21%_32.87%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p10d9ad80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p19fe0840,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1ca17240,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function E5() {
  return e.jsx("div", {
    className: "absolute inset-[60.7%_52.21%_32.87%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 55.4367",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3d459b80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p10d1b200,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2b4a9d40,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function G5() {
  return e.jsx("div", {
    className: "absolute inset-[60.12%_52.21%_37.35%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2d4244b0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3c75bc00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1ca17240,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function A5() {
  return e.jsx("div", {
    className: "absolute inset-[56.21%_52.21%_37.35%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 55.4368",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2c83b380,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p93a9f00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p91e8500,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function D5() {
  return e.jsx("div", {
    className: "absolute inset-[42.8%_48.69%_51.35%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 50.3969",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2c3e680,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2df86e80,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1ee0cc00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function R5() {
  return e.jsx("div", {
    className: "absolute inset-[55.64%_52.21%_41.83%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p318a6700,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.padc200,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p12b32820,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function S5() {
  return e.jsx("div", {
    className: "absolute inset-[51.74%_52.21%_41.83%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 55.4367",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.pf9f4fd0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.ped51400,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p9cf1500,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function I5() {
  return e.jsx("div", {
    className: "absolute inset-[51.16%_52.21%_46.32%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3e5c4740,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1c24f280,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3b9e8fc0,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function T5() {
  return e.jsx("div", {
    className: "absolute inset-[42.2%_48.69%_55.27%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3b41dd80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2de3080,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2ac66f00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function z5() {
  return e.jsx("div", {
    className: "absolute inset-[38.31%_48.69%_55.84%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 50.397",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3ac92100,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2d51dd00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1ee0cc00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function P5() {
  return e.jsx("div", {
    className: "absolute inset-[47.25%_52.21%_46.32%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 55.4086",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p50c0a00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p35461bc0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1b947000,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function H5() {
  return e.jsx("div", {
    className: "absolute inset-[37.73%_48.69%_59.75%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p271fcf00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p359c3280,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p17b33000,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function W5() {
  return e.jsx("div", {
    className: "absolute inset-[33.84%_48.69%_60.31%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 50.397",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p14cff680,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p30a8d480,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1ee0cc00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function O5() {
  return e.jsx("div", {
    className: "absolute inset-[46.69%_52.21%_50.79%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p5669f00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p312ffef0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1ca17240,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function U5() {
  return e.jsx("div", {
    className: "absolute inset-[42.78%_52.21%_50.79%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 55.4368",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p18162800,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pa8a0100,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p156d5d00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function Q5() {
  return e.jsx("div", {
    className: "absolute inset-[42.2%_52.21%_55.27%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2d4244b0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3e2c1500,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p22094680,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function $5() {
  return e.jsx("div", {
    className: "absolute inset-[38.29%_52.21%_55.27%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 55.4086",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p32820000,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p30abc480,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1b947000,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function X5() {
  return e.jsx("div", {
    className: "absolute inset-[33.25%_48.69%_64.23%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7918",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1f9b1b00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p7bd6e80,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pe381980,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function Y5() {
  return e.jsx("div", {
    className: "absolute inset-[37.73%_52.21%_59.75%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p355b9680,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2d52baf0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2fa52f40,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function K5() {
  return e.jsx("div", {
    className: "absolute inset-[33.82%_52.21%_59.75%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 55.4086",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p88b7b40,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2dbf2c00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p18dc0a00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function J5() {
  return e.jsx("div", {
    className: "absolute inset-[33.25%_52.21%_64.23%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7918",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2f5e1780,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p25e3bd00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3539d100,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function q5() {
  return e.jsx("div", {
    className: "absolute inset-[28.8%_52.21%_64.76%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 55.4367",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.pf9f4fd0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2d18300,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p91e8500,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function eo() {
  return e.jsx("div", {
    className: "absolute inset-[28.75%_52.21%_68.73%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p5669f00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2f0c0c00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2d295a00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function to() {
  return e.jsx("div", {
    className: "absolute inset-[15.29%_48.69%_82.18%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p4cb1700,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pe4c7a00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p9ebd200,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function lo() {
  return e.jsx("div", {
    className: "absolute inset-[15.29%_52.21%_82.18%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p9ab6e10,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3bf09300,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1ca17240,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function ro() {
  return e.jsx("div", {
    className: "absolute inset-[10.83%_48.69%_86.65%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p33193a70,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p13fe1700,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p9ebd200,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function io() {
  return e.jsx("div", {
    className: "absolute inset-[0_51.7%_98.15%_46.03%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 18.7831 15.9637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p7d34880,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p11a66500,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p29189980,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function no() {
  return e.jsx("div", {
    className: "absolute inset-[1.02%_52.95%_95.02%_43.74%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 27.4285 34.1236",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.pd59e80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p103b2000,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
        ],
      }),
    }),
  });
}
function so() {
  return e.jsx("div", {
    className: "absolute inset-[0.3%_48.69%_97.17%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p5669f00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p34002200,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p28214700,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function ao() {
  return e.jsx("div", {
    className: "absolute inset-[4.7%_52.19%_92.77%_44.27%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p5669f00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3f09a300,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3abc7000,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function oo() {
  return e.jsx("div", {
    className: "absolute inset-[24.29%_52.21%_69.27%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 55.4367",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p23db8980,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1f6ac980,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2b4a9d40,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function co() {
  return e.jsx("div", {
    className: "absolute inset-[24.28%_52.21%_73.2%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p9ab6e10,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p34002200,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p143c0800,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function po() {
  return e.jsx("div", {
    className: "absolute inset-[19.82%_52.21%_73.75%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 55.4367",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p23db8980,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2f55ab72,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p91e8500,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function fo() {
  return e.jsx("div", {
    className: "absolute inset-[19.79%_52.21%_77.68%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p5669f00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p20254000,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1ca17240,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function uo() {
  return e.jsx("div", {
    className: "absolute inset-[15.37%_52.21%_78.19%_44.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 55.4367",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p19314b80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3c86a300,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2b4a9d40,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function xo() {
  return e.jsx("div", {
    className: "absolute inset-[29.36%_48.69%_64.79%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 50.3689",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3be78e80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p105f6c00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p313abf80,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function ho() {
  return e.jsx("div", {
    className: "absolute inset-[28.75%_48.69%_68.73%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p33193a70,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2f20f940,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pb5b2400,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function vo() {
  return e.jsx("div", {
    className: "absolute inset-[24.87%_48.68%_69.27%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3522 50.4089",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p189a3500,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1890e900,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p388cb400,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function Lo() {
  return e.jsx("div", {
    className: "absolute inset-[24.28%_48.69%_73.2%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p4cb1700,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2b6fe370,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p32f19380,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function jo() {
  return e.jsx("div", {
    className: "absolute inset-[20.39%_48.69%_73.76%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3439 50.4081",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.pc776700,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p261b9000,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2ac8c600,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function Vo() {
  return e.jsx("div", {
    className: "absolute inset-[19.79%_48.69%_77.68%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 21.7636",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p33193a70,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p26b0370,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p9ebd200,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function mo() {
  return e.jsx("div", {
    className: "absolute inset-[15.93%_48.69%_78.22%_47.77%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3433 50.3688",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p26ecd000,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2c9ab900,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p313abf80,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function go() {
  return e.jsx("div", {
    className: "absolute inset-[6.4%_51.73%_21.11%_47.27%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 8.3637 624.557",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p24a80c40,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pdfe8040,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p277b1d00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function _o() {
  return e.jsx("div", {
    className: "absolute inset-[6.83%_46.37%_81.28%_43.25%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 86.0585 102.455",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1ab5de00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p32268ae0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p291f6900,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p23e7ae00,
            fill: "var(--fill-0, #001A46)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.pf5bedb0,
            fill: "var(--fill-0, #03336E)",
            id: "Vector_5",
          }),
          e.jsx("path", {
            d: i.p2d78d00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_6",
          }),
          e.jsx("path", {
            d: i.p16f5be00,
            fill: "var(--fill-0, white)",
            id: "Vector_7",
          }),
          e.jsx("path", {
            d: i.p35db2a00,
            fill: "var(--fill-0, #03336E)",
            id: "Vector_8",
          }),
          e.jsx("path", {
            d: i.p27762b00,
            fill: "var(--fill-0, #001A46)",
            id: "Vector_9",
          }),
        ],
      }),
    }),
  });
}
function bo() {
  return e.jsx("div", {
    className: "absolute inset-[1.01%_49.93%_96.46%_46.54%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 29.3434 21.7637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p5669f00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p34002200,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pf777400,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function Fo() {
  return e.jsx("div", {
    className: "absolute inset-[1.96%_48.19%_96.19%_49.54%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 18.7831 15.9637",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1f0d51a0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p7227f0,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p98bc300,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function Mo() {
  return e.jsx("div", {
    className: "absolute inset-[2.98%_49.45%_93.04%_47.23%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 27.4847 34.2925",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p33bbfbb1,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p13b83180,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_2",
          }),
        ],
      }),
    }),
  });
}
function Co() {
  return e.jsx("div", {
    className: "absolute inset-[42.18%_77.36%_51.86%_19.35%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 27.2875 51.3543",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3adf5d00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p30c9b580,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p302b8c80,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p83e1200,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p38341d80,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function wo() {
  return e.jsxs("div", {
    className: "absolute contents inset-[0_39.98%_16.96%_17.61%]",
    "data-name": "Group",
    children: [
      e.jsx(w6, {}),
      e.jsx(k6, {}),
      e.jsx(N6, {}),
      e.jsx(Z6, {}),
      e.jsx(y6, {}),
      e.jsx(B6, {}),
      e.jsx(E6, {}),
      e.jsx(G6, {}),
      e.jsx(A6, {}),
      e.jsx(D6, {}),
      e.jsx(R6, {}),
      e.jsx(S6, {}),
      e.jsx(I6, {}),
      e.jsx(T6, {}),
      e.jsx(z6, {}),
      e.jsx(P6, {}),
      e.jsx(H6, {}),
      e.jsx($6, {}),
      e.jsx(X6, {}),
      e.jsx(Y6, {}),
      e.jsx(K6, {}),
      e.jsx(J6, {}),
      e.jsx(q6, {}),
      e.jsx(e5, {}),
      e.jsx(t5, {}),
      e.jsx(l5, {}),
      e.jsx(r5, {}),
      e.jsx(i5, {}),
      e.jsx(n5, {}),
      e.jsx(s5, {}),
      e.jsx(a5, {}),
      e.jsx(o5, {}),
      e.jsx(d5, {}),
      e.jsx(c5, {}),
      e.jsx(p5, {}),
      e.jsx(f5, {}),
      e.jsx(u5, {}),
      e.jsx(x5, {}),
      e.jsx(h5, {}),
      e.jsx(v5, {}),
      e.jsx(L5, {}),
      e.jsx(j5, {}),
      e.jsx(V5, {}),
      e.jsx(m5, {}),
      e.jsx(g5, {}),
      e.jsx(_5, {}),
      e.jsx(b5, {}),
      e.jsx(F5, {}),
      e.jsx(M5, {}),
      e.jsx(C5, {}),
      e.jsx(w5, {}),
      e.jsx(k5, {}),
      e.jsx(N5, {}),
      e.jsx(Z5, {}),
      e.jsx(y5, {}),
      e.jsx(B5, {}),
      e.jsx(E5, {}),
      e.jsx(G5, {}),
      e.jsx(A5, {}),
      e.jsx(D5, {}),
      e.jsx(R5, {}),
      e.jsx(S5, {}),
      e.jsx(I5, {}),
      e.jsx(T5, {}),
      e.jsx(z5, {}),
      e.jsx(P5, {}),
      e.jsx(H5, {}),
      e.jsx(W5, {}),
      e.jsx(O5, {}),
      e.jsx(U5, {}),
      e.jsx(Q5, {}),
      e.jsx($5, {}),
      e.jsx(X5, {}),
      e.jsx(Y5, {}),
      e.jsx(K5, {}),
      e.jsx(J5, {}),
      e.jsx(q5, {}),
      e.jsx(eo, {}),
      e.jsx(to, {}),
      e.jsx(lo, {}),
      e.jsx(ro, {}),
      e.jsx(io, {}),
      e.jsx(no, {}),
      e.jsx(so, {}),
      e.jsx(ao, {}),
      e.jsx(oo, {}),
      e.jsx(co, {}),
      e.jsx(po, {}),
      e.jsx(fo, {}),
      e.jsx(uo, {}),
      e.jsx(xo, {}),
      e.jsx(ho, {}),
      e.jsx(vo, {}),
      e.jsx(Lo, {}),
      e.jsx(jo, {}),
      e.jsx(Vo, {}),
      e.jsx(mo, {}),
      e.jsx(go, {}),
      e.jsx(_o, {}),
      e.jsx(bo, {}),
      e.jsx(Fo, {}),
      e.jsx(Mo, {}),
      e.jsx(Co, {}),
      e.jsx("div", {
        className: "absolute inset-[36.44%_77.43%_55.92%_20.95%]",
        "data-name": "Vector",
        children: e.jsx("svg", {
          className: "absolute block inset-0",
          fill: "none",
          preserveAspectRatio: "none",
          viewBox: "0 0 13.3939 65.759",
          children: e.jsx("path", {
            d: i.p373b1c80,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector",
          }),
        }),
      }),
    ],
  });
}
function ko() {
  return e.jsx("div", {
    className: "absolute inset-[18.32%_30.62%_39.26%_53.4%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 132.495 365.449",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p117b2580,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2cfb6100,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_2",
          }),
          e.jsxs("g", {
            id: "Group_2",
            children: [
              e.jsx("path", {
                d: i.p1e26bc80,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_3",
              }),
              e.jsx("path", {
                d: i.p1d632c80,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_4",
              }),
              e.jsx("path", {
                d: i.p33990140,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_5",
              }),
              e.jsx("path", {
                d: i.p3d843a80,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_6",
              }),
              e.jsx("path", {
                d: i.p1ab55000,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_7",
              }),
              e.jsx("path", {
                d: i.p3145c00,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_8",
              }),
              e.jsx("path", {
                d: i.p20eb3e80,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_9",
              }),
              e.jsx("path", {
                d: i.p3a748900,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_10",
              }),
              e.jsx("path", {
                d: i.p181aa200,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_11",
              }),
              e.jsx("path", {
                d: i.p3e078e80,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_12",
              }),
              e.jsx("path", {
                d: i.p2ebfac00,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_13",
              }),
              e.jsx("path", {
                d: i.p461f000,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_14",
              }),
              e.jsx("path", {
                d: i.p16a61f80,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_15",
              }),
              e.jsx("path", {
                d: i.p398ea300,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_16",
              }),
              e.jsx("path", {
                d: i.p38e01d80,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_17",
              }),
              e.jsx("path", {
                d: i.p165a1bf0,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_18",
              }),
              e.jsx("path", {
                d: i.p15efbb80,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_19",
              }),
              e.jsx("path", {
                d: i.p3f66d730,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_20",
              }),
              e.jsx("path", {
                d: i.p23c96f40,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_21",
              }),
              e.jsx("path", {
                d: i.p2482d800,
                fill: "var(--fill-0, #084C94)",
                id: "Vector_22",
              }),
            ],
          }),
          e.jsx("path", {
            d: i.p6794900,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_23",
          }),
          e.jsxs("g", {
            id: "Group_3",
            children: [
              e.jsx("path", {
                d: i.p3234a700,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_24",
              }),
              e.jsx("path", {
                d: i.p11351700,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_25",
              }),
              e.jsx("path", {
                d: i.p3151f500,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_26",
              }),
              e.jsx("path", {
                d: i.p31a1c100,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_27",
              }),
              e.jsx("path", {
                d: i.p3cf01600,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_28",
              }),
              e.jsx("path", {
                d: i.p3c03a8c0,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_29",
              }),
              e.jsx("path", {
                d: i.p20826600,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_30",
              }),
              e.jsx("path", {
                d: i.p1720a500,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_31",
              }),
              e.jsx("path", {
                d: i.p24f0a8d0,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_32",
              }),
              e.jsx("path", {
                d: i.p2df4700,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_33",
              }),
              e.jsx("path", {
                d: i.p32b8d580,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_34",
              }),
              e.jsx("path", {
                d: i.pc3b3b00,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_35",
              }),
              e.jsx("path", {
                d: i.p16083f0,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_36",
              }),
              e.jsx("path", {
                d: i.p363c19f0,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_37",
              }),
              e.jsx("path", {
                d: i.p166b4180,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_38",
              }),
              e.jsx("path", {
                d: i.p12bf7980,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_39",
              }),
              e.jsx("path", {
                d: i.pe745280,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_40",
              }),
              e.jsx("path", {
                d: i.p2b2f9f20,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_41",
              }),
              e.jsx("path", {
                d: i.p2718dd30,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_42",
              }),
              e.jsx("path", {
                d: i.p13a64380,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_43",
              }),
            ],
          }),
        ],
      }),
    }),
  });
}
function No() {
  return e.jsx("div", {
    className: "absolute inset-[19.02%_33.37%_74.27%_56.17%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 86.7625 57.7736",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3c9e00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p13667100,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3b124d80,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.pf9b0b00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.pfe3b480,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function Zo() {
  return e.jsx("div", {
    className: "absolute inset-[18.92%_36.01%_76.61%_58.81%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 42.9448 38.572",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p34124300,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p27158d00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3b3cb870,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p29624900,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p4370a00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function yo() {
  return e.jsxs("div", {
    className: "absolute contents inset-[18.32%_30.62%_39.26%_53.4%]",
    "data-name": "Group",
    children: [e.jsx(ko, {}), e.jsx(No, {}), e.jsx(Zo, {})],
  });
}
function Bo() {
  return e.jsx("div", {
    className: "absolute inset-[20.85%_33.18%_36.89%_65.88%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 7.77232 364.125",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1968c6f0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1feb2a00,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_2",
          }),
        ],
      }),
    }),
  });
}
function Eo() {
  return e.jsx("div", {
    className: "absolute inset-[21.83%_31.25%_35.91%_67.81%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 7.77228 364.125",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2971ccf0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p14bb7000,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_2",
          }),
        ],
      }),
    }),
  });
}
function Go() {
  return e.jsx("div", {
    className: "absolute inset-[22.81%_29.31%_34.93%_69.75%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 7.77228 364.125",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2971ccf0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p14bb7000,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_2",
          }),
        ],
      }),
    }),
  });
}
function Ao() {
  return e.jsx("div", {
    className: "absolute inset-[23.78%_27.38%_33.95%_71.69%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 7.77228 364.154",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p34f29000,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p19364d80,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_2",
          }),
        ],
      }),
    }),
  });
}
function Do() {
  return e.jsxs("div", {
    className: "absolute contents inset-[20.85%_27.38%_33.95%_65.88%]",
    "data-name": "Group",
    children: [e.jsx(Bo, {}), e.jsx(Eo, {}), e.jsx(Go, {}), e.jsx(Ao, {})],
  });
}
function Ro() {
  return e.jsx("div", {
    className: "absolute inset-[20.85%_18.83%_36.89%_80.24%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 7.77232 364.125",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p53cec00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2534d00,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_2",
          }),
        ],
      }),
    }),
  });
}
function So() {
  return e.jsx("div", {
    className: "absolute inset-[21.83%_20.76%_35.91%_78.3%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 7.77228 364.125",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3f778400,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p29532d00,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_2",
          }),
        ],
      }),
    }),
  });
}
function Io() {
  return e.jsx("div", {
    className: "absolute inset-[22.81%_22.7%_34.93%_76.36%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 7.77228 364.125",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3f778400,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p29532d00,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_2",
          }),
        ],
      }),
    }),
  });
}
function To() {
  return e.jsx("div", {
    className: "absolute inset-[23.78%_24.63%_33.95%_74.43%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 7.77228 364.154",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p298c6c00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1b300f80,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_2",
          }),
        ],
      }),
    }),
  });
}
function zo() {
  return e.jsxs("div", {
    className: "absolute contents inset-[20.85%_18.83%_33.95%_74.43%]",
    "data-name": "Group",
    children: [e.jsx(Ro, {}), e.jsx(So, {}), e.jsx(Io, {}), e.jsx(To, {})],
  });
}
function Po() {
  return e.jsxs("div", {
    className: "absolute contents inset-[11.93%_17.83%_32.27%_64.88%]",
    "data-name": "Group",
    children: [
      e.jsx("div", {
        className: "absolute inset-[16.75%_26.41%_32.27%_64.88%]",
        "data-name": "Vector",
        children: e.jsx("svg", {
          className: "absolute block inset-0",
          fill: "none",
          preserveAspectRatio: "none",
          viewBox: "0 0 72.1754 439.27",
          children: e.jsx("path", {
            d: i.p1746a600,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector",
          }),
        }),
      }),
      e.jsx("div", {
        className: "absolute inset-[16.75%_17.83%_32.27%_73.59%]",
        "data-name": "Vector",
        children: e.jsx("svg", {
          className: "absolute block inset-0",
          fill: "none",
          preserveAspectRatio: "none",
          viewBox: "0 0 71.1616 439.214",
          children: e.jsx("path", {
            d: i.p3e04dd00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
        }),
      }),
      e.jsx("div", {
        className: "absolute inset-[16.75%_26.41%_76.48%_64.88%]",
        "data-name": "Vector",
        children: e.jsx("svg", {
          className: "absolute block inset-0",
          fill: "none",
          preserveAspectRatio: "none",
          viewBox: "0 0 72.1754 58.3648",
          children: e.jsx("path", {
            d: i.p2ea22900,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
        }),
      }),
      e.jsx("div", {
        className: "absolute inset-[16.75%_17.83%_76.48%_73.59%]",
        "data-name": "Vector",
        children: e.jsx("svg", {
          className: "absolute block inset-0",
          fill: "none",
          preserveAspectRatio: "none",
          viewBox: "0 0 71.1616 58.3085",
          children: e.jsx("path", {
            d: i.pa0a5600,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
        }),
      }),
      e.jsx("div", {
        className: "absolute inset-[11.93%_17.83%_78.44%_64.88%]",
        "data-name": "Vector",
        children: e.jsx("svg", {
          className: "absolute block inset-0",
          fill: "none",
          preserveAspectRatio: "none",
          viewBox: "0 0 143.309 82.9721",
          children: e.jsx("path", {
            d: i.p3cafda80,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector",
          }),
        }),
      }),
      e.jsx(Do, {}),
      e.jsx(zo, {}),
    ],
  });
}
function Ho() {
  return e.jsx("div", {
    className: "absolute inset-[10.22%_21.09%_80%_68.14%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 89.2971 84.2672",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p34560180,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1a989080,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_2",
          }),
          e.jsxs("g", {
            id: "Group_2",
            children: [
              e.jsx("path", {
                d: i.p20ae0100,
                fill: "var(--fill-0, #3F92D1)",
                id: "Vector_3",
              }),
              e.jsx("path", {
                d: i.p2268f500,
                fill: "var(--fill-0, #3F92D1)",
                id: "Vector_4",
              }),
              e.jsx("path", {
                d: i.p224da4b0,
                fill: "var(--fill-0, #3F92D1)",
                id: "Vector_5",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_3",
            children: [
              e.jsx("path", {
                d: i.p22a59e00,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_6",
              }),
              e.jsx("path", {
                d: i.p1d7b3680,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_7",
              }),
              e.jsx("path", {
                d: i.p2f335580,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_8",
              }),
            ],
          }),
          e.jsx("path", {
            d: i.p3ef5e800,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_9",
          }),
        ],
      }),
    }),
  });
}
function Wo() {
  return e.jsx("div", {
    className: "absolute inset-[10.61%_23.69%_85.18%_70.74%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 46.2115 36.2633",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p23f21980,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2669e880,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1af88c00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function Oo() {
  return e.jsxs("div", {
    className: "absolute contents inset-[9.01%_17.83%_32.27%_64.88%]",
    "data-name": "Group",
    children: [
      e.jsx(Po, {}),
      e.jsx(Ho, {}),
      e.jsx(Wo, {}),
      e.jsx("div", {
        className: "absolute inset-[9.01%_26.47%_87.13%_72.29%]",
        "data-name": "Vector",
        children: e.jsx("svg", {
          className: "absolute block inset-0",
          fill: "none",
          preserveAspectRatio: "none",
          viewBox: "0 0 10.3349 33.2789",
          children: e.jsx("path", {
            d: i.pbf97ce0,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
        }),
      }),
      e.jsx("div", {
        className: "absolute inset-[9.01%_25.24%_87.13%_73.53%]",
        "data-name": "Vector",
        children: e.jsx("svg", {
          className: "absolute block inset-0",
          fill: "none",
          preserveAspectRatio: "none",
          viewBox: "0 0 10.1941 33.2789",
          children: e.jsx("path", {
            d: i.p164e7700,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
        }),
      }),
    ],
  });
}
function Uo() {
  return e.jsx("div", {
    className: "absolute inset-[36.28%_3.6%_24.27%_79.72%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 138.268 339.856",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1e41ec80,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3e55bf00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p22d08000,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function Qo() {
  return e.jsx("div", {
    className: "absolute inset-[42.48%_4.36%_25.11%_89.6%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 50.0694 279.183",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1e281180,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2321fc00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p12ad4080,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p1e7c9100,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p3f09ed40,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_5",
          }),
          e.jsx("path", {
            d: i.pd917700,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_6",
          }),
          e.jsx("path", {
            d: i.p21177600,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_7",
          }),
          e.jsx("path", {
            d: i.p20d8d300,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_8",
          }),
          e.jsx("path", {
            d: i.p456a100,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_9",
          }),
          e.jsx("path", {
            d: i.p1c7d0c00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_10",
          }),
        ],
      }),
    }),
  });
}
function $o() {
  return e.jsx("div", {
    className: "absolute inset-[42.48%_4.36%_25.11%_89.6%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 50.0694 279.183",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p214b4390,
            fill: "var(--fill-0, #084C94)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p18346b50,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p21117880,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.pcfdb680,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p11426b00,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_5",
          }),
          e.jsx("path", {
            d: i.p50fd780,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_6",
          }),
          e.jsx("path", {
            d: i.p11bde100,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_7",
          }),
          e.jsx("path", {
            d: i.p704c00,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_8",
          }),
          e.jsx("path", {
            d: i.p1b215e00,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_9",
          }),
          e.jsx("path", {
            d: i.p2f7d8f00,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_10",
          }),
          e.jsx("path", {
            d: i.p7b51400,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_11",
          }),
          e.jsx("path", {
            d: i.pd0c71f0,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_12",
          }),
          e.jsx("path", {
            d: i.pd2a1570,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_13",
          }),
          e.jsx("path", {
            d: i.p16489f00,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_14",
          }),
          e.jsx("path", {
            d: i.p1a2140c0,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_15",
          }),
          e.jsx("path", {
            d: i.p3a92a700,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_16",
          }),
          e.jsx("path", {
            d: i.pc0cf280,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_17",
          }),
          e.jsx("path", {
            d: i.p191cb00,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_18",
          }),
          e.jsx("path", {
            d: i.p38d0f100,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_19",
          }),
          e.jsx("path", {
            d: i.p21d81e00,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_20",
          }),
          e.jsx("path", {
            d: i.p8fc7000,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_21",
          }),
          e.jsx("path", {
            d: i.p28226980,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_22",
          }),
        ],
      }),
    }),
  });
}
function Xo() {
  return e.jsx("div", {
    className: "absolute inset-[42.48%_12.78%_25.7%_80.52%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 55.5607 274.171",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p21ddeb00,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3501f0c0,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p30e0cd70,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p3797c600,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p37cc9780,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_5",
          }),
          e.jsx("path", {
            d: i.p3c2fd6f0,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_6",
          }),
          e.jsx("path", {
            d: i.p1a246e00,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_7",
          }),
        ],
      }),
    }),
  });
}
function Yo() {
  return e.jsx("div", {
    className: "absolute inset-[42.48%_12.78%_25.7%_80.52%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 55.5607 274.143",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p37b63000,
            fill: "var(--fill-0, #084C94)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1589c600,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1119bc00,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p11079380,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p2b306100,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_5",
          }),
          e.jsx("path", {
            d: i.p34aa080,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_6",
          }),
          e.jsx("path", {
            d: i.p254f7900,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_7",
          }),
          e.jsx("path", {
            d: i.p1d920a00,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_8",
          }),
          e.jsx("path", {
            d: i.p2872cf00,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_9",
          }),
          e.jsx("path", {
            d: i.p24c2f800,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_10",
          }),
          e.jsx("path", {
            d: i.p1e41a000,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_11",
          }),
          e.jsx("path", {
            d: i.p1c3e4800,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_12",
          }),
          e.jsx("path", {
            d: i.p3ecce4f0,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_13",
          }),
          e.jsx("path", {
            d: i.p19face00,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_14",
          }),
          e.jsx("path", {
            d: i.p3a22fe00,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_15",
          }),
          e.jsx("path", {
            d: i.p3d3b9772,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_16",
          }),
          e.jsx("path", {
            d: i.p120e9380,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_17",
          }),
          e.jsx("path", {
            d: i.p26551a00,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_18",
          }),
          e.jsx("path", {
            d: i.p282f10f0,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_19",
          }),
          e.jsx("path", {
            d: i.p3aeb3380,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_20",
          }),
          e.jsx("path", {
            d: i.p31f9e100,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_21",
          }),
          e.jsx("path", {
            d: i.pf083500,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_22",
          }),
          e.jsx("path", {
            d: i.p3a0dff00,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_23",
          }),
          e.jsx("path", {
            d: i.p186e9e80,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_24",
          }),
          e.jsx("path", {
            d: i.p3e1a6980,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_25",
          }),
          e.jsx("path", {
            d: i.pdee15f0,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_26",
          }),
          e.jsx("path", {
            d: i.p3f84b940,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_27",
          }),
          e.jsx("path", {
            d: i.pb161cf0,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_28",
          }),
          e.jsx("path", {
            d: i.p1dd748d0,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_29",
          }),
          e.jsx("path", {
            d: i.p3a477c00,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_30",
          }),
          e.jsx("path", {
            d: i.p2ca4c980,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_31",
          }),
          e.jsx("path", {
            d: i.p264f7780,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_32",
          }),
          e.jsx("path", {
            d: i.p1f6b4680,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_33",
          }),
          e.jsx("path", {
            d: i.p3e038880,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_34",
          }),
          e.jsx("path", {
            d: i.pcd0eb80,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_35",
          }),
        ],
      }),
    }),
  });
}
function Ko() {
  return e.jsx("div", {
    className: "absolute inset-[36.28%_5.55%_55.54%_81.69%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 105.743 70.4432",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p20ae7100,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p33d06200,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p280c7780,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function Jo() {
  return e.jsx("div", {
    className: "absolute inset-[37.05%_6.79%_57.3%_83.06%]",
    "data-name": "Group",
    children: e.jsxs("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 84.1154 48.7077",
      children: [
        e.jsxs("g", {
          id: "Group",
          children: [
            e.jsxs("g", {
              id: "Group_2",
              children: [
                e.jsx("path", {
                  d: i.p159380b0,
                  fill: "url(#paint0_linear_1_3551)",
                  id: "Vector",
                }),
                e.jsx("path", {
                  d: i.p18949900,
                  fill: "var(--fill-0, #72B5E8)",
                  id: "Vector_2",
                }),
                e.jsx("path", {
                  d: i.pe8b7f00,
                  fill: "var(--fill-0, #A8CFF0)",
                  id: "Vector_3",
                }),
              ],
            }),
            e.jsx("path", {
              d: i.p4b04980,
              fill: "var(--fill-0, #D1EBFF)",
              id: "Vector_4",
            }),
          ],
        }),
        e.jsx("defs", {
          children: e.jsxs("linearGradient", {
            gradientUnits: "userSpaceOnUse",
            id: "paint0_linear_1_3551",
            x1: "85.6361",
            x2: "38.7639",
            y1: "107.41",
            y2: "18.0393",
            children: [
              e.jsx("stop", { stopColor: "#AFB6E5" }),
              e.jsx("stop", { offset: "0.14", stopColor: "#B5BCE8" }),
              e.jsx("stop", { offset: "0.35", stopColor: "#C7CDF0" }),
              e.jsx("stop", { offset: "0.58", stopColor: "#E5E9FF" }),
              e.jsx("stop", { offset: "0.95", stopColor: "#F4F4FB" }),
              e.jsx("stop", { offset: "1", stopColor: "#F7F6FB" }),
            ],
          }),
        }),
      ],
    }),
  });
}
function qo() {
  return e.jsxs("div", {
    className: "absolute contents inset-[36.28%_3.6%_24.27%_79.72%]",
    "data-name": "Group",
    children: [
      e.jsx(Uo, {}),
      e.jsx(Qo, {}),
      e.jsx($o, {}),
      e.jsx(Xo, {}),
      e.jsx(Yo, {}),
      e.jsx(Ko, {}),
      e.jsx(Jo, {}),
    ],
  });
}
function e8() {
  return e.jsx("div", {
    className: "absolute inset-[78.69%_62.09%_0_3.85%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 282.309 183.569",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.pb7ffe00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pcf1780,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p25507280,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function t8() {
  return e.jsx("div", {
    className: "absolute inset-[57.01%_92.35%_13.05%_6.96%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 257.898",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1321f600,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p5690ab0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1306380,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function l8() {
  return e.jsx("div", {
    className: "absolute inset-[55.51%_89.63%_14.56%_9.68%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 257.869",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p27ea0700,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p385f4200,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p14209f00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function r8() {
  return e.jsx("div", {
    className: "absolute inset-[54%_86.91%_16.07%_12.4%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 257.869",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p7f4d0c0,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1b14800,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2d3b2cc0,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function i8() {
  return e.jsx("div", {
    className: "absolute inset-[52.5%_84.19%_17.57%_15.12%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 257.869",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p18c4f180,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3e6f3f30,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1f60c9e0,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function n8() {
  return e.jsx("div", {
    className: "absolute inset-[50.99%_81.48%_19.08%_17.83%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 257.898",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p329b0f80,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1ea2b00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1d35e200,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function s8() {
  return e.jsxs("div", {
    className: "absolute contents inset-[50.99%_81.48%_13.05%_6.96%]",
    "data-name": "Group",
    children: [
      e.jsx(t8, {}),
      e.jsx(l8, {}),
      e.jsx(r8, {}),
      e.jsx(i8, {}),
      e.jsx(n8, {}),
    ],
  });
}
function a8() {
  return e.jsx("div", {
    className: "absolute inset-[56.97%_65.18%_13.09%_34.13%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 257.869",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p21e58580,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1b14800,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p33d2900,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function o8() {
  return e.jsx("div", {
    className: "absolute inset-[55.47%_67.9%_14.59%_31.41%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71659 257.898",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p253b3100,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1e13a3c0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2ec10380,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function d8() {
  return e.jsx("div", {
    className: "absolute inset-[53.97%_70.62%_16.09%_28.69%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 257.898",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p34dbf300,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p252daf00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2eafc500,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function c8() {
  return e.jsx("div", {
    className: "absolute inset-[52.48%_73.34%_17.59%_25.97%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.7166 257.869",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p9c98680,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p36f3a280,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pc3c3380,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function p8() {
  return e.jsx("div", {
    className: "absolute inset-[50.98%_76.06%_19.09%_23.26%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.68843 257.869",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.pe1ba00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p330aa80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.peb21080,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function f8() {
  return e.jsx("div", {
    className: "absolute inset-[49.48%_78.78%_20.59%_20.54%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.68843 257.898",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1a0db000,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pd16a300,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pe260e80,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function u8() {
  return e.jsxs("div", {
    className: "absolute contents inset-[49.48%_65.18%_13.09%_20.54%]",
    "data-name": "Group",
    children: [
      e.jsx(a8, {}),
      e.jsx(o8, {}),
      e.jsx(d8, {}),
      e.jsx(c8, {}),
      e.jsx(p8, {}),
      e.jsx(f8, {}),
    ],
  });
}
function x8() {
  return e.jsx("div", {
    className: "absolute inset-[58.45%_62.46%_11.62%_36.85%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71659 257.869",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p34573ff0,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p14ffa500,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2a499900,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function h8() {
  return e.jsx("div", {
    className: "absolute inset-[58.47%_95.07%_11.59%_4.24%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.68842 257.869",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p17c56b00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2ce61780,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p27725200,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function v8() {
  return e.jsxs("div", {
    className: "absolute contents inset-[49.48%_62.46%_11.59%_4.24%]",
    "data-name": "Group",
    children: [e.jsx(s8, {}), e.jsx(u8, {}), e.jsx(x8, {}), e.jsx(h8, {})],
  });
}
function L8() {
  return e.jsx("div", {
    className: "absolute inset-[66.49%_62.09%_14.05%_3.85%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 282.309 167.633",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p26e95700,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p11a6900,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pe3926c0,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function j8() {
  return e.jsx("div", {
    className: "absolute inset-[81.27%_78.77%_2.58%_20.54%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 139.085",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1aeccf00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p9697c00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2d739b00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function V8() {
  return e.jsx("div", {
    className: "absolute inset-[79.77%_76.05%_4.09%_23.26%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.7166 139.084",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p17a6b5c0,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3d01e000,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2829b680,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function m8() {
  return e.jsx("div", {
    className: "absolute inset-[78.26%_73.33%_5.59%_25.98%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71661 139.085",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1f43f100,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p5e32e00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1230cc0c,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function g8() {
  return e.jsx("div", {
    className: "absolute inset-[76.75%_70.61%_7.1%_28.7%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.7166 139.084",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.pa007420,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2f314600,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1230cc0c,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function _8() {
  return e.jsx("div", {
    className: "absolute inset-[75.25%_67.9%_8.6%_31.42%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71659 139.085",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p11aed000,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2c75bd70,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p29f10780,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function b8() {
  return e.jsx("div", {
    className: "absolute inset-[73.75%_65.18%_10.11%_34.13%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.7166 139.084",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p6356e00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1e06ebc0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p304bef00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function F8() {
  return e.jsx("div", {
    className: "absolute inset-[72.26%_62.46%_11.62%_36.85%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71659 138.916",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p16acf880,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p33b05f80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2a499900,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function M8() {
  return e.jsx("div", {
    className: "absolute inset-[79.76%_81.48%_4.1%_17.83%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 139.084",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p36824500,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pdecae80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1b42a1f0,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function C8() {
  return e.jsx("div", {
    className: "absolute inset-[78.26%_84.2%_5.6%_15.11%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.7166 139.084",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3fe73bc0,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p41dc580,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2951ca00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function w8() {
  return e.jsx("div", {
    className: "absolute inset-[76.76%_86.92%_7.1%_12.39%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 139.084",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1b5fef70,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2d7932f0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p94bb00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function k8() {
  return e.jsx("div", {
    className: "absolute inset-[75.26%_89.64%_8.59%_9.67%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.68845 139.085",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p13ae7500,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p11ce2580,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p363c980,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function N8() {
  return e.jsx("div", {
    className: "absolute inset-[73.76%_92.36%_10.09%_6.96%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.68845 139.084",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p10390980,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p15c2980,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1c89f480,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function Z8() {
  return e.jsx("div", {
    className: "absolute inset-[72.28%_95.07%_11.59%_4.24%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.68842 138.916",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3b1c4280,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p62f7900,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p27725200,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function y8() {
  return e.jsxs("div", {
    className: "absolute contents inset-[72.26%_62.46%_2.58%_4.24%]",
    "data-name": "Group",
    children: [
      e.jsx(j8, {}),
      e.jsx(V8, {}),
      e.jsx(m8, {}),
      e.jsx(g8, {}),
      e.jsx(_8, {}),
      e.jsx(b8, {}),
      e.jsx(F8, {}),
      e.jsx(M8, {}),
      e.jsx(C8, {}),
      e.jsx(w8, {}),
      e.jsx(k8, {}),
      e.jsx(N8, {}),
      e.jsx(Z8, {}),
    ],
  });
}
function B8() {
  return e.jsx("div", {
    className: "absolute inset-[83.88%_92.98%_10.41%_3.87%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1612 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p69bd100,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p4f8a000,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pc722900,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.ped8e200,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p14dfec80,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function E8() {
  return e.jsx("div", {
    className: "absolute inset-[85.45%_90.13%_8.84%_6.72%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1611 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p132cb00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2d47fa00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2bb21500,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p26d31d00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p3372b00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function G8() {
  return e.jsx("div", {
    className: "absolute inset-[87.01%_87.29%_7.27%_9.55%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1893 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.pc987e80,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1d0165f0,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3027fe00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p2a49ea80,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p2e0e7700,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function A8() {
  return e.jsx("div", {
    className: "absolute inset-[88.58%_84.44%_5.7%_12.4%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1611 49.2709",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3f00900,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1513b780,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pa04ceb0,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.pd0c8370,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p18f31100,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function D8() {
  return e.jsx("div", {
    className: "absolute inset-[90.14%_81.61%_4.14%_15.24%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1611 49.2428",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p7f67f00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1b0d5700,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p158f0b70,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.pd15d680,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p33736180,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function R8() {
  return e.jsx("div", {
    className: "absolute inset-[91.71%_78.76%_2.58%_18.09%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1611 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p15fdf880,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p6298e00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3b959a00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p237a9140,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p1e7f4200,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function S8() {
  return e.jsxs("div", {
    className: "absolute contents inset-[83.88%_78.76%_2.58%_3.87%]",
    "data-name": "Group",
    children: [
      e.jsx(B8, {}),
      e.jsx(E8, {}),
      e.jsx(G8, {}),
      e.jsx(A8, {}),
      e.jsx(D8, {}),
      e.jsx(R8, {}),
    ],
  });
}
function I8() {
  return e.jsx("div", {
    className: "absolute inset-[83.88%_62.09%_10.41%_34.76%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1613 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2564d480,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2bedc000,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pf579400,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p35474000,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p30a13880,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function T8() {
  return e.jsx("div", {
    className: "absolute inset-[85.45%_64.94%_8.84%_31.91%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1611 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p8dd83d0,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pb189b00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2c62ca00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p217c880,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p44cc900,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function z8() {
  return e.jsx("div", {
    className: "absolute inset-[87.01%_67.77%_7.27%_29.07%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1613 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2566b300,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p244f8080,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3b4c0300,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p36334180,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p8784a00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function P8() {
  return e.jsx("div", {
    className: "absolute inset-[88.58%_70.62%_5.7%_26.22%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1611 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p788e900,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p316bce00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2b249e00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p2bf4800,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p22664200,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function H8() {
  return e.jsx("div", {
    className: "absolute inset-[90.14%_73.46%_4.14%_23.38%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1893 49.2428",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2d00b800,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p22676000,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p20f74f80,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p6a49b00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p3f2a7900,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function W8() {
  return e.jsx("div", {
    className: "absolute inset-[91.71%_76.31%_2.58%_20.53%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1893 49.2426",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p28a7f00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p23579880,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1a109e00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p235c6900,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p8cdbf80,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function O8() {
  return e.jsxs("div", {
    className: "absolute contents inset-[83.88%_62.09%_2.58%_20.53%]",
    "data-name": "Group",
    children: [
      e.jsx(I8, {}),
      e.jsx(T8, {}),
      e.jsx(z8, {}),
      e.jsx(P8, {}),
      e.jsx(H8, {}),
      e.jsx(W8, {}),
    ],
  });
}
function U8() {
  return e.jsx("div", {
    className: "absolute inset-[79.81%_92.98%_14.47%_3.87%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1611 49.2426",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p34c9a000,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2485f800,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p9841c00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p15de4e00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p2aed5800,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function Q8() {
  return e.jsx("div", {
    className: "absolute inset-[81.38%_90.13%_12.9%_6.72%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1611 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1ca04bc0,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2d47fa00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p24d05200,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p233cda00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p2fe79180,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function $8() {
  return e.jsx("div", {
    className: "absolute inset-[82.95%_87.29%_11.34%_9.55%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1893 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.pc987e80,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1d0165f0,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p24d05200,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p191e4080,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p2e0e7700,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function X8() {
  return e.jsx("div", {
    className: "absolute inset-[84.52%_84.44%_9.77%_12.4%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1612 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2c790bb0,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p25398f00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2178fea0,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.pd0c8370,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p149fbf0,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function Y8() {
  return e.jsx("div", {
    className: "absolute inset-[86.08%_81.61%_8.21%_15.24%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1611 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p14414b00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3abd5e00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1d1b6000,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p15ad6800,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.pff1c800,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function K8() {
  return e.jsx("div", {
    className: "absolute inset-[87.64%_78.76%_6.64%_18.09%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1611 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1c26ec00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pe10d7f2,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2dfe7f00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p26d31d00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p28429200,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function J8() {
  return e.jsxs("div", {
    className: "absolute contents inset-[79.81%_78.76%_6.64%_3.87%]",
    "data-name": "Group",
    children: [
      e.jsx(U8, {}),
      e.jsx(Q8, {}),
      e.jsx($8, {}),
      e.jsx(X8, {}),
      e.jsx(Y8, {}),
      e.jsx(K8, {}),
    ],
  });
}
function q8() {
  return e.jsx("div", {
    className: "absolute inset-[79.81%_62.09%_14.47%_34.76%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1613 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p31026900,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p20b42bf0,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p26b0f000,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p3a11bf00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.pc3fdb00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function e7() {
  return e.jsx("div", {
    className: "absolute inset-[81.38%_64.94%_12.9%_31.91%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1611 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.pddeea00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p24984480,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1e931800,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p217c880,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.pedbc180,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function t7() {
  return e.jsx("div", {
    className: "absolute inset-[82.95%_67.77%_11.34%_29.07%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1613 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2566b300,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p244f8080,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3b4c0300,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p87ecf00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p8784a00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function l7() {
  return e.jsx("div", {
    className: "absolute inset-[84.52%_70.62%_9.77%_26.22%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1611 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p342317b0,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p281a3160,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p39d9b500,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p2bf4800,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p2e865e00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function r7() {
  return e.jsx("div", {
    className: "absolute inset-[86.08%_73.46%_8.21%_23.38%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1893 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p306affb0,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p8f00200,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p11297d00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p5fe6200,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p24bea170,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function i7() {
  return e.jsx("div", {
    className: "absolute inset-[87.64%_76.31%_6.64%_20.53%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1893 49.2426",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p20a0ff00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p270320f0,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3362cc00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.pb7c1400,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p11dceb40,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function n7() {
  return e.jsxs("div", {
    className: "absolute contents inset-[79.81%_62.09%_6.64%_20.53%]",
    "data-name": "Group",
    children: [
      e.jsx(q8, {}),
      e.jsx(e7, {}),
      e.jsx(t7, {}),
      e.jsx(l7, {}),
      e.jsx(r7, {}),
      e.jsx(i7, {}),
    ],
  });
}
function s7() {
  return e.jsx("div", {
    className: "absolute inset-[75.72%_92.98%_18.57%_3.87%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1612 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2dc3db80,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p23b2f900,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pa23be00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.ped8e200,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p14dfec80,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function a7() {
  return e.jsx("div", {
    className: "absolute inset-[77.29%_90.13%_17%_6.72%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1611 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p132cb00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p304ae300,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p818b5c0,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p10a44c00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p2fe79180,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function o7() {
  return e.jsx("div", {
    className: "absolute inset-[78.85%_87.29%_15.43%_9.55%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1893 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p132cb00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pc344500,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p384ce780,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.peb96200,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p27c00570,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function d7() {
  return e.jsx("div", {
    className: "absolute inset-[80.42%_84.44%_13.86%_12.4%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1611 49.2709",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2c790bb0,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1513b780,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1d860680,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.pcffd080,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p1751f280,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function c7() {
  return e.jsx("div", {
    className: "absolute inset-[81.98%_81.61%_12.3%_15.24%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1611 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p37edd800,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p31e72500,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p29a557f0,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p10a44c00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p5593400,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function p7() {
  return e.jsx("div", {
    className: "absolute inset-[83.55%_78.76%_10.74%_18.09%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1611 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p15fdf880,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1968b2,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2dfe7f00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p237a9140,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p11f9a900,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function f7() {
  return e.jsxs("div", {
    className: "absolute contents inset-[75.72%_78.76%_10.74%_3.87%]",
    "data-name": "Group",
    children: [
      e.jsx(s7, {}),
      e.jsx(a7, {}),
      e.jsx(o7, {}),
      e.jsx(d7, {}),
      e.jsx(c7, {}),
      e.jsx(p7, {}),
    ],
  });
}
function u7() {
  return e.jsx("div", {
    className: "absolute inset-[75.72%_62.09%_18.57%_34.76%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1613 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p31026900,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3ac7ec00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p133c5a00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p30250200,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.pc3fdb00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function x7() {
  return e.jsx("div", {
    className: "absolute inset-[77.29%_64.94%_17%_31.91%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1611 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.pddeea00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p10bee600,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p4182b00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p103d4680,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.pedbc180,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function h7() {
  return e.jsx("div", {
    className: "absolute inset-[78.85%_67.77%_15.43%_29.07%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1613 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p8ae3b00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3f372540,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p22e60800,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p20169e00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p1bbf8f80,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function v7() {
  return e.jsx("div", {
    className: "absolute inset-[80.42%_70.62%_13.86%_26.22%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1611 49.2426",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p342317b0,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p316bce00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3736dc00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p3cb38a80,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p206e7000,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function L7() {
  return e.jsx("div", {
    className: "absolute inset-[81.98%_73.46%_12.3%_23.38%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1893 49.2427",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3aeef300,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pc804e00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2bb0c000,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p174b2500,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p1b891800,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function j7() {
  return e.jsx("div", {
    className: "absolute inset-[83.55%_76.31%_10.74%_20.53%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1893 49.2426",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p28a7f00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3abba800,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3362cc00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p235c6900,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p38567d40,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function V7() {
  return e.jsxs("div", {
    className: "absolute contents inset-[75.72%_62.09%_10.74%_20.53%]",
    "data-name": "Group",
    children: [
      e.jsx(u7, {}),
      e.jsx(x7, {}),
      e.jsx(h7, {}),
      e.jsx(v7, {}),
      e.jsx(L7, {}),
      e.jsx(j7, {}),
    ],
  });
}
function m7() {
  return e.jsx("div", {
    className: "absolute inset-[62.42%_62.09%_18.12%_3.85%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 282.309 167.633",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2eecfa00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p11a6900,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p25507280,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function g7() {
  return e.jsx("div", {
    className: "absolute inset-[76.59%_78.77%_18.91%_20.54%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p227bec00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2b33b270,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2d3b2cc0,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function _7() {
  return e.jsx("div", {
    className: "absolute inset-[75.09%_76.05%_20.42%_23.26%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1f99cd00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1d5e2f00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1817b500,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function b7() {
  return e.jsx("div", {
    className: "absolute inset-[73.58%_73.33%_21.92%_25.98%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.pc02da00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2cdac100,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1817b500,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function F7() {
  return e.jsx("div", {
    className: "absolute inset-[72.08%_70.61%_23.43%_28.7%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.7128",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3601e400,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1cf49170,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3802400,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function M7() {
  return e.jsx("div", {
    className: "absolute inset-[70.57%_67.9%_24.93%_31.42%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.741",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p208e63c0,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p6d52180,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p17c10f80,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function C7() {
  return e.jsx("div", {
    className: "absolute inset-[69.07%_65.18%_26.44%_34.13%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71659 38.741",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2cf1f872,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1c461b80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2829b680,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function w7() {
  return e.jsx("div", {
    className: "absolute inset-[67.56%_62.46%_27.94%_36.85%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71659 38.741",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p10dfd080,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3c4b1300,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1230cc0c,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function k7() {
  return e.jsxs("div", {
    className: "absolute contents inset-[67.56%_62.46%_18.91%_20.54%]",
    "data-name": "Group",
    children: [
      e.jsx(g7, {}),
      e.jsx(_7, {}),
      e.jsx(b7, {}),
      e.jsx(F7, {}),
      e.jsx(M7, {}),
      e.jsx(C7, {}),
      e.jsx(w7, {}),
    ],
  });
}
function N7() {
  return e.jsx("div", {
    className: "absolute inset-[75.08%_81.48%_20.42%_17.83%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p227bec00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2b33b270,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p8733ff0,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function Z7() {
  return e.jsx("div", {
    className: "absolute inset-[73.58%_84.2%_21.92%_15.11%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.7166 38.741",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3c429080,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p23e11200,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3b2caf60,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function y7() {
  return e.jsx("div", {
    className: "absolute inset-[72.08%_86.92%_23.42%_12.39%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.741",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p34c84680,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p17b02e00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2fe22300,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function B7() {
  return e.jsx("div", {
    className: "absolute inset-[70.58%_89.64%_24.92%_9.67%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.68843 38.741",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p38b0100,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pcc779a8,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p231c5010,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function E7() {
  return e.jsx("div", {
    className: "absolute inset-[69.08%_92.36%_26.42%_6.96%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.68843 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1c009000,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1ef22380,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3f61f700,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function G7() {
  return e.jsx("div", {
    className: "absolute inset-[67.58%_95.07%_27.92%_4.24%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.68842 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2cad6900,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p19761280,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pcb83780,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function A7() {
  return e.jsxs("div", {
    className: "absolute contents inset-[67.58%_81.48%_20.42%_4.24%]",
    "data-name": "Group",
    children: [
      e.jsx(N7, {}),
      e.jsx(Z7, {}),
      e.jsx(y7, {}),
      e.jsx(B7, {}),
      e.jsx(E7, {}),
      e.jsx(G7, {}),
    ],
  });
}
function D7() {
  return e.jsxs("div", {
    className: "absolute contents inset-[67.56%_62.46%_18.91%_4.24%]",
    "data-name": "Group",
    children: [e.jsx(k7, {}), e.jsx(A7, {})],
  });
}
function R7() {
  return e.jsx("div", {
    className: "absolute inset-[57.63%_62.09%_22.91%_3.85%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 282.309 167.634",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p48eebf2,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p4f13e80,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2f637d80,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function S7() {
  return e.jsx("div", {
    className: "absolute inset-[71.81%_78.77%_23.7%_20.54%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.741",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p10087700,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p349f9500,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p233ab600,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function I7() {
  return e.jsx("div", {
    className: "absolute inset-[70.3%_76.05%_25.2%_23.26%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.7128",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p33057380,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1cf49170,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p17c10f80,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function T7() {
  return e.jsx("div", {
    className: "absolute inset-[68.8%_73.33%_26.71%_25.98%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.pbfe8c00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p5f87d00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2829b680,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function z7() {
  return e.jsx("div", {
    className: "absolute inset-[67.29%_70.61%_28.21%_28.7%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1a834500,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2173e500,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pf466b80,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function P7() {
  return e.jsx("div", {
    className: "absolute inset-[65.78%_67.9%_29.72%_31.42%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p218b5900,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pa483a00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1817b500,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function H7() {
  return e.jsx("div", {
    className: "absolute inset-[64.28%_65.18%_31.23%_34.13%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71659 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2779300,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p5f56200,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1817b500,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function W7() {
  return e.jsx("div", {
    className: "absolute inset-[62.77%_62.46%_32.73%_36.85%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71659 38.7128",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3a4cd400,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p394b7940,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p17c10f80,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function O7() {
  return e.jsxs("div", {
    className: "absolute contents inset-[62.77%_62.46%_23.7%_20.54%]",
    "data-name": "Group",
    children: [
      e.jsx(S7, {}),
      e.jsx(I7, {}),
      e.jsx(T7, {}),
      e.jsx(z7, {}),
      e.jsx(P7, {}),
      e.jsx(H7, {}),
      e.jsx(W7, {}),
    ],
  });
}
function U7() {
  return e.jsx("div", {
    className: "absolute inset-[70.29%_81.48%_25.21%_17.83%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.741",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p351ca200,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3f804780,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p163b1000,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function Q7() {
  return e.jsx("div", {
    className: "absolute inset-[68.79%_84.2%_26.71%_15.11%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.7166 38.741",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p237f6f00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pe3ba600,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p271cf400,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function $7() {
  return e.jsx("div", {
    className: "absolute inset-[67.29%_86.92%_28.21%_12.39%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p227bec00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p27492500,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p38e7c400,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function X7() {
  return e.jsx("div", {
    className: "absolute inset-[65.79%_89.64%_29.71%_9.67%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.68843 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1169e300,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p235e69f0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pcb83780,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function Y7() {
  return e.jsx("div", {
    className: "absolute inset-[64.29%_92.36%_31.21%_6.96%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.68843 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p5ca5880,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pfffcb00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pcb83780,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function K7() {
  return e.jsx("div", {
    className: "absolute inset-[62.8%_95.07%_32.71%_4.24%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.68845 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.pb80c440,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p20698100,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p363c980,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function J7() {
  return e.jsxs("div", {
    className: "absolute contents inset-[62.8%_81.48%_25.21%_4.24%]",
    "data-name": "Group",
    children: [
      e.jsx(U7, {}),
      e.jsx(Q7, {}),
      e.jsx($7, {}),
      e.jsx(X7, {}),
      e.jsx(Y7, {}),
      e.jsx(K7, {}),
    ],
  });
}
function q7() {
  return e.jsxs("div", {
    className: "absolute contents inset-[62.77%_62.46%_23.7%_4.24%]",
    "data-name": "Group",
    children: [e.jsx(O7, {}), e.jsx(J7, {})],
  });
}
function e9() {
  return e.jsx("div", {
    className: "absolute inset-[53.32%_62.09%_27.22%_3.85%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 282.309 167.634",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p48eebf2,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p4f13e80,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p236b8f00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function t9() {
  return e.jsx("div", {
    className: "absolute inset-[67.5%_78.77%_28.01%_20.54%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.741",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3a723d80,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p27681a00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p233ab600,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function l9() {
  return e.jsx("div", {
    className: "absolute inset-[65.99%_76.05%_29.51%_23.26%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.741",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p29ccbff0,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p33535800,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p35b16b00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function r9() {
  return e.jsx("div", {
    className: "absolute inset-[64.49%_73.33%_31.02%_25.98%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1b68a400,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2b33b270,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p17c10f80,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function i9() {
  return e.jsx("div", {
    className: "absolute inset-[62.98%_70.61%_32.52%_28.7%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1a834500,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2173e500,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pf466b80,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function n9() {
  return e.jsx("div", {
    className: "absolute inset-[61.47%_67.9%_34.03%_31.42%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p218b5900,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pa483a00,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1817b500,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function s9() {
  return e.jsx("div", {
    className: "absolute inset-[59.97%_65.18%_35.54%_34.13%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71659 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2c20ef80,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p17c06500,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1817b500,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function a9() {
  return e.jsx("div", {
    className: "absolute inset-[58.46%_62.46%_37.04%_36.85%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71659 38.7411",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p380efb40,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p29a75800,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pfa99d00,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function o9() {
  return e.jsxs("div", {
    className: "absolute contents inset-[58.46%_62.46%_28.01%_20.54%]",
    "data-name": "Group",
    children: [
      e.jsx(t9, {}),
      e.jsx(l9, {}),
      e.jsx(r9, {}),
      e.jsx(i9, {}),
      e.jsx(n9, {}),
      e.jsx(s9, {}),
      e.jsx(a9, {}),
    ],
  });
}
function d9() {
  return e.jsx("div", {
    className: "absolute inset-[65.98%_81.48%_29.52%_17.83%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.741",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2613df00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1ce034f0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2ee37600,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function c9() {
  return e.jsx("div", {
    className: "absolute inset-[64.48%_84.2%_31.02%_15.11%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.7166 38.7128",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p3afb9670,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3c55c380,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3efbb800,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function p9() {
  return e.jsx("div", {
    className: "absolute inset-[62.98%_86.92%_32.52%_12.39%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.71658 38.741",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1436a070,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p2943fb80,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1b274bf0,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function f9() {
  return e.jsx("div", {
    className: "absolute inset-[61.48%_89.64%_34.02%_9.67%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.68843 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p1885e4c0,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1ef22380,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3f61f700,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function u9() {
  return e.jsx("div", {
    className: "absolute inset-[59.98%_92.36%_35.52%_6.96%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.68843 38.7409",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2090f600,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p235e69f0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pcb83780,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function x9() {
  return e.jsx("div", {
    className: "absolute inset-[58.49%_95.07%_37.02%_4.24%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 5.68845 38.7128",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p12251300,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p196c280,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p363c980,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function h9() {
  return e.jsxs("div", {
    className: "absolute contents inset-[58.49%_81.48%_29.52%_4.24%]",
    "data-name": "Group",
    children: [
      e.jsx(d9, {}),
      e.jsx(c9, {}),
      e.jsx(p9, {}),
      e.jsx(f9, {}),
      e.jsx(u9, {}),
      e.jsx(x9, {}),
    ],
  });
}
function v9() {
  return e.jsxs("div", {
    className: "absolute contents inset-[58.46%_62.46%_28.01%_4.24%]",
    "data-name": "Group",
    children: [e.jsx(o9, {}), e.jsx(h9, {})],
  });
}
function L9() {
  return e.jsxs("div", {
    className: "absolute contents inset-[49.48%_62.09%_0_3.85%]",
    "data-name": "Group",
    children: [
      e.jsx(e8, {}),
      e.jsx(v8, {}),
      e.jsx(L8, {}),
      e.jsx(y8, {}),
      e.jsx(S8, {}),
      e.jsx(O8, {}),
      e.jsx(J8, {}),
      e.jsx(n7, {}),
      e.jsx(f7, {}),
      e.jsx(V7, {}),
      e.jsx(m7, {}),
      e.jsx(D7, {}),
      e.jsx(R7, {}),
      e.jsx(q7, {}),
      e.jsx(e9, {}),
      e.jsx(v9, {}),
    ],
  });
}
function j9() {
  return e.jsx("div", {
    className: "absolute inset-[31.04%_18.32%_15.35%_59.01%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 187.999 461.879",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p5acb400,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1f228100,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_2",
          }),
          e.jsxs("g", {
            id: "Group_2",
            children: [
              e.jsx("path", {
                d: i.p3d3c3200,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_3",
              }),
              e.jsx("path", {
                d: i.p22e23ff0,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_4",
              }),
              e.jsx("path", {
                d: i.p31e91280,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_5",
              }),
              e.jsx("path", {
                d: i.p26fbcd00,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_6",
              }),
              e.jsx("path", {
                d: i.p3691fdc0,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_7",
              }),
              e.jsx("path", {
                d: i.p34e30300,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_8",
              }),
              e.jsx("path", {
                d: i.p846200,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_9",
              }),
              e.jsx("path", {
                d: i.p55a5d00,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_10",
              }),
              e.jsx("path", {
                d: i.p23afbc00,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_11",
              }),
              e.jsx("path", {
                d: i.p29fded00,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_12",
              }),
              e.jsx("path", {
                d: i.p18f74f00,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_13",
              }),
              e.jsx("path", {
                d: i.pe35e600,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_14",
              }),
              e.jsx("path", {
                d: i.p3f0e2000,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_15",
              }),
              e.jsx("path", {
                d: i.p1b0e680,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_16",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_3",
            children: [
              e.jsx("path", {
                d: i.p32aa3d00,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_17",
              }),
              e.jsx("path", {
                d: i.p32cda280,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_18",
              }),
              e.jsx("path", {
                d: i.p2370f880,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_19",
              }),
              e.jsx("path", {
                d: i.p125bb700,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_20",
              }),
              e.jsx("path", {
                d: i.p2935c972,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_21",
              }),
              e.jsx("path", {
                d: i.p33103f00,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_22",
              }),
              e.jsx("path", {
                d: i.p328ade80,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_23",
              }),
              e.jsx("path", {
                d: i.p1bfdf200,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_24",
              }),
              e.jsx("path", {
                d: i.p15f99840,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_25",
              }),
              e.jsx("path", {
                d: i.p268aa880,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_26",
              }),
              e.jsx("path", {
                d: i.p35821900,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_27",
              }),
              e.jsx("path", {
                d: i.p28652000,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_28",
              }),
              e.jsx("path", {
                d: i.p620cb00,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_29",
              }),
              e.jsx("path", {
                d: i.p327dc070,
                fill: "var(--fill-0, #2672AB)",
                id: "Vector_30",
              }),
            ],
          }),
          e.jsx("path", {
            d: i.p272dd300,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_31",
            opacity: "0.5",
          }),
          e.jsx("path", {
            d: i.p3db98380,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_32",
          }),
        ],
      }),
    }),
  });
}
function V9() {
  return e.jsx("div", {
    className: "absolute inset-[31.85%_22.38%_14.57%_59.66%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 148.913 461.597",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p6713500,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p4ade000,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pc563000,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p383de300,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p2e7a2380,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_5",
          }),
          e.jsxs("g", {
            id: "Group_2",
            children: [
              e.jsx("path", {
                d: i.p20d73380,
                fill: "var(--fill-0, #03336E)",
                id: "Vector_6",
              }),
              e.jsx("path", {
                d: i.pa06c400,
                fill: "var(--fill-0, #03336E)",
                id: "Vector_7",
              }),
              e.jsx("path", {
                d: i.p3d12dd00,
                fill: "var(--fill-0, #03336E)",
                id: "Vector_8",
              }),
              e.jsx("path", {
                d: i.p1ffa8100,
                fill: "var(--fill-0, #03336E)",
                id: "Vector_9",
              }),
              e.jsx("path", {
                d: i.pbc06d00,
                fill: "var(--fill-0, #03336E)",
                id: "Vector_10",
              }),
              e.jsx("path", {
                d: i.p36fc8280,
                fill: "var(--fill-0, #03336E)",
                id: "Vector_11",
              }),
              e.jsx("path", {
                d: i.p55b4d00,
                fill: "var(--fill-0, #03336E)",
                id: "Vector_12",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_3",
            children: [
              e.jsx("path", {
                d: i.p3a983880,
                fill: "var(--fill-0, #3F92D1)",
                id: "Vector_13",
              }),
              e.jsx("path", {
                d: i.p1a29e700,
                fill: "var(--fill-0, #3F92D1)",
                id: "Vector_14",
              }),
              e.jsx("path", {
                d: i.p1bfeac80,
                fill: "var(--fill-0, #3F92D1)",
                id: "Vector_15",
              }),
              e.jsx("path", {
                d: i.p2091dd80,
                fill: "var(--fill-0, #3F92D1)",
                id: "Vector_16",
              }),
              e.jsx("path", {
                d: i.p3bc23dc0,
                fill: "var(--fill-0, #3F92D1)",
                id: "Vector_17",
              }),
              e.jsx("path", {
                d: i.p1ed79900,
                fill: "var(--fill-0, #3F92D1)",
                id: "Vector_18",
              }),
              e.jsx("path", {
                d: i.p2c626f00,
                fill: "var(--fill-0, #3F92D1)",
                id: "Vector_19",
              }),
            ],
          }),
          e.jsx("path", {
            d: i.p3605c00,
            fill: "var(--fill-0, #03336E)",
            id: "Vector_20",
          }),
          e.jsx("path", {
            d: i.p363e4700,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_21",
          }),
          e.jsx("path", {
            d: i.p37c96d00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_22",
          }),
          e.jsx("path", {
            d: i.p337a2580,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_23",
          }),
        ],
      }),
    }),
  });
}
function m9() {
  return e.jsxs("div", {
    className: "absolute contents inset-[31.04%_18.32%_14.57%_59.01%]",
    "data-name": "Group",
    children: [e.jsx(j9, {}), e.jsx(V9, {})],
  });
}
function g9() {
  return e.jsx("div", {
    className: "absolute inset-[75.55%_38.48%_10.44%_45.83%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 130.073 120.671",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p9cf0e40,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p4e9fe00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_2",
          }),
          e.jsxs("g", {
            id: "Group_2",
            children: [
              e.jsx("path", {
                d: i.p1b256e00,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_3",
              }),
              e.jsx("path", {
                d: i.p19d28c00,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_4",
              }),
              e.jsx("path", {
                d: i.pace4f00,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_5",
              }),
              e.jsx("path", {
                d: i.p20a6c100,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_6",
              }),
              e.jsx("path", {
                d: i.p31d37580,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_7",
              }),
              e.jsx("path", {
                d: i.p3be3bb00,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_8",
              }),
              e.jsx("path", {
                d: i.p341a5300,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_9",
              }),
              e.jsx("path", {
                d: i.p8082e00,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_10",
              }),
              e.jsx("path", {
                d: i.p274d9e80,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_11",
              }),
              e.jsx("path", {
                d: i.p6b0c300,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_12",
              }),
              e.jsx("path", {
                d: i.p325ae800,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_13",
              }),
              e.jsx("path", {
                d: i.pa015f80,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_14",
              }),
              e.jsx("path", {
                d: i.p3415f00,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_15",
              }),
              e.jsx("path", {
                d: i.p312b0dc0,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_16",
              }),
              e.jsx("path", {
                d: i.p3ef4cf80,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_17",
              }),
              e.jsx("path", {
                d: i.p268b2380,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_18",
              }),
              e.jsx("path", {
                d: i.p3f6ea00,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_19",
              }),
              e.jsx("path", {
                d: i.p95a4a80,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_20",
              }),
              e.jsx("path", {
                d: i.p40a6400,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_21",
              }),
              e.jsx("path", {
                d: i.p1f4e1900,
                fill: "var(--fill-0, #A8CFF0)",
                id: "Vector_22",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_3",
            children: [
              e.jsx("path", {
                d: i.pe4a9c00,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_23",
              }),
              e.jsx("path", {
                d: i.p290a0300,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_24",
              }),
              e.jsx("path", {
                d: i.p18d9c100,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_25",
              }),
              e.jsx("path", {
                d: i.p31908600,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_26",
              }),
              e.jsx("path", {
                d: i.pdd5b200,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_27",
              }),
              e.jsx("path", {
                d: i.pcf5eb00,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_28",
              }),
              e.jsx("path", {
                d: i.p17f45e80,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_29",
              }),
              e.jsx("path", {
                d: i.p2ccbc680,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_30",
              }),
              e.jsx("path", {
                d: i.p20a86800,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_31",
              }),
              e.jsx("path", {
                d: i.p12734300,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_32",
              }),
              e.jsx("path", {
                d: i.pa668f00,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_33",
              }),
              e.jsx("path", {
                d: i.pccadf80,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_34",
              }),
              e.jsx("path", {
                d: i.pd5bbd00,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_35",
              }),
              e.jsx("path", {
                d: i.p7c7b700,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_36",
              }),
              e.jsx("path", {
                d: i.p24d02700,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_37",
              }),
              e.jsx("path", {
                d: i.p79a3400,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_38",
              }),
              e.jsx("path", {
                d: i.p333d2800,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_39",
              }),
              e.jsx("path", {
                d: i.p2baa5780,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_40",
              }),
              e.jsx("path", {
                d: i.p31678700,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_41",
              }),
              e.jsx("path", {
                d: i.p94fbc00,
                fill: "var(--fill-0, #F0F8FF)",
                id: "Vector_42",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_4",
            children: [
              e.jsx("path", {
                d: i.p33022f00,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_43",
              }),
              e.jsx("path", {
                d: i.p158b7140,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_44",
              }),
              e.jsx("path", {
                d: i.pdbfd770,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_45",
              }),
              e.jsx("path", {
                d: i.p384d5f00,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_46",
              }),
              e.jsx("path", {
                d: i.p25fcdf40,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_47",
              }),
              e.jsx("path", {
                d: i.p30e5b400,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_48",
              }),
              e.jsx("path", {
                d: i.p3e3f42c0,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_49",
              }),
              e.jsx("path", {
                d: i.p2726fe00,
                fill: "var(--fill-0, #72B5E8)",
                id: "Vector_50",
              }),
            ],
          }),
          e.jsxs("g", {
            id: "Group_5",
            children: [
              e.jsx("path", {
                d: i.p12c6c100,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_51",
              }),
              e.jsx("path", {
                d: i.p25cf8d00,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_52",
              }),
              e.jsx("path", {
                d: i.p11541af0,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_53",
              }),
              e.jsx("path", {
                d: i.p86e8180,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_54",
              }),
              e.jsx("path", {
                d: i.p38f96300,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_55",
              }),
              e.jsx("path", {
                d: i.p1e337500,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_56",
              }),
              e.jsx("path", {
                d: i.p38781f0,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_57",
              }),
              e.jsx("path", {
                d: i.p331eb800,
                fill: "var(--fill-0, #D1EBFF)",
                id: "Vector_58",
              }),
            ],
          }),
          e.jsx("path", {
            d: i.pe06ba00,
            fill: "var(--fill-0, #0BA19F)",
            id: "Vector_59",
          }),
          e.jsx("path", {
            d: i.p19ce0500,
            fill: "var(--fill-0, #0FBAB8)",
            id: "Vector_60",
          }),
          e.jsx("path", {
            d: i.p7ea8d00,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_61",
            opacity: "0.5",
          }),
          e.jsx("path", {
            d: i.p3b266100,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_62",
            opacity: "0.5",
          }),
          e.jsx("path", {
            d: i.p27df5b00,
            fill: "var(--fill-0, #3ECFCD)",
            id: "Vector_63",
          }),
          e.jsxs("g", {
            id: "Group_6",
            children: [
              e.jsx("path", {
                d: i.p6cc1de0,
                fill: "var(--fill-0, #0FBAB8)",
                id: "Vector_64",
              }),
              e.jsx("path", {
                d: i.p16553400,
                fill: "var(--fill-0, #0FBAB8)",
                id: "Vector_65",
              }),
              e.jsx("path", {
                d: i.p1b9ab680,
                fill: "var(--fill-0, #0FBAB8)",
                id: "Vector_66",
              }),
              e.jsx("path", {
                d: i.pc149f30,
                fill: "var(--fill-0, #0FBAB8)",
                id: "Vector_67",
              }),
              e.jsx("path", {
                d: i.p18bfe500,
                fill: "var(--fill-0, #0FBAB8)",
                id: "Vector_68",
              }),
              e.jsx("path", {
                d: i.p28829200,
                fill: "var(--fill-0, #0FBAB8)",
                id: "Vector_69",
              }),
              e.jsx("path", {
                d: i.p19979c80,
                fill: "var(--fill-0, #0FBAB8)",
                id: "Vector_70",
              }),
              e.jsx("path", {
                d: i.p106a9870,
                fill: "var(--fill-0, #0FBAB8)",
                id: "Vector_71",
              }),
              e.jsx("path", {
                d: i.p168629f0,
                fill: "var(--fill-0, #0FBAB8)",
                id: "Vector_72",
              }),
              e.jsx("path", {
                d: i.pc14c500,
                fill: "var(--fill-0, #0FBAB8)",
                id: "Vector_73",
              }),
            ],
          }),
          e.jsx("path", {
            d: i.p2970d080,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_74",
          }),
          e.jsx("path", {
            d: i.p2a259280,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_75",
          }),
          e.jsx("path", {
            d: i.p2e34d9c0,
            fill: "var(--fill-0, #3F92D1)",
            id: "Vector_76",
          }),
          e.jsx("path", {
            d: i.p29e100,
            fill: "var(--fill-0, #2672AB)",
            id: "Vector_77",
          }),
          e.jsx("path", {
            d: i.p93096f0,
            fill: "var(--fill-0, #72B5E8)",
            id: "Vector_78",
            opacity: "0.5",
          }),
          e.jsx("path", {
            d: i.p3e976500,
            fill: "var(--fill-0, #084C94)",
            id: "Vector_79",
            opacity: "0.5",
          }),
        ],
      }),
    }),
  });
}
function _9() {
  return e.jsx("div", {
    className: "absolute inset-[26.37%_59.28%_49.14%_26.9%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 114.529 211.024",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2345bb00,
            fill: "var(--fill-0, #0FBAB8)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p3a6fc100,
            fill: "var(--fill-0, #0FBAB8)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2cb11e30,
            fill: "var(--fill-0, #0FBAB8)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p143e1e80,
            fill: "var(--fill-0, #0FBAB8)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p29327700,
            fill: "var(--fill-0, #0FBAB8)",
            id: "Vector_5",
          }),
          e.jsx("path", {
            d: i.pa15eec0,
            fill: "var(--fill-0, #0FBAB8)",
            id: "Vector_6",
          }),
          e.jsx("path", {
            d: i.p65cb2c0,
            fill: "var(--fill-0, #0FBAB8)",
            id: "Vector_7",
          }),
          e.jsx("path", {
            d: i.pbba0380,
            fill: "var(--fill-0, #0FBAB8)",
            id: "Vector_8",
          }),
          e.jsx("path", {
            d: i.p39b50300,
            fill: "var(--fill-0, #0FBAB8)",
            id: "Vector_9",
          }),
          e.jsx("path", {
            d: i.p18f7eec0,
            fill: "var(--fill-0, #0FBAB8)",
            id: "Vector_10",
          }),
        ],
      }),
    }),
  });
}
function b9() {
  return e.jsx("div", {
    className: "absolute inset-[9.91%_0_7.44%_0]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 828.989 712.034",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p675540,
            fill: "var(--fill-0, #FFD70F)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p121e1800,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p1110ea70,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p4eb7300,
            fill: "var(--fill-0, #FFD70F)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p3e64f00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_5",
          }),
          e.jsx("path", {
            d: i.p13a47380,
            fill: "var(--fill-0, #FFD70F)",
            id: "Vector_6",
          }),
          e.jsx("path", {
            d: i.p2f299100,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_7",
          }),
          e.jsx("path", {
            d: i.p1ae30880,
            fill: "var(--fill-0, #FFD70F)",
            id: "Vector_8",
          }),
          e.jsx("path", {
            d: i.p1c53bb00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_9",
          }),
          e.jsx("path", {
            d: i.p23643600,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_10",
          }),
          e.jsx("path", {
            d: i.p937780,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_11",
          }),
          e.jsx("path", {
            d: i.p576f680,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_12",
          }),
        ],
      }),
    }),
  });
}
function F9() {
  return e.jsx("div", {
    className: "absolute inset-[87.22%_37.85%_1.64%_45.07%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 141.619 96.0078",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p6740500,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p4729600,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p101c5a00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function M9() {
  return e.jsx("div", {
    className: "absolute inset-[85.34%_37.85%_3.52%_45.07%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 141.619 96.0077",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.pe45d900,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p4729600,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p101c5a00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_3",
          }),
        ],
      }),
    }),
  });
}
function C9() {
  return e.jsx("div", {
    className: "absolute inset-[92.39%_52.56%_1.65%_44.14%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 27.2875 51.3543",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.pedf2e00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p49407b0,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.pcc88e80,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p30084680,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p236a4000,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function w9() {
  return e.jsx("div", {
    className: "absolute inset-[92.75%_53.32%_1.29%_43.39%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 27.2875 51.3261",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p2111ab70,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.pd990820,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p5fdf500,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p3b50b980,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p35951b00,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function k9() {
  return e.jsx("div", {
    className: "absolute inset-[93.12%_54.05%_0.92%_42.66%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 27.2875 51.3543",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p26000a00,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p19ba7700,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p2c0ab400,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p83e1200,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p3b4ad400,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function N9() {
  return e.jsxs("div", {
    className: "absolute contents inset-[92.39%_52.56%_0.92%_42.66%]",
    "data-name": "Group",
    children: [e.jsx(C9, {}), e.jsx(w9, {}), e.jsx(k9, {})],
  });
}
function Z9() {
  return e.jsx("div", {
    className: "absolute inset-[89.42%_37.77%_4.87%_59.08%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 26.1613 49.2428",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p19ed3500,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p1e97ab80,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p3126a4c0,
            fill: "var(--fill-0, #D1EBFF)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p3b92e870,
            fill: "var(--fill-0, #A8CFF0)",
            id: "Vector_4",
          }),
          e.jsx("path", {
            d: i.p1d06e500,
            fill: "var(--fill-0, #F0F8FF)",
            id: "Vector_5",
          }),
        ],
      }),
    }),
  });
}
function y9() {
  return e.jsxs("div", {
    className: "absolute contents inset-[85.34%_37.77%_0.92%_42.66%]",
    "data-name": "Group",
    children: [e.jsx(F9, {}), e.jsx(M9, {}), e.jsx(N9, {}), e.jsx(Z9, {})],
  });
}
function B9() {
  return e.jsxs("div", {
    className:
      "absolute h-[861.536px] left-[1041px] overflow-clip top-[191px] w-[828.989px]",
    "data-name": "Layer_1",
    children: [
      e.jsx(wo, {}),
      e.jsx("div", {
        className: "absolute inset-[41.38%_38.85%_56.97%_58.64%]",
        "data-name": "Vector",
        children: e.jsx("svg", {
          className: "absolute block inset-0",
          fill: "none",
          preserveAspectRatio: "none",
          viewBox: "0 0 20.8388 14.19",
          children: e.jsx("path", {
            d: i.p1c340040,
            fill: "var(--fill-0, #0FBAB8)",
            id: "Vector",
          }),
        }),
      }),
      e.jsx(yo, {}),
      e.jsx(Oo, {}),
      e.jsx(qo, {}),
      e.jsx(L9, {}),
      e.jsx(m9, {}),
      e.jsx(g9, {}),
      e.jsx(_9, {}),
      e.jsx(b9, {}),
      e.jsx(y9, {}),
    ],
  });
}
function E9() {
  return e.jsx("div", {
    className: "absolute contents left-[1041px] top-[191px]",
    children: e.jsx(B9, {}),
  });
}
function G9() {
  return e.jsxs("div", {
    className: "absolute contents left-[107px] top-[791.54px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-[#fafbfe] border-[#d1ebff] border-[1.5px] border-solid h-[159px] left-[107px] rounded-[20px] shadow-[0px_0px_17.1px_0px_rgba(63,146,209,0.2)] top-[791.54px] w-[196px]",
      }),
      e.jsx("div", {
        className:
          "absolute bg-[#fafbfe] border-[1.5px] border-solid border-white h-[159px] left-[333px] rounded-[20px] shadow-[0px_0px_4px_0px_rgba(205,212,224,0.8)] top-[791.54px] w-[196px]",
      }),
      e.jsx("div", {
        className:
          "absolute bg-[#fafbfe] border-[1.5px] border-solid border-white h-[159px] left-[559px] rounded-[20px] shadow-[0px_0px_4px_0px_rgba(205,212,224,0.8)] top-[791.54px] w-[196px]",
      }),
      e.jsx("div", {
        className:
          "absolute bg-[#fafbfe] border-[1.5px] border-solid border-white h-[159px] left-[785px] rounded-[20px] shadow-[0px_0px_4px_0px_rgba(205,212,224,0.8)] top-[791.54px] w-[196px]",
      }),
      e.jsx("div", {
        className: "absolute h-[116px] left-[138px] top-[818.54px] w-[133px]",
        "data-name": "ChatGPT Image Feb 6, 2026 at 06_32_14 PM 1",
        children: e.jsx("div", {
          className: "absolute inset-0 overflow-hidden pointer-events-none",
          children: e.jsx("img", {
            alt: "",
            className:
              "absolute h-[559.56%] left-[-155.98%] max-w-none top-[-366.67%] w-[734.93%]",
            src: B0,
          }),
        }),
      }),
      e.jsx("div", {
        className: "absolute h-[134px] left-[364px] top-[809.54px] w-[136px]",
        "data-name": "ChatGPT Image Feb 6, 2026 at 06_32_14 PM 2",
        children: e.jsx("div", {
          className:
            "absolute inset-0 opacity-20 overflow-hidden pointer-events-none",
          children: e.jsx("img", {
            alt: "",
            className:
              "absolute h-[485.31%] left-[-253.56%] max-w-none top-[-304.74%] w-[714.42%]",
            src: B0,
          }),
        }),
      }),
      e.jsx("div", {
        className: "absolute h-[134px] left-[590px] top-[809.54px] w-[137px]",
        "data-name": "ChatGPT Image Feb 6, 2026 at 06_32_14 PM 3",
        children: e.jsx("div", {
          className:
            "absolute inset-0 opacity-20 overflow-hidden pointer-events-none",
          children: e.jsx("img", {
            alt: "",
            className:
              "absolute h-[485.31%] left-[-357.3%] max-w-none top-[-304.74%] w-[714.42%]",
            src: B0,
          }),
        }),
      }),
      e.jsx("div", {
        className: "absolute h-[142px] left-[812px] top-[803.54px] w-[140px]",
        "data-name": "ChatGPT Image Feb 6, 2026 at 06_32_14 PM 4",
        children: e.jsx("div", {
          className:
            "absolute inset-0 opacity-20 overflow-hidden pointer-events-none",
          children: e.jsx("img", {
            alt: "",
            className:
              "absolute h-[457.14%] left-[-448.31%] max-w-none top-[-281.25%] w-[695.02%]",
            src: B0,
          }),
        }),
      }),
      e.jsx("div", {
        className: "absolute h-[15px] left-[269px] top-[916.54px] w-[103px]",
        children: e.jsx("div", {
          className: "absolute inset-[-3.04%_0_-3.33%_-0.2%]",
          children: e.jsx("svg", {
            className: "block size-full",
            fill: "none",
            preserveAspectRatio: "none",
            viewBox: "0 0 103.246 15.9567",
            children: e.jsx("path", {
              d: i.p3b4e6d80,
              id: "Ellipse 13",
              stroke: "var(--stroke-0, #286FED)",
            }),
          }),
        }),
      }),
      e.jsx("div", {
        className: "absolute h-[7.69px] left-[500px] top-[928.54px] w-[91px]",
        children: e.jsx("div", {
          className: "absolute inset-[-5.94%_-0.23%_-6.5%_-0.22%]",
          children: e.jsx("svg", {
            className: "block size-full",
            fill: "none",
            preserveAspectRatio: "none",
            viewBox: "0 0 91.4146 8.64696",
            children: e.jsx("path", {
              d: i.p77f4400,
              id: "Ellipse 14",
              stroke: "var(--stroke-0, #286FED)",
              strokeOpacity: "0.1",
            }),
          }),
        }),
      }),
      e.jsx("div", {
        className: "absolute h-[7.69px] left-[723px] top-[928.54px] w-[96.5px]",
        children: e.jsx("div", {
          className: "absolute inset-[-5.94%_-0.22%_-6.5%_-0.21%]",
          children: e.jsx("svg", {
            className: "block size-full",
            fill: "none",
            preserveAspectRatio: "none",
            viewBox: "0 0 96.9146 8.64698",
            children: e.jsx("path", {
              d: i.p17cde880,
              id: "Ellipse 15",
              stroke: "var(--stroke-0, #286FED)",
              strokeOpacity: "0.1",
            }),
          }),
        }),
      }),
    ],
  });
}
function A9() {
  return e.jsxs("div", {
    className:
      "-translate-x-1/2 absolute contents left-[calc(50%+559.62px)] top-[2326.76px]",
    children: [
      e.jsx("div", {
        className:
          "-translate-x-1/2 absolute left-[calc(50%+558.42px)] size-[353.221px] top-[2376.48px]",
        children: e.jsx("img", {
          alt: "",
          className: "absolute block inset-0 max-w-none",
          height: "353.221",
          src: Gr,
          width: "353.221",
        }),
      }),
      e.jsx("div", {
        className:
          "-translate-x-1/2 absolute left-[calc(50%+559.62px)] size-[452.647px] top-[2326.76px]",
        children: e.jsx("svg", {
          className: "absolute block inset-0",
          fill: "none",
          preserveAspectRatio: "none",
          viewBox: "0 0 452.647 452.647",
          children: e.jsx("circle", {
            cx: "226.323",
            cy: "226.323",
            id: "Ellipse 19",
            r: "225.323",
            stroke: "var(--stroke-0, #286FED)",
            strokeOpacity: "0.5",
            strokeWidth: "2",
          }),
        }),
      }),
    ],
  });
}
function D9() {
  return e.jsxs("div", {
    className: "absolute contents left-[1443.06px] top-[2476.53px]",
    children: [
      e.jsx("div", {
        className:
          "-translate-x-1/2 absolute bg-[#2663eb] border border-[#e6e9ef] border-solid left-[calc(50%+559.62px)] rounded-[37px] shadow-[0px_4px_4px_0px_rgba(232,242,254,0.45)] size-[153.117px] top-[2476.53px]",
      }),
      e.jsx("p", {
        className:
          "absolute font-['Prata:Regular',sans-serif] h-[25.706px] leading-[22.5px] left-[1459.82px] not-italic text-[21px] text-white top-[2540.23px] tracking-[1px] w-[118.47px] whitespace-pre-wrap",
        children: "TruBoard",
      }),
    ],
  });
}
function R9() {
  return e.jsx("div", {
    className: "absolute inset-[36.31%_19.31%_63.25%_79.23%]",
    children: e.jsx("div", {
      className: "absolute inset-[-3.58%]",
      children: e.jsx("svg", {
        className: "block size-full",
        fill: "none",
        preserveAspectRatio: "none",
        viewBox: "0 0 29.9411 29.9411",
        children: e.jsxs("g", {
          id: "Group 258",
          children: [
            e.jsx("path", {
              d: i.p146a6600,
              id: "Vector",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: i.p2a628b00,
              id: "Vector_2",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
          ],
        }),
      }),
    }),
  });
}
function S9() {
  return e.jsx("div", {
    className: "absolute inset-[38.7%_32.07%_60.84%_66.72%]",
    children: e.jsx("div", {
      className: "absolute inset-[-3.44%_-4.3%]",
      children: e.jsx("svg", {
        className: "block size-full",
        fill: "none",
        preserveAspectRatio: "none",
        viewBox: "0 0 25.247 31.0637",
        children: e.jsxs("g", {
          id: "Group 259",
          children: [
            e.jsx("path", {
              d: i.p3eab4e00,
              id: "Vector",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: "M12.6218 9.71854V15.5303",
              id: "Vector_2",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: "M12.6218 21.3418H12.6369",
              id: "Vector_3",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
          ],
        }),
      }),
    }),
  });
}
function I9() {
  return e.jsx("div", {
    className: "absolute inset-[42.04%_9.45%_57.55%_89.19%]",
    children: e.jsx("div", {
      className: "absolute inset-[-3.82%_-3.82%_-3.82%_-3.83%]",
      children: e.jsx("svg", {
        className: "block size-full",
        fill: "none",
        preserveAspectRatio: "none",
        viewBox: "0 0 28.1528 28.1525",
        children: e.jsxs("g", {
          id: "Group 260",
          children: [
            e.jsx("path", {
              d: "M5.35903 1V18.4353",
              id: "Vector",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: i.p3c55f000,
              id: "Vector_2",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: i.p351ca100,
              id: "Vector_3",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: i.p388dab00,
              id: "Vector_4",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
          ],
        }),
      }),
    }),
  });
}
function T9() {
  return e.jsx("div", {
    className: "absolute inset-[42.52%_30.31%_57.03%_68.17%]",
    children: e.jsx("div", {
      className: "absolute inset-[-3.44%]",
      children: e.jsx("svg", {
        className: "block size-full",
        fill: "none",
        preserveAspectRatio: "none",
        viewBox: "0 0 31.0588 31.0588",
        children: e.jsxs("g", {
          id: "Group 261",
          children: [
            e.jsx("path", {
              d: i.p226d3820,
              id: "Vector",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: "M15.5296 9.71746V15.5292",
              id: "Vector_2",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: "M15.5296 21.3407H15.5447",
              id: "Vector_3",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
          ],
        }),
      }),
    }),
  });
}
function z9() {
  return e.jsxs("div", {
    className: "absolute contents left-[1262px] top-[2291px]",
    children: [
      e.jsx(A9, {}),
      e.jsx("div", {
        className:
          "absolute bg-white border border-[#e6e9ef] border-solid h-[60.353px] left-[1504.53px] rounded-[10px] shadow-[0px_4px_14px_0px_#d1d5dc] top-[2291px] w-[61.471px]",
      }),
      e.jsx("div", {
        className:
          "absolute bg-white border border-[#e6e9ef] border-solid h-[60.353px] left-[1694.53px] rounded-[10px] shadow-[0px_4px_14px_0px_#d1d5dc] top-[2655.35px] w-[61.471px]",
      }),
      e.jsx("div", {
        className:
          "absolute bg-white border border-[#e6e9ef] border-solid h-[60.353px] left-[1293.29px] rounded-[10px] shadow-[0px_4px_14px_0px_#d1d5dc] top-[2686.65px] w-[61.471px]",
      }),
      e.jsx("div", {
        className:
          "absolute bg-white border border-[#e6e9ef] border-solid h-[60.353px] left-[1262px] rounded-[10px] shadow-[0px_4px_14px_0px_#d1d5dc] top-[2445.24px] w-[61.471px]",
      }),
      e.jsx(D9, {}),
      e.jsx(R9, {}),
      e.jsx(S9, {}),
      e.jsx(I9, {}),
      e.jsx(T9, {}),
    ],
  });
}
function P9() {
  return e.jsx("div", {
    className: "absolute left-0 size-[20px] top-[2px]",
    "data-name": "Icon",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 20 20",
      children: e.jsxs("g", {
        id: "Icon",
        children: [
          e.jsx("path", {
            d: i.p14d24500,
            id: "Vector",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.25",
          }),
          e.jsx("path", {
            d: "M10 5V10L13.3333 11.6667",
            id: "Vector_2",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.25",
          }),
        ],
      }),
    }),
  });
}
function H9() {
  return e.jsx("div", {
    className: "absolute h-[26px] left-[36px] top-0 w-[202.656px]",
    "data-name": "Text",
    children: e.jsx("p", {
      className:
        "absolute font-['Inter:Regular',sans-serif] font-normal leading-[26px] left-0 not-italic text-[#475569] text-[16px] top-[-0.67px] tracking-[-0.3125px]",
      children: "Cost and schedule overruns",
    }),
  });
}
function W9() {
  return e.jsxs("div", {
    className: "absolute h-[26px] left-[129px] top-[2530px] w-[718px]",
    "data-name": "List Item",
    children: [e.jsx(P9, {}), e.jsx(H9, {})],
  });
}
function O9() {
  return e.jsx("div", {
    className: "absolute left-0 size-[20px] top-[2px]",
    "data-name": "Icon",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 20 20",
      children: e.jsxs("g", {
        id: "Icon",
        children: [
          e.jsx("path", {
            d: i.p25fc4100,
            id: "Vector",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.25",
          }),
          e.jsx("path", {
            d: "M10 6.66667V10",
            id: "Vector_2",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.25",
          }),
          e.jsx("path", {
            d: "M10 13.3333H10.0083",
            id: "Vector_3",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.25",
          }),
        ],
      }),
    }),
  });
}
function U9() {
  return e.jsx("div", {
    className: "absolute h-[26px] left-[36px] top-0 w-[272.906px]",
    "data-name": "Text",
    children: e.jsx("p", {
      className:
        "absolute font-['Inter:Regular',sans-serif] font-normal leading-[26px] left-0 not-italic text-[#475569] text-[16px] top-[-0.67px] tracking-[-0.3125px]",
      children: "Capital leakage and weak governance",
    }),
  });
}
function Q9() {
  return e.jsxs("div", {
    className: "absolute h-[26px] left-[129px] top-[2586px] w-[718px]",
    "data-name": "List Item",
    children: [e.jsx(O9, {}), e.jsx(U9, {})],
  });
}
function $9() {
  return e.jsx("div", {
    className: "absolute left-0 size-[20px] top-[2px]",
    "data-name": "Icon",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 20 20",
      children: e.jsxs("g", {
        id: "Icon",
        children: [
          e.jsx("path", {
            d: "M5 2.5V12.5",
            id: "Vector",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.25",
          }),
          e.jsx("path", {
            d: i.p3a3cf580,
            id: "Vector_2",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.25",
          }),
          e.jsx("path", {
            d: i.p34c9bb80,
            id: "Vector_3",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.25",
          }),
          e.jsx("path", {
            d: i.p13cf9c00,
            id: "Vector_4",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.25",
          }),
        ],
      }),
    }),
  });
}
function X9() {
  return e.jsx("div", {
    className: "absolute h-[26px] left-[36px] top-0 w-[253.094px]",
    "data-name": "Text",
    children: e.jsx("p", {
      className:
        "absolute font-['Inter:Regular',sans-serif] font-normal leading-[26px] left-0 not-italic text-[#475569] text-[16px] top-[-0.67px] tracking-[-0.3125px]",
      children: "Disconnected teams and data silos",
    }),
  });
}
function Y9() {
  return e.jsxs("div", {
    className: "absolute h-[26px] left-[129px] top-[2640px] w-[718px]",
    "data-name": "List Item",
    children: [e.jsx($9, {}), e.jsx(X9, {})],
  });
}
function K9() {
  return e.jsx("div", {
    className: "absolute left-0 size-[20px] top-[2px]",
    "data-name": "Icon",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 20 20",
      children: e.jsxs("g", {
        id: "Icon",
        children: [
          e.jsx("path", {
            d: i.p14d24500,
            id: "Vector",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.25",
          }),
          e.jsx("path", {
            d: "M10 6.66667V10",
            id: "Vector_2",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.25",
          }),
          e.jsx("path", {
            d: "M10 13.3333H10.0083",
            id: "Vector_3",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "1.25",
          }),
        ],
      }),
    }),
  });
}
function J9() {
  return e.jsx("div", {
    className: "absolute h-[26px] left-[36px] top-0 w-[330.552px]",
    "data-name": "Text",
    children: e.jsx("p", {
      className:
        "absolute font-['Inter:Regular',sans-serif] font-normal leading-[26px] left-0 not-italic text-[#475569] text-[16px] top-[-0.67px] tracking-[-0.3125px]",
      children: "Reactive reporting instead of real-time insight",
    }),
  });
}
function q9() {
  return e.jsxs("div", {
    className: "absolute h-[26px] left-[129px] top-[2696px] w-[718px]",
    "data-name": "List Item",
    children: [e.jsx(K9, {}), e.jsx(J9, {})],
  });
}
function ed() {
  return e.jsxs("div", {
    className: "absolute contents left-[112px] top-[2523px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-[#fdfdfd] border border-[#f6f7f7] border-solid inset-[39.69%_53.28%_59.68%_5.83%] rounded-[12px] shadow-[0px_8px_31.5px_0px_rgba(153,161,175,0.25)]",
      }),
      e.jsx("div", {
        className:
          "absolute bg-[#fdfdfd] border border-[#f6f7f7] border-solid inset-[41.43%_53.28%_57.95%_5.83%] rounded-[12px] shadow-[0px_8px_31.5px_0px_rgba(153,161,175,0.25)]",
      }),
      e.jsx("div", {
        className:
          "absolute bg-[#fdfdfd] border border-[#f6f7f7] border-solid inset-[40.56%_53.28%_58.81%_5.83%] rounded-[12px] shadow-[0px_8px_31.5px_0px_rgba(153,161,175,0.25)]",
      }),
      e.jsx("div", {
        className:
          "absolute bg-[#fdfdfd] border border-[#f6f7f7] border-solid inset-[42.29%_53.28%_57.08%_5.83%] rounded-[12px] shadow-[0px_8px_31.5px_0px_rgba(153,161,175,0.25)]",
      }),
      e.jsx(W9, {}),
      e.jsx(Q9, {}),
      e.jsx(Y9, {}),
      e.jsx(q9, {}),
    ],
  });
}
function td() {
  return e.jsx("div", {
    className: "absolute contents left-[51px] top-[4px]",
    children: e.jsx("p", {
      className:
        "-translate-x-1/2 absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[28px] left-[394.5px] not-italic text-[20px] text-center text-white top-[4px] tracking-[-0.4492px] w-[687px] whitespace-pre-wrap",
      children: "TruBoard exists to fix this.",
    }),
  });
}
function ld() {
  return e.jsx("div", {
    className:
      "absolute bg-[#286fed] h-[35px] left-[111px] rounded-[8px] top-[2746px] w-[786px]",
    "data-name": "Paragraph",
    children: e.jsx(td, {}),
  });
}
function rd() {
  return e.jsxs("div", {
    className: "absolute contents left-[111px] top-[2291px]",
    children: [
      e.jsx(z9, {}),
      e.jsx("p", {
        className:
          "absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[60px] left-[111px] not-italic text-[#0c1b56] text-[45px] top-[2291px] tracking-[0.3516px] w-[630px] whitespace-pre-wrap",
        children: "Assets fail from fragmented, not flawed execution",
      }),
      e.jsx("div", {
        className:
          "absolute flex items-center justify-center left-[111px] top-[2424px] w-[941.748px]",
        style: {
          "--transform-inner-width": "1184.65625",
          "--transform-inner-height": "42.65625",
        },
        children: e.jsx("div", {
          className: "flex-none skew-x-[-0.06deg]",
          children: e.jsx("p", {
            className:
              "font-['Inter:Regular',sans-serif] font-normal leading-[29.25px] not-italic relative text-[#475569] text-[18px] tracking-[-0.4395px] w-[941.683px] whitespace-pre-wrap",
            children:
              "Real estate projects break down when execution is disconnected, visibility is limited, and decisions arrive too late.  Even well-capitalized assets suffer when teams, data, and accountability operate in silos.",
          }),
        }),
      }),
      e.jsx(ed, {}),
      e.jsx(ld, {}),
    ],
  });
}
function id() {
  return e.jsx("div", {
    className: "h-[60px] relative shrink-0 w-full",
    "data-name": "Heading 2",
    children: e.jsx("p", {
      className:
        "-translate-x-1/2 absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[60px] left-[584px] not-italic text-[#0c1b56] text-[45px] text-center top-[-0.1px] tracking-[0.3516px] w-[1168px] whitespace-pre-wrap",
      children: "Two Integrated Capabilities. One Operating Layer.",
    }),
  });
}
function nd() {
  return e.jsx("div", {
    className: "h-[29.25px] relative shrink-0 w-full",
    "data-name": "Paragraph",
    children: e.jsx("p", {
      className:
        "-translate-x-1/2 absolute font-['Inter:Regular',sans-serif] font-normal leading-[29.25px] left-[584px] not-italic text-[#475569] text-[18px] text-center top-[-0.1px] tracking-[-0.4395px] w-[1168px] whitespace-pre-wrap",
      children:
        "Execution on the ground, intelligence in real time - unified into one system.",
    }),
  });
}
function sd() {
  return e.jsx("div", {
    className: "h-[32px] relative shrink-0 w-full",
    "data-name": "Heading 3",
    children: e.jsx("p", {
      className:
        "absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[32px] left-0 not-italic text-[#fafbfe] text-[24px] top-[-0.67px] tracking-[0.0703px]",
      children: "Services",
    }),
  });
}
function ad() {
  return e.jsx("div", {
    className: "h-[104px] relative shrink-0 w-full",
    "data-name": "Paragraph",
    children: e.jsx("p", {
      className:
        "absolute font-['Inter:Regular',sans-serif] font-normal leading-[26px] left-0 not-italic text-[16px] text-white top-[-0.67px] tracking-[-0.3125px] w-[483px] whitespace-pre-wrap",
      children:
        "End-to-end real estate services combining Project Management Consultancy and Asset Management to deliver execution certainty, disciplined governance, and capital protection across the asset lifecycle.",
    }),
  });
}
function od() {
  return e.jsxs("div", {
    className:
      "bg-[#286fed] col-1 content-stretch flex flex-col gap-[21px] items-start justify-self-start p-[20px] relative rounded-[12px] row-1 self-start shadow-[0px_4px_13.4px_0px_rgba(0,0,0,0.25)] shrink-0 w-[575px]",
    "data-name": "Container",
    children: [
      e.jsx(sd, {}),
      e.jsx(ad, {}),
      e.jsx("p", {
        className:
          "font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[14px] text-white tracking-[-0.1504px] w-full whitespace-pre-wrap",
        children: "Learn more →",
      }),
    ],
  });
}
function dd() {
  return e.jsx("div", {
    className: "h-[32px] relative shrink-0 w-full",
    "data-name": "Heading 3",
    children: e.jsx("p", {
      className:
        "absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[32px] left-0 not-italic text-[#0c1b56] text-[24px] top-[-0.67px] tracking-[0.0703px]",
      children: "TruGenie",
    }),
  });
}
function cd() {
  return e.jsx("div", {
    className: "h-[78px] relative shrink-0 w-full",
    "data-name": "Paragraph",
    children: e.jsx("p", {
      className:
        "absolute font-['Inter:Regular',sans-serif] font-normal leading-[26px] left-0 not-italic text-[#475569] text-[16px] top-[-0.67px] tracking-[-0.3125px] w-[492px] whitespace-pre-wrap",
      children:
        "An AI-enabled real estate intelligence platform providing real-time dashboards, workflow automation, and early-warning signals across construction, sales, and cashflows.",
    }),
  });
}
function pd() {
  return e.jsxs("div", {
    className:
      "bg-white col-2 content-stretch flex flex-col gap-[21px] h-[238px] items-start justify-self-start p-[20px] relative rounded-[12px] row-1 self-start shrink-0 w-[575px]",
    "data-name": "Container",
    children: [
      e.jsx("div", {
        "aria-hidden": "true",
        className:
          "absolute border border-[rgba(0,0,0,0.08)] border-solid inset-0 pointer-events-none rounded-[12px]",
      }),
      e.jsx(dd, {}),
      e.jsx(cd, {}),
      e.jsx("p", {
        className:
          "font-['Inter:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[#286fed] text-[14px] tracking-[-0.1504px] w-full whitespace-pre-wrap",
        children: "Explore TruGenie →",
      }),
    ],
  });
}
function fd() {
  return e.jsxs("div", {
    className:
      "gap-x-[20px] gap-y-[80px] grid grid-cols-[repeat(2,minmax(0,1fr))] grid-rows-[repeat(1,minmax(0,1fr))] h-[240px] relative shrink-0 w-full",
    "data-name": "Container",
    children: [e.jsx(od, {}), e.jsx(pd, {})],
  });
}
function ud() {
  return e.jsxs("div", {
    className:
      "absolute content-stretch flex flex-col gap-[38px] h-[375px] items-start left-[373px] top-[2871px] w-[1168px]",
    "data-name": "Container",
    children: [e.jsx(id, {}), e.jsx(nd, {}), e.jsx(fd, {})],
  });
}
function xd() {
  return e.jsxs("div", {
    className: "absolute contents left-[1129px] top-[3530px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-white border border-[#e6e9ef] border-solid h-[185.74px] left-[1129px] rounded-[24px] shadow-[0px_4px_4px_0px_rgba(232,242,254,0.45)] top-[3530px] w-[269.549px]",
      }),
      e.jsx("p", {
        className:
          "absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[52px] leading-[23px] left-[1148px] not-italic text-[#002672] text-[18px] top-[3623px] tracking-[-0.4395px] w-[152px] whitespace-pre-wrap",
        children: "Institutional capital mindset",
      }),
      e.jsx("div", {
        className:
          "absolute bg-[#eff6ff] h-[53.23px] left-[1143.72px] rounded-[13px] top-[3546.99px] w-[52.098px]",
      }),
      e.jsx("div", {
        className: "absolute inset-[56.02%_38.54%_43.57%_60.39%]",
        "data-name": "Vector",
        children: e.jsx("div", {
          className: "absolute inset-[-3.84%_-4.91%]",
          children: e.jsx("svg", {
            className: "block size-full",
            fill: "none",
            preserveAspectRatio: "none",
            viewBox: "0 0 22.386 28.0488",
            children: e.jsx("path", {
              d: i.pa924e70,
              id: "Vector",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
          }),
        }),
      }),
    ],
  });
}
function hd() {
  return e.jsx("div", {
    className:
      "absolute h-[53.23px] left-[551.31px] top-[3546.99px] w-[52.098px]",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 52.0977 53.2302",
      children: e.jsxs("g", {
        id: "Group 251",
        children: [
          e.jsx("rect", {
            fill: "var(--fill-0, #EFF6FF)",
            height: "53.2302",
            id: "Rectangle 146",
            rx: "13",
            width: "52.0977",
          }),
          e.jsx("path", {
            d: i.p58595b0,
            id: "Vector",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
          e.jsx("path", {
            d: i.p1f47bf00,
            id: "Vector_2",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
          e.jsx("path", {
            d: i.p1412a600,
            id: "Vector_3",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
          e.jsx("path", {
            d: "M23.0283 18.876H28.3136",
            id: "Vector_4",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
          e.jsx("path", {
            d: "M23.0283 24.1609H28.3136",
            id: "Vector_5",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
          e.jsx("path", {
            d: "M23.0283 29.4465H28.3136",
            id: "Vector_6",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
          e.jsx("path", {
            d: "M23.0283 34.7317H28.3136",
            id: "Vector_7",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
        ],
      }),
    }),
  });
}
function vd() {
  return e.jsxs("div", {
    className: "absolute contents left-[523px] top-[3530px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-white border border-[#e6e9ef] border-solid h-[185.74px] left-[523px] rounded-[24px] shadow-[0px_4px_4px_0px_rgba(232,242,254,0.45)] top-[3530px] w-[269.549px]",
      }),
      e.jsx("p", {
        className:
          "absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[52px] leading-[23px] left-[551px] not-italic text-[#002672] text-[18px] top-[3623px] tracking-[-0.4395px] w-[201px] whitespace-pre-wrap",
        children: "Deep real estate execution expertise",
      }),
      e.jsx(hd, {}),
    ],
  });
}
function Ld() {
  return e.jsx("div", {
    className: "absolute inset-[59.37%_74.25%_40.23%_24.43%]",
    children: e.jsx("div", {
      className: "absolute inset-[-3.92%]",
      children: e.jsx("svg", {
        className: "block size-full",
        fill: "none",
        preserveAspectRatio: "none",
        viewBox: "0 0 27.4826 27.4826",
        children: e.jsxs("g", {
          id: "Group 246",
          children: [
            e.jsx("path", {
              d: i.p20a08b00,
              id: "Vector",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: i.p39daa800,
              id: "Vector_2",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: "M17.5637 1V3.54826",
              id: "Vector_3",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: "M17.5637 23.9343V26.4826",
              id: "Vector_4",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: "M1 17.5637H3.54826",
              id: "Vector_5",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: "M1 9.9189H3.54826",
              id: "Vector_6",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: "M23.9343 17.5637H26.4826",
              id: "Vector_7",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: "M23.9343 9.9189H26.4826",
              id: "Vector_8",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: "M9.9189 1V3.54826",
              id: "Vector_9",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: "M9.9189 23.9343V26.4826",
              id: "Vector_10",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
          ],
        }),
      }),
    }),
  });
}
function jd() {
  return e.jsxs("div", {
    className: "absolute contents left-[428px] top-[3738.39px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-white border border-[#e6e9ef] border-solid h-[185.74px] left-[428px] rounded-[24px] shadow-[0px_4px_4px_0px_rgba(232,242,254,0.45)] top-[3738.39px] w-[269.549px]",
      }),
      e.jsx("p", {
        className:
          "absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[52px] leading-[23px] left-[456px] not-italic text-[#002672] text-[18px] top-[3839px] tracking-[-0.4395px] w-[206px] whitespace-pre-wrap",
        children: "Technology-first approach",
      }),
      e.jsx("div", {
        className:
          "absolute bg-[#eff6ff] h-[53.23px] left-[456.31px] rounded-[13px] top-[3759.91px] w-[52.098px]",
      }),
      e.jsx(Ld, {}),
    ],
  });
}
function Vd() {
  return e.jsx("div", {
    className: "absolute inset-[61.41%_53.18%_38.18%_46.02%]",
    children: e.jsx("div", {
      className: "absolute inset-[-3.92%_-6.54%]",
      children: e.jsx("svg", {
        className: "block size-full",
        fill: "none",
        preserveAspectRatio: "none",
        viewBox: "0 0 17.2895 27.4819",
        children: e.jsxs("g", {
          id: "Group 247",
          children: [
            e.jsx("path", {
              d: i.p30842b80,
              id: "Vector",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: i.p3f890400,
              id: "Vector_2",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
          ],
        }),
      }),
    }),
  });
}
function md() {
  return e.jsx("div", {
    className: "absolute inset-[59.39%_33.74%_40.23%_65.24%]",
    children: e.jsx("div", {
      className: "absolute inset-[-4.08%_-5.1%_-4.08%_-5.09%]",
      children: e.jsx("svg", {
        className: "block size-full",
        fill: "none",
        preserveAspectRatio: "none",
        viewBox: "0 0 21.631 26.5388",
        children: e.jsxs("g", {
          id: "Group 248",
          children: [
            e.jsx("path", {
              d: i.p267e0e00,
              id: "Vector",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: i.p31bd7028,
              id: "Vector_2",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: i.p1ad76b80,
              id: "Vector_3",
              stroke: "var(--stroke-0, #286FED)",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
            }),
          ],
        }),
      }),
    }),
  });
}
function gd() {
  return e.jsxs("div", {
    className: "absolute contents left-[1222px] top-[3738.39px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-white border border-[#e6e9ef] border-solid h-[185.74px] left-[1222px] rounded-[24px] shadow-[0px_4px_4px_0px_rgba(232,242,254,0.45)] top-[3738.39px] w-[269.549px]",
      }),
      e.jsx("p", {
        className:
          "absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[52px] leading-[23px] left-[1241.47px] not-italic text-[#002672] text-[18px] top-[3836px] tracking-[-0.4395px] w-[185px] whitespace-pre-wrap",
        children: "Independent, objective reporting",
      }),
      e.jsx("div", {
        className:
          "absolute bg-[#eff6ff] h-[53.23px] left-[1236.72px] rounded-[13px] top-[3759.91px] w-[52.098px]",
      }),
      e.jsx(md, {}),
    ],
  });
}
function _d() {
  return e.jsx("div", {
    className: "absolute inset-[58.05%_48.47%_41.28%_48.7%]",
    "data-name": "Group",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 54.3627 42.6402",
      children: e.jsxs("g", {
        id: "Group",
        children: [
          e.jsx("path", {
            d: i.p16b9f400,
            fill: "var(--fill-0, #001C57)",
            id: "Vector",
          }),
          e.jsx("path", {
            d: i.p133ff400,
            fill: "var(--fill-0, #001C57)",
            id: "Vector_2",
          }),
          e.jsx("path", {
            d: i.p27493c00,
            fill: "var(--fill-0, #001C57)",
            id: "Vector_3",
          }),
          e.jsx("path", {
            d: i.p165cb300,
            fill: "var(--fill-0, #001C57)",
            id: "Vector_4",
          }),
        ],
      }),
    }),
  });
}
function bd() {
  return e.jsxs("div", {
    className:
      "-translate-x-1/2 absolute contents left-[calc(50%-0.23px)] top-[3438px]",
    children: [
      e.jsx("p", {
        className:
          "-translate-x-1/2 absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[30px] left-[963px] not-italic text-[#002672] text-[45px] text-center top-[3438px] tracking-[-0.4492px]",
        children: "Why TruBoard",
      }),
      e.jsx("div", {
        className:
          "absolute bg-white border border-[#e6e9ef] border-solid h-[185.74px] left-[827px] rounded-[24px] shadow-[0px_4px_4px_0px_rgba(232,242,254,0.45)] top-[3865px] w-[269.549px]",
      }),
      e.jsxs("div", {
        className:
          "absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[78px] leading-[23px] left-[869px] not-italic text-[#002672] text-[18px] top-[3956.74px] tracking-[-0.4395px] w-[211px] whitespace-pre-wrap",
        children: [
          e.jsx("p", {
            className: "mb-0",
            children: "Proven experience across large, ",
          }),
          e.jsx("p", { children: "complex portfolios" }),
        ],
      }),
      e.jsx("div", {
        className:
          "-translate-x-1/2 absolute bg-white border border-[#e6e9ef] border-solid left-[calc(50%+1.37px)] rounded-[17px] shadow-[0px_4px_4px_0px_rgba(232,242,254,0.45)] size-[74.749px] top-[3673.83px]",
      }),
      e.jsx("div", {
        className:
          "absolute bg-[#eff6ff] h-[53.23px] left-[867.72px] rounded-[13px] top-[3892.18px] w-[52.098px]",
      }),
      e.jsx("div", {
        className:
          "-translate-x-1/2 absolute left-[calc(50%+1.45px)] size-[152.895px] top-[3634.2px]",
        children: e.jsx("img", {
          alt: "",
          className: "absolute block inset-0 max-w-none",
          height: "152.895",
          src: Ar,
          width: "152.895",
        }),
      }),
      e.jsx("div", {
        className:
          "-translate-x-1/2 absolute left-[calc(50%+1.97px)] size-[195.933px] top-[3612.68px]",
        children: e.jsx("svg", {
          className: "absolute block inset-0",
          fill: "none",
          preserveAspectRatio: "none",
          viewBox: "0 0 195.933 195.933",
          children: e.jsx("circle", {
            cx: "97.9663",
            cy: "97.9663",
            id: "Ellipse 17",
            r: "96.9663",
            stroke: "var(--stroke-0, #286FED)",
            strokeOpacity: "0.5",
            strokeWidth: "2",
          }),
        }),
      }),
      e.jsx(xd, {}),
      e.jsx(vd, {}),
      e.jsx(jd, {}),
      e.jsx(Vd, {}),
      e.jsx(gd, {}),
      e.jsx(_d, {}),
    ],
  });
}
function Fd() {
  return e.jsx("div", {
    className: "h-[585px] opacity-90 relative shrink-0 w-[1039px]",
    "data-name": "Image (TruGenie Platform Interface)",
    children: e.jsx("img", {
      alt: "",
      className:
        "absolute inset-0 max-w-none object-cover pointer-events-none size-full",
      src: Dr,
    }),
  });
}
function Md() {
  return e.jsx("div", {
    className:
      "bg-[rgba(255,255,255,0)] content-stretch flex flex-col h-[585px] items-start overflow-clip relative rounded-[10px] shadow-[0px_10px_40px_0px_rgba(40,111,237,0.08)] shrink-0 w-[668px]",
    "data-name": "Container",
    children: e.jsx(Fd, {}),
  });
}
function Cd() {
  return e.jsxs("div", {
    className:
      "content-stretch flex flex-col gap-[11px] items-end not-italic relative shrink-0 w-[671px]",
    children: [
      e.jsx("div", {
        className:
          "flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[44px] justify-center leading-[0] relative shrink-0 text-[#002672] text-[32px] w-full",
        children: e.jsx("p", {
          className: "leading-[61px] whitespace-pre-wrap",
          children: "TruGenie - Real Estate Intelligence",
        }),
      }),
      e.jsxs("p", {
        className:
          "font-['Avenir:Roman',sans-serif] leading-[36px] relative shrink-0 text-[#475569] text-[18px] w-full whitespace-pre-wrap",
        children: [
          "TruGenie transforms raw project data into actionable insights.",
          e.jsx("br", { "aria-hidden": "true" }),
          "Key capabilities:",
        ],
      }),
    ],
  });
}
function wd() {
  return e.jsx("div", {
    className: "relative shrink-0 size-[28px]",
    "data-name": "Icon",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 28 28",
      children: e.jsxs("g", {
        id: "Icon",
        children: [
          e.jsx("path", {
            d: i.p39243580,
            id: "Vector",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2.33333",
          }),
          e.jsx("path", {
            d: i.p3ca38d80,
            id: "Vector_2",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2.33333",
          }),
          e.jsx("path", {
            d: i.p3884aec0,
            id: "Vector_3",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2.33333",
          }),
          e.jsx("path", {
            d: i.p13a12d80,
            id: "Vector_4",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2.33333",
          }),
        ],
      }),
    }),
  });
}
function kd() {
  return e.jsx("div", {
    className: "flex-[1_0_0] min-h-px min-w-px relative w-[276px]",
    "data-name": "Heading 3",
    children: e.jsx("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid relative size-full",
      children: e.jsx("p", {
        className:
          "absolute font-['Inter:Medium',sans-serif] font-medium leading-[24px] left-0 not-italic text-[#002672] text-[17px] top-px tracking-[-0.4316px] w-[229px] whitespace-pre-wrap",
        children: "Construction progress & cost tracking",
      }),
    }),
  });
}
function Nd() {
  return e.jsxs("div", {
    className:
      "bg-white col-1 justify-self-stretch relative rounded-[10px] row-1 self-stretch shrink-0",
    "data-name": "CapabilityBlock",
    children: [
      e.jsx("div", {
        "aria-hidden": "true",
        className:
          "absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[10px] shadow-[0px_2px_12.1px_0px_rgba(0,38,114,0.32)]",
      }),
      e.jsxs("div", {
        className:
          "content-stretch flex flex-col gap-[12px] items-start pl-[25px] pr-px py-[25px] relative size-full",
        children: [e.jsx(wd, {}), e.jsx(kd, {})],
      }),
    ],
  });
}
function Zd() {
  return e.jsx("div", {
    className: "relative shrink-0 size-[28px]",
    "data-name": "Icon",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 28 28",
      children: e.jsxs("g", {
        id: "Icon",
        children: [
          e.jsx("path", {
            d: i.p3997a780,
            id: "Vector",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2.33333",
          }),
          e.jsx("path", {
            d: i.p275e0300,
            id: "Vector_2",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2.33333",
          }),
        ],
      }),
    }),
  });
}
function yd() {
  return e.jsx("div", {
    className: "flex-[1_0_0] min-h-px min-w-px relative w-[276px]",
    "data-name": "Heading 3",
    children: e.jsx("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid relative size-full",
      children: e.jsx("p", {
        className:
          "absolute font-['Inter:Medium',sans-serif] font-medium leading-[24px] left-0 not-italic text-[#002672] text-[17px] top-px tracking-[-0.4316px] w-[220px] whitespace-pre-wrap",
        children: "Sales velocity and collection monitoring",
      }),
    }),
  });
}
function Bd() {
  return e.jsxs("div", {
    className:
      "bg-white col-2 justify-self-stretch relative rounded-[10px] row-1 self-stretch shrink-0",
    "data-name": "CapabilityBlock",
    children: [
      e.jsx("div", {
        "aria-hidden": "true",
        className:
          "absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[10px] shadow-[0px_2px_8px_0px_rgba(0,38,114,0.04)]",
      }),
      e.jsxs("div", {
        className:
          "content-stretch flex flex-col gap-[12px] items-start pl-[25px] pr-px py-[25px] relative size-full",
        children: [e.jsx(Zd, {}), e.jsx(yd, {})],
      }),
    ],
  });
}
function Ed() {
  return e.jsx("div", {
    className: "relative shrink-0 size-[28px]",
    "data-name": "Icon",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 28 28",
      children: e.jsxs("g", {
        id: "Icon",
        children: [
          e.jsx("path", {
            d: i.p2fdbf200,
            id: "Vector",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2.33333",
          }),
          e.jsx("path", {
            d: i.p1f5a7680,
            id: "Vector_2",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2.33333",
          }),
        ],
      }),
    }),
  });
}
function Gd() {
  return e.jsx("div", {
    className: "flex-[1_0_0] min-h-px min-w-px relative w-[276px]",
    "data-name": "Heading 3",
    children: e.jsx("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid relative size-full",
      children: e.jsx("p", {
        className:
          "absolute font-['Inter:Medium',sans-serif] font-medium leading-[24px] left-0 not-italic text-[#002672] text-[17px] top-px tracking-[-0.4316px] w-[186px] whitespace-pre-wrap",
        children: "Cashflow and fund-flow intelligence",
      }),
    }),
  });
}
function Ad() {
  return e.jsxs("div", {
    className:
      "bg-white col-1 justify-self-stretch relative rounded-[10px] row-2 self-stretch shrink-0",
    "data-name": "CapabilityBlock",
    children: [
      e.jsx("div", {
        "aria-hidden": "true",
        className:
          "absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[10px] shadow-[0px_2px_8px_0px_rgba(0,38,114,0.04)]",
      }),
      e.jsxs("div", {
        className:
          "content-stretch flex flex-col gap-[12px] items-start pl-[25px] pr-px py-[25px] relative size-full",
        children: [e.jsx(Ed, {}), e.jsx(Gd, {})],
      }),
    ],
  });
}
function Dd() {
  return e.jsx("div", {
    className: "relative shrink-0 size-[28px]",
    "data-name": "Icon",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 28 28",
      children: e.jsxs("g", {
        id: "Icon",
        children: [
          e.jsx("path", {
            d: i.p3da6200,
            id: "Vector",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2.33333",
          }),
          e.jsx("path", {
            d: i.p394f8700,
            id: "Vector_2",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2.33333",
          }),
          e.jsx("path", {
            d: i.pb465bc0,
            id: "Vector_3",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2.33333",
          }),
        ],
      }),
    }),
  });
}
function Rd() {
  return e.jsx("div", {
    className: "h-[24px] relative shrink-0 w-[224.875px]",
    "data-name": "Heading 3",
    children: e.jsx("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid relative size-full",
      children: e.jsx("p", {
        className:
          "absolute font-['Inter:Medium',sans-serif] font-medium leading-[24px] left-0 not-italic text-[#002672] text-[17px] top-px tracking-[-0.4316px]",
        children: "NOC and approval workflows",
      }),
    }),
  });
}
function Sd() {
  return e.jsxs("div", {
    className:
      "bg-white col-2 justify-self-stretch relative rounded-[10px] row-2 self-stretch shrink-0",
    "data-name": "CapabilityBlock",
    children: [
      e.jsx("div", {
        "aria-hidden": "true",
        className:
          "absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[10px] shadow-[0px_2px_8px_0px_rgba(0,38,114,0.04)]",
      }),
      e.jsxs("div", {
        className:
          "content-stretch flex flex-col gap-[12px] items-start pb-px pl-[25px] pr-px pt-[25px] relative size-full",
        children: [e.jsx(Dd, {}), e.jsx(Rd, {})],
      }),
    ],
  });
}
function Id() {
  return e.jsx("div", {
    className: "relative shrink-0 size-[28px]",
    "data-name": "Icon",
    children: e.jsx("svg", {
      className: "absolute block inset-0",
      fill: "none",
      preserveAspectRatio: "none",
      viewBox: "0 0 28 28",
      children: e.jsxs("g", {
        id: "Icon",
        children: [
          e.jsx("path", {
            d: i.p1b228440,
            id: "Vector",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2.33333",
          }),
          e.jsx("path", {
            d: i.p309e840,
            id: "Vector_2",
            stroke: "var(--stroke-0, #286FED)",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2.33333",
          }),
        ],
      }),
    }),
  });
}
function Td() {
  return e.jsx("div", {
    className: "flex-[1_0_0] min-h-px min-w-px relative w-[276px]",
    "data-name": "Heading 3",
    children: e.jsx("div", {
      className:
        "bg-clip-padding border-0 border-[transparent] border-solid relative size-full",
      children: e.jsx("p", {
        className:
          "absolute font-['Inter:Medium',sans-serif] font-medium leading-[24px] left-0 not-italic text-[#002672] text-[17px] top-px tracking-[-0.4316px] w-[222px] whitespace-pre-wrap",
        children: "Compliance, covenant & risk tracking",
      }),
    }),
  });
}
function zd() {
  return e.jsxs("div", {
    className:
      "bg-white col-1 justify-self-stretch relative rounded-[10px] row-3 self-stretch shrink-0",
    "data-name": "CapabilityBlock",
    children: [
      e.jsx("div", {
        "aria-hidden": "true",
        className:
          "absolute border border-[#e2e8f0] border-solid inset-0 pointer-events-none rounded-[10px] shadow-[0px_2px_8px_0px_rgba(0,38,114,0.04)]",
      }),
      e.jsxs("div", {
        className:
          "content-stretch flex flex-col gap-[12px] items-start pl-[25px] pr-px py-[25px] relative size-full",
        children: [e.jsx(Id, {}), e.jsx(Td, {})],
      }),
    ],
  });
}
function Pd() {
  return e.jsxs("div", {
    className:
      "col-1 gap-x-[16px] gap-y-[16px] grid grid-cols-[repeat(2,minmax(0,1fr))] grid-rows-[repeat(3,minmax(0,1fr))] h-[446px] ml-0 mt-0 relative row-1 w-[668px]",
    "data-name": "Container",
    children: [
      e.jsx(Nd, {}),
      e.jsx(Bd, {}),
      e.jsx(Ad, {}),
      e.jsx(Sd, {}),
      e.jsx(zd, {}),
    ],
  });
}
function Hd() {
  return e.jsx("div", {
    className:
      "grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0",
    children: e.jsx(Pd, {}),
  });
}
function Wd() {
  return e.jsxs("div", {
    className:
      "content-stretch flex flex-col gap-[12px] items-start relative shrink-0",
    children: [e.jsx(Cd, {}), e.jsx(Hd, {})],
  });
}
function Od() {
  return e.jsxs("div", {
    className:
      "-translate-x-1/2 absolute content-stretch flex gap-[76px] items-start justify-center left-[calc(50%-0.5px)] top-[4483px]",
    children: [e.jsx(Md, {}), e.jsx(Wd, {})],
  });
}
function Ud() {
  return e.jsxs("div", {
    className: "absolute contents left-[674px] top-[4339px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-[#fdfdfd] border border-[#f6f7f7] border-solid inset-[68.27%_55.83%_31.1%_35.1%] rounded-[14px] shadow-[0px_8px_31.5px_0px_rgba(0,38,114,0.1)]",
      }),
      e.jsx("p", {
        className:
          "absolute font-['Avenir:Medium',sans-serif] h-[28px] leading-[31px] left-[704px] not-italic text-[#005bab] text-[27px] top-[4345px] w-[115px] whitespace-pre-wrap",
        children: "TruGenie",
      }),
    ],
  });
}
function Qd() {
  return e.jsxs("div", {
    className: "absolute contents left-[889px] top-[4339px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-[#fdfdfd] border border-[#f6f7f7] border-solid inset-[68.27%_44.64%_31.1%_46.3%] rounded-[14px]",
      }),
      e.jsx("p", {
        className:
          "-translate-x-1/2 absolute font-['Avenir:Roman',sans-serif] h-[26px] leading-[31px] left-[976px] not-italic text-[#1b2431] text-[27px] text-center top-[4346px] w-[86px] whitespace-pre-wrap",
        children: "PDMS",
      }),
    ],
  });
}
function $d() {
  return e.jsxs("div", {
    className:
      "-translate-x-1/2 absolute contents left-[calc(50%+1px)] top-[4339px]",
    children: [
      e.jsx(Ud, {}),
      e.jsx(Qd, {}),
      e.jsx("p", {
        className:
          "-translate-x-1/2 absolute font-['Avenir:Roman',sans-serif] h-[25px] leading-[31px] left-[1191.5px] not-italic text-[#1b2431] text-[27px] text-center top-[4347px] w-[113px] whitespace-pre-wrap",
        children: "Advisory",
      }),
    ],
  });
}
function Xd() {
  return e.jsxs("div", {
    className: "absolute contents left-[674px] top-[4339px]",
    children: [
      e.jsx("div", {
        className:
          "absolute bg-[#fdfdfd] border border-[#f6f7f7] border-solid inset-[68.49%_34.22%_30.88%_56.72%] rounded-[14px]",
      }),
      e.jsx($d, {}),
    ],
  });
}
function Yd() {
  return e.jsx("div", {
    className: "h-[25.5px] relative shrink-0 w-full",
    "data-name": "Text",
    children: e.jsx("p", {
      className:
        "-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[25.5px] left-[108px] not-italic text-[#1d1d1f] text-[17px] text-center top-0 tracking-[-0.4316px]",
      children: "Request a TruGenie Demo",
    }),
  });
}
function Kd() {
  return e.jsxs("div", {
    className:
      "bg-[rgba(255,255,255,0.6)] content-stretch flex flex-col h-[60px] items-start pb-px pt-[17px] px-[37px] relative rounded-[16777200px] shrink-0 w-[293px]",
    "data-name": "Button",
    children: [
      e.jsx("div", {
        "aria-hidden": "true",
        className:
          "absolute border border-[rgba(0,0,0,0.08)] border-solid inset-0 pointer-events-none rounded-[16777200px] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.04)]",
      }),
      e.jsx(Yd, {}),
    ],
  });
}
function Jd() {
  return e.jsx("div", {
    className:
      "content-stretch flex h-[20px] items-start relative shrink-0 w-full",
    "data-name": "Text",
    children: e.jsx("p", {
      className:
        "font-['Inter:Medium',sans-serif] font-medium leading-[25.5px] not-italic relative shrink-0 text-[17px] text-center text-white tracking-[-0.4316px] w-[206px] whitespace-pre-wrap",
      children: "Talk to Our Services Team",
    }),
  });
}
function qd() {
  return e.jsx("div", {
    className:
      "bg-[#286fed] content-stretch flex flex-col h-[58px] items-center overflow-clip pt-[16px] px-[36px] relative rounded-[16777200px] shadow-[0px_4px_16px_0px_rgba(40,111,237,0.3)] shrink-0 w-[278px]",
    "data-name": "Button",
    children: e.jsx(Jd, {}),
  });
}
function ec() {
  return e.jsxs("div", {
    className:
      "content-stretch flex gap-[10px] items-start justify-center relative shrink-0",
    children: [e.jsx(Kd, {}), e.jsx(qd, {})],
  });
}
function tc() {
  return e.jsxs("div", {
    className:
      "content-stretch flex flex-col gap-[27px] items-center justify-center relative shrink-0 w-full",
    children: [
      e.jsx("div", {
        className:
          "flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[61px] justify-end leading-[0] not-italic relative shrink-0 text-[#002672] text-[45px] text-center w-[1355px]",
        children: e.jsx("p", {
          className: "leading-[61px] whitespace-pre-wrap",
          children:
            "Ready to bring clarity and control to your real estate assets?",
        }),
      }),
      e.jsx(ec, {}),
    ],
  });
}
function lc() {
  return e.jsx("div", {
    className:
      "absolute content-stretch flex flex-col h-[318px] items-start left-0 px-[229px] py-[66px] top-[5229px] w-[1920px]",
    style: {
      backgroundImage:
        "url('data:image/svg+xml;utf8,<svg viewBox=\\'0 0 1920 318\\' xmlns=\\'http://www.w3.org/2000/svg\\' preserveAspectRatio=\\'none\\'><rect x=\\'0\\' y=\\'0\\' height=\\'100%\\' width=\\'100%\\' fill=\\'url(%23grad)\\' opacity=\\'1\\'/><defs><radialGradient id=\\'grad\\' gradientUnits=\\'userSpaceOnUse\\' cx=\\'0\\' cy=\\'0\\' r=\\'10\\' gradientTransform=\\'matrix(8.7609e-15 23.697 -143.08 6.5352e-14 960 81.029)\\'><stop stop-color=\\'rgba(233,240,255,1)\\' offset=\\'0\\'/><stop stop-color=\\'rgba(255,255,255,1)\\' offset=\\'1\\'/></radialGradient></defs></svg>')",
    },
    children: e.jsx(tc, {}),
  });
}
function rc() {
  return e.jsxs("div", {
    className: "bg-white relative size-full",
    "data-name": "12-Feb-Home Page - F",
    children: [
      e.jsx("div", {
        className:
          "-translate-x-1/2 absolute bottom-[82.96%] left-[calc(50%+1px)] top-0 w-[1920px]",
        style: {
          backgroundImage:
            "url('data:image/svg+xml;utf8,<svg viewBox=\\'0 0 1920 1083\\' xmlns=\\'http://www.w3.org/2000/svg\\' preserveAspectRatio=\\'none\\'><rect x=\\'0\\' y=\\'0\\' height=\\'100%\\' width=\\'100%\\' fill=\\'url(%23grad)\\' opacity=\\'1\\'/><defs><radialGradient id=\\'grad\\' gradientUnits=\\'userSpaceOnUse\\' cx=\\'0\\' cy=\\'0\\' r=\\'10\\' gradientTransform=\\'matrix(8.7609e-15 80.704 -143.08 2.2257e-13 960 275.96)\\'><stop stop-color=\\'rgba(233,240,255,1)\\' offset=\\'0\\'/><stop stop-color=\\'rgba(255,255,255,1)\\' offset=\\'1\\'/></radialGradient></defs></svg>')",
        },
      }),
      e.jsx("div", {
        className:
          "absolute bg-[#d9d9d9] h-[660px] left-[1920px] top-[1414px] w-[53px]",
      }),
      e.jsx("div", {
        className:
          "-translate-x-1/2 absolute bg-[rgba(240,245,255,0.42)] bottom-[74.35%] left-1/2 top-[17.73%] w-[1920px]",
      }),
      e.jsx(e4, {}),
      e.jsx(d4, {}),
      e.jsx(k4, {}),
      e.jsx("p", {
        className:
          "-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold h-[27px] leading-[33px] left-[431.5px] not-italic text-[#7e9ed6] text-[18px] text-center top-[959.54px] tracking-[0.9px] w-[135px] whitespace-pre-wrap",
        children: "Build",
      }),
      e.jsx("p", {
        className:
          "-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold h-[27px] leading-[33px] left-[669px] not-italic text-[#7e9ed6] text-[18px] text-center top-[959.54px] tracking-[0.9px] w-[152px] whitespace-pre-wrap",
        children: "Monetize ",
      }),
      e.jsx("p", {
        className:
          "-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold h-[27px] leading-[33px] left-[891px] not-italic text-[#7e9ed6] text-[18px] text-center top-[959.54px] tracking-[0.9px] w-[104px] whitespace-pre-wrap",
        children: "Exit",
      }),
      e.jsxs("div", {
        className:
          "-translate-x-1/2 absolute font-['Avenir:Roman',sans-serif] h-[58px] leading-[17px] left-[668.5px] not-italic text-[14px] text-[rgba(27,36,49,0.5)] text-center top-[994.54px] tracking-[-0.16px] w-[203px] whitespace-pre-wrap",
        children: [
          e.jsx("p", { className: "mb-0", children: "Sales velocity" }),
          e.jsx("p", { className: "mb-0", children: "Collections tracking" }),
          e.jsx("p", { children: "Cashflow intelligence" }),
        ],
      }),
      e.jsxs("div", {
        className:
          "-translate-x-1/2 absolute font-['Avenir:Roman',sans-serif] h-[65px] leading-[17px] left-[888px] not-italic text-[14px] text-[rgba(27,36,49,0.5)] text-center top-[994.54px] tracking-[-0.16px] w-[248px] whitespace-pre-wrap",
        children: [
          e.jsx("p", { className: "mb-0", children: "Asset performance" }),
          e.jsx("p", {
            className: "mb-0",
            children: "Governance & compliance",
          }),
          e.jsx("p", { children: "Value optimization" }),
        ],
      }),
      e.jsxs("div", {
        className:
          "-translate-x-1/2 absolute font-['Avenir:Roman',sans-serif] h-[63px] leading-[17px] left-[430.5px] not-italic text-[14px] text-[rgba(27,36,49,0.5)] text-center top-[994.54px] tracking-[-0.16px] w-[201px] whitespace-pre-wrap",
        children: [
          e.jsx("p", { className: "mb-0", children: "Construction oversight" }),
          e.jsx("p", {
            className: "mb-0",
            children: "Cost & schedule control",
          }),
          e.jsx("p", { children: "Execution risk visibility" }),
        ],
      }),
      e.jsx("p", {
        className:
          "-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold h-[27px] leading-[33px] left-[205px] not-italic text-[#286fed] text-[18px] text-center top-[959.54px] tracking-[0.9px] w-[150px] whitespace-pre-wrap",
        children: "Plan",
      }),
      e.jsxs("div", {
        className:
          "-translate-x-1/2 absolute font-['Avenir:Roman',sans-serif] h-[65px] leading-[17px] left-[204px] not-italic text-[#182655] text-[14px] text-center top-[994.54px] tracking-[-0.16px] w-[172px] whitespace-pre-wrap",
        children: [
          e.jsx("p", { className: "mb-0", children: "Feasibility" }),
          e.jsx("p", { className: "mb-0", children: "Risk assessment" }),
          e.jsx("p", { children: "Capital structuring" }),
        ],
      }),
      e.jsx(p6, {}),
      e.jsxs("p", {
        className:
          "absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[0] left-[110px] not-italic text-[#0c1b56] text-[0px] text-[45px] top-[1173px] w-[279px] whitespace-pre-wrap",
        children: [
          e.jsx("span", { className: "leading-[72px]", children: "Our " }),
          e.jsx("span", { className: "leading-[72px]", children: "Impact" }),
        ],
      }),
      e.jsx(x6, {}),
      e.jsx(h6, {}),
      e.jsx(v6, {}),
      e.jsx(C6, {}),
      e.jsx(E9, {}),
      e.jsx(G9, {}),
      e.jsx("div", {
        className:
          "-translate-x-1/2 absolute bottom-[49.62%] left-[calc(50%+1px)] top-[34.64%] w-[1920px]",
        style: {
          backgroundImage:
            "url('data:image/svg+xml;utf8,<svg viewBox=\\'0 0 1920 1000\\' xmlns=\\'http://www.w3.org/2000/svg\\' preserveAspectRatio=\\'none\\'><rect x=\\'0\\' y=\\'0\\' height=\\'100%\\' width=\\'100%\\' fill=\\'url(%23grad)\\' opacity=\\'1\\'/><defs><radialGradient id=\\'grad\\' gradientUnits=\\'userSpaceOnUse\\' cx=\\'0\\' cy=\\'0\\' r=\\'10\\' gradientTransform=\\'matrix(8.7609e-15 74.519 -143.08 2.0551e-13 960 254.81)\\'><stop stop-color=\\'rgba(233,240,255,1)\\' offset=\\'0\\'/><stop stop-color=\\'rgba(255,255,255,1)\\' offset=\\'1\\'/></radialGradient></defs></svg>')",
        },
      }),
      e.jsx("div", {
        className:
          "-translate-x-1/2 absolute bottom-[33.95%] left-[calc(50%+1px)] top-[52.82%] w-[1920px]",
        style: {
          backgroundImage:
            "url('data:image/svg+xml;utf8,<svg viewBox=\\'0 0 1920 841\\' xmlns=\\'http://www.w3.org/2000/svg\\' preserveAspectRatio=\\'none\\'><rect x=\\'0\\' y=\\'0\\' height=\\'100%\\' width=\\'100%\\' fill=\\'url(%23grad)\\' opacity=\\'0.5199999809265137\\'/><defs><radialGradient id=\\'grad\\' gradientUnits=\\'userSpaceOnUse\\' cx=\\'0\\' cy=\\'0\\' r=\\'10\\' gradientTransform=\\'matrix(8.7609e-15 62.671 -143.08 1.7283e-13 960 214.29)\\'><stop stop-color=\\'rgba(233,240,255,1)\\' offset=\\'0\\'/><stop stop-color=\\'rgba(255,255,255,1)\\' offset=\\'1\\'/></radialGradient></defs></svg>')",
        },
      }),
      e.jsx(rd, {}),
      e.jsx(ud, {}),
      e.jsx(bd, {}),
      e.jsx(Od, {}),
      e.jsx("p", {
        className:
          "-translate-x-1/2 absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[61px] left-[calc(50%+0.5px)] not-italic text-[#0c1b56] text-[45px] text-center top-[4213px] w-[1191px] whitespace-pre-wrap",
        children: "TruBoard Real Estate Offerings",
      }),
      e.jsx(Xd, {}),
      e.jsx(lc, {}),
    ],
  });
}
const ic =
  "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODgiIGhlaWdodD0iODgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBvcGFjaXR5PSIuMyIgZmlsbD0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIzLjciPjxyZWN0IHg9IjE2IiB5PSIxNiIgd2lkdGg9IjU2IiBoZWlnaHQ9IjU2IiByeD0iNiIvPjxwYXRoIGQ9Im0xNiA1OCAxNi0xOCAzMiAzMiIvPjxjaXJjbGUgY3g9IjUzIiBjeT0iMzUiIHI9IjciLz48L3N2Zz4KCg==";
function Qn(L) {
  const [F, u] = $.useState(!1),
    k = () => {
      u(!0);
    },
    { src: g, alt: M, style: P, className: D, ...N } = L;
  return F
    ? e.jsx("div", {
        className: `inline-block bg-gray-100 text-center align-middle ${D ?? ""}`,
        style: P,
        children: e.jsx("div", {
          className: "flex items-center justify-center w-full h-full",
          children: e.jsx("img", {
            src: ic,
            alt: "Error loading image",
            ...N,
            "data-original-url": g,
          }),
        }),
      })
    : e.jsx("img", {
        src: g,
        alt: M,
        className: D,
        style: P,
        ...N,
        onError: k,
      });
}
const nc =
    "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100'%3E%3Crect fill='%23f0f0f0' width='100' height='100'/%3E%3C/svg%3E",
  sc = [
    "https://images.unsplash.com/photo-1762146828422-50a8bd416d3c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZWFsJTIwZXN0YXRlJTIwcGxhbm5pbmclMjBibHVlcHJpbnQlMjBhcmNoaXRlY3R1cmV8ZW58MXx8fHwxNzcxNTAxMDUzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    "https://images.unsplash.com/photo-1698234790025-4f3faa2a2df0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjBidWlsZGluZyUyMHNpdGUlMjBwcm9ncmVzc3xlbnwxfHx8fDE3NzE1MDEwNTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    "https://images.unsplash.com/flagged/photo-1558954157-aa76c0d246c6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZWFsJTIwZXN0YXRlJTIwc2FsZXMlMjBidXNpbmVzcyUyMGFuYWx5dGljc3xlbnwxfHx8fDE3NzE1MDEwNTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    "https://images.unsplash.com/photo-1578088369622-b26f899a016e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBidWlsZGluZyUyMGFzc2V0JTIwbWFuYWdlbWVudCUyMHBvcnRmb2xpb3xlbnwxfHx8fDE3NzE1MDEwNTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  ],
  E0 = [
    {
      label: "Plan",
      items: ["Feasibility", "Risk assessment", "Capital structuring"],
      imgStyle: {
        height: "559.56%",
        left: "-155.98%",
        top: "-366.67%",
        width: "734.93%",
      },
      imgW: 133,
      imgH: 116,
      imgX: 31,
      imgY: 27,
    },
    {
      label: "Build",
      items: [
        "Construction oversight",
        "Cost & schedule control",
        "Execution risk visibility",
      ],
      imgStyle: {
        height: "485.31%",
        left: "-253.56%",
        top: "-304.74%",
        width: "714.42%",
      },
      imgW: 136,
      imgH: 134,
      imgX: 31,
      imgY: 18,
    },
    {
      label: "Monetize",
      items: [
        "Sales velocity",
        "Collections tracking",
        "Cashflow intelligence",
      ],
      imgStyle: {
        height: "485.31%",
        left: "-357.3%",
        top: "-304.74%",
        width: "714.42%",
      },
      imgW: 137,
      imgH: 134,
      imgX: 31,
      imgY: 18,
    },
    {
      label: "Exit",
      items: [
        "Asset performance",
        "Governance & compliance",
        "Value optimization",
      ],
      imgStyle: {
        height: "457.14%",
        left: "-448.31%",
        top: "-281.25%",
        width: "695.02%",
      },
      imgW: 140,
      imgH: 142,
      imgX: 27,
      imgY: 12,
    },
  ];
function ac() {
  const [L, F] = $.useState(0),
    [u, k] = $.useState(!1),
    g = $.useCallback(() => {
      F((A) => (A + 1) % 4);
    }, []);
  $.useEffect(() => {
    if (u) return;
    const A = setInterval(g, 3500);
    return () => clearInterval(A);
  }, [u, g]);
  const M = (A) => {
      (F(A), k(!0), setTimeout(() => k(!1), 8e3));
    },
    P = [107, 333, 559, 785],
    D = [
      { left: 205, width: 150 },
      { left: 431.5, width: 135 },
      { left: 669, width: 152 },
      { left: 891, width: 104 },
    ],
    N = [
      { left: 204, width: 172 },
      { left: 430.5, width: 201 },
      { left: 668.5, width: 203 },
      { left: 888, width: 248 },
    ];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsxs("div", {
        className: "absolute left-0 top-[791.54px] w-[1100px] h-[300px] z-10",
        children: [
          e.jsx("div", {
            className:
              "absolute pointer-events-none transition-opacity duration-500 z-30",
            style: {
              left: 269,
              top: 125,
              width: 103,
              height: 15,
              opacity: L === 0 ? 1 : 0.1,
            },
            children: e.jsx("div", {
              className: "absolute",
              style: { inset: "-3.04% -0.2% -3.33% 0" },
              children: e.jsx("svg", {
                className: "block size-full",
                fill: "none",
                preserveAspectRatio: "none",
                viewBox: "0 0 103.246 15.9567",
                children: e.jsx("path", {
                  d: i.p3b4e6d80,
                  stroke: "#286FED",
                  strokeWidth: "1",
                }),
              }),
            }),
          }),
          e.jsx("div", {
            className:
              "absolute pointer-events-none transition-opacity duration-500 z-30",
            style: {
              left: 500,
              top: 137,
              width: 91,
              height: 7.69,
              opacity: L === 1 ? 1 : 0.1,
            },
            children: e.jsx("div", {
              className: "absolute",
              style: { inset: "-5.94% -0.22% -6.5% -0.23%" },
              children: e.jsx("svg", {
                className: "block size-full",
                fill: "none",
                preserveAspectRatio: "none",
                viewBox: "0 0 91.4146 8.64696",
                children: e.jsx("path", {
                  d: i.p77f4400,
                  stroke: "#286FED",
                  strokeWidth: "1",
                }),
              }),
            }),
          }),
          e.jsx("div", {
            className:
              "absolute pointer-events-none transition-opacity duration-500 z-30",
            style: {
              left: 723,
              top: 137,
              width: 96.5,
              height: 7.69,
              opacity: L === 2 ? 1 : 0.1,
            },
            children: e.jsx("div", {
              className: "absolute",
              style: { inset: "-5.94% -0.21% -6.5% -0.22%" },
              children: e.jsx("svg", {
                className: "block size-full",
                fill: "none",
                preserveAspectRatio: "none",
                viewBox: "0 0 96.9146 8.64698",
                children: e.jsx("path", {
                  d: i.p17cde880,
                  stroke: "#286FED",
                  strokeWidth: "1",
                }),
              }),
            }),
          }),
          E0.map((A, z) => {
            const H = z === L;
            return e.jsx(
              "div",
              {
                className:
                  "absolute cursor-pointer transition-all duration-500",
                style: {
                  left: P[z],
                  top: 0,
                  width: 196,
                  height: 159,
                  borderRadius: 20,
                  background: "#fafbfe",
                  border: H ? "1.5px solid #d1ebff" : "1.5px solid white",
                  boxShadow: H
                    ? "0px 0px 17.1px 0px rgba(63,146,209,0.2)"
                    : "0px 0px 4px 0px rgba(205,212,224,0.8)",
                },
                onClick: () => M(z),
                children: e.jsx("div", {
                  className:
                    "absolute overflow-hidden pointer-events-none transition-opacity duration-500",
                  style: {
                    width: A.imgW,
                    height: A.imgH,
                    left: A.imgX,
                    top: A.imgY,
                    opacity: H ? 1 : 0.2,
                  },
                  children: e.jsx("img", {
                    alt: "",
                    className: "absolute max-w-none",
                    src: nc,
                    style: {
                      height: A.imgStyle.height,
                      left: A.imgStyle.left,
                      top: A.imgStyle.top,
                      width: A.imgStyle.width,
                    },
                  }),
                }),
              },
              A.label,
            );
          }),
          E0.map((A, z) => {
            const H = z === L;
            return e.jsx(
              "div",
              {
                className: "absolute text-center cursor-pointer",
                style: {
                  left: D[z].left,
                  width: D[z].width,
                  top: 168,
                  transform: "translateX(-50%)",
                },
                onClick: () => M(z),
                children: e.jsx("p", {
                  className:
                    "font-['Inter',sans-serif] font-bold leading-[33px] text-[18px] tracking-[0.9px] transition-colors duration-500 whitespace-pre-wrap",
                  style: { color: H ? "#286fed" : "#7e9ed6" },
                  children: A.label === "Monetize" ? "Monetize " : A.label,
                }),
              },
              `label-${A.label}`,
            );
          }),
          E0.map((A, z) => {
            const H = z === L;
            return e.jsx(
              "div",
              {
                className:
                  "absolute text-center transition-colors duration-500",
                style: {
                  left: N[z].left,
                  width: N[z].width,
                  top: 203,
                  transform: "translateX(-50%)",
                  color: H ? "#182655" : "rgba(27,36,49,0.5)",
                },
                children: e.jsx("div", {
                  className:
                    "font-['Avenir',sans-serif] leading-[17px] text-[14px] tracking-[-0.16px]",
                  children: A.items.map((Q, ue) =>
                    e.jsx(
                      "p",
                      {
                        className: ue < A.items.length - 1 ? "mb-0" : "",
                        children: Q,
                      },
                      ue,
                    ),
                  ),
                }),
              },
              `desc-${A.label}`,
            );
          }),
        ],
      }),
      e.jsx("div", {
        className: "absolute overflow-hidden z-10 pointer-events-none",
        style: { left: 1041, top: 191, width: 829, height: 862 },
        children: sc.map((A, z) =>
          e.jsx(
            Qn,
            {
              alt: E0[z].label,
              src: A,
              className: "absolute inset-0 w-full h-full object-cover",
              style: {
                opacity: z === L ? 1 : 0,
                transition: "opacity 0.8s ease-in-out",
              },
            },
            z,
          ),
        ),
      }),
    ],
  });
}
const oc = [
  {
    prefix: "$",
    value: 4,
    suffix: "Bn+",
    label: "assets under oversight",
    left: 109,
  },
  {
    prefix: "~",
    value: 200,
    suffix: "Mn",
    label: "sq ft overseeing valued",
    left: 719,
  },
  {
    prefix: "~$",
    value: 5,
    suffix: "Bn",
    label: "across the USA and India",
    left: 1329,
  },
];
function dc({ config: L, animate: F }) {
  const [u, k] = $.useState(0);
  $.useEffect(() => {
    if (!F) {
      k(0);
      return;
    }
    const M = 2e3,
      P = performance.now(),
      D = L.value;
    let N;
    function A(z) {
      const H = z - P,
        Q = Math.min(H / M, 1),
        ue = 1 - Math.pow(1 - Q, 3);
      (k(Math.round(ue * D)), Q < 1 && (N = requestAnimationFrame(A)));
    }
    return ((N = requestAnimationFrame(A)), () => cancelAnimationFrame(N));
  }, [F, L.value]);
  const g = `${L.prefix}${u}${L.suffix}`;
  return e.jsxs("div", {
    className: "flex flex-col items-center justify-center w-full h-full",
    children: [
      e.jsx("p", {
        className:
          "font-['Roboto',sans-serif] font-bold leading-[60px] text-[#286fed] text-[60px] text-center whitespace-pre-wrap",
        style: { fontVariationSettings: "'wdth' 100" },
        children: g,
      }),
      e.jsx("p", {
        className:
          "font-['Avenir',sans-serif] leading-[28px] text-[#1b2431] text-[24px] text-center mt-[4px]",
        children: L.label,
      }),
    ],
  });
}
function cc() {
  const [L, F] = $.useState(!1),
    u = $.useRef(null),
    k = $.useCallback(
      (g) => {
        g.forEach((M) => {
          M.isIntersecting && !L && F(!0);
        });
      },
      [L],
    );
  return (
    $.useEffect(() => {
      const g = new IntersectionObserver(k, { threshold: 0.3 });
      return (u.current && g.observe(u.current), () => g.disconnect());
    }, [k]),
    e.jsx("div", {
      ref: u,
      className: "absolute top-[1299px] left-0 w-full h-[213px] z-10",
      children: oc.map((g, M) =>
        e.jsx(
          "div",
          {
            className:
              "absolute bg-white rounded-[45px] flex items-center justify-center",
            style: {
              left: g.left,
              top: 0,
              width: 483.681,
              height: 213,
              border: "1.5px solid rgba(229,229,229,0.36)",
            },
            children: e.jsx(dc, { config: g, animate: L }),
          },
          M,
        ),
      ),
    })
  );
}
const pc = [
    "Developers & Asset Owners ",
    "Lenders & Banks ",
    "NBFCs & Alternative Capital",
    "Funds & Institutional Investors",
  ],
  fc = [139, 216, 291, 378],
  uc = [55, 55, 55, 55],
  xc = [
    [
      {
        w: 186.356,
        h: 75.299,
        imgH: "688.89%",
        imgL: "-10.64%",
        imgT: "-83.64%",
        imgW: "550.44%",
      },
      {
        w: 185.025,
        h: 75.299,
        imgH: "688.89%",
        imgL: "-129.76%",
        imgT: "-83.64%",
        imgW: "550.44%",
      },
      {
        w: 165.058,
        h: 56.804,
        imgH: "953.85%",
        imgL: "-7.65%",
        imgT: "-296.74%",
        imgW: "621.46%",
      },
      {
        w: 186.356,
        h: 75.299,
        imgH: "879.43%",
        imgL: "-122.07%",
        imgT: "-287.96%",
        imgW: "702.68%",
      },
      {
        w: 186.356,
        h: 75.299,
        imgH: "879.43%",
        imgL: "-217.93%",
        imgT: "-300.46%",
        imgW: "702.68%",
      },
      {
        w: 154.409,
        h: 109.645,
        imgH: "603.04%",
        imgL: "-12.8%",
        imgT: "-369.29%",
        imgW: "848.07%",
      },
      {
        w: 198.336,
        h: 107.003,
        imgH: "620.77%",
        imgL: "-105.02%",
        imgT: "-353.21%",
        imgW: "661.13%",
      },
      {
        w: 141.098,
        h: 107.003,
        imgH: "620.77%",
        imgL: "-285.41%",
        imgT: "-411.78%",
        imgW: "924.58%",
      },
    ],
    [
      {
        w: 186.356,
        h: 75.299,
        imgH: "879.43%",
        imgL: "-217.93%",
        imgT: "-300.46%",
        imgW: "702.68%",
      },
      {
        w: 165.058,
        h: 56.804,
        imgH: "953.85%",
        imgL: "-7.65%",
        imgT: "-296.74%",
        imgW: "621.46%",
      },
      {
        w: 186.356,
        h: 75.299,
        imgH: "688.89%",
        imgL: "-10.64%",
        imgT: "-83.64%",
        imgW: "550.44%",
      },
      {
        w: 141.098,
        h: 107.003,
        imgH: "620.77%",
        imgL: "-285.41%",
        imgT: "-411.78%",
        imgW: "924.58%",
      },
      {
        w: 185.025,
        h: 75.299,
        imgH: "688.89%",
        imgL: "-129.76%",
        imgT: "-83.64%",
        imgW: "550.44%",
      },
      {
        w: 186.356,
        h: 75.299,
        imgH: "879.43%",
        imgL: "-122.07%",
        imgT: "-287.96%",
        imgW: "702.68%",
      },
      {
        w: 198.336,
        h: 107.003,
        imgH: "620.77%",
        imgL: "-105.02%",
        imgT: "-353.21%",
        imgW: "661.13%",
      },
      {
        w: 154.409,
        h: 109.645,
        imgH: "603.04%",
        imgL: "-12.8%",
        imgT: "-369.29%",
        imgW: "848.07%",
      },
    ],
    [
      {
        w: 198.336,
        h: 107.003,
        imgH: "620.77%",
        imgL: "-105.02%",
        imgT: "-353.21%",
        imgW: "661.13%",
      },
      {
        w: 141.098,
        h: 107.003,
        imgH: "620.77%",
        imgL: "-285.41%",
        imgT: "-411.78%",
        imgW: "924.58%",
      },
      {
        w: 186.356,
        h: 75.299,
        imgH: "879.43%",
        imgL: "-217.93%",
        imgT: "-300.46%",
        imgW: "702.68%",
      },
      {
        w: 186.356,
        h: 75.299,
        imgH: "688.89%",
        imgL: "-10.64%",
        imgT: "-83.64%",
        imgW: "550.44%",
      },
      {
        w: 154.409,
        h: 109.645,
        imgH: "603.04%",
        imgL: "-12.8%",
        imgT: "-369.29%",
        imgW: "848.07%",
      },
      {
        w: 185.025,
        h: 75.299,
        imgH: "688.89%",
        imgL: "-129.76%",
        imgT: "-83.64%",
        imgW: "550.44%",
      },
      {
        w: 165.058,
        h: 56.804,
        imgH: "953.85%",
        imgL: "-7.65%",
        imgT: "-296.74%",
        imgW: "621.46%",
      },
      {
        w: 186.356,
        h: 75.299,
        imgH: "879.43%",
        imgL: "-122.07%",
        imgT: "-287.96%",
        imgW: "702.68%",
      },
    ],
    [
      {
        w: 165.058,
        h: 56.804,
        imgH: "953.85%",
        imgL: "-7.65%",
        imgT: "-296.74%",
        imgW: "621.46%",
      },
      {
        w: 186.356,
        h: 75.299,
        imgH: "879.43%",
        imgL: "-122.07%",
        imgT: "-287.96%",
        imgW: "702.68%",
      },
      {
        w: 141.098,
        h: 107.003,
        imgH: "620.77%",
        imgL: "-285.41%",
        imgT: "-411.78%",
        imgW: "924.58%",
      },
      {
        w: 185.025,
        h: 75.299,
        imgH: "688.89%",
        imgL: "-129.76%",
        imgT: "-83.64%",
        imgW: "550.44%",
      },
      {
        w: 186.356,
        h: 75.299,
        imgH: "688.89%",
        imgL: "-10.64%",
        imgT: "-83.64%",
        imgW: "550.44%",
      },
      {
        w: 198.336,
        h: 107.003,
        imgH: "620.77%",
        imgL: "-105.02%",
        imgT: "-353.21%",
        imgW: "661.13%",
      },
      {
        w: 186.356,
        h: 75.299,
        imgH: "879.43%",
        imgL: "-217.93%",
        imgT: "-300.46%",
        imgW: "702.68%",
      },
      {
        w: 154.409,
        h: 109.645,
        imgH: "603.04%",
        imgL: "-12.8%",
        imgT: "-369.29%",
        imgW: "848.07%",
      },
    ],
  ],
  zn = [
    { left: 639, top: 1794 },
    { left: 945, top: 1794 },
    { left: 1252, top: 1794 },
    { left: 1557.56, top: 1794 },
    { left: 639, top: 1997.39 },
    { left: 945, top: 1997.39 },
    { left: 1252, top: 1997.39 },
    { left: 1557.56, top: 1997.39 },
  ];
function hc({ brand: L, pos: F }) {
  return e.jsx("div", {
    className:
      "absolute bg-white rounded-[20px] transition-opacity duration-500",
    style: {
      border: "1.5px solid white",
      width: F.left >= 1500 ? 255.574 : 256.905,
      height: 138.708,
      left: F.left,
      top: F.top,
    },
    children: e.jsx("div", {
      className: "absolute overflow-hidden pointer-events-none",
      style: {
        width: L.w,
        height: L.h,
        left: "50%",
        top: "50%",
        transform: "translate(-50%, -50%)",
      },
      children: e.jsx("img", {
        alt: "",
        className: "absolute max-w-none",
        src: V1,
        style: { height: L.imgH, left: L.imgL, top: L.imgT, width: L.imgW },
      }),
    }),
  });
}
function vc() {
  const [L, F] = $.useState(0);
  return e.jsxs("div", {
    className: "absolute left-0 top-[1704px] w-[1920px] h-[530px] z-10",
    children: [
      e.jsxs("p", {
        className:
          "absolute left-[110px] top-0 font-['Inter',sans-serif] font-semibold leading-[0] text-[#0c1b56] text-[45px] w-[833px] whitespace-pre-wrap",
        children: [
          e.jsx("span", { className: "leading-[48px]", children: "TruBoard " }),
          e.jsx("span", {
            className: "leading-[48px]",
            children: "Technologies",
          }),
          e.jsx("span", { className: "leading-[48px]", children: " Trusted" }),
          e.jsx("span", { className: "leading-[48px]", children: " by" }),
        ],
      }),
      pc.map((u, k) => {
        const g = k === L;
        return e.jsx(
          "div",
          {
            className:
              "absolute cursor-pointer rounded-[14px] transition-all duration-300",
            style: {
              left: 110,
              top: fc[k],
              height: uc[k],
              width: 520,
              background: "#fdfdfd",
              border: "1px solid #f6f7f7",
              boxShadow: g ? "0px 8px 31.5px 0px rgba(0,38,114,0.1)" : "none",
              paddingLeft: k === 0 ? 19 : 13,
              paddingTop: 12,
            },
            onClick: () => F(k),
            children: e.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                e.jsx("p", {
                  className:
                    "font-['Avenir',sans-serif] leading-[31px] text-[27px] whitespace-pre-wrap transition-colors duration-300",
                  style: {
                    color: g ? "#005bab" : "#1b2431",
                    fontWeight: g ? 500 : 400,
                  },
                  children: u,
                }),
                g &&
                  k === L &&
                  e.jsx("div", {
                    className: "ml-1 mt-1",
                    children: e.jsx("svg", {
                      width: "18",
                      height: "15",
                      viewBox: "0 0 18 15",
                      fill: "none",
                      children: e.jsx("path", {
                        d: i.p2e313df0,
                        fill: "#F39130",
                      }),
                    }),
                  }),
              ],
            }),
          },
          u,
        );
      }),
      xc[L].map((u, k) =>
        e.jsx(
          hc,
          { brand: u, pos: { left: zn[k].left, top: zn[k].top - 1704 } },
          `${L}-${k}`,
        ),
      ),
    ],
  });
}
const Lc = `
@keyframes slowRotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
@keyframes gentlePulse {
  0%, 100% { transform: scale(1); opacity: 1; }
  50% { transform: scale(1.015); opacity: 0.95; }
}
@keyframes floatUpDown {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-5px); }
}
`;
function jc() {
  const u = 257.6199999999999;
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("style", { dangerouslySetInnerHTML: { __html: Lc } }),
      e.jsxs("div", {
        className: "absolute z-10 pointer-events-none",
        style: { left: 1262, top: 2291, width: 500, height: 500 },
        children: [
          e.jsx("div", {
            style: {
              position: "absolute",
              left: u - 226.323,
              top: 2326.76 - 2291,
              width: 452.647,
              height: 452.647,
              animation: "slowRotate 30s linear infinite",
              transformOrigin: "center center",
            },
            children: e.jsx("svg", {
              className: "block size-full",
              fill: "none",
              preserveAspectRatio: "none",
              viewBox: "0 0 452.647 452.647",
              children: e.jsx("circle", {
                cx: "226.323",
                cy: "226.323",
                r: "225.323",
                stroke: "#286FED",
                strokeOpacity: "0.5",
                strokeWidth: "2",
              }),
            }),
          }),
          e.jsxs("div", {
            style: {
              position: "absolute",
              left: 0,
              top: 0,
              width: 500,
              height: 500,
              animation:
                "elegantFloat 8s cubic-bezier(0.45,0.05,0.55,0.95) infinite",
              transformOrigin: `${u}px 262px`,
            },
            children: [
              e.jsx("style", {
                dangerouslySetInnerHTML: {
                  __html: `
            @keyframes elegantFloat {
              0%, 100% { transform: translate(0, 0) scale(1) rotate(0deg); }
              25% { transform: translate(4px, -7px) scale(1.01) rotate(0.5deg); }
              50% { transform: translate(-2px, -12px) scale(1.018) rotate(-0.3deg); }
              75% { transform: translate(-5px, -4px) scale(1.005) rotate(0.2deg); }
            }
            @keyframes circleGlow {
              0%, 100% { box-shadow: 0 0 15px 4px rgba(40,111,237,0.08), 0 0 40px 8px rgba(40,111,237,0.04); }
              50% { box-shadow: 0 0 30px 10px rgba(40,111,237,0.2), 0 0 60px 20px rgba(40,111,237,0.08); }
            }
            @keyframes badgePulseGlow {
              0%, 100% { box-shadow: 0px 4px 4px 0px rgba(232,242,254,0.45), 0 0 0 0 rgba(38,99,235,0); }
              50% { box-shadow: 0px 8px 24px 0px rgba(40,111,237,0.35), 0 0 20px 4px rgba(38,99,235,0.15); }
            }
            @keyframes badgeFloat {
              0%, 100% { transform: translateY(0); }
              50% { transform: translateY(-4px); }
            }
          `,
                },
              }),
              e.jsx("div", {
                className: "absolute",
                style: {
                  left: 1518.42 - 1262 - 176.61,
                  top: 2376.48 - 2291,
                  width: 353.221,
                  height: 353.221,
                  borderRadius: "50%",
                  animation: "circleGlow 4s ease-in-out infinite",
                },
                children: e.jsx("img", {
                  alt: "",
                  className: "block size-full rounded-full",
                  src: Gr,
                }),
              }),
              e.jsx("div", {
                className:
                  "absolute bg-[#2663eb] rounded-[37px] flex items-center justify-center",
                style: {
                  left: u - 76.558,
                  top: 2476.53 - 2291,
                  width: 153.117,
                  height: 153.117,
                  border: "1px solid #e6e9ef",
                  animation:
                    "badgePulseGlow 4s ease-in-out infinite 1s, badgeFloat 5s ease-in-out infinite 0.5s",
                },
                children: e.jsx("p", {
                  className:
                    "font-['Prata',sans-serif] text-[21px] text-white tracking-[1px] leading-[22.5px]",
                  children: "TruBoard",
                }),
              }),
            ],
          }),
          e.jsx("div", {
            className: "absolute bg-white rounded-[10px]",
            style: {
              left: 1504.53 - 1262,
              top: 0,
              width: 61.471,
              height: 60.353,
              border: "1px solid #e6e9ef",
              boxShadow: "0px 4px 14px 0px #d1d5dc",
              animation: "floatUpDown 4s ease-in-out infinite",
            },
            children: e.jsx("div", {
              className: "absolute inset-[15px]",
              children: e.jsxs("svg", {
                className: "block size-full",
                fill: "none",
                viewBox: "0 0 29.9411 29.9411",
                children: [
                  e.jsx("path", {
                    d: i.p146a6600,
                    stroke: "#286FED",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: "2",
                  }),
                  e.jsx("path", {
                    d: i.p2a628b00,
                    stroke: "#286FED",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: "2",
                  }),
                ],
              }),
            }),
          }),
          e.jsx("div", {
            className: "absolute bg-white rounded-[10px]",
            style: {
              left: 0,
              top: 2445.24 - 2291,
              width: 61.471,
              height: 60.353,
              border: "1px solid #e6e9ef",
              boxShadow: "0px 4px 14px 0px #d1d5dc",
              animation: "floatUpDown 5s ease-in-out infinite 0.5s",
            },
            children: e.jsx("div", {
              className: "absolute inset-[12px]",
              children: e.jsxs("svg", {
                className: "block size-full",
                fill: "none",
                viewBox: "0 0 25.247 31.0637",
                children: [
                  e.jsx("path", {
                    d: i.p3eab4e00,
                    stroke: "#286FED",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: "2",
                  }),
                  e.jsx("path", {
                    d: "M12.6218 9.71854V15.5303",
                    stroke: "#286FED",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: "2",
                  }),
                  e.jsx("path", {
                    d: "M12.6218 21.3418H12.6369",
                    stroke: "#286FED",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: "2",
                  }),
                ],
              }),
            }),
          }),
          e.jsx("div", {
            className: "absolute bg-white rounded-[10px]",
            style: {
              left: 1694.53 - 1262,
              top: 2655.35 - 2291,
              width: 61.471,
              height: 60.353,
              border: "1px solid #e6e9ef",
              boxShadow: "0px 4px 14px 0px #d1d5dc",
              animation: "floatUpDown 4.5s ease-in-out infinite 1s",
            },
            children: e.jsx("div", {
              className: "absolute inset-[14px]",
              children: e.jsxs("svg", {
                className: "block size-full",
                fill: "none",
                viewBox: "0 0 28.1528 28.1525",
                children: [
                  e.jsx("path", {
                    d: "M5.35903 1V18.4353",
                    stroke: "#286FED",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: "2",
                  }),
                  e.jsx("path", {
                    d: i.p3c55f000,
                    stroke: "#286FED",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: "2",
                  }),
                  e.jsx("path", {
                    d: i.p351ca100,
                    stroke: "#286FED",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: "2",
                  }),
                  e.jsx("path", {
                    d: i.p388dab00,
                    stroke: "#286FED",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: "2",
                  }),
                ],
              }),
            }),
          }),
          e.jsx("div", {
            className: "absolute bg-white rounded-[10px]",
            style: {
              left: 1293.29 - 1262,
              top: 2686.65 - 2291,
              width: 61.471,
              height: 60.353,
              border: "1px solid #e6e9ef",
              boxShadow: "0px 4px 14px 0px #d1d5dc",
              animation: "floatUpDown 5.5s ease-in-out infinite 1.5s",
            },
            children: e.jsx("div", {
              className: "absolute inset-[14px]",
              children: e.jsxs("svg", {
                className: "block size-full",
                fill: "none",
                viewBox: "0 0 20 20",
                children: [
                  e.jsx("path", {
                    d: i.p14d24500,
                    stroke: "#286FED",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: "1.25",
                  }),
                  e.jsx("path", {
                    d: "M10 5V10L13.3333 11.6667",
                    stroke: "#286FED",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: "1.25",
                  }),
                ],
              }),
            }),
          }),
        ],
      }),
    ],
  });
}
const Vc = [
  {
    id: "expertise",
    left: 523,
    top: 3530,
    title: "Deep real estate execution expertise",
    iconType: "grid",
    iconLeft: 551.31,
    iconTop: 3546.99,
    titleLeft: 551,
    titleTop: 3623,
    titleWidth: 201,
  },
  {
    id: "capital",
    left: 1129,
    top: 3530,
    title: "Institutional capital mindset",
    iconType: "chart",
    iconLeft: 1143.72,
    iconTop: 3546.99,
    titleLeft: 1148,
    titleTop: 3623,
    titleWidth: 152,
  },
  {
    id: "tech",
    left: 428,
    top: 3738.39,
    title: "Technology-first approach",
    iconType: "tech",
    iconLeft: 456.31,
    iconTop: 3759.91,
    titleLeft: 456,
    titleTop: 3839,
    titleWidth: 206,
  },
  {
    id: "proven",
    left: 827,
    top: 3865,
    title: "Proven experience across large, complex portfolios",
    iconType: "experience",
    iconLeft: 867.72,
    iconTop: 3892.18,
    titleLeft: 869,
    titleTop: 3956.74,
    titleWidth: 211,
  },
  {
    id: "independent",
    left: 1222,
    top: 3738.39,
    title: "Independent, objective reporting",
    iconType: "reporting",
    iconLeft: 1236.72,
    iconTop: 3759.91,
    titleLeft: 1241.47,
    titleTop: 3836,
    titleWidth: 185,
  },
];
function mc({ type: L }) {
  return L === "grid"
    ? e.jsxs("svg", {
        className: "block size-full",
        fill: "none",
        viewBox: "0 0 52.0977 53.2302",
        children: [
          e.jsx("rect", {
            fill: "#EFF6FF",
            height: "53.2302",
            rx: "13",
            width: "52.0977",
          }),
          e.jsx("path", {
            d: i.p58595b0,
            stroke: "#286FED",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
          e.jsx("path", {
            d: i.p1f47bf00,
            stroke: "#286FED",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
          e.jsx("path", {
            d: i.p1412a600,
            stroke: "#286FED",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
          e.jsx("path", {
            d: "M23.0283 18.876H28.3136",
            stroke: "#286FED",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
          e.jsx("path", {
            d: "M23.0283 24.1609H28.3136",
            stroke: "#286FED",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
          e.jsx("path", {
            d: "M23.0283 29.4465H28.3136",
            stroke: "#286FED",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
          e.jsx("path", {
            d: "M23.0283 34.7317H28.3136",
            stroke: "#286FED",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
        ],
      })
    : e.jsx("div", {
        className:
          "w-full h-full bg-[#eff6ff] rounded-[13px] flex items-center justify-center",
        children: e.jsxs("svg", {
          width: "24",
          height: "24",
          viewBox: "0 0 24 24",
          fill: "none",
          children: [
            e.jsx("circle", {
              cx: "12",
              cy: "12",
              r: "10",
              stroke: "#286FED",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: "M8 12L11 15L16 9",
              stroke: "#286FED",
              strokeWidth: "2",
              strokeLinecap: "round",
              strokeLinejoin: "round",
            }),
          ],
        }),
      });
}
function gc() {
  const [L, F] = $.useState(null),
    [u, k] = $.useState(null),
    g = 3438;
  return e.jsxs("div", {
    className: "absolute left-0 w-[1920px] z-10",
    style: { top: g, height: 620 },
    children: [
      e.jsx("p", {
        className:
          "absolute font-['Inter',sans-serif] font-semibold leading-[30px] text-[#002672] text-[45px] text-center tracking-[-0.4492px]",
        style: { left: 963, top: 0, transform: "translateX(-50%)" },
        children: "Why TruBoard",
      }),
      e.jsx("div", {
        className: "absolute",
        style: {
          left: "50%",
          top: 3612.68 - g,
          width: 195.933,
          height: 195.933,
          transform: "translateX(-50%)",
        },
        children: e.jsx("svg", {
          className: "block size-full",
          fill: "none",
          viewBox: "0 0 195.933 195.933",
          children: e.jsx("circle", {
            cx: "97.9663",
            cy: "97.9663",
            r: "96.9663",
            stroke: "#286FED",
            strokeOpacity: "0.5",
            strokeWidth: "2",
          }),
        }),
      }),
      e.jsx("div", {
        className: "absolute",
        style: {
          left: "50%",
          top: 3634.2 - g,
          width: 152.895,
          height: 152.895,
          transform: "translateX(-50%)",
        },
        children: e.jsx("img", {
          alt: "",
          className: "block size-full rounded-full",
          src: Ar,
        }),
      }),
      e.jsx("div", {
        className: "absolute bg-white rounded-[17px]",
        style: {
          left: "50%",
          top: 3673.83 - g,
          width: 74.749,
          height: 74.749,
          transform: "translateX(-50%)",
          border: "1px solid #e6e9ef",
          boxShadow: "0px 4px 4px 0px rgba(232,242,254,0.45)",
        },
      }),
      e.jsx("div", {
        className: "absolute flex items-center justify-center",
        style: {
          left: "50%",
          top: 3673.83 - g,
          width: 74.749,
          height: 74.749,
          transform: "translateX(-50%)",
        },
        children: e.jsxs("svg", {
          width: "54",
          height: "43",
          viewBox: "0 0 54.3627 42.6402",
          fill: "none",
          children: [
            e.jsx("path", { d: i.p16b9f400, fill: "#001C57" }),
            e.jsx("path", { d: i.p133ff400, fill: "#001C57" }),
            e.jsx("path", { d: i.p27493c00, fill: "#001C57" }),
            e.jsx("path", { d: i.p165cb300, fill: "#001C57" }),
          ],
        }),
      }),
      Vc.map((M) => {
        const P = L === M.id,
          D = u === M.id,
          N = P || D;
        return e.jsxs(
          "div",
          {
            className:
              "absolute rounded-[24px] cursor-pointer transition-all duration-300",
            style: {
              left: M.left,
              top: M.top - g,
              width: 269.549,
              height: 185.74,
              background: "white",
              border: "1px solid #e6e9ef",
              boxShadow: N
                ? "0px 4px 16px 0px rgba(40,111,237,0.18), 0px 4px 4px 0px rgba(232,242,254,0.45)"
                : "0px 4px 4px 0px rgba(232,242,254,0.45)",
              transform: N ? "translateY(-4px)" : "translateY(0)",
            },
            onMouseEnter: () => F(M.id),
            onMouseLeave: () => F(null),
            onClick: () => k(u === M.id ? null : M.id),
            children: [
              e.jsx("div", {
                className: "absolute",
                style: {
                  left: M.iconLeft - M.left,
                  top: M.iconTop - M.top,
                  width: 52.098,
                  height: 53.23,
                },
                children: e.jsx(mc, { type: M.iconType }),
              }),
              e.jsx("p", {
                className:
                  "absolute font-['Inter',sans-serif] font-semibold leading-[23px] text-[#002672] text-[18px] tracking-[-0.4395px] whitespace-pre-wrap",
                style: {
                  left: M.titleLeft - M.left,
                  top: M.titleTop - M.top,
                  width: M.titleWidth,
                },
                children: M.title,
              }),
            ],
          },
          M.id,
        );
      }),
    ],
  });
}
const _c = [
    {
      tab: "TruGenie",
      title: "TruGenie - Real Estate Intelligence",
      description: `TruGenie transforms raw project data into actionable insights.
Key capabilities:`,
      capabilities: [
        "Construction progress & cost tracking",
        "Sales velocity and collection monitoring",
        "Cashflow and fund-flow intelligence",
        "NOC and approval workflows",
        "Compliance, covenant & risk tracking",
      ],
    },
    {
      tab: "PDMS",
      title: "PDMS - Project Development Management",
      description: `End-to-end project development management system for real estate.
Key capabilities:`,
      capabilities: [
        "Project planning & scheduling",
        "Resource allocation & tracking",
        "Quality assurance monitoring",
        "Vendor & contractor management",
        "Budget & milestone oversight",
      ],
    },
    {
      tab: "Advisory",
      title: "Advisory - Strategic Asset Services",
      description: `Expert advisory services for real estate asset optimization.
Key capabilities:`,
      capabilities: [
        "Portfolio strategy & optimization",
        "Risk assessment & mitigation",
        "Market analysis & benchmarking",
        "Regulatory compliance advisory",
        "Capital structuring guidance",
      ],
    },
  ],
  Pn = [
    e.jsxs("svg", {
      className: "block size-full",
      fill: "none",
      viewBox: "0 0 28 28",
      children: [
        e.jsx("path", {
          d: i.p39243580,
          stroke: "#286FED",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "2.33333",
        }),
        e.jsx("path", {
          d: i.p3ca38d80,
          stroke: "#286FED",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "2.33333",
        }),
        e.jsx("path", {
          d: i.p3884aec0,
          stroke: "#286FED",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "2.33333",
        }),
        e.jsx("path", {
          d: i.p13a12d80,
          stroke: "#286FED",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "2.33333",
        }),
      ],
    }),
    e.jsxs("svg", {
      className: "block size-full",
      fill: "none",
      viewBox: "0 0 28 28",
      children: [
        e.jsx("path", {
          d: i.p3997a780,
          stroke: "#286FED",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "2.33333",
        }),
        e.jsx("path", {
          d: i.p275e0300,
          stroke: "#286FED",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "2.33333",
        }),
      ],
    }),
    e.jsxs("svg", {
      className: "block size-full",
      fill: "none",
      viewBox: "0 0 28 28",
      children: [
        e.jsx("path", {
          d: i.p2fdbf200,
          stroke: "#286FED",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "2.33333",
        }),
        e.jsx("path", {
          d: i.p1f5a7680,
          stroke: "#286FED",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "2.33333",
        }),
      ],
    }),
    e.jsxs("svg", {
      className: "block size-full",
      fill: "none",
      viewBox: "0 0 28 28",
      children: [
        e.jsx("path", {
          d: i.p3da6200,
          stroke: "#286FED",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "2.33333",
        }),
        e.jsx("path", {
          d: i.p394f8700,
          stroke: "#286FED",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "2.33333",
        }),
        e.jsx("path", {
          d: i.pb465bc0,
          stroke: "#286FED",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "2.33333",
        }),
      ],
    }),
    e.jsxs("svg", {
      className: "block size-full",
      fill: "none",
      viewBox: "0 0 28 28",
      children: [
        e.jsx("path", {
          d: i.p1b228440,
          stroke: "#286FED",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "2.33333",
        }),
        e.jsx("path", {
          d: i.p309e840,
          stroke: "#286FED",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeWidth: "2.33333",
        }),
      ],
    }),
  ];
function bc() {
  const [L, F] = $.useState(0),
    [u, k] = $.useState(null),
    g = _c[L],
    M = [
      { label: "TruGenie", left: 674, width: 174 },
      { label: "PDMS", left: 889, width: 174 },
      { label: "Advisory", left: 1089, width: 174 },
    ];
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("p", {
        className:
          "absolute font-['Inter',sans-serif] font-semibold leading-[61px] text-[#0c1b56] text-[45px] text-center z-10",
        style: {
          left: "50%",
          top: 4213,
          transform: "translateX(-50%)",
          width: 1191,
        },
        children: "TruBoard Real Estate Offerings",
      }),
      e.jsx("div", {
        className: "absolute z-10",
        style: { left: 0, top: 4335, width: 1920, height: 50 },
        children: M.map((P, D) => {
          const N = D === L;
          return e.jsx(
            "div",
            {
              className:
                "absolute cursor-pointer rounded-[14px] transition-all duration-300 flex items-center justify-center",
              style: {
                left: P.left,
                top: 0,
                width: P.width,
                height: 46,
                background: "#fdfdfd",
                border: "1px solid #f6f7f7",
                boxShadow: N ? "0px 8px 31.5px 0px rgba(0,38,114,0.1)" : "none",
              },
              onClick: () => F(D),
              children: e.jsx("p", {
                className:
                  "font-['Avenir',sans-serif] leading-[31px] text-[27px] text-center whitespace-pre-wrap transition-colors duration-300",
                style: {
                  color: N ? "#005bab" : "#1b2431",
                  fontWeight: N ? 500 : 400,
                },
                children: P.label,
              }),
            },
            P.label,
          );
        }),
      }),
      e.jsx("div", {
        className: "absolute z-10 bg-white",
        style: { left: 0, top: 4420, width: 1920 },
        children: e.jsxs("div", {
          className:
            "flex gap-[76px] items-start justify-center pt-[63px] pb-[60px]",
          children: [
            e.jsx("div", {
              className:
                "flex flex-col items-start overflow-clip rounded-[10px] shrink-0",
              style: {
                width: 668,
                height: 585,
                boxShadow: "0px 10px 40px 0px rgba(40,111,237,0.08)",
                background: "rgba(255,255,255,0)",
              },
              children: e.jsx("img", {
                alt: "",
                className: "object-cover w-full h-full",
                src: Dr,
                style: { opacity: 0.9 },
              }),
            }),
            e.jsxs("div", {
              className: "flex flex-col gap-[11px] items-end",
              style: { width: 671 },
              children: [
                e.jsx("div", {
                  className: "w-full",
                  children: e.jsx("p", {
                    className:
                      "font-['Inter',sans-serif] font-semibold leading-[61px] text-[#002672] text-[32px] whitespace-pre-wrap",
                    children: g.title,
                  }),
                }),
                e.jsx("p", {
                  className:
                    "font-['Avenir',sans-serif] leading-[36px] text-[#475569] text-[18px] w-full whitespace-pre-wrap",
                  children: g.description,
                }),
                e.jsx("div", {
                  className: "grid grid-cols-2 gap-[16px] mt-[1px]",
                  style: { width: 668 },
                  children: g.capabilities.map((P, D) => {
                    const N = D === 0,
                      A = u === D;
                    return e.jsxs(
                      "div",
                      {
                        className:
                          "bg-white rounded-[10px] relative cursor-pointer transition-all duration-300",
                        style: {
                          border: "1px solid #e2e8f0",
                          boxShadow:
                            N || A
                              ? "0px 2px 12.1px 0px rgba(0,38,114,0.32)"
                              : "0px 2px 8px 0px rgba(0,38,114,0.04)",
                          padding: "25px 1px 25px 25px",
                          minHeight: 120,
                          transform: A ? "translateY(-2px)" : "none",
                        },
                        onMouseEnter: () => k(D),
                        onMouseLeave: () => k(null),
                        children: [
                          e.jsx("div", {
                            className: "size-[28px] mb-[12px]",
                            children: Pn[D % Pn.length],
                          }),
                          e.jsx("p", {
                            className:
                              "font-['Inter',sans-serif] font-medium leading-[24px] text-[#002672] text-[17px] tracking-[-0.4316px] whitespace-pre-wrap",
                            style: { width: 229 },
                            children: P,
                          }),
                        ],
                      },
                      `${L}-${D}`,
                    );
                  }),
                }),
              ],
            }),
          ],
        }),
      }),
    ],
  });
}
const Fc = [
    "https://images.unsplash.com/photo-1762146828422-50a8bd416d3c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZWFsJTIwZXN0YXRlJTIwcGxhbm5pbmclMjBibHVlcHJpbnQlMjBhcmNoaXRlY3R1cmV8ZW58MXx8fHwxNzcxNTAxMDUzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    "https://images.unsplash.com/photo-1698234790025-4f3faa2a2df0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjBidWlsZGluZyUyMHNpdGUlMjBwcm9ncmVzc3xlbnwxfHx8fDE3NzE1MDEwNTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    "https://images.unsplash.com/flagged/photo-1558954157-aa76c0d246c6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZWFsJTIwZXN0YXRlJTIwc2FsZXMlMjBidXNpbmVzcyUyMGFuYWx5dGljc3xlbnwxfHx8fDE3NzE1MDEwNTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    "https://images.unsplash.com/photo-1578088369622-b26f899a016e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBidWlsZGluZyUyMGFzc2V0JTIwbWFuYWdlbWVudCUyMHBvcnRmb2xpb3xlbnwxfHx8fDE3NzE1MDEwNTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  ],
  Br = [
    {
      label: "Plan",
      items: ["Feasibility", "Risk assessment", "Capital structuring"],
    },
    {
      label: "Build",
      items: [
        "Construction oversight",
        "Cost & schedule control",
        "Execution risk visibility",
      ],
    },
    {
      label: "Monetize",
      items: [
        "Sales velocity",
        "Collections tracking",
        "Cashflow intelligence",
      ],
    },
    {
      label: "Exit",
      items: [
        "Asset performance",
        "Governance & compliance",
        "Value optimization",
      ],
    },
  ],
  Mc = [
    { prefix: "$", value: 4, suffix: "Bn+", label: "assets under oversight" },
    { prefix: "~", value: 200, suffix: "Mn", label: "sq ft overseeing valued" },
    { prefix: "~$", value: 5, suffix: "Bn", label: "across the USA and India" },
  ],
  Cc = [
    "Developers & Asset Owners",
    "Lenders & Banks",
    "NBFCs & Alternative Capital",
    "Funds & Institutional Investors",
  ],
  wc = [
    { title: "Deep real estate execution expertise", icon: "grid" },
    { title: "Institutional capital mindset", icon: "chart" },
    { title: "Technology-first approach", icon: "tech" },
    {
      title: "Proven experience across large, complex portfolios",
      icon: "experience",
    },
    { title: "Independent, objective reporting", icon: "reporting" },
  ],
  Hn = [
    {
      tab: "TruGenie",
      title: "TruGenie - Real Estate Intelligence",
      description: `TruGenie transforms raw project data into actionable insights.
Key capabilities:`,
      capabilities: [
        "Construction progress & cost tracking",
        "Sales velocity and collection monitoring",
        "Cashflow and fund-flow intelligence",
        "NOC and approval workflows",
        "Compliance, covenant & risk tracking",
      ],
    },
    {
      tab: "PDMS",
      title: "PDMS - Project Development Management",
      description: `End-to-end project development management system for real estate.
Key capabilities:`,
      capabilities: [
        "Project planning & scheduling",
        "Resource allocation & tracking",
        "Quality assurance monitoring",
        "Vendor & contractor management",
        "Budget & milestone oversight",
      ],
    },
    {
      tab: "Advisory",
      title: "Advisory - Strategic Asset Services",
      description: `Expert advisory services for real estate asset optimization.
Key capabilities:`,
      capabilities: [
        "Portfolio strategy & optimization",
        "Risk assessment & mitigation",
        "Market analysis & benchmarking",
        "Regulatory compliance advisory",
        "Capital structuring guidance",
      ],
    },
  ];
function kc({ prefix: L, value: F, suffix: u, animate: k }) {
  const [g, M] = $.useState(0);
  return (
    $.useEffect(() => {
      if (!k) {
        M(0);
        return;
      }
      const P = 2e3,
        D = performance.now();
      let N;
      function A(z) {
        const H = z - D,
          Q = Math.min(H / P, 1),
          ue = 1 - Math.pow(1 - Q, 3);
        (M(Math.round(ue * F)), Q < 1 && (N = requestAnimationFrame(A)));
      }
      return ((N = requestAnimationFrame(A)), () => cancelAnimationFrame(N));
    }, [k, F]),
    e.jsxs("span", {
      className:
        "font-['Roboto',sans-serif] font-bold text-[#286fed] text-[36px] leading-[44px]",
      children: [L, g, u],
    })
  );
}
function Nc({ type: L }) {
  return L === "grid"
    ? e.jsxs("svg", {
        className: "size-10",
        fill: "none",
        viewBox: "0 0 52.0977 53.2302",
        children: [
          e.jsx("rect", {
            fill: "#EFF6FF",
            height: "53.2302",
            rx: "13",
            width: "52.0977",
          }),
          e.jsx("path", {
            d: i.p58595b0,
            stroke: "#286FED",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
          e.jsx("path", {
            d: i.p1f47bf00,
            stroke: "#286FED",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
          e.jsx("path", {
            d: i.p1412a600,
            stroke: "#286FED",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
          e.jsx("path", {
            d: "M23.0283 18.876H28.3136",
            stroke: "#286FED",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
          e.jsx("path", {
            d: "M23.0283 24.1609H28.3136",
            stroke: "#286FED",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
          e.jsx("path", {
            d: "M23.0283 29.4465H28.3136",
            stroke: "#286FED",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
          e.jsx("path", {
            d: "M23.0283 34.7317H28.3136",
            stroke: "#286FED",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
          }),
        ],
      })
    : e.jsx("div", {
        className:
          "size-10 bg-[#eff6ff] rounded-[13px] flex items-center justify-center",
        children: e.jsxs("svg", {
          width: "20",
          height: "20",
          viewBox: "0 0 24 24",
          fill: "none",
          children: [
            e.jsx("circle", {
              cx: "12",
              cy: "12",
              r: "10",
              stroke: "#286FED",
              strokeWidth: "2",
            }),
            e.jsx("path", {
              d: "M8 12L11 15L16 9",
              stroke: "#286FED",
              strokeWidth: "2",
              strokeLinecap: "round",
              strokeLinejoin: "round",
            }),
          ],
        }),
      });
}
function Zc({ index: L }) {
  const F = [i.p39243580, i.p3997a780, i.p2fdbf200, i.p3da6200, i.p1b228440];
  return e.jsx("svg", {
    className: "size-6",
    fill: "none",
    viewBox: "0 0 28 28",
    children: e.jsx("path", {
      d: F[L % F.length],
      stroke: "#286FED",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      strokeWidth: "2.333",
    }),
  });
}
function yc() {
  return e.jsxs("div", {
    className: "w-full bg-white min-h-screen overflow-x-hidden",
    children: [
      e.jsx(Bc, {}),
      e.jsx(Ec, {}),
      e.jsx(Gc, {}),
      e.jsx(Ac, {}),
      e.jsx(Dc, {}),
      e.jsx(Rc, {}),
      e.jsx(Sc, {}),
      e.jsx(Ic, {}),
      e.jsx(Tc, {}),
    ],
  });
}
function Bc() {
  const [L, F] = $.useState(!1);
  return e.jsxs("header", {
    className: "sticky top-0 z-50 bg-white border-b border-[#f3f4f6] px-4 py-3",
    children: [
      e.jsxs("div", {
        className: "flex items-center justify-between",
        children: [
          e.jsx("img", { src: Un, alt: "TruBoard", className: "h-8 w-auto" }),
          e.jsx("button", {
            onClick: () => F(!L),
            className: "p-2 rounded-lg hover:bg-gray-50",
            "aria-label": "Toggle menu",
            children: e.jsx("svg", {
              width: "24",
              height: "24",
              viewBox: "0 0 24 24",
              fill: "none",
              stroke: "#061b45",
              strokeWidth: "2",
              children: L
                ? e.jsx("path", { d: "M18 6L6 18M6 6l12 12" })
                : e.jsxs(e.Fragment, {
                    children: [
                      e.jsx("path", { d: "M3 6h18" }),
                      e.jsx("path", { d: "M3 12h18" }),
                      e.jsx("path", { d: "M3 18h18" }),
                    ],
                  }),
            }),
          }),
        ],
      }),
      L &&
        e.jsxs("nav", {
          className: "mt-3 pb-2 flex flex-col gap-1",
          children: [
            ["Services", "Product", "Resources"].map((u) =>
              e.jsx(
                "a",
                {
                  href: "#",
                  className:
                    "px-3 py-2 rounded-lg text-[#061b45] font-['Inter',sans-serif] font-medium text-[15px] hover:bg-[#f0f5ff] transition-all duration-200 active:scale-[0.97]",
                  children: u,
                },
                u,
              ),
            ),
            e.jsx("a", {
              href: "#",
              className:
                "mt-1 px-4 py-2.5 rounded-[10px] bg-[#286fed] text-white font-['Inter',sans-serif] font-medium text-[15px] text-center transition-all duration-200 hover:bg-[#3b7ff5] hover:shadow-[0px_4px_14px_0px_rgba(40,111,237,0.4)] active:scale-[0.97]",
              children: "Contact Us",
            }),
          ],
        }),
    ],
  });
}
function Ec() {
  return e.jsxs("section", {
    className: "px-5 pt-10 pb-8 bg-gradient-to-b from-[#e9f0ff] to-white",
    children: [
      e.jsx("h1", {
        className:
          "font-['Inter',sans-serif] font-bold text-[#286fed] text-[32px] leading-[40px] tracking-[-0.5px]",
        children: "Unified Real Estate",
      }),
      e.jsx("h2", {
        className:
          "font-['Inter',sans-serif] font-semibold text-[#0c1b56] text-[28px] leading-[36px] tracking-[-0.5px] mt-1",
        children: "Asset Management & Intelligence",
      }),
      e.jsx("p", {
        className:
          "font-['Inter',sans-serif] text-[#6e6e73] text-[16px] leading-[26px] tracking-[-0.3px] mt-4",
        children:
          "TruBoard brings together execution, asset oversight, and real-time intelligence to help developers, lenders, and investors build better, monitor smarter, and protect capital across the real estate lifecycle.",
      }),
      e.jsxs("div", {
        className: "flex flex-col gap-3 mt-6",
        children: [
          e.jsxs("a", {
            href: "#",
            className:
              "flex items-center justify-center gap-1 h-[50px] rounded-full bg-white/60 border border-[rgba(0,0,0,0.08)] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.04)] font-['Inter',sans-serif] font-medium text-[#1d1d1f] text-[16px] transition-all duration-250 hover:bg-white/90 hover:shadow-[0px_4px_16px_0px_rgba(0,0,0,0.08)] active:scale-[0.97]",
            children: [
              "Explore TruGenie",
              e.jsx("span", {
                className: "text-[#f39130] ml-0.5",
                children: "→",
              }),
            ],
          }),
          e.jsx("a", {
            href: "#",
            className:
              "flex items-center justify-center h-[50px] rounded-full bg-[#286fed] shadow-[0px_4px_16px_0px_rgba(40,111,237,0.3)] font-['Inter',sans-serif] font-medium text-white text-[16px] transition-all duration-250 hover:bg-[#3b7ff5] hover:shadow-[0px_6px_22px_0px_rgba(40,111,237,0.45)] active:scale-[0.97]",
            children: "Contact Us",
          }),
        ],
      }),
    ],
  });
}
function Gc() {
  const [L, F] = $.useState(0),
    [u, k] = $.useState(!1),
    g = $.useCallback(() => {
      F((D) => (D + 1) % 4);
    }, []);
  $.useEffect(() => {
    if (u) return;
    const D = setInterval(g, 3500);
    return () => clearInterval(D);
  }, [u, g]);
  const M = (D) => {
      (F(D), k(!0), setTimeout(() => k(!1), 8e3));
    },
    P = Br[L];
  return e.jsxs("section", {
    className: "px-5 py-10",
    children: [
      e.jsx("div", {
        className:
          "relative w-full aspect-[4/3] rounded-2xl overflow-hidden mb-6",
        children: Fc.map((D, N) =>
          e.jsx(
            Qn,
            {
              alt: Br[N].label,
              src: D,
              className:
                "absolute inset-0 w-full h-full object-cover transition-opacity duration-700",
              style: { opacity: N === L ? 1 : 0 },
            },
            N,
          ),
        ),
      }),
      e.jsx("div", {
        className: "grid grid-cols-4 gap-2 mb-4",
        children: Br.map((D, N) => {
          const A = N === L;
          return e.jsx(
            "button",
            {
              onClick: () => M(N),
              className:
                "py-2.5 rounded-xl text-center transition-all duration-300 font-['Inter',sans-serif] font-bold text-[14px] tracking-[0.5px]",
              style: {
                background: "#fafbfe",
                border: A ? "1.5px solid #d1ebff" : "1.5px solid #eef0f4",
                boxShadow: A ? "0px 0px 12px 0px rgba(63,146,209,0.2)" : "none",
                color: A ? "#286fed" : "#7e9ed6",
              },
              children: D.label,
            },
            D.label,
          );
        }),
      }),
      e.jsx("div", {
        className: "text-center",
        children: P.items.map((D, N) =>
          e.jsx(
            "p",
            {
              className:
                "font-['Inter',sans-serif] text-[#182655] text-[14px] leading-[22px] tracking-[-0.16px]",
              children: D,
            },
            N,
          ),
        ),
      }),
    ],
  });
}
function Ac() {
  const [L, F] = $.useState(!1),
    u = $.useRef(null),
    k = $.useCallback(
      (g) => {
        g.forEach((M) => {
          M.isIntersecting && !L && F(!0);
        });
      },
      [L],
    );
  return (
    $.useEffect(() => {
      const g = new IntersectionObserver(k, { threshold: 0.3 });
      return (u.current && g.observe(u.current), () => g.disconnect());
    }, [k]),
    e.jsxs("section", {
      ref: u,
      className: "px-5 py-10 bg-[rgba(240,245,255,0.42)]",
      children: [
        e.jsx("h2", {
          className:
            "font-['Inter',sans-serif] font-semibold text-[#0c1b56] text-[28px] leading-[36px] text-center mb-6",
          children: "Our Impact",
        }),
        e.jsx("div", {
          className: "flex flex-col gap-4",
          children: Mc.map((g, M) =>
            e.jsxs(
              "div",
              {
                className:
                  "bg-white rounded-[24px] border border-[rgba(229,229,229,0.36)] py-5 px-4 text-center",
                children: [
                  e.jsx(kc, {
                    prefix: g.prefix,
                    value: g.value,
                    suffix: g.suffix,
                    animate: L,
                  }),
                  e.jsx("p", {
                    className:
                      "font-['Inter',sans-serif] text-[#1b2431] text-[16px] leading-[24px] mt-1",
                    children: g.label,
                  }),
                ],
              },
              M,
            ),
          ),
        }),
      ],
    })
  );
}
function Dc() {
  const [L, F] = $.useState(0);
  return e.jsxs("section", {
    className: "px-5 py-10",
    children: [
      e.jsx("h2", {
        className:
          "font-['Inter',sans-serif] font-semibold text-[#0c1b56] text-[28px] leading-[36px] mb-6",
        children: "TruBoard Technologies Trusted by",
      }),
      e.jsx("div", {
        className: "flex flex-col gap-2 mb-6",
        children: Cc.map((u, k) => {
          const g = k === L;
          return e.jsx(
            "button",
            {
              onClick: () => F(k),
              className:
                "text-left px-4 py-3 rounded-[14px] transition-all duration-300 font-['Inter',sans-serif] text-[16px]",
              style: {
                background: "#fdfdfd",
                border: "1px solid #f6f7f7",
                boxShadow: g ? "0px 8px 31.5px 0px rgba(0,38,114,0.1)" : "none",
                color: g ? "#005bab" : "#1b2431",
                fontWeight: g ? 500 : 400,
              },
              children: e.jsxs("span", {
                className: "flex items-center gap-2",
                children: [
                  u,
                  g &&
                    e.jsx("svg", {
                      width: "14",
                      height: "11",
                      viewBox: "0 0 18 15",
                      fill: "none",
                      children: e.jsx("path", {
                        d: i.p2e313df0,
                        fill: "#F39130",
                      }),
                    }),
                ],
              }),
            },
            u,
          );
        }),
      }),
      e.jsx("div", {
        className:
          "bg-white rounded-2xl border border-[#f0f0f0] p-4 overflow-hidden",
        children: e.jsx("div", {
          className: "relative w-full aspect-[3/1]",
          children: e.jsx("img", {
            src: V1,
            alt: "Trusted brands",
            className: "w-full h-full object-contain",
          }),
        }),
      }),
    ],
  });
}
function Rc() {
  return e.jsxs("section", {
    className: "px-5 py-10 bg-gradient-to-b from-[#f0f5ff42] to-white",
    children: [
      e.jsx("h2", {
        className:
          "font-['Inter',sans-serif] font-semibold text-[#0c1b56] text-[26px] leading-[34px] tracking-[0.2px] mb-4",
        children: "Assets fail from fragmented, not flawed execution",
      }),
      e.jsx("p", {
        className:
          "font-['Inter',sans-serif] text-[#475569] text-[16px] leading-[26px] tracking-[-0.3px] mb-6",
        children:
          "Real estate projects break down when execution is disconnected, visibility is limited, and decisions arrive too late. Even well-capitalized assets suffer when teams, data, and accountability operate in silos.",
      }),
      e.jsx("div", {
        className: "flex items-center justify-center my-6",
        children: e.jsxs("div", {
          className: "relative w-[180px] h-[180px]",
          children: [
            e.jsx("div", {
              className:
                "absolute inset-0 rounded-full border-2 border-[#286fed]/30",
            }),
            e.jsx("div", {
              className: "absolute inset-[13px]",
              children: e.jsx("img", {
                src: Gr,
                alt: "",
                className: "w-full h-full rounded-full object-cover",
              }),
            }),
            e.jsx("div", {
              className:
                "absolute left-1/2 -translate-x-1/2 bottom-[-10px] bg-[#2663eb] rounded-[20px] px-4 py-2 border border-[#e6e9ef]",
              children: e.jsx("span", {
                className:
                  "font-['Prata',sans-serif] text-white text-[13px] tracking-[0.8px]",
                children: "TruBoard",
              }),
            }),
          ],
        }),
      }),
      e.jsx("div", {
        className: "bg-[#286fed] rounded-lg px-4 py-2.5 text-center",
        children: e.jsx("p", {
          className:
            "font-['Inter',sans-serif] font-semibold text-white text-[16px]",
          children: "TruBoard exists to fix this.",
        }),
      }),
    ],
  });
}
function Sc() {
  const [L, F] = $.useState(null);
  return e.jsxs("section", {
    className: "px-5 py-10 bg-gradient-to-b from-[#e9f0ff52] to-white",
    children: [
      e.jsx("h2", {
        className:
          "font-['Inter',sans-serif] font-semibold text-[#002672] text-[28px] leading-[36px] text-center mb-3",
        children: "Why TruBoard",
      }),
      e.jsx("div", {
        className: "flex justify-center mb-6",
        children: e.jsxs("div", {
          className: "relative w-[100px] h-[100px]",
          children: [
            e.jsx("div", {
              className:
                "absolute inset-0 rounded-full border border-[#286fed]/50",
            }),
            e.jsx("div", {
              className: "absolute inset-[10px]",
              children: e.jsx("img", {
                src: Ar,
                alt: "",
                className: "w-full h-full rounded-full",
              }),
            }),
            e.jsx("div", {
              className:
                "absolute inset-[22px] bg-white rounded-[10px] border border-[#e6e9ef] shadow-[0px_2px_4px_0px_rgba(232,242,254,0.45)] flex items-center justify-center",
              children: e.jsxs("svg", {
                width: "28",
                height: "22",
                viewBox: "0 0 54.3627 42.6402",
                fill: "none",
                children: [
                  e.jsx("path", { d: i.p16b9f400, fill: "#001C57" }),
                  e.jsx("path", { d: i.p133ff400, fill: "#001C57" }),
                  e.jsx("path", { d: i.p27493c00, fill: "#001C57" }),
                  e.jsx("path", { d: i.p165cb300, fill: "#001C57" }),
                ],
              }),
            }),
          ],
        }),
      }),
      e.jsx("div", {
        className: "flex flex-col gap-3",
        children: wc.map((u, k) => {
          const g = L === k;
          return e.jsxs(
            "button",
            {
              onClick: () => F(g ? null : k),
              className:
                "w-full rounded-[16px] border border-[#e6e9ef] bg-white px-4 py-4 text-left transition-all duration-300 flex items-center gap-3",
              style: {
                boxShadow: g
                  ? "0px 4px 16px 0px rgba(40,111,237,0.18), 0px 4px 4px 0px rgba(232,242,254,0.45)"
                  : "0px 4px 4px 0px rgba(232,242,254,0.45)",
                transform: g ? "translateY(-2px)" : "none",
              },
              children: [
                e.jsx(Nc, { type: u.icon }),
                e.jsx("span", {
                  className:
                    "font-['Inter',sans-serif] font-semibold text-[#002672] text-[15px] leading-[20px] tracking-[-0.3px] flex-1",
                  children: u.title,
                }),
              ],
            },
            k,
          );
        }),
      }),
    ],
  });
}
function Ic() {
  const [L, F] = $.useState(0),
    u = Hn[L];
  return e.jsxs("section", {
    className: "px-5 py-10",
    children: [
      e.jsx("h2", {
        className:
          "font-['Inter',sans-serif] font-semibold text-[#0c1b56] text-[26px] leading-[34px] text-center mb-6",
        children: "TruBoard Real Estate Offerings",
      }),
      e.jsx("div", {
        className: "grid grid-cols-3 gap-2 mb-6",
        children: Hn.map((k, g) => {
          const M = g === L;
          return e.jsx(
            "button",
            {
              onClick: () => F(g),
              className:
                "py-2.5 rounded-[14px] transition-all duration-300 font-['Inter',sans-serif] text-[15px] text-center",
              style: {
                background: "#fdfdfd",
                border: "1px solid #f6f7f7",
                boxShadow: M ? "0px 8px 31.5px 0px rgba(0,38,114,0.1)" : "none",
                color: M ? "#005bab" : "#1b2431",
                fontWeight: M ? 500 : 400,
              },
              children: k.tab,
            },
            k.tab,
          );
        }),
      }),
      e.jsx("div", {
        className:
          "rounded-[10px] overflow-hidden shadow-[0px_10px_40px_0px_rgba(40,111,237,0.08)] mb-5",
        children: e.jsx("img", {
          src: Dr,
          alt: u.tab,
          className: "w-full h-auto object-cover",
          style: { opacity: 0.9 },
        }),
      }),
      e.jsx("h3", {
        className:
          "font-['Inter',sans-serif] font-semibold text-[#002672] text-[22px] leading-[30px] mb-2",
        children: u.title,
      }),
      e.jsx("p", {
        className:
          "font-['Inter',sans-serif] text-[#475569] text-[15px] leading-[24px] mb-4 whitespace-pre-wrap",
        children: u.description,
      }),
      e.jsx("div", {
        className: "flex flex-col gap-3",
        children: u.capabilities.map((k, g) =>
          e.jsxs(
            "div",
            {
              className:
                "bg-white rounded-[10px] border border-[#e2e8f0] p-4 flex items-start gap-3",
              style: {
                boxShadow:
                  g === 0
                    ? "0px 2px 12.1px 0px rgba(0,38,114,0.32)"
                    : "0px 2px 8px 0px rgba(0,38,114,0.04)",
              },
              children: [
                e.jsx("div", {
                  className: "shrink-0 mt-0.5",
                  children: e.jsx(Zc, { index: g }),
                }),
                e.jsx("p", {
                  className:
                    "font-['Inter',sans-serif] font-medium text-[#002672] text-[15px] leading-[22px] tracking-[-0.3px]",
                  children: k,
                }),
              ],
            },
            `${L}-${g}`,
          ),
        ),
      }),
    ],
  });
}
function Tc() {
  return e.jsxs("section", {
    className:
      "px-5 py-12 bg-gradient-to-b from-[#e9f0ff] to-white text-center",
    children: [
      e.jsx("h2", {
        className:
          "font-['Inter',sans-serif] font-semibold text-[#002672] text-[24px] leading-[32px] mb-6",
        children:
          "Ready to bring clarity and control to your real estate assets?",
      }),
      e.jsxs("div", {
        className: "flex flex-col gap-3",
        children: [
          e.jsxs("a", {
            href: "#",
            className:
              "flex items-center justify-center h-[50px] rounded-full bg-white/60 border border-[rgba(0,0,0,0.08)] shadow-[0px_1px_3px_0px_rgba(0,0,0,0.04)] font-['Inter',sans-serif] font-medium text-[#1d1d1f] text-[16px] transition-all duration-250 hover:bg-white/90 hover:shadow-[0px_4px_16px_0px_rgba(0,0,0,0.08)] active:scale-[0.97]",
            children: [
              "Request a TruGenie Demo",
              e.jsx("span", {
                className: "text-[#f39130] ml-1",
                children: "→",
              }),
            ],
          }),
          e.jsx("a", {
            href: "#",
            className:
              "flex items-center justify-center h-[50px] rounded-full bg-[#286fed] shadow-[0px_4px_16px_0px_rgba(40,111,237,0.3)] font-['Inter',sans-serif] font-medium text-white text-[16px] transition-all duration-250 hover:bg-[#3b7ff5] hover:shadow-[0px_6px_22px_0px_rgba(40,111,237,0.45)] active:scale-[0.97]",
            children: "Talk to Our Services Team",
          }),
        ],
      }),
      e.jsx("p", {
        className: "mt-8 font-['Inter',sans-serif] text-[#6e6e73] text-[13px]",
        children: "© 2026 TruBoard Technologies. All rights reserved.",
      }),
    ],
  });
}
const zc = `
@keyframes btnPressBlue {
  0%   { transform: scale(1); }
  50%  { transform: scale(0.97); }
  100% { transform: scale(1); }
}
@keyframes btnPressGhost {
  0%   { transform: scale(1); }
  50%  { transform: scale(0.97); }
  100% { transform: scale(1); }
}
`;
function j1({
  left: L,
  top: F,
  width: u,
  height: k,
  variant: g,
  label: M,
  arrow: P,
  borderRadius: D,
}) {
  const [N, A] = $.useState(!1),
    [z, H] = $.useState(!1),
    Q = D ?? (g === "nav" ? 8 : g === "navBlue" ? 10 : 16777200),
    ue = () =>
      g === "blue" || g === "navBlue"
        ? {
            background: N ? "rgba(255,255,255,0.12)" : "transparent",
            boxShadow: N ? "0px 6px 22px 0px rgba(40,111,237,0.35)" : "none",
            transform: z ? "scale(0.97)" : N ? "scale(1.03)" : "scale(1)",
          }
        : g === "ghost"
          ? {
              background: N ? "rgba(255,255,255,0.35)" : "transparent",
              boxShadow: N ? "0px 4px 16px 0px rgba(0,0,0,0.06)" : "none",
              transform: z ? "scale(0.97)" : N ? "scale(1.03)" : "scale(1)",
            }
          : {
              background: N ? "rgba(240,245,255,0.7)" : "transparent",
              transform: z ? "scale(0.96)" : "scale(1)",
            };
  return e.jsx("div", {
    className: "absolute z-20 cursor-pointer",
    style: {
      left: L,
      top: F,
      width: u,
      height: k,
      borderRadius: Q,
      transition: "all 0.25s cubic-bezier(0.4, 0, 0.2, 1)",
      ...ue(),
    },
    onMouseEnter: () => A(!0),
    onMouseLeave: () => {
      (A(!1), H(!1));
    },
    onMouseDown: () => H(!0),
    onMouseUp: () => H(!1),
  });
}
function Pc() {
  return e.jsxs(e.Fragment, {
    children: [
      e.jsx("style", { dangerouslySetInnerHTML: { __html: zc } }),
      e.jsx(j1, {
        left: 109,
        top: 608,
        width: 159,
        height: 57.5,
        variant: "blue",
        label: "Contact Us",
      }),
      e.jsx(j1, {
        left: 284,
        top: 607,
        width: 230,
        height: 59.5,
        variant: "ghost",
        label: "Explore TruGenie",
        arrow: !0,
      }),
      e.jsx(j1, {
        left: 1293,
        top: 61,
        width: 110,
        height: 42.5,
        variant: "nav",
        label: "Services",
      }),
      e.jsx(j1, {
        left: 1412,
        top: 61,
        width: 106,
        height: 42.5,
        variant: "nav",
        label: "Product",
      }),
      e.jsx(j1, {
        left: 1525,
        top: 61,
        width: 124,
        height: 42.5,
        variant: "nav",
        label: "Resources",
      }),
      e.jsx(j1, {
        left: 1657,
        top: 61,
        width: 150,
        height: 42.5,
        variant: "navBlue",
        label: "Contact Us",
        borderRadius: 10,
      }),
      e.jsx(j1, {
        left: 670,
        top: 5390,
        width: 293,
        height: 60,
        variant: "ghost",
        label: "Request a TruGenie Demo",
        arrow: !0,
      }),
      e.jsx(j1, {
        left: 973,
        top: 5391,
        width: 278,
        height: 58,
        variant: "blue",
        label: "Talk to Our Services Team",
      }),
      e.jsx(j1, {
        left: 393,
        top: 3087,
        width: 180,
        height: 28,
        variant: "ghost",
        label: "Learn more",
        arrow: !0,
        borderRadius: 6,
      }),
      e.jsx(j1, {
        left: 988,
        top: 3087,
        width: 200,
        height: 28,
        variant: "ghost",
        label: "Explore TruGenie",
        arrow: !0,
        borderRadius: 6,
      }),
    ],
  });
}
const Wn = 1920,
  On = 6269;
function Hc() {
  const [L, F] = $.useState(typeof window < "u" ? window.innerWidth : 1920);
  return (
    $.useEffect(() => {
      const u = () => F(window.innerWidth);
      return (
        window.addEventListener("resize", u),
        () => window.removeEventListener("resize", u)
      );
    }, []),
    L
  );
}
function Wc() {
  const L = Hc(),
    F = L < 768,
    u = Math.min(L / Wn, 1),
    k = On * u;
  return F
    ? e.jsx(yc, {})
    : e.jsx("div", {
        className: "w-full bg-white overflow-hidden",
        style: { height: k },
        children: e.jsxs("div", {
          className: "relative",
          style: {
            width: Wn,
            height: On,
            transform: `scale(${u})`,
            transformOrigin: "top left",
          },
          children: [
            e.jsx(rc, {}),
            e.jsx(ac, {}),
            e.jsx(cc, {}),
            e.jsx(vc, {}),
            e.jsx(jc, {}),
            e.jsx(gc, {}),
            e.jsx(bc, {}),
            e.jsx(Pc, {}),
          ],
        }),
      });
}
Ja.createRoot(document.getElementById("root")).render(e.jsx(Wc, {}));
